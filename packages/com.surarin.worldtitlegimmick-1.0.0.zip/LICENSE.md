# World Title Gimmick（ワールド内称号ギミック）利用規約 / License

Copyright (c) 2026 Surarin

日本語の文と英語の文で意味が食い違うときは、日本語の文を優先します。
If the Japanese and English texts differ, the Japanese text takes precedence.

---

## 日本語

この規約は、World Title Gimmick（以下「本パッケージ」）に含まれるスクリプト・アセット・説明書のすべてに適用されます。本パッケージを入手した方は、価格（無料の版・支援用の版）にかかわらず、同じ規約で使えます。

### してよいこと

- 自分の VRChat ワールド（公開・非公開を問いません）に組み込んで使うこと。
- 本パッケージを改変して使うこと。
- 有料・商用のワールド（イベントの会場・企業の案件・依頼を受けて作るワールドなど）で使うこと。
- 本パッケージを組み込んだワールドを、VRChat にアップロードして公開すること。

### クレジットの表記

- 任意です。書かなくてもかまいません。書くときは「World Title Gimmick / Surarin」などと書いてください。

### してはいけないこと

- 本パッケージそのもの（改変したもの・一部を切り出したものを含む）を、アセットとして再配布・販売すること。
  - ワールドのプロジェクトやシーンを、アセットとして配布・販売するときに本パッケージを同梱することも含みます。そのときは、本パッケージを各自で入手してもらう形にしてください。
- 本パッケージを自分が作ったものだと偽ること。

### そのほか

- ワールドの作者が称号の表に書いた称号の語・説明・画像などは、その作者のものです。
- 本パッケージは現状のまま提供します。動作の保証はしません。本パッケージを使ったことで生じた損害について、作者は責任を負いません。
- PlayerData の保存は VRChat の機能です。VRChat の仕様の変更などで、保存した称号が読めなくなることがあります。
- 規約は予告なく変わることがあります。変わったあとは、新しい版を入手した時点から新しい規約が適用されます。

---

## English

This license applies to all scripts, assets, and documentation included in World Title Gimmick ("this package"). The same terms apply regardless of the price you paid (the free version or a support version).

### You may

- Use this package in your own VRChat worlds (public or private).
- Modify this package.
- Use this package in paid or commercial worlds (event venues, corporate projects, worlds made on commission, etc.).
- Upload and publish worlds that include this package on VRChat.

### Credit

- Optional. You do not have to credit. If you do, please write something like "World Title Gimmick / Surarin".

### You may not

- Redistribute or sell this package itself as an asset, including modified versions or parts of it.
  - This includes bundling this package in a world project or scene that you distribute or sell as an asset. In that case, ask your users to obtain this package themselves.
- Claim this package as your own work.

### Other terms

- Title words, descriptions, images, etc. that a world creator writes in their title table belong to that creator.
- This package is provided "as is", without warranty of any kind. The author is not liable for any damage caused by using this package.
- Saving uses VRChat's PlayerData feature. Saved titles may become unreadable due to changes in VRChat.
- These terms may change without notice. New terms apply from the time you obtain a new version.
