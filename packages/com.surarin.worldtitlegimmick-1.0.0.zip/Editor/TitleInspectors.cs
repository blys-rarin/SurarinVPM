using System.Collections.Generic;
using System.Linq;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEngine;

namespace WorldTitleGimmick.EditorTools
{
    // 部品のインスペクター（仕様書 7章・14章）。称号はキーの文字ではなく、表の一覧から名前で選ぶ。
    // 数で持つ設定（エリアのきっかけなど）は選択肢で選ぶ。
    public static class TitleGUI
    {
        private static bool openUdon;

        // 部品の上の共通の見出し（2026-10-28、ユーザー指定「インスペクターを日本語化」）。
        // UdonSharp の DrawDefaultUdonSharpBehaviourHeader は文言が英語に固定なので、同じ処理を日本語で描く。
        // ふつうは触らない所（プログラム・同期・道具）は「Udon の設定」に折りたたむ。
        // showInteract：押すときの設定（距離・押してみる）を出すか。ownText：部品が自分の欄で押すときの文字を決める（上の文字の欄は出さない）。
        // matchProp：「ほかの押せる部品に合わせる」の欄（ない部品は null）。matched：合わせている先（なければ null）。
        public static bool Header(Object target, bool showInteract, bool ownText, SerializedProperty matchProp = null, VRC.Udon.UdonBehaviour matched = null)
        {
            var proxy = target as UdonSharpBehaviour;
            VRC.Udon.UdonBehaviour backing = proxy != null ? UdonSharpEditorUtility.GetBackingUdonBehaviour(proxy) : null;
            if (backing == null || !(backing.programSource is UdonSharpProgramAsset program))
                return UdonSharpGUI.DrawDefaultUdonSharpBehaviourHeader(target);

            if (showInteract && program.hasInteractEvent) InteractSettings(backing, ownText, matchProp, matched);
            openUdon = EditorGUILayout.Foldout(openUdon, "Udon の設定（ふつうは触らない：プログラム・同期・道具）", true);
            if (openUdon)
            {
                EditorGUI.indentLevel++;
                bool stop = UdonSharpGUI.DrawProgramSource(target);
                if (!stop)
                {
                    UdonSharpGUI.DrawSyncSettings(target);
                    UdonSharpGUI.DrawUtilities(target);
                }
                EditorGUI.indentLevel--;
                if (stop) return true;
            }
            UdonSharpGUI.DrawCompileErrorTextArea();
            UdonSharpGUI.DrawUILine();
            return false;
        }

        // UdonSharpGUI.DrawInteractSettings と同じ処理（文言だけ日本語）。
        private static void InteractSettings(VRC.Udon.UdonBehaviour b, bool ownText, SerializedProperty matchProp, VRC.Udon.UdonBehaviour matched)
        {
            // 「ほかの押せる部品に合わせる」（2026-10-29）。合わせている間は、距離と文字の欄を触れなくする。
            bool locked = false;
            if (matchProp != null)
            {
                EditorGUILayout.PropertyField(matchProp, new GUIContent("ほかの押せる部品に合わせる",
                    "オンなら、同じ物にほかの押せる Udon（元からあるスイッチなど）があるとき、押せる距離と出る文字をそちらに合わせる。Play・ビルドの前にも写す\n［Match Other Interact / matchOtherInteract］"));
                matchProp.serializedObject.ApplyModifiedProperties();
                if (matchProp.boolValue && matched != null)
                {
                    locked = true;
                    string source = matched.programSource != null ? matched.programSource.name : "Udon";
                    EditorGUILayout.HelpBox("同じ物の「" + source + "」に合わせています（距離 " + matched.proximity.ToString("0.##") + " m・文字「" + matched.interactText + "」）。変えるときは、そちらの部品で変えてください。", MessageType.None);
                }
                else if (matchProp.boolValue)
                    EditorGUILayout.LabelField(" ", "同じ物にほかの押せる部品はありません（この部品の設定を使います）", EditorStyles.miniLabel);
            }
            EditorGUI.BeginDisabledGroup(locked);
            EditorGUI.BeginChangeCheck();
            string text = b.interactText;
            if (!ownText) text = EditorGUILayout.TextField(new GUIContent("物に向けたときに出る文字", "VRChat で物に向けたときに出る文字\n［Interaction Text］"), text);
            float proximity = EditorGUILayout.Slider(new GUIContent("押せる距離", "どこまで離れて押せるか（VRChat の Interact の距離）\n［Proximity］"), b.proximity, 0f, 100f);
            bool changed = EditorGUI.EndChangeCheck();
            EditorGUI.EndDisabledGroup();
            if (changed)
            {
                Undo.RecordObject(b, "押すときの設定を変える");
                b.interactText = text;
                b.proximity = proximity;
                if (PrefabUtility.IsPartOfPrefabInstance(b)) PrefabUtility.RecordPrefabInstancePropertyModifications(b);
            }
            using (new EditorGUI.DisabledScope(!EditorApplication.isPlaying))
                if (GUILayout.Button(new GUIContent("押してみる（Play 中だけ）", "［Trigger Interact］")))
                {
                    UdonSharpBehaviour proxy = UdonSharpEditorUtility.GetProxyBehaviour(b);
                    UdonSharpEditorUtility.CopyProxyToUdon(proxy, ProxySerializationPolicy.All);
                    b.SendCustomEvent("_interact");
                    UdonSharpEditorUtility.CopyUdonToProxy(proxy, ProxySerializationPolicy.All);
                }
        }

        public static TitleDatabase SceneDatabase()
        {
            TitleManager manager = Object.FindObjectOfType<TitleManager>(true);
            return TitleBake.DatabaseOf(manager);
        }

        // 称号を選ぶ欄。connectorsOnly なら接続語だけ、titlesOnly なら接続語を除く（通常と記録）。
        public static string KeyField(string label, string current, TitleDatabase db, bool connectorsOnly = false, bool titlesOnly = false)
        {
            if (db == null) return EditorGUILayout.TextField(label, current);
            var rows = db.rows.Where(r => r != null && !string.IsNullOrEmpty(r.key)
                && (!connectorsOnly || r.kind == TitleDatabase.Kind.接続語)
                && (!titlesOnly || r.kind != TitleDatabase.Kind.接続語)).ToList();
            var names = new List<string> { "（なし）" };
            names.AddRange(rows.Select(r => (string.IsNullOrEmpty(r.word) ? "（語なし）" : r.word) + "　[" + r.key + "]" + (r.state == TitleDatabase.State.廃止 ? "（廃止）" : "")));
            int index = rows.FindIndex(r => r.key == current) + 1;
            if (index == 0 && !string.IsNullOrEmpty(current)) { names.Add("？ " + current + "（表にない）"); index = names.Count - 1; }
            int next = EditorGUILayout.Popup(label, index, names.ToArray());
            if (next == index) return current;
            return next == 0 ? "" : next - 1 < rows.Count ? rows[next - 1].key : current;
        }

        public static void KeyArray(SerializedProperty array, TitleDatabase db, bool titlesOnly, string label = null)
        {
            EditorGUILayout.LabelField((label ?? array.displayName) + "（" + array.arraySize + "）", EditorStyles.boldLabel);
            EditorGUI.indentLevel++;
            for (int i = 0; i < array.arraySize; i++)
            {
                EditorGUILayout.BeginHorizontal();
                SerializedProperty element = array.GetArrayElementAtIndex(i);
                element.stringValue = KeyField("　" + (i + 1), element.stringValue, db, false, titlesOnly);
                if (GUILayout.Button("－", GUILayout.Width(24))) { array.DeleteArrayElementAtIndex(i); EditorGUILayout.EndHorizontal(); break; }
                EditorGUILayout.EndHorizontal();
            }
            if (GUILayout.Button("＋ 称号を足す")) { array.arraySize++; array.GetArrayElementAtIndex(array.arraySize - 1).stringValue = ""; }
            EditorGUI.indentLevel--;
        }

        // 記録の称号を選ぶ欄（2026-10-28）。
        public static string RecordField(string label, string current, TitleDatabase db)
        {
            if (db == null) return EditorGUILayout.TextField(label, current);
            var rows = db.rows.Where(r => r != null && !string.IsNullOrEmpty(r.key) && r.kind == TitleDatabase.Kind.記録).ToList();
            var names = new List<string> { "（見ない）" };
            names.AddRange(rows.Select(r => (string.IsNullOrEmpty(r.word) ? "（語なし）" : r.word) + "　[" + r.key + "]"));
            int index = rows.FindIndex(r => r.key == current) + 1;
            if (index == 0 && !string.IsNullOrEmpty(current)) { names.Add("？ " + current + "（表にない）"); index = names.Count - 1; }
            int next = EditorGUILayout.Popup(label, index, names.ToArray());
            if (next == index) return current;
            return next == 0 ? "" : next - 1 < rows.Count ? rows[next - 1].key : current;
        }

        public static void StatField(SerializedProperty property, string label = null)
        {
            int index = TitleBake.StatIndex(property.stringValue) + 1;
            var labels = new List<string> { "（見ない）" };
            for (int i = 0; i < TitleBake.StatNames.Length; i++) labels.Add(TitleBake.StatLabels[i] + "　[" + TitleBake.StatNames[i] + "]");
            int next = EditorGUILayout.Popup(label ?? property.displayName, index, labels.ToArray());
            if (next != index) property.stringValue = next == 0 ? "" : TitleBake.StatNames[next - 1];
        }
    }

    // 部品に共通のインスペクター（2026-10-28、ユーザー指摘「パラメータが多すぎて何をいじればいいかが分かりづらい」）。
    // いちばん上に「今の設定で何が起きるか」の文、次によく使う欄だけ、残りは「詳しい設定」にたたむ。
    public abstract class TitleComponentEditor : Editor
    {
        // 称号のキーの配列（通常の称号だけ）。
        private static readonly HashSet<string> KeyArrays = new HashSet<string> { "requiredKeys", "forbiddenKeys", "equippedKeys", "titleKeys" };
        // 接続語も選べるキーの配列（渡す・外す・並び順・枠の位置）。解禁で使う接続語を部品で解禁できるようにする。
        private static readonly HashSet<string> AnyKeyArrays = new HashSet<string> { "grantKeys", "stepKeys", "revokeKeys", "sequenceKeys", "slotCheckKeys", "watchKeys", "revealKeys" };
        private static readonly HashSet<string> StatFields = new HashSet<string> { "statName" };
        private static readonly Dictionary<string, bool> openAdvanced = new Dictionary<string, bool>();
        private const string OtherGroup = "そのほか";

        // 称号を渡す部品（エリア・アクション・条件まとめ）に共通の「詳しい設定」の分け方。
        protected static readonly string[][] TriggerGroups =
        {
            new[] { "ヒント（持っていない称号を明かす）", "revealKeys", "revealWhat", "revealPopup" },
            new[] { "前提の条件（このときだけ動く）", "requiredKeys", "forbiddenKeys", "equippedKeys", "heldObjects", "minPlayers", "maxPlayers", "period", "device" },
            new[] { "称号のほかに起こすこと", "revokeKeys", "counterKey", "counterAdd", "enableObjects", "disableObjects" },
            new[] { "イベントを送る（Udon Graph など）", "eventTargets", "eventNames" },
            new[] { "知らせ・音", "showPopup", "sound" },
            new[] { "くり返し", "once", "cooldownSeconds" },
        };

        // どの部品にもある、ふつうは触らない欄。
        protected static readonly string[] LinkGroup = { "つなぎ（ふつうは空のまま。自動で入る）", "manager" };

        protected TitleDatabase db;

        protected virtual Dictionary<string, string[]> Choices => new Dictionary<string, string[]>
        {
            { "device", new[] { "すべて", "VR だけ", "デスクトップだけ" } },
            { "revealWhat", new[] { "名前と取得条件", "名前だけ", "取得条件だけ" } },
        };

        // よく使う欄（この順に出す）。ほかは「詳しい設定」へ。
        protected abstract string[] BasicFields { get; }

        // 「詳しい設定」の中の分け方：各行の先頭がジャンルの名前、続きが欄の名前。どこにもない欄は「そのほか」に出す。
        protected virtual string[][] Groups => new[] { LinkGroup };

        // 欄の日本語の名前（なければ欄の名前のまま）。英語の名前はツールチップに出す。
        protected virtual Dictionary<string, string> Labels => new Dictionary<string, string>
        {
            { "manager", "称号マネージャー（空なら自動）" },
            { "grantKeys", "渡す称号" },
            { "revokeKeys", "外す称号" },
            { "once", "一度だけ" },
            { "revealKeys", "明かす称号（ヒント）" },
            { "revealWhat", "明かすもの" },
            { "revealPopup", "明かしたら知らせを出す" },
            { "requiredKeys", "この称号を全部持っている人だけ" },
            { "forbiddenKeys", "この称号を持っている人には渡さない" },
            { "equippedKeys", "この称号を装備している人だけ" },
            { "heldObjects", "この物を手に持っている人だけ" },
            { "minPlayers", "人数がこれ以上のとき（0 なら見ない）" },
            { "maxPlayers", "人数がこれ以下のとき（0 なら見ない）" },
            { "period", "期間（例 1025-1031。空なら見ない）" },
            { "device", "端末" },
            { "counterKey", "足すカウンターの名前（空なら足さない）" },
            { "counterAdd", "カウンターに足す数" },
            { "eventTargets", "イベントの送り先" },
            { "eventNames", "送るイベントの名前（送り先と同じ並び）" },
            { "enableObjects", "本人の画面で出す物" },
            { "disableObjects", "本人の画面で消す物" },
            { "showPopup", "獲得の知らせを出す" },
            { "sound", "効果音（空なら知らせの音）" },
            { "cooldownSeconds", "次に反応するまでの秒数" },
            { "interactText", "物に向けたときに出る文字（Interact）" },
            { "matchOtherInteract", "ほかの押せる部品に合わせる" },
        };

        // 今の設定で何が起きるか（インスペクターのいちばん上に出す）。null なら出さない。
        protected virtual string Summary() { return null; }

        // 表示しない欄（ほかの欄の選択で使わないもの）。
        protected virtual bool Hidden(string name) { return false; }

        // どの部品でも、明かす称号がなければ「明かすもの」などを出さない。
        private bool HiddenAll(string name)
        {
            if (name != "revealWhat" && name != "revealPopup") return Hidden(name);
            SerializedProperty keys = serializedObject.FindProperty("revealKeys");
            return keys == null || keys.arraySize == 0 || Hidden(name);
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            // 「ほかの押せる部品に合わせる」がオンなら、開くたびに写す（変わったときだけ書く）。
            SerializedProperty matchProp = serializedObject.FindProperty("matchOtherInteract");
            matchedOther = matchProp != null && matchProp.boolValue && ShowInteract ? TitleInteractMatch.Apply(target as UdonSharpBehaviour, true) : null;
            if (TitleGUI.Header(target, ShowInteract, OwnInteractText, matchProp, matchedOther)) return;
            db = TitleGUI.SceneDatabase();
            serializedObject.Update();
            string summary = Summary();
            if (!string.IsNullOrEmpty(summary)) EditorGUILayout.HelpBox(summary, MessageType.None);
            if (db == null && NeedsDatabase) EditorGUILayout.HelpBox("シーンに TitleManager がないか、称号の表が設定されていません。称号はキーを文字で入れてください。", MessageType.Info);
            var basic = new HashSet<string>(BasicFields);
            foreach (string name in BasicFields)
            {
                SerializedProperty p = serializedObject.FindProperty(name);
                if (p != null && !HiddenAll(name)) DrawField(p);
            }

            // 「詳しい設定」に出す欄を、ジャンルごとに分ける（ジャンルの順は Groups の順。どこにもない欄は「そのほか」）。
            var grouped = new Dictionary<string, List<string>>();
            var order = new List<string>();
            var groupOf = new Dictionary<string, string>();
            foreach (string[] g in Groups) for (int i = 1; i < g.Length; i++) if (!groupOf.ContainsKey(g[i])) groupOf[g[i]] = g[0];
            SerializedProperty it = serializedObject.GetIterator();
            bool enter = true;
            while (it.NextVisible(enter))
            {
                enter = false;
                if (it.name == "m_Script" || it.name == "matchOtherInteract" || basic.Contains(it.name) || HiddenAll(it.name)) continue;
                if (!groupOf.TryGetValue(it.name, out string g)) g = OtherGroup;
                if (!grouped.ContainsKey(g)) grouped[g] = new List<string>();
                grouped[g].Add(it.name);
            }
            foreach (string[] g in Groups) if (grouped.ContainsKey(g[0]) && !order.Contains(g[0])) order.Add(g[0]);
            if (grouped.ContainsKey(OtherGroup)) order.Add(OtherGroup);
            if (order.Count == 0) { serializedObject.ApplyModifiedProperties(); return; }

            string key = target.GetType().Name;
            openAdvanced.TryGetValue(key, out bool open);
            EditorGUILayout.Space(2);
            open = EditorGUILayout.Foldout(open, "詳しい設定（" + string.Join("・", order.Select(o => ShortName(o))) + "）", true);
            openAdvanced[key] = open;
            if (open)
            {
                EditorGUI.indentLevel++;
                foreach (string g in order)
                {
                    // 欄を入れた（空でない）ジャンルには「（設定あり）」を付けて、閉じていても分かるようにする。
                    // 中の欄の順は Groups に書いた順（「そのほか」はスクリプトの順）。
                    List<string> fields = grouped[g];
                    string[] def = Groups.FirstOrDefault(x => x[0] == g);
                    if (def != null) fields = def.Skip(1).Where(fields.Contains).ToList();
                    bool used = fields.Any(f => f != "manager" && IsSet(serializedObject.FindProperty(f)));
                    string groupKey = key + "/" + g;
                    openAdvanced.TryGetValue(groupKey, out bool gOpen);
                    gOpen = EditorGUILayout.Foldout(gOpen, g + (used ? "　（設定あり）" : ""), true, used ? BoldFoldout : EditorStyles.foldout);
                    openAdvanced[groupKey] = gOpen;
                    if (!gOpen) continue;
                    EditorGUI.indentLevel++;
                    foreach (string f in fields) DrawField(serializedObject.FindProperty(f));
                    EditorGUI.indentLevel--;
                }
                EditorGUI.indentLevel--;
            }
            serializedObject.ApplyModifiedProperties();
        }

        // 称号の表を使う部品か（使わない部品では「表がない」の知らせを出さない）。
        protected virtual bool NeedsDatabase => true;

        // 上の見出しに押すときの設定（距離など）を出すか（例：アクションは「押す」のときだけ）。
        protected virtual bool ShowInteract => true;
        // 押すときの文字を部品の欄（interactText）で決めるか（決めるなら上の文字の欄は出さない。Start で上書きされるため）。
        protected virtual bool OwnInteractText => serializedObject.FindProperty("interactText") != null;

        private static GUIStyle boldFoldout;
        private static GUIStyle BoldFoldout => boldFoldout ?? (boldFoldout = new GUIStyle(EditorStyles.foldout) { fontStyle = FontStyle.Bold });

        // 「詳しい設定」の見出しに並べる短い名前（括弧の前まで）。
        private static string ShortName(string group)
        {
            int at = group.IndexOf('（');
            return at > 0 ? group.Substring(0, at) : group;
        }

        // 欄に何か入っているか（配列は1つ以上・文字は空でない・物は入っている）。数やオン・オフは初期値が欄ごとに違うので見ない。
        private static bool IsSet(SerializedProperty p)
        {
            if (p == null) return false;
            if (p.isArray && p.propertyType != SerializedPropertyType.String) return p.arraySize > 0;
            if (p.propertyType == SerializedPropertyType.String) return !string.IsNullOrEmpty(p.stringValue);
            if (p.propertyType == SerializedPropertyType.ObjectReference) return p.objectReferenceValue != null;
            return false;
        }

        // 合わせている先（上の見出しで決める）。あれば「物に向けたときに出る文字」を触れなくする。
        private VRC.Udon.UdonBehaviour matchedOther;

        private void DrawField(SerializedProperty p)
        {
            if (p == null) return;
            if (p.name == "interactText" && matchedOther != null)
            {
                using (new EditorGUI.DisabledScope(true)) DrawFieldInner(p);
                return;
            }
            DrawFieldInner(p);
        }

        private void DrawFieldInner(SerializedProperty p)
        {
            Labels.TryGetValue(p.name, out string label);
            if (KeyArrays.Contains(p.name) && p.isArray) { TitleGUI.KeyArray(p, db, true, label); return; }
            if (AnyKeyArrays.Contains(p.name) && p.isArray) { TitleGUI.KeyArray(p, db, false, label); return; }
            if (StatFields.Contains(p.name)) { TitleGUI.StatField(p, label); return; }
            // 記録の称号のキー（ゲート）：記録の行だけから選ぶ。
            if (p.name == "recordKey" && p.propertyType == SerializedPropertyType.String) { p.stringValue = TitleGUI.RecordField(label ?? "記録の称号", p.stringValue, db); return; }
            // ツールチップの最後に英語の名前（説明書・コードでの名前）を出す。
            string tip = (string.IsNullOrEmpty(p.tooltip) ? "" : p.tooltip + "\n") + "［" + p.displayName + " / " + p.name + "］";
            var content = new GUIContent(label ?? p.displayName, tip);
            if (Choices.TryGetValue(p.name, out string[] labels) && p.propertyType == SerializedPropertyType.Integer)
            {
                p.intValue = EditorGUILayout.Popup(content, Mathf.Clamp(p.intValue, 0, labels.Length - 1), labels);
                return;
            }
            EditorGUILayout.PropertyField(p, content, true);
        }

        protected int Int(string name) { SerializedProperty p = serializedObject.FindProperty(name); return p == null ? 0 : p.intValue; }
        protected float Float(string name) { SerializedProperty p = serializedObject.FindProperty(name); return p == null ? 0f : p.floatValue; }
        protected bool Bool(string name) { SerializedProperty p = serializedObject.FindProperty(name); return p != null && p.boolValue; }
        protected string Str(string name) { SerializedProperty p = serializedObject.FindProperty(name); return p == null ? "" : p.stringValue; }

        // 称号のキーの配列を「『語』『語』」の文字に。空なら「（称号を選んでください）」。
        protected string Titles(string arrayName)
        {
            SerializedProperty p = serializedObject.FindProperty(arrayName);
            var words = new List<string>();
            if (p != null)
                for (int i = 0; i < p.arraySize; i++)
                {
                    string k = p.GetArrayElementAtIndex(i).stringValue;
                    if (string.IsNullOrEmpty(k)) continue;
                    TitleDatabase.Row row = db != null ? db.Find(k) : null;
                    words.Add("『" + (row != null && !string.IsNullOrEmpty(row.word) ? row.word : k) + "』");
                }
            return words.Count == 0 ? "（渡す称号を選んでください）" : string.Join("", words);
        }

        protected string OnceText() { return Bool("once") ? "（一度だけ）" : "（何度でも）"; }

        // 結果の文：「『A』を渡し、『B』の名前と取得条件を明かします」。渡す称号がなく明かす称号だけなら、明かすほうだけ。
        // 外す称号（2026-10-29）があれば、「『C』を外し、」を前に付ける。
        protected string Results()
        {
            bool anyReveal = AnyKey("revealKeys");
            bool anyGrant = AnyKey("grantKeys");
            string revoke = AnyKey("revokeKeys") ? Titles("revokeKeys") + "を外し" : "";
            if (!anyReveal && !anyGrant && revoke.Length > 0) return revoke.Substring(0, revoke.Length - 1) + "します";
            string head = revoke.Length > 0 ? revoke + "、" : "";
            if (!anyReveal) return head + Titles("grantKeys") + "を渡します";
            int what = Int("revealWhat");
            string revealText = Titles("revealKeys") + "の" + (what == 1 ? "名前" : what == 2 ? "取得条件" : "名前と取得条件") + "を明かします";
            return head + (anyGrant ? Titles("grantKeys") + "を渡し、" + revealText : revealText);
        }

        private bool AnyKey(string name)
        {
            SerializedProperty keys = serializedObject.FindProperty(name);
            if (keys != null) for (int i = 0; i < keys.arraySize; i++) if (!string.IsNullOrEmpty(keys.GetArrayElementAtIndex(i).stringValue)) return true;
            return false;
        }
    }

    [CustomEditor(typeof(TitleArea))]
    public class TitleAreaEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "grantKeys", "who", "objects", "layers", "trigger", "seconds", "count", "crowdCount", "once" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["who"] = "何が入ったら";
                map["objects"] = "入る物";
                map["layers"] = "入る物のレイヤー";
                map["trigger"] = "きっかけ";
                map["seconds"] = "秒数";
                map["count"] = "回数";
                map["crowdCount"] = "人数";
                map["receiver"] = "誰に渡すか";
                map["objectCount"] = "同時に入る物の数";
                map["saveKey"] = "保存の名前（合計の秒・回数。空なら保存しない）";
                return map;
            }
        }

        protected override string[][] Groups => new[] { new[] { "物が入ったとき", "receiver", "objectCount" }, new[] { "保存", "saveKey" } }
            .Concat(TriggerGroups).Append(LinkGroup).ToArray();

        protected override Dictionary<string, string[]> Choices
        {
            get
            {
                var map = base.Choices;
                map["who"] = new[] { "本人（プレイヤー）", "指定した物", "指定したレイヤーの物" };
                map["receiver"] = new[] { "その物を持っている人", "最後に持った人（持ち主）", "エリアの中にいる人" };
                map["trigger"] = new[] { "入ったら", "出たら", "続けてN秒いたら", "合計N秒いたら（保存）", "N回入ったら", "中の人数がN人以上（本人のとき）" };
                return map;
            }
        }

        protected override string Summary()
        {
            string who = Int("who") == TitleArea.WhoPlayer ? "プレイヤーがこのエリアに" : "指定した物がこのエリアに";
            int trigger = Int("trigger");
            string when = trigger == TitleArea.OnExit ? "出たら"
                : trigger == TitleArea.OnStay ? "続けて" + Float("seconds") + "秒いたら"
                : trigger == TitleArea.OnStayTotal ? "合計" + Float("seconds") + "秒いたら"
                : trigger == TitleArea.OnEnterCount ? Int("count") + "回入ったら"
                : trigger == TitleArea.OnCrowd ? "入り、中に" + Int("crowdCount") + "人以上いたら（中にいる人それぞれに）" : "入ったら";
            string to = Int("who") != TitleArea.WhoPlayer && Int("receiver") == TitleArea.ReceiverInside ? "（エリアの中にいる人に）" : "";
            return who + when + "、" + to + Results() + OnceText() + "。\nこの物には Is Trigger のコライダーが要ります。";
        }

        protected override bool Hidden(string name)
        {
            int who = Int("who");
            int trigger = Int("trigger");
            if (name == "objects") return who != TitleArea.WhoObjects;
            if (name == "layers") return who != TitleArea.WhoLayer;
            if (name == "receiver" || name == "objectCount") return who == TitleArea.WhoPlayer;
            if (name == "seconds") return trigger != TitleArea.OnStay && trigger != TitleArea.OnStayTotal;
            if (name == "count") return trigger != TitleArea.OnEnterCount;
            if (name == "crowdCount") return trigger != TitleArea.OnCrowd;
            if (name == "saveKey") return trigger != TitleArea.OnStayTotal && trigger != TitleArea.OnEnterCount;
            return false;
        }
    }

    [CustomEditor(typeof(TitleAction))]
    public class TitleActionEditor : TitleComponentEditor
    {
        protected override bool ShowInteract => Int("action") == TitleAction.ActInteract;

        private static readonly string[] ActionNames = { "掴む", "離す", "使う（トリガー）", "押す（Interact）", "持ったままN秒", "投げる", "持ったままN m動く", "ほかの人から受け取る（手渡し）", "ほかの物に当てる" };

        protected override string[] BasicFields => new[] { "grantKeys", "revealKeys", "revealWhat", "action", "requiredCount", "seconds", "throwSpeed", "meters", "hitObjects", "hitLayers", "hitSeconds", "once" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["action"] = "行動";
                map["requiredCount"] = "回数";
                map["seconds"] = "秒数";
                map["throwSpeed"] = "投げる速さ（m/s）";
                map["meters"] = "距離（m）";
                map["hitObjects"] = "当てる物";
                map["hitLayers"] = "当てるレイヤー";
                map["hitSeconds"] = "投げてから待つ秒数";
                map["steps"] = "段の回数";
                map["stepKeys"] = "段で渡す称号";
                map["saveKey"] = "回数を保存する名前（空なら保存しない）";
                return map;
            }
        }

        protected override string[][] Groups => new[] { new[] { "段（N回で称号A、M回で称号B）", "steps", "stepKeys" }, new[] { "回数の保存", "saveKey" }, new[] { "押す（Interact）", "interactText" } }
            .Concat(TriggerGroups).Append(LinkGroup).ToArray();

        protected override Dictionary<string, string[]> Choices
        {
            get
            {
                var map = base.Choices;
                map["action"] = ActionNames;
                return map;
            }
        }

        protected override string Summary()
        {
            int action = Int("action");
            string what = action == TitleAction.ActGrab ? "この物を掴む"
                : action == TitleAction.ActDrop ? "この物を離す"
                : action == TitleAction.ActUse ? "この物を持ってトリガーを引く"
                : action == TitleAction.ActInteract ? "この物を押す（Interact）"
                : action == TitleAction.ActHoldSeconds ? "この物を" + Float("seconds") + "秒持ち続ける"
                : action == TitleAction.ActThrow ? "この物を" + Float("throwSpeed") + " m/s 以上で投げる"
                : action == TitleAction.ActReceive ? "この物をほかの人から手渡しで受け取る（ほかの人の手が近くにあるときに掴む）"
                : action == TitleAction.ActHit ? "この物を持ったまま、または投げて、指定した物・レイヤーに当てる"
                : "この物を持ったまま" + Float("meters") + " m 動く";
            int count = Mathf.Max(1, Int("requiredCount"));
            string times = count > 1 ? "のを" + count + "回したら" : "と";
            string need = action == TitleAction.ActInteract ? "\nこの物にはコライダーが要ります。" : "\nこの物には VRC Pickup と Rigidbody が要ります。";
            return what + times + "、" + Results() + OnceText() + "。" + need;
        }

        protected override bool Hidden(string name)
        {
            int action = Int("action");
            if (name == "seconds") return action != TitleAction.ActHoldSeconds;
            if (name == "throwSpeed") return action != TitleAction.ActThrow;
            if (name == "meters") return action != TitleAction.ActCarryMeters;
            if (name == "hitObjects" || name == "hitLayers" || name == "hitSeconds") return action != TitleAction.ActHit;
            if (name == "interactText") return action != TitleAction.ActInteract;
            return false;
        }
    }

    [CustomEditor(typeof(TitleGate))]
    public class TitleGateEditor : TitleComponentEditor
    {
        // 反転は「満たしたら○○」の欄すべての向きを変えるので、よく使う欄に出す（2026-10-29、ユーザー指定）。
        protected override string[] BasicFields => new[] { "titleKeys", "mode", "matchAll", "invert", "renderers", "colliders", "objects", "objectsWhenNot" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["titleKeys"] = "条件の称号";
                map["mode"] = "条件";
                map["matchAll"] = "全部そろったら（オフ＝どれか1つ）";
                map["renderers"] = "満たしたら見える";
                map["colliders"] = "満たしたら当たり判定あり";
                map["objects"] = "満たしたら出す物";
                map["objectsWhenNot"] = "満たすまで出す物（壁など）";
                map["behaviours"] = "満たしたら有効にするコンポーネント";
                map["behavioursWhenNot"] = "満たしたら無効にするコンポーネント";
                map["pickupObjects"] = "満たしたら掴める物（Pickup）";
                map["interactTargets"] = "満たしたら押せる Udon（Interact）";
                map["requiredCount"] = "このうち何個でよいか（0＝全部／どれか で決める）";
                map["invert"] = "反転（満たさない人のほうで切り替える）";
                map["sequenceKeys"] = "肩書きにこの順で並んでいる";
                map["sequenceContiguous"] = "間にほかの語を挟まない";
                map["slotCheckSlots"] = "枠の番号（1〜10）";
                map["slotCheckKeys"] = "その枠に入っている語";
                map["minOwned"] = "持っている称号の数がこれ以上（0 なら見ない）";
                map["statName"] = "行動の値";
                map["statMin"] = "行動の値がこれ以上";
                map["recordKey"] = "記録の称号";
                map["recordMin"] = "記録がこの値に届いている";
                map["metEvent"] = "満たしたときに送るイベント";
                map["unmetEvent"] = "満たさなくなったときに送るイベント";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "条件の数", "requiredCount" },
            new[] { "肩書きの並び・枠", "sequenceKeys", "sequenceContiguous", "slotCheckSlots", "slotCheckKeys" },
            new[] { "称号の数・行動の値・記録", "minOwned", "statName", "statMin", "recordKey", "recordMin" },
            new[] { "切り替える物（コンポーネント・掴む・押す）", "behaviours", "behavioursWhenNot", "pickupObjects", "interactTargets" },
            new[] { "イベントを送る（Udon Graph など）", "eventTargets", "metEvent", "unmetEvent" },
            LinkGroup,
        };

        protected override Dictionary<string, string[]> Choices
        {
            get
            {
                var map = base.Choices;
                map["mode"] = new[] { "持っている", "装備している" };
                return map;
            }
        }

        protected override string Summary()
        {
            SerializedProperty keys = serializedObject.FindProperty("titleKeys");
            string titles = keys.arraySize == 0 ? "（条件の称号を選んでください）" : Titles("titleKeys").Replace("（渡す称号を選んでください）", "（条件の称号を選んでください）");
            string verb = Int("mode") == TitleGate.ModeEquipped ? "装備している" : "持っている";
            int need = Int("requiredCount");
            string how = need > 0 ? "のうち" + need + "つを" : keys.arraySize > 1 ? (Bool("matchAll") ? "を全部" : "のどれかを") : "を";
            string text = titles + how + verb + "人だけ、この物が切り替わります（その人の画面の中だけ）。";
            if (Bool("invert")) text += "\n「反転」がオンなので、条件を満たさない人のほうで切り替わります。";
            return text;
        }

        protected override bool Hidden(string name) { return name == "statMin" && string.IsNullOrEmpty(serializedObject.FindProperty("statName").stringValue); }
    }

    [CustomEditor(typeof(TitleCounter))]
    public class TitleCounterEditor : TitleComponentEditor
    {
        protected override bool ShowInteract => Bool("interactable");

        protected override string[] BasicFields => new[] { "counterKey", "steps", "stepKeys" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["counterKey"] = "カウンターの名前（英数字）";
                map["saved"] = "保存する（オフ＝入室のたびに 0 から）";
                map["steps"] = "回数（下の称号と同じ並び）";
                map["stepKeys"] = "その回数で渡す称号";
                map["addAmount"] = "1回に足す数";
                map["interactable"] = "押して（Interact）増やす";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "数え方", "addAmount", "saved" },
            new[] { "押して数える（Interact）", "interactable", "interactText" },
            LinkGroup,
        };

        protected override string Summary()
        {
            string name = Str("counterKey");
            SerializedProperty steps = serializedObject.FindProperty("steps");
            SerializedProperty keys = serializedObject.FindProperty("stepKeys");
            var parts = new List<string>();
            for (int i = 0; i < steps.arraySize && i < keys.arraySize; i++)
            {
                string k = keys.GetArrayElementAtIndex(i).stringValue;
                TitleDatabase.Row row = db != null ? db.Find(k) : null;
                parts.Add(steps.GetArrayElementAtIndex(i).intValue + "回で『" + (row != null ? row.word : k) + "』");
            }
            string head = Bool("interactable") ? "押すたびに" : "ほかの Udon から Add を呼ぶたびに";
            return head + "カウンター「" + (string.IsNullOrEmpty(name) ? "（名前を入れてください）" : name) + "」を" + Int("addAmount") + "足して保存します。"
                + (parts.Count > 0 ? "\n" + string.Join("、", parts) + "を渡します。" : "\n回数と称号を下で足してください。");
        }
    }

    [CustomEditor(typeof(TitleReset))]
    public class TitleResetEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "mode", "revokeKeys", "confirmSeconds" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["mode"] = "すること";
                map["revokeKeys"] = "外す称号";
                map["confirmSeconds"] = "確認の秒数（0＝1回で実行）";
                map["enableObjects"] = "やり直したあとに出す物";
                map["disableObjects"] = "やり直したあとに消す物";
                map["eventName"] = "送るイベントの名前";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "押す（Interact）", "interactText" },
            new[] { "やり直したあとに", "enableObjects", "disableObjects", "eventTargets", "eventName" },
            LinkGroup,
        };

        protected override Dictionary<string, string[]> Choices
        {
            get
            {
                var map = base.Choices;
                map["mode"] = new[] { "全部やり直す", "指定の称号を外す" };
                return map;
            }
        }

        protected override string Summary()
        {
            string what = Int("mode") == TitleReset.ModeAll ? "その人の称号・肩書き・カウンター・行動の値を全部消します" : Titles("revokeKeys").Replace("（渡す称号を選んでください）", "（外す称号を選んでください）") + "を外します";
            float confirm = Float("confirmSeconds");
            return (confirm > 0f ? confirm + "秒以内に2回押すと、" : "押すと、") + what + "（押した本人の分だけ）。";
        }

        protected override bool Hidden(string name) { return name == "revokeKeys" && Int("mode") != TitleReset.ModeKeys; }
    }

    [CustomEditor(typeof(TitlePerk))]
    public class TitlePerkEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "titleKeys", "mode", "matchAll", "changeSpeed", "walkSpeed", "runSpeed", "strafeSpeed", "changeJump", "jumpImpulse", "changeGravity", "gravityStrength", "objects" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["titleKeys"] = "条件の称号";
                map["mode"] = "条件";
                map["matchAll"] = "全部そろったら（オフ＝どれか1つ）";
                map["changeSpeed"] = "移動の速さを変える";
                map["walkSpeed"] = "歩く速さ（初期値 2）";
                map["runSpeed"] = "走る速さ（初期値 4）";
                map["strafeSpeed"] = "横歩きの速さ（初期値 2）";
                map["changeJump"] = "ジャンプ力を変える";
                map["jumpImpulse"] = "ジャンプ力（初期値 3）";
                map["changeGravity"] = "重力を変える";
                map["gravityStrength"] = "重力（1 が普通）";
                map["objects"] = "満たしたら出す物";
                map["metEvent"] = "満たしたときに送るイベント";
                map["unmetEvent"] = "満たさなくなったときに送るイベント";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "イベントを送る（Udon Graph など）", "eventTargets", "metEvent", "unmetEvent" },
            LinkGroup,
        };

        protected override Dictionary<string, string[]> Choices
        {
            get
            {
                var map = base.Choices;
                map["mode"] = new[] { "持っている", "装備している" };
                return map;
            }
        }

        protected override string Summary()
        {
            SerializedProperty keys = serializedObject.FindProperty("titleKeys");
            string titles = Titles("titleKeys").Replace("（渡す称号を選んでください）", "（条件の称号を選んでください）");
            string verb = Int("mode") == TitlePerk.ModeEquipped ? "装備している" : "持っている";
            string how = keys.arraySize > 1 ? (Bool("matchAll") ? "を全部" : "のどれかを") : "を";
            var effects = new List<string>();
            if (Bool("changeSpeed")) effects.Add("歩く速さ " + Float("walkSpeed") + "・走る速さ " + Float("runSpeed"));
            if (Bool("changeJump")) effects.Add("ジャンプ力 " + Float("jumpImpulse"));
            if (Bool("changeGravity")) effects.Add("重力 " + Float("gravityStrength"));
            if (serializedObject.FindProperty("objects").arraySize > 0) effects.Add("物を出す");
            string what = effects.Count == 0 ? "（効果を選んでください）" : string.Join("・", effects);
            return titles + how + verb + "人は、" + what + "になります（本人だけ）。\n満たさなくなったら元に戻します。";
        }

        protected override bool Hidden(string name)
        {
            if (name == "walkSpeed" || name == "runSpeed" || name == "strafeSpeed") return !Bool("changeSpeed");
            if (name == "jumpImpulse") return !Bool("changeJump");
            if (name == "gravityStrength") return !Bool("changeGravity");
            return false;
        }
    }

    [CustomEditor(typeof(TitleAllOf))]
    public class TitleAllOfEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "grantKeys", "parts", "saved", "saveKey" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["parts"] = "まとめる部品";
                map["saved"] = "これまでに全部（オフ＝この入室で全部）";
                map["saveKey"] = "保存の名前（英数字）";
                return map;
            }
        }

        protected override string[][] Groups => TriggerGroups.Append(LinkGroup).ToArray();

        protected override string Summary()
        {
            SerializedProperty parts = serializedObject.FindProperty("parts");
            var names = new List<string>();
            for (int i = 0; i < parts.arraySize; i++)
            {
                Object part = parts.GetArrayElementAtIndex(i).objectReferenceValue;
                if (part != null) names.Add("「" + part.name + "」");
            }
            string list = names.Count == 0 ? "（まとめる部品を入れてください）" : string.Join("", names);
            string when = Bool("saved") ? "これまでに（別の日でも）全部動いたら" : "この入室の間に全部動いたら";
            return list + "が" + when + "、" + Results() + OnceText() + "。\n部品はそれぞれ、自分の条件（エリアに入る・掴むなど）を満たしたときに「動いた」になります。";
        }

        protected override bool Hidden(string name) { return name == "saveKey" && !Bool("saved"); }
    }

    [CustomEditor(typeof(TitleRelay))]
    public class TitleRelayEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "watchKeys", "eventTargets", "grantedEvent", "revokedEvent", "equippedEvent", "unequippedEvent", "plateChangedEvent" };

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["watchKeys"] = "見る称号（空＝どれでも）";
                map["eventTargets"] = "送り先";
                map["grantedEvent"] = "もらったとき";
                map["revokedEvent"] = "外れたとき";
                map["equippedEvent"] = "装備したとき";
                map["unequippedEvent"] = "装備を外したとき";
                map["plateChangedEvent"] = "肩書きを変えたとき";
                map["keyVariable"] = "称号のキーを入れる送り先の変数（空なら入れない）";
                map["fireOnJoin"] = "入室したときにも送る（持っている・装備している称号の分）";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "送り方", "keyVariable", "fireOnJoin" },
            LinkGroup,
        };

        protected override string Summary()
        {
            SerializedProperty keys = serializedObject.FindProperty("watchKeys");
            string which = keys.arraySize == 0 ? "どの称号でも" : Titles("watchKeys");
            var events = new List<string>();
            void Add(string field, string label) { if (!string.IsNullOrEmpty(Str(field))) events.Add(label + "「" + Str(field) + "」"); }
            Add("grantedEvent", "もらったら");
            Add("revokedEvent", "外れたら");
            Add("equippedEvent", "装備したら");
            Add("unequippedEvent", "装備を外したら");
            Add("plateChangedEvent", "肩書きを変えたら");
            int targets = serializedObject.FindProperty("eventTargets").arraySize;
            if (events.Count == 0) return "送るイベントの名前を入れてください。";
            return which + "について、" + string.Join("、", events) + "を送り先（" + targets + "）に送ります（本人の端末だけ）。"
                + (string.IsNullOrEmpty(Str("keyVariable")) ? "" : "\n送る前に、送り先の変数「" + Str("keyVariable") + "」に称号のキーを入れます。");
        }
    }

    // ここから下は、称号を選ぶ欄のない部品（2026-10-28、ユーザー指定「インスペクターで日本語化できるところは日本語化」）。
    // 欄を日本語の名前にして、ジャンルに分ける。

    [CustomEditor(typeof(TitleSeat))]
    public class TitleSeatEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new string[0];
        protected override bool NeedsDatabase => false;
        protected override string Summary() { return "この席（VRC Station と同じ物）に本人が座った回数（sits）と座っていた時間（sit_min）を数えます。\n設定する欄はありません。"; }
    }

    [CustomEditor(typeof(TitleTouch))]
    public class TitleTouchEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "part", "cooldownSeconds" };
        protected override bool NeedsDatabase => false;

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["part"] = "付いていく所";
                map["cooldownSeconds"] = "同じ所で次に数えるまでの秒数";
                return map;
            }
        }

        protected override Dictionary<string, string[]> Choices
        {
            get
            {
                var map = base.Choices;
                map["part"] = new[] { "頭", "左手", "右手" };
                return map;
            }
        }

        protected override string Summary() { return "本人の" + (Int("part") == TitleTouch.PartHead ? "頭" : Int("part") == TitleTouch.PartLeftHand ? "左手" : "右手") + "に付いていき、ほかの人に撫でられた・撫でた・ハイタッチを数えます。\n撫でる・ハイタッチの条件を使っていなければ、始めに消えます。"; }
    }

    [CustomEditor(typeof(TitleNameplates))]
    public class TitleNameplatesEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "height", "textColor", "backColor", "hideMeters", "maxShown" };
        protected override bool NeedsDatabase => false;

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["height"] = "頭からの高さ（m）";
                map["textColor"] = "文字の色";
                map["backColor"] = "背景の色（透明なら A を 0）";
                map["oneLineChars"] = "1行に収まる文字数の目安";
                map["normalSize"] = "文字の大きさ";
                map["smallSize"] = "長い肩書きの文字の大きさ";
                map["hideMeters"] = "これより遠い人には出さない（m。0＝消さない）";
                map["maxShown"] = "一度に出す数の上限（0＝板の数まで）";
                map["refreshSeconds"] = "誰に出すかを選び直す間隔（秒）";
                map["farMeters"] = "これより遠い人は 0.1 秒ごとに追う（m）";
                map["roots"] = "名札の板";
                map["labels"] = "名札の文字";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "文字", "oneLineChars", "normalSize", "smallSize" },
            new[] { "負荷", "refreshSeconds", "farMeters" },
            new[] { "画面の部品（自動で作られる。ふつうは触らない）", "roots", "labels" },
            LinkGroup,
        };

        protected override string Summary() { return "いる人の頭の上に、その人の肩書きを出します（本人の画面の中だけ）。"; }
    }

    [CustomEditor(typeof(TitlePopup))]
    public class TitlePopupEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "clip", "showSeconds", "mergeAbove" };
        protected override bool NeedsDatabase => false;

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["clip"] = "獲得の効果音（空なら鳴らさない）";
                map["showSeconds"] = "出しておく秒数";
                map["busySeconds"] = "順番待ちがあるときの1つの秒数";
                map["mergeAbove"] = "順番待ちがこの数を超えたらまとめる（0＝まとめない）";
                map["slideSeconds"] = "出し入れにかける秒数";
                map["distance"] = "目からの距離（m）";
                map["downAngle"] = "目の高さから下げる角度（度）";
                map["followRate"] = "顔の向きについていく速さ";
                map["slideDistance"] = "出し入れで動く距離（m）";
                map["root"] = "知らせの板";
                map["headline"] = "見出しの文字";
                map["words"] = "称号の文字";
                map["desc"] = "取得条件の文字";
                map["audioSource"] = "音を鳴らす AudioSource";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "出し方", "busySeconds", "slideSeconds", "distance", "downAngle", "followRate", "slideDistance" },
            new[] { "画面の部品（自動で作られる。ふつうは触らない）", "root", "headline", "words", "desc", "audioSource" },
            LinkGroup,
        };

        protected override string Summary() { return "称号をもらった・明かしたときに、本人の目の前に知らせの板を出します。"; }
    }

    [CustomEditor(typeof(TitleRoster))]
    public class TitleRosterEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "showEmpty", "pageSeconds", "plateColor", "noneColor" };
        protected override bool NeedsDatabase => false;

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["showEmpty"] = "肩書きのない人も名前だけ出す";
                map["pageSeconds"] = "ページをめくる間隔（秒）";
                map["refreshSeconds"] = "見直す間隔（秒）";
                map["plateColor"] = "肩書きの色";
                map["noneColor"] = "「（肩書きなし）」の色";
                map["titleText"] = "見出しの文字";
                map["lines"] = "1人1行の文字";
                map["pageText"] = "ページの文字";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "負荷", "refreshSeconds" },
            new[] { "画面の部品（自動で作られる。ふつうは触らない）", "titleText", "lines", "pageText" },
            LinkGroup,
        };

        protected override string Summary() { return "いまいる人の名前と肩書きを一覧にして出します（人が多いとページをめくる）。"; }
    }

    [CustomEditor(typeof(TitleNotebook))]
    public class TitleNotebookEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new[] { "keySummon", "summonKey", "vrSummon", "vrHoldSeconds" };
        protected override bool NeedsDatabase => false;

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["keySummon"] = "デスクトップでキーを押して呼ぶ";
                map["summonKey"] = "呼ぶキー";
                map["vrSummon"] = "VR で両手のトリガー長押しで呼ぶ";
                map["vrHoldSeconds"] = "長押しの秒数";
                map["notebookDistance"] = "手帳を置く目からの距離（m）";
                map["boardDistance"] = "ボードを出す目からの距離（m）";
                map["boardDown"] = "ボードを目の高さから下げる長さ（m）";
                map["board"] = "出し入れする称号ボード";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "置き方", "notebookDistance", "boardDistance", "boardDown" },
            new[] { "画面の部品（自動で作られる。ふつうは触らない）", "board" },
            LinkGroup,
        };

        protected override bool Hidden(string name)
        {
            if (name == "summonKey") return !Bool("keySummon");
            if (name == "vrHoldSeconds") return !Bool("vrSummon");
            return false;
        }

        protected override string Summary() { return "称号の手帳。呼ぶと目の前に来て、開くと称号ボードが出ます。\n使わないときは、マネージャーの「その場で出すボード（手帳）を使う」をオフにします。"; }
    }

    [CustomEditor(typeof(TitleBoard))]
    public class TitleBoardEditor : TitleComponentEditor
    {
        protected override string[] BasicFields => new string[0];
        protected override bool NeedsDatabase => false;

        protected override Dictionary<string, string> Labels
        {
            get
            {
                var map = base.Labels;
                map["cardOwned"] = "持っている称号の札";
                map["cardLocked"] = "持っていない称号の札";
                map["cardSelected"] = "選んでいる札";
                map["textOwned"] = "持っている称号の文字";
                map["textLocked"] = "持っていない称号の文字";
                map["slotNormal"] = "肩書きの枠";
                map["slotFixed"] = "固定の語の枠";
                map["slotDimmed"] = "入れられない枠（灰色）";
                map["filterNormal"] = "絞り込みのボタン";
                map["textWarn"] = "注意の文字";
                map["pressButtons"] = "ボタン";
                map["pressKinds"] = "ボタンの種類";
                map["pressIndexes"] = "ボタンの番号";
                map["cardTexts"] = "称号の札の文字";
                map["cardImages"] = "称号の札の画像";
                map["connectorTexts"] = "接続語の札の文字";
                map["connectorImages"] = "接続語の札の画像";
                map["slotRoots"] = "肩書きの枠";
                map["slotTexts"] = "枠の文字";
                map["slotTypeTexts"] = "枠の種類の文字";
                map["slotImages"] = "枠の画像";
                map["titleText"] = "見出し";
                map["ownedText"] = "獲得の数";
                map["pageText"] = "ページ";
                map["descText"] = "取得条件";
                map["previewText"] = "肩書きの見本";
                map["countText"] = "文字数";
                map["statusText"] = "状態の文";
                map["nameplateText"] = "名札のボタンの文字";
                map["myPlateText"] = "今の肩書き";
                map["filterTexts"] = "絞り込みの文字";
                map["filterImages"] = "絞り込みの画像";
                map["closeRoot"] = "閉じるときに消す物";
                map["closeText"] = "閉じるの文字";
                map["languageText"] = "言語のボタンの文字";
                map["applyImage"] = "決定のボタンの画像";
                map["connectorsLabel"] = "「接続語」の見出し";
                map["plateLabel"] = "「肩書きの設定」の見出し";
                map["plateHintText"] = "肩書きの案内";
                map["listLabel"] = "「称号一覧」の見出し";
                map["applyText"] = "決定の文字";
                map["revertText"] = "元に戻すの文字";
                map["clearText"] = "全部消すの文字";
                map["prevText"] = "前へ の文字";
                map["nextText"] = "次へ の文字";
                return map;
            }
        }

        protected override string[][] Groups => new[]
        {
            new[] { "色", "cardOwned", "cardLocked", "cardSelected", "textOwned", "textLocked", "slotNormal", "slotFixed", "slotDimmed", "filterNormal", "textWarn" },
            new[] { "画面の部品（自動で作られる。ふつうは触らない）", "pressButtons", "pressKinds", "pressIndexes", "cardTexts", "cardImages", "connectorTexts", "connectorImages",
                "slotRoots", "slotTexts", "slotTypeTexts", "slotImages", "titleText", "ownedText", "pageText", "descText", "previewText", "countText", "statusText",
                "nameplateText", "myPlateText", "filterTexts", "filterImages", "closeRoot", "closeText", "languageText", "applyImage", "connectorsLabel", "plateLabel",
                "plateHintText", "listLabel", "applyText", "revertText", "clearText", "prevText", "nextText" },
            LinkGroup,
        };

        protected override string Summary() { return "称号ボード。称号の一覧を見て、肩書きを並べて決定します。\n板とボタンは「シーンに称号システムを置く」が作ります。色は「詳しい設定」の「色」で変えられます。"; }
    }

    // マネージャーのインスペクター：表の選択（GUID で持つ）・言語・枠の種類・焼き込みのボタン。
    [CustomEditor(typeof(TitleManager))]
    public class TitleManagerEditor : Editor
    {
        private static readonly string[] SlotLabels = { "どちらも", "称号だけ", "接続語だけ", "固定の語", "使わない" };

        public override void OnInspectorGUI()
        {
            if (TitleGUI.Header(target, true, false)) return;
            var manager = (TitleManager)target;
            serializedObject.Update();
            TitleDatabase db = TitleBake.DatabaseOf(manager);
            EditorGUILayout.LabelField("全体", EditorStyles.boldLabel);
            var picked = (TitleDatabase)EditorGUILayout.ObjectField("称号の表", db, typeof(TitleDatabase), false);
            if (picked != db)
            {
                serializedObject.FindProperty("databaseGuid").stringValue = picked == null ? "" : AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(picked));
                db = picked;
            }
            SerializedProperty language = serializedObject.FindProperty("language");
            language.intValue = EditorGUILayout.Popup(new GUIContent("言語", "自動：見る人の VRChat の言語が日本語なら日本語、ほかは英語。英語の語・説明が空の行は日本語で出す"),
                Mathf.Clamp(language.intValue, 0, 2), new[] { "日本語", "English", "自動（見る人の言語）" });
            EditorGUILayout.PropertyField(serializedObject.FindProperty("keyPrefix"), new GUIContent("保存のキーの頭"));

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("肩書き", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("maxPlateChars"), new GUIContent("文字数の上限"));
            SerializedProperty types = serializedObject.FindProperty("slotTypes");
            SerializedProperty fixedKeys = serializedObject.FindProperty("slotFixedKeys");
            SerializedProperty unlockKeys = serializedObject.FindProperty("slotUnlockKeys");
            if (unlockKeys.arraySize != TitleManager.SlotCount) unlockKeys.arraySize = TitleManager.SlotCount;
            if (types.arraySize != TitleManager.SlotCount) types.arraySize = TitleManager.SlotCount;
            if (fixedKeys.arraySize != TitleManager.SlotCount) fixedKeys.arraySize = TitleManager.SlotCount;
            for (int i = 0; i < TitleManager.SlotCount; i++)
            {
                SerializedProperty type = types.GetArrayElementAtIndex(i);
                EditorGUILayout.BeginHorizontal();
                type.intValue = EditorGUILayout.Popup("枠 " + (i + 1), Mathf.Clamp(type.intValue, 0, SlotLabels.Length - 1), SlotLabels);
                EditorGUILayout.EndHorizontal();
                EditorGUI.indentLevel++;
                if (type.intValue == TitleManager.SlotFixed)
                {
                    SerializedProperty key = fixedKeys.GetArrayElementAtIndex(i);
                    key.stringValue = TitleGUI.KeyField("固定の語", key.stringValue, db, true);
                }
                if (type.intValue != TitleManager.SlotUnused)
                {
                    SerializedProperty unlock = unlockKeys.GetArrayElementAtIndex(i);
                    unlock.stringValue = TitleGUI.KeyField("解禁の称号（なし＝最初から）", unlock.stringValue, db);
                }
                EditorGUI.indentLevel--;
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("表示", EditorStyles.boldLabel);
            SerializedProperty showPopups = serializedObject.FindProperty("showPopups");
            EditorGUILayout.PropertyField(showPopups, new GUIContent("称号の知らせを出す", "オフなら、称号の獲得・ヒント・記録の知らせを出さない（部品に効果音があれば、音だけ鳴らす）。やり直しのボタンの確認は出す"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("popup"), new GUIContent("獲得の知らせ"));
            SerializedProperty popupMode = serializedObject.FindProperty("popupMode");
            if (showPopups.boolValue) popupMode.intValue = EditorGUILayout.Popup(new GUIContent("知らせの出し方", "1つずつ：もらった称号を1つずつ順に出し、称号の下に取得条件を出す。まとめて：同時にもらった称号を1回の知らせに並べる"),
                Mathf.Clamp(popupMode.intValue, 0, 1), new[] { "1つずつ（称号の下に取得条件）", "まとめて" });
            SerializedProperty revealEquipped = serializedObject.FindProperty("revealEquipped");
            revealEquipped.intValue = EditorGUILayout.Popup(new GUIContent("ほかの人の装備で明かす", "同じインスタンスのほかの人が肩書きに入れている称号を、まだ持っていなくても称号ボードで見えるようにする（保存する）。「隠す」「一覧に出さない」の称号にも効く。名札を見せない設定の人の分は数えない"),
                Mathf.Clamp(revealEquipped.intValue, 0, 2), new[] { "明かさない", "名前だけ", "名前と取得条件" });
            EditorGUILayout.PropertyField(serializedObject.FindProperty("showNameplatesDefault"), new GUIContent("名札を最初は出す"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("usePortableBoard"), new GUIContent("その場で出すボード（手帳）を使う", "オンなら、称号の手帳（キー T か VR で両手のトリガー長押しで呼ぶ）を使うと、目の前に称号ボードが出る。オフなら手帳を消す"));
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("行動の値", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("teleportMeters"), new GUIContent("テレポートとみなす距離（m）"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("nearMeters"), new GUIContent("近くにいるとみなす距離（m）", "near_min（ほかの人の近くにいた時間）で使う。数えるときは3秒ごとに全員との距離を見る"));
            EditorGUILayout.PropertyField(serializedObject.FindProperty("handoffMeters"), new GUIContent("手渡しとみなす距離（m）", "received_items（受け取った回数）で使う。称号アクションの物を掴んだとき、ほかの人の手がこの距離以内なら手渡し"));
            SerializedProperty holders = serializedObject.FindProperty("holderKeys");
            EditorGUILayout.LabelField(new GUIContent("会うと数える称号", "met_title_holders（称号を持つ人と会った回数）で使う。どれか1つを持つ人と会うと1回（1人につき入室1回）"));
            EditorGUI.indentLevel++;
            for (int i = 0; i < holders.arraySize; i++)
            {
                EditorGUILayout.BeginHorizontal();
                SerializedProperty key = holders.GetArrayElementAtIndex(i);
                key.stringValue = TitleGUI.KeyField("称号 " + (i + 1), key.stringValue, db);
                bool remove = GUILayout.Button("－", GUILayout.Width(24));
                EditorGUILayout.EndHorizontal();
                if (remove) { holders.DeleteArrayElementAtIndex(i); break; }
            }
            if (GUILayout.Button("＋ 称号を足す")) { holders.arraySize++; holders.GetArrayElementAtIndex(holders.arraySize - 1).stringValue = ""; }
            EditorGUI.indentLevel--;
            EditorGUILayout.PropertyField(serializedObject.FindProperty("creatorNames"), new GUIContent("会うと数える人の表示名", "met_creator（作者などと会った回数）で使う。表示名は変えられるので、景品などには使わない"), true);
            EditorGUILayout.Space();
            EditorGUILayout.LabelField("テスト", EditorStyles.boldLabel);
            EditorGUILayout.PropertyField(serializedObject.FindProperty("testAllOwned"), new GUIContent("Editor で始めたとき全称号を持つ", "Editor の Play（ClientSim）だけ。全部の称号と解禁で使う接続語を持った状態で始める。所持は保存しない。アップロードしたワールドでは効かない"));
            serializedObject.ApplyModifiedProperties();

            EditorGUILayout.Space();
            int rows = manager.ids == null ? 0 : manager.ids.Length;
            EditorGUILayout.HelpBox("焼き込み済み：" + rows + " 行。Play とビルドの前にも自動で焼き込みます。", MessageType.None);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("今すぐ焼き込む")) TitleBake.Bake(manager, true);
            if (GUILayout.Button("シーンを点検")) TitleSceneCheck.Open();
            using (new EditorGUI.DisabledScope(db == null))
                if (GUILayout.Button("称号の表を開く")) Selection.activeObject = db;
            EditorGUILayout.EndHorizontal();
        }
    }
}
