using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Components;

namespace WorldTitleGimmick.EditorTools
{
    // 「World Title Gimmick/Check Scene」（2026-10-28、ユーザー指定）。置き間違いをまとめて見つけ、窓に並べる。
    // 行を押すと、その物（または表）を選ぶ。シーンや表は変えない（焼き込みだけは行う。Play の前と同じ）。
    public class TitleSceneCheck : EditorWindow
    {
        public enum Level { 問題 = 0, 注意 = 1, 情報 = 2 }

        public class Item
        {
            public Level level;
            public string text;
            public Object target;
            // 直すボタン（あれば行の右に出す。押したあともう一度点検する）。
            public string fixLabel;
            public System.Action fix;
        }

        private List<Item> items = new List<Item>();
        private Vector2 scroll;
        private bool showInfo = true;

        [MenuItem("World Title Gimmick/シーンを点検（Check Scene）")]
        public static void Open()
        {
            var window = GetWindow<TitleSceneCheck>("称号の点検");
            window.Run();
            window.Show();
        }

        private void OnGUI()
        {
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("もう一度点検する", GUILayout.Width(140))) Run();
            showInfo = GUILayout.Toggle(showInfo, "情報も出す");
            EditorGUILayout.EndHorizontal();
            int bad = items.Count(i => i.level == Level.問題);
            int warn = items.Count(i => i.level == Level.注意);
            EditorGUILayout.HelpBox(bad == 0 && warn == 0 ? "問題は見つかりませんでした。" : "問題 " + bad + " 件・注意 " + warn + " 件。行を押すと、その物を選びます。",
                bad > 0 ? MessageType.Error : warn > 0 ? MessageType.Warning : MessageType.Info);
            scroll = EditorGUILayout.BeginScrollView(scroll);
            System.Action pending = null;
            foreach (Item item in items)
            {
                if (item.level == Level.情報 && !showInfo) continue;
                string mark = item.level == Level.問題 ? "✖ " : item.level == Level.注意 ? "▲ " : "・ ";
                string where = item.target != null ? "　（" + item.target.name + "）" : "";
                var style = new GUIStyle(EditorStyles.label) { wordWrap = true, richText = false };
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button(mark + item.text + where, style) && item.target != null)
                {
                    Selection.activeObject = item.target;
                    EditorGUIUtility.PingObject(item.target);
                }
                if (item.fix != null && GUILayout.Button(item.fixLabel, GUILayout.ExpandWidth(false))) pending = item.fix;
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();
            // 一覧を描き終えてから直す（直すと一覧が変わるため）。
            if (pending != null) { pending(); Run(); GUIUtility.ExitGUI(); }
        }

        public void Run()
        {
            items = Check();
            Repaint();
        }

        // 点検の本体（窓なしでも使える）。
        public static List<Item> Check()
        {
            var list = new List<Item>();
            void Add(Level level, string text, Object target = null) { list.Add(new Item { level = level, text = text, target = target }); }

            TitleManager[] managers = Object.FindObjectsOfType<TitleManager>(true);
            if (managers.Length == 0)
            {
                Add(Level.問題, "シーンに TitleManager がありません。「World Title Gimmick/シーンに称号システムを置く」を実行してください。");
                return list;
            }
            if (managers.Length > 1) foreach (TitleManager m in managers) Add(Level.問題, "TitleManager が " + managers.Length + " 個あります。1つにしてください。", m);
            TitleManager manager = managers[0];
            TitleDatabase db = TitleBake.DatabaseOf(manager);
            if (db == null)
            {
                Add(Level.問題, "マネージャーに称号の表が設定されていません。", manager);
                return list;
            }

            // 表と焼き込み（警告を集める）。
            // Play 中は焼き込まない（動いているマネージャーの語・文言の配列を上書きしてしまうため）。
            if (Application.isPlaying) Add(Level.情報, "Play 中なので、表の条件の点検（焼き込み）は飛ばしました。Play を止めてから点検すると全部見ます。");
            else
            {
                var bakeProblems = new List<string>();
                TitleBake.Bake(manager, false, bakeProblems);
                foreach (string p in bakeProblems) Add(Level.問題, p, db);
            }

            // 表示の部品。
            if (manager.popup == null) Add(Level.注意, "獲得の知らせ（TitlePopup）がマネージャーに設定されていません。称号をもらっても知らせが出ません。", manager);
            if (Object.FindObjectsOfType<TitleBoard>(true).Length == 0) Add(Level.注意, "称号ボードがありません。プレイヤーが肩書きを作れません。", manager);
            if (Object.FindObjectsOfType<TitleNameplates>(true).Length == 0) Add(Level.情報, "頭上の名札がありません（肩書きはほかの人に見えません）。", manager);

            // 行動の値で、ほかの部品や設定が要るもの（2026-10-28）。
            bool On(int stat) => manager.statOn != null && stat < manager.statOn.Length && manager.statOn[stat];
            // 座った回数・時間は、席（VRC Station）ごとの席の部品（TitleSeat）で数える。付いていない席があれば、まとめて付けるボタンを出す。
            if (On(TitleManager.StatSits) || On(TitleManager.StatSitMin))
            {
                VRCStation[] stations = Object.FindObjectsOfType<VRCStation>(true);
                int without = stations.Count(s => s.GetComponent<TitleSeat>() == null);
                if (stations.Length == 0)
                    Add(Level.注意, "座った回数・時間（sits・sit_min）を使っていますが、シーンに席（VRC Station）がありません。", manager);
                else if (without > 0)
                {
                    bool none = without == stations.Length;
                    Add(none ? Level.問題 : Level.注意, "座った回数・時間（sits・sit_min）を使っていますが、" + (none ? "どの席" : without + " 個の席") + "にも席の部品（TitleSeat）が付いていません。右のボタンで、シーンの全部の席に付けられます（付けた席だけで数えます）。", manager);
                    list[list.Count - 1].fixLabel = "すべての席に付ける";
                    list[list.Count - 1].fix = TitleSystemBuilder.AddSeatCounters;
                }
            }
            if ((On(TitleManager.StatPats) || On(TitleManager.StatPatted) || On(TitleManager.StatHighFives)) && Object.FindObjectsOfType<TitleTouch>(true).Length == 0)
                Add(Level.問題, "撫でる・ハイタッチ（pats・patted・high_fives）を使っていますが、TitleTouch がありません。「シーンに称号システムを置く」をもう一度実行してください。", manager);
            if (On(TitleManager.StatMetHolders))
            {
                if (manager.holderKeys == null || manager.holderKeys.All(string.IsNullOrEmpty)) Add(Level.問題, "称号を持つ人と会った回数（met_title_holders）を使っていますが、マネージャーの「会うと数える称号」が空です。", manager);
                else foreach (string key in manager.holderKeys)
                    if (!string.IsNullOrEmpty(key) && db.Find(key) == null) Add(Level.問題, "「会うと数える称号」のキーが表にありません：" + key, manager);
            }
            if (On(TitleManager.StatMetCreator) && (manager.creatorNames == null || manager.creatorNames.All(string.IsNullOrEmpty)))
                Add(Level.問題, "作者などと会った回数（met_creator）を使っていますが、マネージャーの「会うと数える人の表示名」が空です。", manager);
            if (On(TitleManager.StatReceived) && Object.FindObjectsOfType<TitleAction>(true).Length == 0)
                Add(Level.問題, "受け取った回数（received_items）を使っていますが、称号アクションの物がありません（手渡しは称号アクションの付いた物で数えます）。", manager);
            if (On(TitleManager.StatNearMin)) Add(Level.情報, "近くにいた時間（near_min）は、1秒ごとに全員との距離を見ます（人数が多いと少し重くなります）。", manager);
            if (On(TitleManager.StatPats) || On(TitleManager.StatPatted) || On(TitleManager.StatHighFives))
                Add(Level.情報, "撫でる・ハイタッチは、頭と手に付いていく受け手を毎フレーム動かします。アバターのコンタクトを受けられるかは実機で確かめてください。", manager);

            // 部品ごとの点検。
            var granted = new HashSet<string>();
            void Keys(Object owner, string label, IEnumerable<string> keys, bool grants)
            {
                if (keys == null) return;
                foreach (string key in keys)
                {
                    if (string.IsNullOrEmpty(key)) continue;
                    TitleDatabase.Row row = db.Find(key);
                    if (row == null) Add(Level.問題, label + "の称号「" + key + "」が表にありません。", owner);
                    else if (row.state == TitleDatabase.State.廃止) Add(Level.注意, label + "の称号「" + row.word + "」は廃止です（渡せない・表示されない）。", owner);
                    if (grants) granted.Add(key);
                }
            }

            var allOfParts = new HashSet<TitleTriggerBase>();
            foreach (TitleAllOf a in Object.FindObjectsOfType<TitleAllOf>(true))
            {
                if (a.parts == null || a.parts.All(p => p == null)) Add(Level.問題, "条件まとめに部品がありません。", a);
                else foreach (TitleTriggerBase p in a.parts) if (p != null) allOfParts.Add(p);
                if (a.saved && string.IsNullOrEmpty(a.saveKey)) Add(Level.問題, "条件まとめが「これまでに全部」ですが、保存の名前（Save Key）が空です。", a);
                if (a.parts != null && a.parts.Any(p => p == a)) Add(Level.問題, "条件まとめの部品に自分自身が入っています。", a);
            }
            foreach (TitleTriggerBase c in Object.FindObjectsOfType<TitleTriggerBase>(true))
            {
                Keys(c, "渡す", c.grantKeys, true);
                Keys(c, "前提（持っている）", c.requiredKeys, false);
                Keys(c, "前提（持っていない）", c.forbiddenKeys, false);
                Keys(c, "前提（装備している）", c.equippedKeys, false);
                Keys(c, "明かす", c.revealKeys, false);
                if (c.revealKeys != null) foreach (string key in c.revealKeys)
                {
                    TitleDatabase.Row row = string.IsNullOrEmpty(key) ? null : db.Find(key);
                    if (row != null && row.nameMode == TitleDatabase.NameMode.内部用) Add(Level.注意, "明かす称号「" + row.word + "」は内部用です（明かしても出ません）。", c);
                }
                bool nothing = (c.grantKeys == null || c.grantKeys.All(string.IsNullOrEmpty)) && (c.revealKeys == null || c.revealKeys.All(string.IsNullOrEmpty)) && string.IsNullOrEmpty(c.counterKey)
                    && (c.eventTargets == null || c.eventTargets.Length == 0) && (c.enableObjects == null || c.enableObjects.Length == 0)
                    && (c.disableObjects == null || c.disableObjects.Length == 0)
                    && !(c is TitleAction stepped && stepped.stepKeys != null && stepped.stepKeys.Any(k => !string.IsNullOrEmpty(k)));
                if (nothing && !allOfParts.Contains(c)) Add(Level.問題, "渡す称号も明かす称号もカウンターもイベントもありません（何も起きません）。", c);
                if (c.heldObjects != null) foreach (GameObject held in c.heldObjects)
                    if (held != null && held.GetComponent<VRCPickup>() == null) Add(Level.問題, "前提の「持っている物」に VRC Pickup がありません：" + held.name, c);
                if (c.eventTargets != null && c.eventNames != null && c.eventTargets.Length != c.eventNames.Length)
                    Add(Level.注意, "イベントの送り先（Event Targets）と名前（Event Names）の数が違います。", c);

                if (c is TitleArea area)
                {
                    if (!area.GetComponents<Collider>().Any(col => col.isTrigger)) Add(Level.問題, "称号エリアに Is Trigger のコライダーがありません。", area);
                    if (area.who == TitleArea.WhoObjects && (area.objects == null || area.objects.All(o => o == null))) Add(Level.問題, "「入る物」が空です。", area);
                    if (area.who == TitleArea.WhoLayer && area.layers.value == 0) Add(Level.問題, "「入る物のレイヤー」が選ばれていません。", area);
                    if (area.trigger == TitleArea.OnCrowd && area.who != TitleArea.WhoPlayer) Add(Level.問題, "きっかけ「中の人数」は、「何が入ったら」が「本人（プレイヤー）」のときだけ使えます。", area);
                    if (area.trigger == TitleArea.OnCrowd && area.crowdCount < 2) Add(Level.注意, "きっかけ「中の人数」の人数が 2 より小さいです（1人なら「入ったら」と同じです）。", area);
                }
                if (c is TitleAction action)
                {
                    Keys(action, "段で渡す", action.stepKeys, true);
                    if (action.steps != null && action.stepKeys != null && action.steps.Length != action.stepKeys.Length) Add(Level.問題, "段の回数（Steps）と段で渡す称号（Step Keys）の数が違います。", action);
                    if (action.action == TitleAction.ActHit && (action.hitObjects == null || action.hitObjects.All(o => o == null)) && action.hitLayers.value == 0)
                        Add(Level.問題, "「ほかの物に当てる」の当てる物・レイヤーがありません。", action);
                    if (action.action == TitleAction.ActReceive && action.GetComponent<VRCObjectSync>() == null)
                        Add(Level.注意, "「ほかの人から受け取る」の物に VRC Object Sync がありません（ほかの人が持っている様子が見えないので、手渡しになりません）。", action);
                    if (action.action == TitleAction.ActInteract)
                    {
                        if (action.GetComponent<Collider>() == null) Add(Level.問題, "Interact で押す物にコライダーがありません。", action);
                    }
                    else
                    {
                        if (action.GetComponent<VRCPickup>() == null) Add(Level.問題, "掴む・使う・投げる物に VRC Pickup がありません。", action);
                        if (action.GetComponent<Rigidbody>() == null) Add(Level.問題, "掴む・使う・投げる物に Rigidbody がありません。", action);
                        if (action.GetComponent<Collider>() == null) Add(Level.問題, "掴む・使う・投げる物にコライダーがありません。", action);
                        VRCPickup pickup = action.GetComponent<VRCPickup>();
                        if (pickup != null && action.action == TitleAction.ActUse && pickup.AutoHold != VRC.SDKBase.VRC_Pickup.AutoHoldMode.Yes)
                            Add(Level.注意, "「使う」は、VRC Pickup の Auto Hold が Yes でないとデスクトップで使いにくいことがあります。", action);
                    }
                }
            }

            foreach (TitleCounter c in Object.FindObjectsOfType<TitleCounter>(true))
            {
                Keys(c, "回数で渡す", c.stepKeys, true);
                if (string.IsNullOrEmpty(c.counterKey)) Add(Level.問題, "カウンターの名前が空です。", c);
                if (c.steps == null || c.stepKeys == null || c.steps.Length != c.stepKeys.Length) Add(Level.問題, "回数（Steps）と渡す称号（Step Keys）の数が違います。", c);
                if (c.interactable && c.GetComponent<Collider>() == null) Add(Level.問題, "押すカウンターにコライダーがありません。", c);
                if (!c.saved && Object.FindObjectsOfType<TitleCounter>(true).Any(o => o != c && o.saved && o.counterKey == c.counterKey))
                    Add(Level.注意, "同じ名前のカウンターに「保存する」がオンの物とオフの物があります。1つでもオフなら、その名前のカウンターは保存しません：" + c.counterKey, c);
            }

            foreach (TitleGate g in Object.FindObjectsOfType<TitleGate>(true))
            {
                Keys(g, "条件", g.titleKeys, false);
                Keys(g, "並び順", g.sequenceKeys, false);
                Keys(g, "枠の位置", g.slotCheckKeys, false);
                bool hasCondition = (g.titleKeys != null && g.titleKeys.Any(k => !string.IsNullOrEmpty(k))) || (g.sequenceKeys != null && g.sequenceKeys.Length > 0)
                    || (g.slotCheckSlots != null && g.slotCheckSlots.Length > 0) || g.minOwned > 0 || !string.IsNullOrEmpty(g.statName) || !string.IsNullOrEmpty(g.recordKey);
                if (!hasCondition) Add(Level.問題, "称号ゲートに条件がありません。", g);
                bool hasTarget = Count(g.renderers) + Count(g.colliders) + Count(g.objects) + Count(g.behaviours) + Count(g.behavioursWhenNot) + Count(g.pickupObjects) + Count(g.objectsWhenNot) + Count(g.eventTargets) + Count(g.interactTargets) > 0;
                if (!string.IsNullOrEmpty(g.recordKey))
                {
                    TitleDatabase.Row rec = db.Find(g.recordKey);
                    if (rec == null || rec.kind != TitleDatabase.Kind.記録) Add(Level.問題, "記録の称号のキーが表にありません（記録の行ではありません）：" + g.recordKey, g);
                }
                if (!hasTarget) Add(Level.問題, "称号ゲートで切り替える物がありません。", g);
                if (!string.IsNullOrEmpty(g.statName) && TitleBake.StatIndex(g.statName) < 0) Add(Level.問題, "行動の値の名前がありません：" + g.statName, g);
                if (g.slotCheckSlots != null && g.slotCheckKeys != null && g.slotCheckSlots.Length != g.slotCheckKeys.Length) Add(Level.問題, "枠の番号と枠の称号の数が違います。", g);
                if (g.colliders != null) foreach (Collider col in g.colliders)
                    if (col != null && col.GetComponentInParent<VRCObjectSync>() != null)
                        Add(Level.注意, "Object Sync の物の当たり判定を切り替えています（人によって動きが食い違います。説明書 01 の 13-3）：" + col.name, g);
                var selfUdon = UdonSharpEditor.UdonSharpEditorUtility.GetBackingUdonBehaviour(g);
                if ((g.behaviours != null && g.behaviours.Contains(selfUdon)) || (g.behavioursWhenNot != null && g.behavioursWhenNot.Contains(selfUdon)))
                    Add(Level.問題, "称号ゲートの「有効・無効にするコンポーネント」に、ゲート自身が入っています（止めると切り替えが止まります）。", g);
                if (g.pickupObjects != null) foreach (GameObject o in g.pickupObjects)
                    if (o != null && o.GetComponent<VRCPickup>() == null) Add(Level.問題, "「掴めるか」の物に VRC Pickup がありません：" + o.name, g);
            }

            foreach (TitleReset r in Object.FindObjectsOfType<TitleReset>(true))
            {
                Keys(r, "外す", r.revokeKeys, false);
                if (r.GetComponent<Collider>() == null) Add(Level.問題, "やり直しのボタンにコライダーがありません。", r);
            }

            foreach (TitlePerk p in Object.FindObjectsOfType<TitlePerk>(true))
            {
                Keys(p, "効果の条件", p.titleKeys, false);
                if (p.titleKeys == null || p.titleKeys.All(string.IsNullOrEmpty)) Add(Level.問題, "効果の部品に条件の称号がありません。", p);
                if (!p.changeSpeed && !p.changeJump && !p.changeGravity && Count(p.objects) + Count(p.eventTargets) == 0) Add(Level.問題, "効果が選ばれていません。", p);
            }
            foreach (TitleRelay r in Object.FindObjectsOfType<TitleRelay>(true))
            {
                Keys(r, "中継で見る", r.watchKeys, false);
                if (Count(r.eventTargets) == 0) Add(Level.問題, "称号イベント中継に送り先がありません。", r);
            }
            if (Object.FindObjectsOfType<TitlePerk>(true).Count(p => p.changeSpeed) > 1)
                Add(Level.注意, "移動の速さを変える効果の部品が2つ以上あります。同時に満たすと、どちらか一方（シーンであとに動き出した部品）の値になります。");

            // マネージャーの枠。
            if (manager.slotUnlockKeys != null) Keys(manager, "枠の解禁", manager.slotUnlockKeys, false);

            // 渡すものがない称号（情報）。コードや Udon Graph から渡す場合もあるので、問題にはしない。
            foreach (TitleDatabase.Row row in db.rows)
            {
                if (row == null || string.IsNullOrEmpty(row.key) || row.state == TitleDatabase.State.廃止) continue;
                if (!string.IsNullOrEmpty(row.condition) || granted.Contains(row.key)) continue;
                if (row.kind == TitleDatabase.Kind.接続語 && !row.lockedConnector) continue;
                Add(Level.情報, "「" + row.word + "」[" + row.key + "] を渡すもの（表の条件・部品）がシーンにありません。コードや Udon Graph から渡すなら問題ありません。", db);
            }

            // 保存の大きさ（説明書 01 の 13-4）。
            int maxId = db.rows.Where(r => r != null).Select(r => r.kind == TitleDatabase.Kind.接続語 && !r.lockedConnector ? 0 : r.id).DefaultIfEmpty(0).Max();
            int bytes = maxId / 8 + 1 + TitleManager.SlotCount * 2;
            Add(maxId > 2000 ? Level.注意 : Level.情報, "保存の大きさの目安：称号の所持と肩書きで最大 " + bytes + " バイト（＋カウンター・行動の値 1つ4バイト）。");
            if (string.IsNullOrEmpty(manager.keyPrefix)) Add(Level.問題, "保存のキーの頭が空です。ほかのアセットとぶつかります。", manager);
            return list;
        }

        private static int Count<T>(T[] array) where T : Object { return array == null ? 0 : array.Count(x => x != null); }
    }
}
