using System;
using System.Collections.Generic;
using UnityEngine;

namespace WorldTitleGimmick.EditorTools
{
    // 称号の表（仕様書 4章）。Editor だけで使うアセットで、焼き込み（TitleBake）が TitleManager の配列へ書き込む。
    // ID は自動で振り、一度使った ID は二度と出さない（やめるときは「廃止」にする）。
    [CreateAssetMenu(menuName = "World Title Gimmick/称号の表（Title Database）", fileName = "Titles")]
    public class TitleDatabase : ScriptableObject
    {
        // 記録（2026-10-28）：保存した値から語を作る称号（「最速タイム 12.34秒」）。語は前置きになる。
        public enum Kind { 通常 = 0, 接続語 = 1, 記録 = 2 }
        // 記録の書式：数（3けたごとに,）／小数（けた数）／時間（0.01秒単位の値を 12.34 に）／分:秒（秒の値を 1:05 に）
        public enum RecordFormat { 数 = 0, 小数 = 1, 時間 = 2, 分秒 = 3 }
        // 内部用：ずっとボードに出さず、もらっても知らせない・獲得数に数えない・肩書きに入れない（セーブの印など）。
        public enum NameMode { 見せる = 0, 隠す = 1, 一覧に出さない = 2, 内部用 = 3 }
        public enum State { 使用 = 0, 廃止 = 1 }

        [Serializable]
        public class Row
        {
            // インスペクターでは書き換えられない（2026-10-28、ユーザー指摘：手で大きな番号を入れると、次の行の番号がそこから振られてしまう）。
            [Tooltip("自動で振る番号。変えられない（変えると、プレイヤーの保存済みの称号が別のものに入れ替わる）")]
            [TitleReadOnly] public int id;
            // Delayed：打ち終わって確定したときだけ書き換える（打っている途中の名前で ID の記録が書き換わらないように）。
            [Tooltip("呼び出しに使う名前（英数字と _）。表の中で重複しない。行を複製したら、写しのほうのキーを書き換える（元の行のキーを書き換えると、ID は写しのほうに移る）")]
            [Delayed] public string key = "";
            public Kind kind = Kind.通常;
            [Tooltip("日本語の語")]
            public string word = "";
            [Tooltip("英語の語（空なら日本語）")]
            public string wordEn = "";
            [Tooltip("持っていないときの説明（ぼかしてよい。空なら取得後の説明）")]
            [TextArea(1, 3)] public string descBefore = "";
            [TextArea(1, 3)] public string descBeforeEn = "";
            [Tooltip("持っているときの説明")]
            [TextArea(1, 3)] public string descAfter = "";
            [TextArea(1, 3)] public string descAfterEn = "";
            [Tooltip("表だけで判定する条件。例：count:button>=10 / stat:jumps>=100 / owned>=5 / all:key1,key2。空なら部品から渡す")]
            public string condition = "";
            public NameMode nameMode = NameMode.見せる;
            [Tooltip("接続語だけ：オンなら最初は使えず、条件か部品で解禁する（2026-10-28）")]
            public bool lockedConnector;
            public State state = State.使用;
            [Tooltip("称号ボードでの並び（小さいほど前。同じなら ID の順）")]
            public int order;

            // ---- 記録の設定（分類が「記録」の行だけ使う。語が前置きになる） ----
            [Tooltip("記録だけ：値の書式")]
            public RecordFormat recordFormat = RecordFormat.数;
            [Tooltip("記録だけ：小数のけた数（書式が「小数」のとき。値 1234・2けたなら 12.34）")]
            public int recordDigits = 2;
            [Tooltip("記録だけ：値のあとに付ける語（例：秒・点・匹）")]
            public string recordSuffix = "";
            [Tooltip("記録だけ：値のあとに付ける語（英語。空なら日本語）")]
            public string recordSuffixEn = "";
            [Tooltip("記録だけ：オンなら小さいほど良い記録（タイムなど）。オフなら大きいほど良い（スコアなど）")]
            public bool recordLowerBetter;
            [Tooltip("記録だけ：保存のキー（PlayerData のキーをそのまま）。空なら <頭>rec.<キー>。ほかの仕組みが保存している値を読むときに使う")]
            public string recordSaveKey = "";
            [Tooltip("記録だけ：記録の数え方を変えたら上げる（版が違う記録は「記録なし」になる。0 なら版を付けない）")]
            public int recordVersion;
        }

        public List<Row> rows = new List<Row>();
        // これまでに使った一番大きい ID（通常・接続語）。減らさない。
        [HideInInspector] public int lastNormalId;
        [HideInInspector] public int lastConnectorId = 9000;
        [HideInInspector] public int lastRecordId = 9999;

        public const int NormalMax = 8999;
        public const int ConnectorMin = 9001;
        public const int ConnectorMax = 9999;
        public const int RecordMin = 10000;
        public const int RecordMax = 32767;

        // どの ID をどのキーに振ったか（2026-10-28）。行を複製すると、元の行と写しが同じ ID になり、写しでない側（元の行）に
        // 新しい ID が振られることがある。写しのキーを書き換えたときに、元のキーの行へ ID を戻すために覚えておく。
        [HideInInspector] public List<int> issuedIds = new List<int>();
        [HideInInspector] public List<string> issuedKeys = new List<string>();

        private static bool Fits(Row row) { return InRange(row.kind, row.id); }

        public static bool InRange(Kind kind, int id)
        {
            if (kind == Kind.通常) return id > 0 && id <= NormalMax;
            if (kind == Kind.接続語) return id >= ConnectorMin && id <= ConnectorMax;
            return id >= RecordMin && id <= RecordMax;
        }

        private string IssuedKey(int id)
        {
            int at = issuedIds.IndexOf(id);
            return at >= 0 && at < issuedKeys.Count ? issuedKeys[at] : null;
        }

        private void Issue(int id, string key)
        {
            int at = issuedIds.IndexOf(id);
            if (at >= 0 && at < issuedKeys.Count) issuedKeys[at] = key;
            else { issuedIds.Add(id); issuedKeys.Add(key); }
        }

        // ID のない行・重なった行に ID を振る。種類を変えた行は、範囲が合わなければ振り直す。
        public void AssignIds()
        {
            if (issuedIds == null) issuedIds = new List<int>();
            if (issuedKeys == null) issuedKeys = new List<string>();
            while (issuedKeys.Count < issuedIds.Count) issuedKeys.Add("");
            foreach (Row row in rows)
            {
                if (row == null) continue;
                if (row.kind == Kind.通常 && row.id > 0 && row.id <= NormalMax) lastNormalId = Math.Max(lastNormalId, row.id);
                if (row.kind == Kind.接続語 && row.id >= ConnectorMin && row.id <= ConnectorMax) lastConnectorId = Math.Max(lastConnectorId, row.id);
                if (row.kind == Kind.記録 && row.id >= RecordMin && row.id <= RecordMax) lastRecordId = Math.Max(lastRecordId, row.id);
            }
            if (lastRecordId < RecordMin - 1) lastRecordId = RecordMin - 1;
            var used = new HashSet<int>();
            foreach (Row row in rows)
            {
                if (row == null) continue;
                if (Fits(row) && used.Add(row.id)) continue;
                if (row.kind == Kind.通常) row.id = ++lastNormalId;
                else if (row.kind == Kind.接続語) row.id = ++lastConnectorId;
                else row.id = ++lastRecordId;
                used.Add(row.id);
            }
            // 振ったときのキーと違う行があり、そのキーの行がほかの（まだ覚えていない）ID を持っていたら、ID を入れ替えて元に戻す。
            foreach (Row a in rows)
            {
                if (a == null || string.IsNullOrEmpty(a.key)) continue;
                string issued = IssuedKey(a.id);
                if (issued == null || issued == a.key || string.IsNullOrEmpty(issued)) continue;
                foreach (Row b in rows)
                {
                    if (b == null || b == a || b.key != issued || b.kind != a.kind || IssuedKey(b.id) == issued) continue;
                    int swap = a.id;
                    a.id = b.id;
                    b.id = swap;
                    break;
                }
            }
            // 覚える：まだ覚えていない ID（ただし、そのキーをほかの行の ID で覚えているなら、写しの途中なので覚えない）。
            // 覚えたキーの行がもうない（キーを書き換えた）ときは、今のキーで覚え直す。
            var keysInRows = new HashSet<string>();
            foreach (Row row in rows) if (row != null && !string.IsNullOrEmpty(row.key)) keysInRows.Add(row.key);
            foreach (Row row in rows)
            {
                if (row == null || string.IsNullOrEmpty(row.key)) continue;
                string issued = IssuedKey(row.id);
                if (issued == row.key) continue;
                if (issued == null || string.IsNullOrEmpty(issued))
                {
                    bool heldByOther = false;
                    foreach (Row other in rows)
                        if (other != null && other != row && other.key == row.key && IssuedKey(other.id) == row.key) { heldByOther = true; break; }
                    if (!heldByOther) Issue(row.id, row.key);
                }
                else
                {
                    // 覚えたキーの行がもうない（キーを書き換えた）か、そのキーをほかの行が自分の ID で持っているなら、この記録は古い。
                    bool stale = !keysInRows.Contains(issued);
                    if (!stale)
                        foreach (Row other in rows)
                            if (other != null && other != row && other.key == issued && IssuedKey(other.id) == issued) { stale = true; break; }
                    if (stale) Issue(row.id, row.key);
                }
            }
        }

        private void OnValidate() { AssignIds(); }

        // 表にある一番大きい ID（種類ごと）。
        public int MaxIdInRows(Kind kind)
        {
            int max = kind == Kind.通常 ? 0 : kind == Kind.接続語 ? ConnectorMin - 1 : RecordMin - 1;
            foreach (Row row in rows)
            {
                if (row == null || row.kind != kind) continue;
                if (InRange(kind, row.id)) max = Math.Max(max, row.id);
            }
            return max;
        }

        // 次に振る ID を、表にある一番大きい ID の次に戻す（手で入れた番号や消した行で飛んだ分を詰める）。
        // 公開済みのワールドで、消した行の ID をプレイヤーが持っているときは使わない（別の称号に入れ替わる）。
        public void ResetLastIds()
        {
            lastNormalId = MaxIdInRows(Kind.通常);
            lastConnectorId = MaxIdInRows(Kind.接続語);
            lastRecordId = MaxIdInRows(Kind.記録);
        }

        public Row Find(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;
            foreach (Row row in rows) if (row != null && row.key == key) return row;
            return null;
        }

        // 表の検査（焼き込みのときに警告で出す）。
        public List<string> Problems()
        {
            var list = new List<string>();
            var keys = new HashSet<string>();
            var words = new Dictionary<string, string>();
            foreach (Row row in rows)
            {
                if (row == null) continue;
                if (string.IsNullOrEmpty(row.key)) list.Add("キーが空の行があります（ID " + row.id + "）");
                else if (!keys.Add(row.key)) list.Add("キーが重複しています：" + row.key);
                bool inner = row.nameMode == NameMode.内部用;
                if (inner && row.kind == Kind.接続語) list.Add("接続語は「内部用」にできません（使えなくなります）：" + row.key);
                if (row.kind == Kind.通常 && !inner && !string.IsNullOrEmpty(row.word))
                {
                    if (words.TryGetValue(row.word, out string other)) list.Add("語が重複しています：" + row.word + "（" + other + "・" + row.key + "）");
                    else words[row.word] = row.key;
                }
                if (row.kind == Kind.通常 && !inner && string.IsNullOrEmpty(row.word)) list.Add("語が空です：" + row.key);
                if (row.kind == Kind.記録 && row.recordFormat == RecordFormat.小数 && (row.recordDigits < 1 || row.recordDigits > 6)) list.Add("記録の小数のけた数は 1〜6 にしてください：" + row.key);
            }
            return list;
        }
    }
}
