namespace WorldTitleGimmick.EditorTools
{
    // 画面の文言（仕様書 13章）。並びは TitleManager の Text〜 の番号と同じ。文言を変えたいときはここを書き換えて焼き込む。
    public static class TitleTextTable
    {
        private static readonly string[] Japanese =
        {
            "？？？",                         // TextUnknown
            "新しい称号を獲得しました！",     // TextNewTitle
            "称号",                           // TextBoardTitle
            "獲得",                           // TextOwned
            "接続語",                         // TextConnectors
            "肩書きの設定",                   // TextPlate（ボードの肩書きの区画の見出し）
            "決定",                           // TextApply
            "戻す",                           // TextRevert
            "全部消す",                       // TextClear
            "他の人の名札：表示",             // TextNameplateOn
            "他の人の名札：非表示",           // TextNameplateOff
            "◀ 前",                           // TextPrev
            "次 ▶",                           // TextNext
            "文字数",                         // TextChars
            "長すぎます（文字数の上限を超えています）", // TextTooLong
            "肩書きを決定しました",           // TextSaved
            "肩書きの枠を押して選んでください", // TextPickSlot
            "まだ持っていない称号です",       // TextNotOwned
            "この枠には入れられません",       // TextNotAllowed
            "固定",                           // TextFixed
            "称号",                           // TextSlotTitle
            "接続語",                         // TextSlotConnector
            "読み込み中…",                    // TextLoading
            "未解禁",                         // TextLocked
            "この枠はまだ使えません",         // TextSlotLocked
            "もう一度押すとやり直します",     // TextResetConfirm
            "やり直しました",                 // TextResetDone
            "自分の名札：見せる",             // TextMyPlateOn
            "自分の名札：見せない",           // TextMyPlateOff
            "いまいる人の肩書き",             // TextRosterTitle
            "（肩書きなし）",                 // TextRosterNone
            "全部",                           // TextFilterAll
            "持っている",                     // TextFilterOwned
            "まだ",                           // TextFilterLocked
            "閉じる",                         // TextClose
            "言語：日本語",                   // TextLanguage（今の言語。押すと English に）
            "決定していない変更があります（決定を押すと反映）", // TextUnsaved
            "称号か接続語を押すと入ります（もう一度この枠を押すと空にします）", // TextSlotPicked
            "称号のヒントを見つけました",     // TextHint
            "枠を押して選び、称号か接続語を押して入れる。同じ枠をもう一度押すと空にする", // TextPlateHint
            "称号一覧",                       // TextListTitle
            "記録を更新しました！",           // TextRecord（記録の称号の記録が良くなったとき）
        };

        private static readonly string[] English =
        {
            "???",
            "New title unlocked!",
            "Titles",
            "Unlocked",
            "Connectors",
            "Your plate",
            "Apply",
            "Revert",
            "Clear all",
            "Others' plates: ON",
            "Others' plates: OFF",
            "◀ Prev",
            "Next ▶",
            "Length",
            "Too long (over the length limit)",
            "Plate saved",
            "Tap a plate slot first",
            "You don't have this title yet",
            "This slot can't hold that",
            "Fixed",
            "Title",
            "Connector",
            "Loading…",
            "Locked",
            "This slot is still locked",
            "Press again to reset",
            "Reset done",
            "My plate: shown",
            "My plate: hidden",
            "Titles of people here",
            "(no title)",
            "All",
            "Unlocked",
            "Locked",
            "Close",
            "Language: English",
            "Unsaved changes (press Apply)",
            "Tap a title or connector to put it here (tap this slot again to clear it)",
            "Found a title hint",
            "Tap a slot, then a title or connector. Tap the slot again to clear it",
            "Title list",
            "New record!",
        };

        public static string[] Texts(int language)
        {
            string[] source = language == 1 ? English : Japanese;
            return (string[])source.Clone();
        }
    }
}
