using System.Collections.Generic;
using System.IO;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDK3.Components;
using VRC.SDK3.Dynamics.Contact.Components;

namespace WorldTitleGimmick.EditorTools
{
    // 「World Title Gimmick/シーンに称号システムを置く」：今のシーンにマネージャー・称号ボード・頭上の名札・獲得の知らせを置く。
    // もう置いてあれば、ボード・名札・知らせを作り直す（マネージャーの設定は残す）。
    public static class TitleSystemBuilder
    {
        // パッケージの場所（VPM パッケージ。VCC か unitypackage で Packages/ に入る）。
        public const string Root = "Packages/com.surarin.worldtitlegimmick";
        private const string ProgramsFolder = Root + "/Programs";
        public const string SamplePath = Root + "/Samples/SampleTitles.asset";
        // 使う人が書き換える物（称号の表・作り直した見本のシーン）を置く所。パッケージの中は更新で上書きされるので書かない。
        public const string UserRoot = "Assets/WorldTitleGimmickData";
        public const string UserTablePath = UserRoot + "/Titles.asset";

        // 開発用のプロジェクト（Assets/WorldTitleGimmickDev があるとき）か。見本のシーンをパッケージの中に作り直す。
        public static bool IsDevProject => AssetDatabase.IsValidFolder("Assets/WorldTitleGimmickDev");

        // Assets の下のフォルダを（なければ）作る。
        public static void EnsureFolder(string path)
        {
            if (AssetDatabase.IsValidFolder(path)) return;
            string parent = Path.GetDirectoryName(path).Replace('\\', '/');
            EnsureFolder(parent);
            AssetDatabase.CreateFolder(parent, Path.GetFileName(path));
        }
        private const int NameplateCount = 16;
        private static readonly Color Navy = new Color(.06f, .08f, .13f, .96f);
        private static readonly Color Card = new Color(.16f, .20f, .30f, 1f);
        private static readonly Color Gold = new Color(.95f, .76f, .25f, 1f);
        // 称号ボードの区画の色（2026-10-28）：肩書き（設定）は暖色、称号一覧は寒色。
        private static readonly Color PlatePanel = new Color(.20f, .15f, .07f, 1f);
        private static readonly Color PlateBorder = new Color(.95f, .76f, .25f, .70f);
        private static readonly Color PlateButton = new Color(.32f, .24f, .11f, 1f);
        private static readonly Color PlateHint = new Color(.90f, .82f, .62f, 1f);
        private static readonly Color ListPanel = new Color(.09f, .12f, .21f, 1f);
        private static readonly Color ListBorder = new Color(.35f, .50f, .80f, .70f);
        private static readonly Color ListHead = new Color(.62f, .76f, 1f, 1f);

        private static readonly string[] Scripts =
        {
            "Runtime/TitleManager.cs", "Runtime/TitleTriggerBase.cs", "Runtime/TitleArea.cs", "Runtime/TitleAction.cs",
            "Runtime/TitleGate.cs", "Runtime/TitleCounter.cs", "Runtime/TitleBoard.cs", "Runtime/TitleNameplates.cs", "Runtime/TitlePopup.cs",
            "Runtime/TitleReset.cs", "Runtime/TitleRoster.cs", "Runtime/TitlePerk.cs", "Runtime/TitleRelay.cs", "Runtime/TitleAllOf.cs", "Runtime/TitleNotebook.cs",
            "Runtime/TitleSeat.cs", "Runtime/TitleTouch.cs",
        };

        [MenuItem("World Title Gimmick/シーンに称号システムを置く（Add Title System To Scene）")]
        public static void AddToScene()
        {
            if (!EnsurePrograms()) return;
            TitleManager manager = Object.FindObjectOfType<TitleManager>(true);
            Transform root;
            if (manager == null)
            {
                root = new GameObject("World Title Gimmick").transform;
                SceneView view = SceneView.lastActiveSceneView;
                if (view != null) root.position = new Vector3(view.pivot.x, 0f, view.pivot.z);
                Undo.RegisterCreatedObjectUndo(root.gameObject, "Add Title System");
                var holder = new GameObject("Title Manager");
                holder.transform.SetParent(root, false);
                manager = holder.AddUdonSharpComponent<TitleManager>();
                manager.databaseGuid = AssetDatabase.AssetPathToGUID(EnsureUserTable());
            }
            else
            {
                root = manager.transform.parent != null ? manager.transform.parent : manager.transform;
                foreach (string name in new[] { "Title Board", "Title Nameplates", "Title Popup", "Title Board (Portable)", "Title Notebook", "Title Touch" })
                {
                    Transform old = root.Find(name);
                    if (old != null) Object.DestroyImmediate(old.gameObject);
                }
            }
            manager.popup = Popup(root);
            Nameplates(root, manager);
            Board(root, manager);
            Notebook(root, manager);
            Touch(root, manager);
            UdonSharpEditorUtility.CopyProxyToUdon(manager);
            TitleBake.Bake(manager, true);
            EditorSceneManager.MarkSceneDirty(manager.gameObject.scene);
            Selection.activeGameObject = manager.gameObject;
            Debug.Log("[World Title Gimmick] シーンに称号の仕組みを置きました。称号ボードの位置を動かし、シーンを保存してください。", manager);
        }

        // ---- Program Asset ----

        public static bool EnsurePrograms()
        {
            Directory.CreateDirectory(ProgramsFolder);
            AssetDatabase.Refresh();
            bool created = false;
            foreach (string relative in Scripts)
                if (!EnsureProgram(Root + "/" + relative, ref created)) return false;
            if (created)
            {
                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
            }
            UdonSharp.Compiler.UdonSharpCompilerV1.CompileSync();
            return true;
        }

        // 1つのスクリプトの Program Asset を用意する（なければ Programs に作る）。コンパイルされていなければ false。
        public static bool EnsureProgram(string path, ref bool created)
        {
            Directory.CreateDirectory(ProgramsFolder);
            MonoScript script = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
            if (script == null || script.GetClass() == null)
            {
                EditorUtility.DisplayDialog("World Title Gimmick", "スクリプトがまだコンパイルされていません：" + path + "\nコンパイルが終わってからもう一度実行してください。", "OK");
                return false;
            }
            foreach (string guid in AssetDatabase.FindAssets("t:UdonSharpProgramAsset"))
            {
                var existing = AssetDatabase.LoadAssetAtPath<UdonSharpProgramAsset>(AssetDatabase.GUIDToAssetPath(guid));
                if (existing != null && existing.sourceCsScript == script) return true;
            }
            var program = ScriptableObject.CreateInstance<UdonSharpProgramAsset>();
            program.sourceCsScript = script;
            program.ScriptVersion = UdonSharpProgramVersion.CurrentVersion;
            AssetDatabase.CreateAsset(program, AssetDatabase.GenerateUniqueAssetPath(ProgramsFolder + "/" + script.name + ".asset"));
            created = true;
            return true;
        }

        // ---- 見本の称号の表 ----

        // 使う人の称号の表（Assets/WorldTitleGimmickData/Titles.asset）。なければ、パッケージの見本の表を写して作る。
        // 見本の表もないとき（消してしまったときなど）は、コードで同じ中身を作る。
        public static string EnsureUserTable()
        {
            if (AssetDatabase.LoadAssetAtPath<TitleDatabase>(UserTablePath) != null) return UserTablePath;
            EnsureFolder(UserRoot);
            if (AssetDatabase.LoadAssetAtPath<TitleDatabase>(SamplePath) != null && AssetDatabase.CopyAsset(SamplePath, UserTablePath))
            {
                AssetDatabase.ImportAsset(UserTablePath, ImportAssetOptions.ForceSynchronousImport);
                return UserTablePath;
            }
            var db = ScriptableObject.CreateInstance<TitleDatabase>();
            void Add(string key, string word, string wordEn, string before, string after, string condition, TitleDatabase.NameMode mode = TitleDatabase.NameMode.見せる)
            {
                db.rows.Add(new TitleDatabase.Row { key = key, word = word, wordEn = wordEn, descBefore = before, descAfter = after, condition = condition, nameMode = mode });
            }
            void Connector(string key, string word)
            {
                db.rows.Add(new TitleDatabase.Row { key = key, kind = TitleDatabase.Kind.接続語, word = word, wordEn = word == "（空白）" ? "（空白）" : "" });
            }
            Add("first_visit", "はじめまして", "Newcomer", "", "このワールドに初めて来た", "stat:visits>=1");
            Add("regular", "常連", "Regular", "", "3日来た", "stat:visit_days>=3");
            Add("jumper", "跳ねる人", "Jumper", "？？？を10回する", "ジャンプを10回する", "stat:jumps>=10", TitleDatabase.NameMode.隠す);
            Add("comeback", "出直し名人", "Respawner", "", "3回リスポーンする", "stat:respawns>=3");
            Add("walker", "散歩好き", "Walker", "", "200 m歩く", "stat:walk_m>=200");
            Add("crowd", "にぎやか", "Party Person", "", "2人以上で一緒にいる", "stat:crowd_max>=2");
            Add("button10", "押したがり", "Button Masher", "", "ボタンを10回押す（カウンター button）", "count:button>=10");
            Add("area_enter", "探検家", "Explorer", "どこかに行く", "指定のエリアに入る（称号エリアで渡す）", "");
            Add("area_stay", "長居", "Lingerer", "", "指定のエリアに10秒いる（称号エリアで渡す）", "");
            Add("grabber", "つかみ屋", "Grabber", "", "指定の物を5回掴む（称号アクションで渡す）", "");
            Add("thrower", "投手", "Pitcher", "", "指定の物を投げる（称号アクションで渡す）", "");
            Add("secret", "隠し部屋の主", "Secret Keeper", "", "隠し部屋を見つける", "", TitleDatabase.NameMode.一覧に出さない);
            Add("collector", "称号コレクター", "Collector", "", "称号を5つ集める", "owned>=5");
            Connector("no", "の");
            Connector("star", "☆");
            Connector("dot", "・");
            Connector("space", "（空白）");
            Connector("blackstar", "★");
            Connector("wave", "〜");
            db.rows.Add(new TitleDatabase.Row { key = "crown", kind = TitleDatabase.Kind.接続語, word = "♛", lockedConnector = true,
                descBefore = "？？？", descAfter = "称号を3つ集めると使える", condition = "owned>=3", nameMode = TitleDatabase.NameMode.隠す });
            db.AssignIds();
            AssetDatabase.CreateAsset(db, UserTablePath);
            AssetDatabase.SaveAssets();
            return UserTablePath;
        }

        // ---- UI 部品 ----

        public static Transform Canvas(Transform parent, string name, Vector2 size, float scale, bool interactive)
        {
            var obj = new GameObject(name, typeof(RectTransform), typeof(Canvas), typeof(Image));
            obj.layer = LayerMask.NameToLayer("Default");
            obj.transform.SetParent(parent, false);
            obj.transform.localScale = Vector3.one * scale;
            obj.GetComponent<RectTransform>().sizeDelta = size;
            obj.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            obj.GetComponent<Image>().color = Navy;
            if (interactive)
            {
                obj.AddComponent<GraphicRaycaster>();
                obj.AddComponent<VRCUiShape>();
                BoxCollider collider = obj.GetComponent<BoxCollider>();
                if (collider == null) collider = obj.AddComponent<BoxCollider>();
                collider.center = Vector3.zero;
                collider.size = new Vector3(size.x, size.y, 2);
                collider.isTrigger = true;
            }
            return obj.transform;
        }

        // 左上を (0,0) にした位置で置く。
        private static RectTransform Rect(Transform parent, string name, float x, float y, float w, float h)
        {
            var obj = new GameObject(name, typeof(RectTransform));
            obj.layer = parent.gameObject.layer;
            var rect = obj.GetComponent<RectTransform>();
            rect.SetParent(parent, false);
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = new Vector2(x, -y);
            rect.sizeDelta = new Vector2(w, h);
            return rect;
        }

        // fit：文字が入りきらないとき小さくする（Best Fit）。文字を変えるたびに大きさを試し直す重い処理なので、
        // 大きさが決まっている文字（見出し・ボタンの短い文字）では外す。
        public static Text Label(Transform parent, string name, string text, float x, float y, float w, float h, int size, TextAnchor anchor = TextAnchor.MiddleCenter, bool fit = true)
        {
            var rect = Rect(parent, name, x, y, w, h);
            var label = rect.gameObject.AddComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.fontSize = size;
            label.text = text;
            label.color = Color.white;
            label.supportRichText = true;
            label.raycastTarget = false;
            label.alignment = anchor;
            label.horizontalOverflow = HorizontalWrapMode.Wrap;
            label.verticalOverflow = VerticalWrapMode.Truncate;
            label.resizeTextForBestFit = fit;
            label.resizeTextMinSize = 10;
            label.resizeTextMaxSize = size;
            return label;
        }

        private static readonly List<Button> buttons = new List<Button>();
        private static readonly List<int> kinds = new List<int>();
        private static readonly List<int> indexes = new List<int>();

        // ボタン1つ。Udon はボタンに付けず、ボードの1つで受ける（クリック：自分の Button を無効に → ボードの _Clicked）。
        private static Button Press(Transform parent, TitleBoard board, string name, float x, float y, float w, float h, string text, int size,
            int kind, int index, out Image frame, out Text caption, bool fit = true)
        {
            RectTransform rect = Rect(parent, name, x, y, w, h);
            frame = rect.gameObject.AddComponent<Image>();
            frame.color = Card;
            var button = rect.gameObject.AddComponent<Button>();
            button.targetGraphic = frame;
            var navigation = button.navigation;
            navigation.mode = Navigation.Mode.None;
            button.navigation = navigation;
            caption = Label(rect, "Caption", text, 4, 2, w - 8, h - 4, size, TextAnchor.MiddleCenter, fit);
            var disable = (UnityEngine.Events.UnityAction<bool>)System.Delegate.CreateDelegate(typeof(UnityEngine.Events.UnityAction<bool>), button, "set_enabled");
            UnityEventTools.AddBoolPersistentListener(button.onClick, disable, false);
            var back = UdonSharpEditorUtility.GetBackingUdonBehaviour(board);
            UnityEventTools.AddStringPersistentListener(button.onClick, back.SendCustomEvent, "_Clicked");
            buttons.Add(button);
            kinds.Add(kind);
            indexes.Add(index);
            return button;
        }

        // ボードの中の子の Canvas（板と同じ大きさ。左上をそろえるので、中の部品の位置はそのまま）。
        // ボタンを押せるよう、子の Canvas にも GraphicRaycaster を付ける（VRCUiShape と当たり判定は親の板だけ）。
        private static Transform SubCanvas(Transform panel, string name, Vector2 size)
        {
            RectTransform rect = Rect(panel, name, 0, 0, size.x, size.y);
            rect.gameObject.AddComponent<Canvas>();
            rect.gameObject.AddComponent<GraphicRaycaster>();
            return rect;
        }

        // 区画の地（縁の色の板の上に、2px 内側へ地の色の板を重ねる）。押せない（当たり判定を取らない）。
        private static void Section(Transform parent, string name, float x, float y, float w, float h, Color border, Color fill)
        {
            RectTransform edge = Rect(parent, name, x, y, w, h);
            var edgeImage = edge.gameObject.AddComponent<Image>();
            edgeImage.color = border;
            edgeImage.raycastTarget = false;
            RectTransform inner = Rect(edge, "Fill", 2, 2, w - 4, h - 4);
            var innerImage = inner.gameObject.AddComponent<Image>();
            innerImage.color = fill;
            innerImage.raycastTarget = false;
        }

        // ---- 称号ボード（1200×900px、縮尺0.002＝2.4m×1.8m） ----

        // name を変えると、同じシーンにボードをいくつも置ける（見本のシーンで使う）。
        // closable なら下に「閉じる」ボタンを足す（持ち運び用のボード）。
        public static Transform Board(Transform root, TitleManager manager, string name = "Title Board", bool closable = false)
        {
            buttons.Clear(); kinds.Clear(); indexes.Clear();
            Transform panel = Canvas(root, name, new Vector2(1200, closable ? 970 : 900), .002f, true);
            panel.localPosition = new Vector3(0, 1.5f, 0);
            TitleBoard board = panel.gameObject.AddUdonSharpComponent<TitleBoard>();
            board.manager = manager;
            // 文字を1つ変えると、その文字のある Canvas 全体を作り直すので、上の帯・一覧・肩書きの3つに分ける。
            Vector2 full = panel.GetComponent<RectTransform>().sizeDelta;
            Transform header = SubCanvas(panel, "Header", full);
            Transform list = SubCanvas(panel, "List", full);
            Transform plate = SubCanvas(panel, "Plate", full);
            board.titleText = Label(header, "Title", "称号", 30, 10, 300, 56, 40, TextAnchor.MiddleLeft, false);
            board.titleText.color = Gold;
            board.ownedText = Label(header, "Owned", "", 230, 10, 210, 56, 28);
            Press(header, board, "Language", 450, 12, 180, 52, "", 20, TitleBoard.PressLanguage, 0, out _, out board.languageText);
            Press(header, board, "Nameplate", 640, 12, 260, 52, "", 22, TitleBoard.PressNameplate, 0, out _, out board.nameplateText);
            Press(header, board, "My Plate", 910, 12, 260, 52, "", 22, TitleBoard.PressMyPlate, 0, out _, out board.myPlateText);

            // 肩書きの区画（設定。2026-10-28 に上へ移し、暖色にした。見取り図：Docs/UI/01_Board.svg）
            Section(plate, "Plate Area", 15, 78, 1170, 300, PlateBorder, PlatePanel);
            board.plateLabel = Label(plate, "Plate Label", "肩書きの設定", 30, 88, 220, 34, 28, TextAnchor.MiddleLeft, false);
            board.plateLabel.color = Gold;
            board.plateLabel.fontStyle = FontStyle.Bold;
            board.plateHintText = Label(plate, "Plate Hint", "", 250, 88, 920, 34, 18, TextAnchor.MiddleLeft);
            board.plateHintText.color = PlateHint;
            board.previewText = Label(plate, "Preview", "", 30, 126, 1140, 46, 30);
            board.previewText.color = Gold;
            board.slotRoots = new GameObject[TitleManager.SlotCount];
            board.slotTexts = new Text[TitleManager.SlotCount];
            board.slotTypeTexts = new Text[TitleManager.SlotCount];
            board.slotImages = new Image[TitleManager.SlotCount];
            for (int i = 0; i < TitleManager.SlotCount; i++)
            {
                Button slot = Press(plate, board, "Slot " + i, 35 + i * 113, 180, 105, 60, "", 22, TitleBoard.PressSlot, i, out board.slotImages[i], out board.slotTexts[i]);
                board.slotImages[i].color = PlateButton;
                board.slotRoots[i] = slot.gameObject;
                board.slotTypeTexts[i] = Label(slot.transform, "Type", "", 0, 62, 105, 20, 16);
                board.slotTypeTexts[i].color = new Color(.7f, .74f, .82f);
            }
            board.countText = Label(plate, "Count", "", 30, 268, 300, 30, 20, TextAnchor.MiddleLeft, false);
            board.statusText = Label(plate, "Status", "", 340, 268, 830, 30, 20, TextAnchor.MiddleRight);
            board.statusText.color = PlateHint;
            Press(plate, board, "Apply", 30, 306, 360, 58, "", 28, TitleBoard.PressApply, 0, out board.applyImage, out board.applyText, false);
            board.applyImage.color = PlateButton;
            Press(plate, board, "Revert", 420, 306, 360, 58, "", 28, TitleBoard.PressRevert, 0, out Image revert, out board.revertText, false);
            revert.color = PlateButton;
            Press(plate, board, "Clear", 810, 306, 360, 58, "", 28, TitleBoard.PressClear, 0, out Image clear, out board.clearText, false);
            clear.color = PlateButton;

            // 称号一覧の区画（寒色）。絞り込み・ページ送りは見出しの行に置く。
            Section(list, "List Area", 15, 390, 1170, 474, ListBorder, ListPanel);
            board.listLabel = Label(list, "List Label", "称号一覧", 30, 400, 160, 46, 28, TextAnchor.MiddleLeft, false);
            board.listLabel.color = ListHead;
            board.listLabel.fontStyle = FontStyle.Bold;
            board.filterTexts = new Text[3];
            board.filterImages = new Image[3];
            for (int i = 0; i < 3; i++)
                Press(list, board, "Filter " + i, 200 + i * 98, 400, 92, 46, "", 22, TitleBoard.PressFilter, i, out board.filterImages[i], out board.filterTexts[i]);
            Press(list, board, "Prev", 780, 400, 130, 46, "", 24, TitleBoard.PressPrev, 0, out _, out board.prevText, false);
            board.pageText = Label(list, "Page", "", 915, 400, 110, 46, 24, TextAnchor.MiddleCenter, false);
            Press(list, board, "Next", 1030, 400, 140, 46, "", 24, TitleBoard.PressNext, 0, out _, out board.nextText, false);
            const int columns = 6, rows = 4;
            board.cardTexts = new Text[columns * rows];
            board.cardImages = new Image[columns * rows];
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < columns; c++)
                {
                    int i = r * columns + c;
                    Press(list, board, "Card " + i, 30 + c * 190, 456 + r * 70, 180, 60, "", 24, TitleBoard.PressCard, i, out board.cardImages[i], out board.cardTexts[i], false);
                }
            board.descText = Label(list, "Desc", "", 30, 744, 1140, 40, 24, TextAnchor.MiddleLeft);
            board.descText.color = new Color(.85f, .88f, .95f);

            board.connectorsLabel = Label(list, "Connectors Label", "接続語", 30, 794, 90, 56, 22, TextAnchor.MiddleLeft);
            board.connectorsLabel.color = ListHead;
            const int connectorCount = 10;
            board.connectorTexts = new Text[connectorCount];
            board.connectorImages = new Image[connectorCount];
            Press(list, board, "Connector Prev", 125, 794, 50, 56, "◀", 24, TitleBoard.PressConnectorPrev, 0, out _, out _, false);
            for (int i = 0; i < connectorCount; i++)
                Press(list, board, "Connector " + i, 182 + i * 95, 794, 88, 56, "", 22, TitleBoard.PressConnector, i, out board.connectorImages[i], out board.connectorTexts[i], false);
            Press(list, board, "Connector Next", 1132, 794, 48, 56, "▶", 24, TitleBoard.PressConnectorNext, 0, out _, out _, false);
            if (closable)
            {
                Press(plate, board, "Close", 450, 890, 300, 60, "", 28, TitleBoard.PressClose, 0, out _, out board.closeText, false);
                board.closeRoot = panel.gameObject;
            }

            board.pressButtons = buttons.ToArray();
            board.pressKinds = kinds.ToArray();
            board.pressIndexes = indexes.ToArray();
            UdonSharpEditorUtility.CopyProxyToUdon(board);
            return panel;
        }

        // ---- 称号の手帳と、持ち運び用のボード（2026-10-28） ----

        // 手帳（Pickup）をボードの横に置き、使うと目の前に出す持ち運び用のボード（初めは消えている）を作る。
        public static TitleNotebook Notebook(Transform root, TitleManager manager)
        {
            Transform portable = Board(root, manager, "Title Board (Portable)", true);
            portable.localScale = Vector3.one * .0012f;
            GameObject book = GameObject.CreatePrimitive(PrimitiveType.Cube);
            book.name = "Title Notebook";
            book.transform.SetParent(root, false);
            book.transform.localPosition = new Vector3(1.6f, 1.0f, 0);
            book.transform.localScale = new Vector3(.18f, .03f, .25f);
            var body = book.AddComponent<Rigidbody>();
            body.isKinematic = true;
            body.useGravity = false;
            var pickup = book.AddComponent<VRCPickup>();
            pickup.AutoHold = VRC.SDKBase.VRC_Pickup.AutoHoldMode.Yes;
            pickup.InteractionText = "称号の手帳";
            pickup.UseText = "ボードを出す・消す";
            TitleNotebook notebook = book.AddUdonSharpComponent<TitleNotebook>();
            notebook.manager = manager;
            notebook.board = portable.gameObject;
            UdonSharpEditorUtility.CopyProxyToUdon(notebook);
            portable.gameObject.SetActive(false);
            return notebook;
        }

        // ---- 撫でる・ハイタッチの受け手（2026-10-28） ----

        // 頭と左右の手に付いていくコンタクトの受け手。撫でる・ハイタッチを称号の条件に使っていなければ、Play で消える。
        private static void Touch(Transform root, TitleManager manager)
        {
            var holder = new GameObject("Title Touch");
            holder.transform.SetParent(root, false);
            TouchPart(holder.transform, manager, "Head", TitleTouch.PartHead, .12f, new[] { "Hand", "HandL", "HandR", "Finger", "FingerL", "FingerR" });
            TouchPart(holder.transform, manager, "Left Hand", TitleTouch.PartLeftHand, .07f, new[] { "Head", "Hand", "HandL", "HandR" });
            TouchPart(holder.transform, manager, "Right Hand", TitleTouch.PartRightHand, .07f, new[] { "Head", "Hand", "HandL", "HandR" });
        }

        private static void TouchPart(Transform parent, TitleManager manager, string name, int part, float radius, string[] tags)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            var receiver = obj.AddComponent<VRCContactReceiver>();
            receiver.shapeType = VRC.Dynamics.ContactBase.ShapeType.Sphere;
            receiver.radius = radius;
            receiver.collisionTags = new List<string>(tags);
            // ほかの人のアバターのコンタクトだけを受ける（自分の体は受けない）。
            receiver.allowSelf = false;
            receiver.allowOthers = true;
            receiver.localOnly = true;
            receiver.contentTypes = VRC.Dynamics.DynamicsUsageFlags.Avatar;
            receiver.receiverType = VRC.Dynamics.ContactReceiver.ReceiverType.OnEnter;
            TitleTouch touch = obj.AddUdonSharpComponent<TitleTouch>();
            touch.manager = manager;
            touch.part = part;
            UdonSharpEditorUtility.CopyProxyToUdon(touch);
        }

        // ---- 席（2026-10-28） ----

        // シーンの全部の席（VRC Station）に TitleSeat を付ける（付いていない席だけ）。
        // メニューには置かず、シーンの点検で「座った回数・時間を使っているのに席の部品がない」ときのボタンから呼ぶ（2026-10-28、ユーザー指定）。
        public static void AddSeatCounters()
        {
            bool created = false;
            if (!EnsureProgram(Root + "/Runtime/TitleSeat.cs", ref created)) return;
            if (created) { AssetDatabase.SaveAssets(); AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport); }
            TitleManager manager = Object.FindObjectOfType<TitleManager>(true);
            int added = 0;
            foreach (VRCStation station in Object.FindObjectsOfType<VRCStation>(true))
            {
                if (station.GetComponent<TitleSeat>() != null) continue;
                Undo.RecordObject(station.gameObject, "席の部品を付ける");
                TitleSeat seat = station.gameObject.AddUdonSharpComponent<TitleSeat>();
                seat.manager = manager;
                UdonSharpEditorUtility.CopyProxyToUdon(seat);
                added++;
            }
            if (added > 0) EditorSceneManager.MarkSceneDirty(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
            EditorUtility.DisplayDialog("World Title Gimmick", added > 0 ? added + " 個の席に TitleSeat を付けました。シーンを保存してください。" : "TitleSeat を付ける席はありませんでした（もう付いているか、席がありません）。", "OK");
        }

        // ---- いまいる人の肩書きの一覧ボード（2026-10-28） ----

        // 1000×(90+行×50)px、縮尺0.002。parent の下に作り、TitleRoster を付けて返す。
        public static TitleRoster Roster(Transform parent, TitleManager manager, int rows = 12)
        {
            float height = 90 + rows * 50 + 50;
            Transform panel = Canvas(parent, "Title Roster", new Vector2(1000, height), .002f, false);
            TitleRoster roster = panel.gameObject.AddUdonSharpComponent<TitleRoster>();
            roster.manager = manager;
            roster.titleText = Label(panel, "Title", "", 30, 15, 940, 60, 40, TextAnchor.MiddleLeft);
            roster.titleText.color = Gold;
            roster.lines = new Text[rows];
            for (int i = 0; i < rows; i++)
            {
                roster.lines[i] = Label(panel, "Line " + i, "", 40, 90 + i * 50, 920, 46, 30, TextAnchor.MiddleLeft);
                roster.lines[i].horizontalOverflow = HorizontalWrapMode.Overflow;
            }
            roster.pageText = Label(panel, "Page", "", 30, 90 + rows * 50, 940, 40, 24, TextAnchor.MiddleRight);
            UdonSharpEditorUtility.CopyProxyToUdon(roster);
            return roster;
        }

        // ---- 頭上の名札 ----

        private static void Nameplates(Transform root, TitleManager manager)
        {
            var holder = new GameObject("Title Nameplates");
            holder.transform.SetParent(root, false);
            TitleNameplates plates = holder.AddUdonSharpComponent<TitleNameplates>();
            plates.manager = manager;
            plates.roots = new GameObject[NameplateCount];
            plates.labels = new Text[NameplateCount];
            for (int i = 0; i < NameplateCount; i++)
            {
                Transform panel = Canvas(holder.transform, "Nameplate " + i, new Vector2(900, 110), .0006f, false);
                panel.GetComponent<Image>().color = new Color(.06f, .08f, .13f, .85f);
                Text label = Label(panel, "Plate", "", 10, 5, 880, 100, 56);
                label.fontStyle = FontStyle.Bold;
                label.resizeTextForBestFit = false;
                label.horizontalOverflow = HorizontalWrapMode.Wrap;
                plates.roots[i] = panel.gameObject;
                plates.labels[i] = label;
                panel.gameObject.SetActive(false);
            }
            UdonSharpEditorUtility.CopyProxyToUdon(plates);
        }

        // ---- 獲得の知らせ ----

        private static TitlePopup Popup(Transform root)
        {
            var holder = new GameObject("Title Popup");
            holder.transform.SetParent(root, false);
            TitlePopup popup = holder.AddUdonSharpComponent<TitlePopup>();
            // 1000×330px（縮尺0.0004＝0.4m×0.13m）：見出し・称号・取得条件の3行。
            Transform panel = Canvas(holder.transform, "Panel", new Vector2(1000, 330), .0004f, false);
            Text headline = Label(panel, "Headline", "", 20, 15, 960, 70, 46);
            headline.color = Gold;
            headline.fontStyle = FontStyle.Bold;
            Text words = Label(panel, "Words", "", 20, 90, 960, 120, 64);
            words.fontStyle = FontStyle.Bold;
            Text desc = Label(panel, "Desc", "", 20, 220, 960, 95, 34);
            desc.color = new Color(.85f, .88f, .95f);
            popup.desc = desc;
            var audio = holder.AddComponent<AudioSource>();
            audio.playOnAwake = false;
            audio.spatialBlend = 0f;
            popup.root = panel.gameObject;
            popup.headline = headline;
            popup.words = words;
            popup.audioSource = audio;
            panel.gameObject.SetActive(false);
            UdonSharpEditorUtility.CopyProxyToUdon(popup);
            return popup;
        }
    }
}
