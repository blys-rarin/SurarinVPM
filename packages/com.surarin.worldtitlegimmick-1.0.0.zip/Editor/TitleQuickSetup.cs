using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEngine;
using VRC.SDK3.Components;

namespace WorldTitleGimmick.EditorTools
{
    // Hierarchy の右クリック（GameObject メニュー）の「World Title Gimmick」（2026-10-28、ユーザー指摘「掴むオブジェクトに対してどのコンポーネントを付ければいいかすぐに判別がつかない」）。
    // やりたいことの言葉で選ぶと、合う部品を付け、足りない部品（コライダー・Pickup・Rigidbody）も付けて、よく使う設定を入れる。
    // 物を選んでいないときは、新しい物を作って付ける（エリア・ボタンなど）。
    public static class TitleQuickSetup
    {
        private const string Menu = "GameObject/World Title Gimmick/";
        private const int Order = 20;

        [MenuItem(Menu + "掴んだら称号を渡す", false, Order)]
        private static void Grab(MenuCommand command) { AddAction(command, TitleAction.ActGrab, "掴む物"); }

        [MenuItem(Menu + "持って使ったら（トリガー）称号を渡す", false, Order + 1)]
        private static void Use(MenuCommand command) { AddAction(command, TitleAction.ActUse, "使う物"); }

        [MenuItem(Menu + "投げたら称号を渡す", false, Order + 2)]
        private static void Throw(MenuCommand command) { AddAction(command, TitleAction.ActThrow, "投げる物"); }

        [MenuItem(Menu + "触ったら（Interact）称号を渡す", false, Order + 3)]
        private static void Touch(MenuCommand command) { AddAction(command, TitleAction.ActInteract, "触る物"); }

        [MenuItem(Menu + "押した回数で称号を渡す（カウンター）", false, Order + 4)]
        private static void Counter(MenuCommand command)
        {
            GameObject target = Target(command, "ボタン", true);
            EnsureCollider(target, false);
            var counter = target.AddUdonSharpComponent<TitleCounter>();
            counter.manager = Manager();
            counter.counterKey = KeyName(target.name);
            counter.steps = new[] { 10 };
            counter.stepKeys = new[] { "" };
            Done(counter, "押すたびに数えます。インスペクターで回数と渡す称号を選んでください。");
        }

        [MenuItem(Menu + "エリアに入ったら称号を渡す", false, Order + 20)]
        private static void EnterArea(MenuCommand command)
        {
            GameObject target = Target(command, "称号エリア", false);
            EnsureCollider(target, true);
            var area = target.AddUdonSharpComponent<TitleArea>();
            area.manager = Manager();
            area.who = TitleArea.WhoPlayer;
            Done(area, "プレイヤーが入ったら渡します。インスペクターで渡す称号を選んでください。");
        }

        [MenuItem(Menu + "エリアに物を置いたら称号を渡す", false, Order + 21)]
        private static void PlaceArea(MenuCommand command)
        {
            GameObject target = Target(command, "物を置くエリア", false);
            EnsureCollider(target, true);
            var area = target.AddUdonSharpComponent<TitleArea>();
            area.manager = Manager();
            area.who = TitleArea.WhoObjects;
            Done(area, "「入る物」に置く物（Pickup）を入れ、渡す称号を選んでください。");
        }

        [MenuItem(Menu + "称号を持つ人だけに見せる・触れさせる", false, Order + 40)]
        private static void ShowGate(MenuCommand command)
        {
            GameObject target = Target(command, "称号で見える物", true);
            var gate = target.AddUdonSharpComponent<TitleGate>();
            gate.manager = Manager();
            gate.renderers = target.GetComponentsInChildren<Renderer>(true);
            gate.colliders = target.GetComponentsInChildren<Collider>(true);
            Done(gate, "条件の称号を選んでください。持っている人の画面でだけ見え、当たり判定もあります。");
        }

        [MenuItem(Menu + "称号を持つ人だけ通れる壁にする", false, Order + 41)]
        private static void WallGate(MenuCommand command)
        {
            GameObject target = Target(command, "称号の扉", true);
            EnsureCollider(target, false);
            var gate = target.AddUdonSharpComponent<TitleGate>();
            gate.manager = Manager();
            // 反転：条件を満たした人の画面では、見た目と当たり判定を消す（物は有効のままなので、称号を外すと壁が戻る）。
            gate.invert = true;
            gate.renderers = target.GetComponentsInChildren<Renderer>(true);
            gate.colliders = target.GetComponentsInChildren<Collider>(true);
            Done(gate, "条件の称号を選んでください。持っている人（装備で判定するなら「条件」を装備に）の画面でだけ、壁が消えて通れます。");
        }

        [MenuItem(Menu + "称号を装備したら速く動ける・高く跳べるようにする", false, Order + 42)]
        private static void Perk(MenuCommand command)
        {
            GameObject target = Target(command, "称号の効果", false, false);
            var perk = target.AddUdonSharpComponent<TitlePerk>();
            perk.manager = Manager();
            Done(perk, "条件の称号を選び、効果（速さ・ジャンプ力・重力）を選んでください。装備した本人だけに効きます。");
        }

        [MenuItem(Menu + "称号をもらったら Udon Graph へイベントを送る", false, Order + 43)]
        private static void Relay(MenuCommand command)
        {
            GameObject target = Target(command, "称号イベント中継", false, false);
            var relay = target.AddUdonSharpComponent<TitleRelay>();
            relay.manager = Manager();
            Done(relay, "送り先（Udon Graph の付いた物）と、送るイベントの名前を入れてください。初期値はもらったときに「OnTitleGranted」です。");
        }

        [MenuItem(Menu + "いくつかのきっかけを全部満たしたら称号を渡す（条件まとめ）", false, Order + 22)]
        private static void AllOf(MenuCommand command)
        {
            GameObject target = Target(command, "条件まとめ", false, false);
            var all = target.AddUdonSharpComponent<TitleAllOf>();
            all.manager = Manager();
            all.saveKey = KeyName(target.name) == "counter" ? "allof" : KeyName(target.name);
            Done(all, "「まとめる部品」に称号エリア・称号アクションなどを入れ、渡す称号を選んでください。全部の部品が動いたら渡します。");
        }

        [MenuItem(Menu + "いまいる人の肩書きの一覧ボードを置く", false, Order + 50)]
        private static void Roster(MenuCommand command)
        {
            Transform parent = command.context is GameObject picked ? picked.transform : null;
            TitleRoster roster = TitleSystemBuilder.Roster(parent, Manager());
            if (parent == null)
            {
                SceneView view = SceneView.lastActiveSceneView;
                roster.transform.position = view != null ? view.pivot + Vector3.up * 1.5f : new Vector3(0, 1.5f, 0);
            }
            Undo.RegisterCreatedObjectUndo(roster.gameObject, "World Title Gimmick");
            Done(roster, "部屋にいる人の名前と肩書きを並べます。置き場所を動かしてください（ほかの人が「自分の名札：見せない」にしていたら、肩書きは出ません）。");
        }

        [MenuItem(Menu + "やり直しのボタンにする", false, Order + 60)]
        private static void Reset(MenuCommand command)
        {
            GameObject target = Target(command, "やり直しボタン", true);
            EnsureCollider(target, false);
            var reset = target.AddUdonSharpComponent<TitleReset>();
            reset.manager = Manager();
            Done(reset, "3秒以内に2回押すと、押した人の称号を全部やり直します。");
        }

        // ---- 共通 ----

        private static void AddAction(MenuCommand command, int action, string newName)
        {
            GameObject target = Target(command, newName, true);
            if (action == TitleAction.ActInteract) EnsureCollider(target, false);
            else EnsurePickup(target);
            var component = target.AddUdonSharpComponent<TitleAction>();
            component.manager = Manager();
            component.action = action;
            Done(component, "インスペクターで渡す称号を選んでください。回数を増やすときは「回数」を変えます。");
        }

        // 右クリックした物（なければ選んでいる物）。どちらもなければ新しく作る（cube なら箱、そうでなければ空の物）。
        private static GameObject Target(MenuCommand command, string newName, bool cube, bool bigEmpty = true)
        {
            GameObject target = command.context as GameObject;
            if (target == null) target = Selection.activeGameObject;
            if (target != null) return target;
            target = cube ? GameObject.CreatePrimitive(PrimitiveType.Cube) : new GameObject();
            target.name = newName;
            SceneView view = SceneView.lastActiveSceneView;
            if (view != null) target.transform.position = view.pivot;
            if (!cube && bigEmpty) target.transform.localScale = new Vector3(3f, 3f, 3f);
            Undo.RegisterCreatedObjectUndo(target, "World Title Gimmick");
            return target;
        }

        private static void EnsureCollider(GameObject target, bool trigger)
        {
            foreach (Collider c in target.GetComponents<Collider>()) if (c.isTrigger == trigger) return;
            var box = Undo.AddComponent<BoxCollider>(target);
            box.isTrigger = trigger;
        }

        // 掴める物にする：コライダー・Rigidbody・VRC Pickup が足りなければ足す。
        private static void EnsurePickup(GameObject target)
        {
            if (target.GetComponent<Collider>() == null) Undo.AddComponent<BoxCollider>(target);
            if (target.GetComponent<Rigidbody>() == null) Undo.AddComponent<Rigidbody>(target);
            if (target.GetComponent<VRCPickup>() == null) Undo.AddComponent<VRCPickup>(target);
        }

        private static TitleManager Manager() { return Object.FindObjectOfType<TitleManager>(true); }

        private static string KeyName(string name)
        {
            var chars = new System.Text.StringBuilder();
            foreach (char ch in name.ToLowerInvariant()) if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '_') chars.Append(ch);
            return chars.Length > 0 ? chars.ToString() : "counter";
        }

        private static void Done(UdonSharpBehaviour behaviour, string message)
        {
            UdonSharpEditorUtility.CopyProxyToUdon(behaviour);
            EditorUtility.SetDirty(behaviour);
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(behaviour.gameObject.scene);
            Selection.activeGameObject = behaviour.gameObject;
            if (Manager() == null) message += "\nシーンに TitleManager がありません。先に「World Title Gimmick/シーンに称号システムを置く」を実行してください。";
            Debug.Log("[World Title Gimmick] " + behaviour.gameObject.name + "：" + message, behaviour);
        }
    }
}
