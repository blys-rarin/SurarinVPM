using System.Collections.Generic;
using System.IO;
using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using VRC.SDK3.Components;
using VRC.Udon;
using WorldTitleGimmick.Examples;

namespace WorldTitleGimmick.EditorTools
{
    // 「World Title Gimmick/Build Example Scene」（2026-10-28、ユーザー指定）：説明書 03 の例を全部試せる見本のシーンを作る。
    // Cube などの基本の形と SDK の VRCWorld だけで作る（購入したアセットは使わない。配布物に入れるため）。
    // 章ごとに1列、例ごとに1区画（床・看板・物・部品）。前提の称号が要る例には「もらう」「外す」ボタンを置く。
    // 秒数・回数は試しやすい小さな数にしてある（看板に書く）。専用の称号の表 ExampleTitles.asset も作る。
    public static class TitleExampleScene
    {
        // パッケージに入っている見本（スクリプト・設定の画像）。
        private const string PackageFolder = TitleSystemBuilder.Root + "/Samples/ExampleScene";
        // 作る所：開発用のプロジェクトではパッケージの中（配布物に入れる見本のシーン）、使う人のプロジェクトでは Assets の下。
        private static string Folder => TitleSystemBuilder.IsDevProject ? PackageFolder : TitleSystemBuilder.UserRoot + "/ExampleScene";
        public static string ScenePath => Folder + "/TitleExamples.unity";
        public static string DatabasePath => Folder + "/ExampleTitles.asset";
        private static string MaterialFolder => Folder + "/Materials";
        private const string WorldPrefab = "Packages/com.vrchat.worlds/Samples/UdonExampleScene/Prefabs/VRCWorld.prefab";
        private static readonly string[] SampleScripts = { PackageFolder + "/Scripts/ExampleEventLog.cs", PackageFolder + "/Scripts/ExampleSendEvent.cs", PackageFolder + "/Scripts/ExampleTeleport.cs", PackageFolder + "/Scripts/ExampleSit.cs", PackageFolder + "/Scripts/ExampleRace.cs", PackageFolder + "/Scripts/ExampleGrant.cs" };

        private const float BoothSize = 10f;   // 区画の中身の広さ
        private const float BoothStep = 14f;   // 区画の間隔（右の 4 m に設定の画像の看板を立てる）
        private const float RowStep = 14f;
        // 設定のスクリーンショット（2026-10-28、ユーザー指定「シーンの中に、それぞれの設定のスクリーンショットを入れたい」）。
        // 区画の番号.png（1-1.png）、2枚目からは 1-1_2.png …。ないときは、置くファイル名と撮る物を仮の看板に書く。
        // 画像はパッケージの中から読む。画像のない区画の仮の札と撮る物の一覧（ShotList.txt）は、開発用のプロジェクトだけで作る。
        public const string ShotFolder = PackageFolder + "/Screenshots";
        private const int MaxShots = 4;

        private static TitleManager manager;
        private static Transform sceneRoot;
        private static readonly Dictionary<string, Material> materials = new Dictionary<string, Material>();
        // 列ごとの一番右の区画の番号（右端にワープのボタンを置くため）。
        private static readonly Dictionary<int, int> lastColumn = new Dictionary<int, int>();
        // 作った区画（番号と物）。最後に設定の画像の看板を立てる。
        private static readonly List<KeyValuePair<string, Transform>> booths = new List<KeyValuePair<string, Transform>>();

        [MenuItem("World Title Gimmick/見本のシーンを作る（Build Example Scene・説明書 03 の例）")]
        public static void Build()
        {
            if (File.Exists(ScenePath) && !EditorUtility.DisplayDialog("World Title Gimmick", "見本のシーンを作り直します（" + ScenePath + "）。\n見本のシーンと見本の表（ExampleTitles）を書き換えた分は消えます。", "作り直す", "やめる")) return;
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            bool created = false;
            foreach (string path in SampleScripts) if (!TitleSystemBuilder.EnsureProgram(path, ref created)) return;
            if (created) { AssetDatabase.SaveAssets(); AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport); }
            if (!TitleSystemBuilder.EnsurePrograms()) return;

            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            GameObject camera = GameObject.Find("Main Camera");
            if (camera != null) Object.DestroyImmediate(camera);
            if (TitleSystemBuilder.IsDevProject) Directory.CreateDirectory(MaterialFolder);
            else TitleSystemBuilder.EnsureFolder(MaterialFolder);
            materials.Clear();
            lastColumn.Clear();
            booths.Clear();

            TitleDatabase db = BuildDatabase();
            sceneRoot = new GameObject("Title Examples").transform;
            World();
            Cube(sceneRoot, "Ground", new Vector3(55, -0.5f, 90), new Vector3(165, 1, 230), Mat("Ground", new Color(.32f, .36f, .34f)));

            TitleSystemBuilder.AddToScene();
            manager = Object.FindObjectOfType<TitleManager>(true);
            if (manager == null) return;
            manager.databaseGuid = AssetDatabase.AssetPathToGUID(DatabasePath);
            manager.language = TitleManager.LangAuto;
            // 13E-3：ほかの人が装備している称号は、名前と取得条件を明かす。
            manager.revealEquipped = 2;
            // 4-2：「はじめの一歩」を持つ人と会うと数える。作者の表示名は自分の名前に書き換えて試す。
            manager.holderKeys = new[] { "first_step" };
            manager.creatorNames = new[] { "YourDisplayName" };
            // 10章・15-2：枠 4〜6 は「上級者」で解禁、枠 7〜10 は使わない。
            for (int i = 0; i < TitleManager.SlotCount; i++)
            {
                manager.slotTypes[i] = i >= 6 ? TitleManager.SlotUnused : TitleManager.SlotBoth;
                manager.slotUnlockKeys[i] = i >= 3 && i <= 5 ? "advanced" : "";
            }
            Transform system = manager.transform.parent;
            system.position = Vector3.zero;

            Lobby(system);
            QuickStart(system);
            Chapter15(system);
            Chapter18(system);
            Border();
            StartRoom();
            Chapter1();
            Chapter2();
            Chapter3And7();
            Chapter4And5();
            Chapter6();
            Chapter8a();
            Chapter8b(system);
            Chapter9To12();
            Chapter13(system);
            Chapter19();
            ShotBoards();
            WarpButtons();

            foreach (UdonSharpBehaviour behaviour in Object.FindObjectsOfType<UdonSharpBehaviour>(true))
            {
                UdonSharpEditorUtility.CopyProxyToUdon(behaviour);
                EditorUtility.SetDirty(behaviour);
            }
            TitleBake.Bake(manager, true);
            EditorSceneManager.MarkSceneDirty(scene);
            EditorSceneManager.SaveScene(scene, ScenePath);
            AssetDatabase.SaveAssets();
            Selection.activeGameObject = manager.gameObject;
            Debug.Log("[World Title Gimmick] 見本のシーンを作りました：" + ScenePath + "。Play して、看板の「試し方」のとおりに試してください。");
        }

        // ---- 称号の表 ----

        private static TitleDatabase BuildDatabase()
        {
            AssetDatabase.DeleteAsset(DatabasePath);
            var db = ScriptableObject.CreateInstance<TitleDatabase>();
            void T(string key, string word, string en, string after, string condition = "", TitleDatabase.NameMode mode = TitleDatabase.NameMode.見せる, string before = "")
            {
                db.rows.Add(new TitleDatabase.Row { key = key, word = word, wordEn = en, descAfter = after, condition = condition, nameMode = mode, descBefore = before });
            }
            void C(string key, string word, string en = "", bool locked = false, string condition = "", TitleDatabase.NameMode mode = TitleDatabase.NameMode.見せる, string after = "")
            {
                db.rows.Add(new TitleDatabase.Row { key = key, kind = TitleDatabase.Kind.接続語, word = word, wordEn = en, lockedConnector = locked, condition = condition, nameMode = mode, descAfter = after, descBefore = locked ? "？？？" : "" });
            }
            // はじめの囲い（入室すると自動でもらい、装備すると囲いの壁が消える）
            T("first_step", "はじめの一歩", "First Step", "このワールドに来る（装備すると、はじめの囲いから出られる）", "stat:visits>=1");
            // 1章
            T("rooftop", "屋上の住人", "Rooftop Dweller", "屋上に登る");
            T("escapee", "脱出者", "Escapee", "迷路から出る");
            T("takigyo", "滝行の人", "Waterfall Monk", "滝の下に5秒いる");
            T("touji", "湯治客", "Hot Spring Guest", "温泉に合計10秒いる（保存）");
            T("gym", "ジム通い", "Gym Regular", "ジムに3回入る");
            T("akari", "灯り運び", "Torchbearer", "たいまつを持ったまま奥へ届ける");
            T("sonae", "供え人", "Offerer", "宝石を祭壇に置く");
            T("gem_keeper", "宝石の守り手", "Gem Keeper", "宝石を3つ祭壇に置く");
            T("striker", "ストライカー", "Striker", "ボールをゴールに入れる");
            // 2章
            T("sword", "剣を抜いた者", "Sword Puller", "剣を掴む");
            T("atsugari", "熱がり", "Heat Shy", "やかんを掴んで離す");
            T("oiwai", "お祝い係", "Celebrator", "クラッカーを鳴らす");
            T("kouko", "考古学者", "Archaeologist", "石碑を調べる");
            T("chikara", "力持ち", "Strongman", "岩を5秒持ち続ける");
            T("gouwan", "豪腕", "Strong Arm", "ボールを速く投げる");
            T("kishu", "旗手", "Flag Bearer", "旗を持って10 m動く");
            T("taiko_master", "太鼓の達人", "Drum Master", "太鼓を3回叩く");
            // 3章・7章
            T("renda", "連打の人", "Button Masher", "ボタンを3回押す");
            T("oshi1", "押し見習い", "Push Novice", "2回押す");
            T("oshi2", "押し常連", "Push Regular", "4回押す");
            T("oshi3", "押し名人", "Push Master", "6回押す");
            T("dondon", "どんどん", "Boom Boom", "太鼓で合計20回（金の太鼓は1回で10回分）");
            T("views5", "景色好き", "Scenery Lover", "展望台に3回着く", "count:views>=3");
            T("minigame", "ミニゲーム好き", "Gamer", "ミニゲームを3回クリアする");
            T("village_hero", "村の英雄", "Village Hero", "鐘・井戸・塔の3つをする");
            T("gates3", "くぐり抜け", "Gate Runner", "ゲートを3回くぐる", "count:gates>=3");
            // 4章
            T("taiko10", "太鼓の見習い", "Drum Novice", "太鼓を5回叩く（2-8 の太鼓）", "count:taiko>=5");
            T("taiko100", "太鼓の名人", "Drum Expert", "太鼓を10回叩く（2-8 の太鼓）", "count:taiko>=10");
            T("s_jumps", "跳ねる人", "Hopper", "ジャンプを3回する", "stat:jumps>=3");
            T("s_respawns", "不死鳥", "Phoenix", "1回リスポーンする", "stat:respawns>=1");
            T("s_walk", "旅人", "Traveler", "30 m歩く", "stat:walk_m>=30");
            T("s_height", "雲の上の人", "Above the Clouds", "高さ3 mまで登る", "stat:height_max_m>=3");
            T("s_visits", "よく来る人", "Frequent Visitor", "2回入室する", "stat:visits>=2");
            T("s_days", "来訪者", "Visitor", "1日来る", "stat:visit_days>=1");
            T("s_stay", "住人", "Resident", "1分いる", "stat:stay_min>=1");
            T("s_met", "出会い", "Encounter", "ほかの人に1人会う", "stat:met_people>=1");
            T("s_crowd", "お祭り好き", "Crowd Lover", "2人以上で一緒にいる", "stat:crowd_max>=2");
            T("s_avatar", "着せ替え好き", "Quick Change", "アバターを1回変える", "stat:avatar_changes>=1");
            T("s_pickups", "手癖の人", "Grabby", "物を3回掴む", "stat:pickups>=3");
            T("s_streak", "三日坊主じゃない", "Streaker", "続けて来る（試し用：1日）", "stat:visit_streak>=1");
            T("s_streakmax", "皆勤賞", "Perfect Attendance", "続けて来た日数の最高（試し用：1日）", "stat:visit_streak_max>=1");
            T("s_vr", "VRの住人", "VR Dweller", "VR で1分過ごす", "stat:vr_min>=1");
            T("s_desktop", "画面の向こうの人", "Screen Dweller", "VR でなく1分過ごす", "stat:desktop_min>=1");
            T("s_together", "人なつっこい", "Friendly", "ほかの人と1分いる", "stat:together_min>=1");
            // 2026-10-28 追加の行動の値。
            T("s_fall", "落ちる人", "Faller", "3 m以上の高さから落ちる（4-2 の階段の上から）", "stat:fall_max_m>=3");
            T("s_air", "滞空の人", "Airborne", "空中に合わせて3秒いる", "stat:airtime_s>=3");
            T("s_afk", "うたた寝", "Dozer", "1回放置する（ヘッドセットを外す・ゲームを止める）", "stat:afk_count>=1");
            T("s_sits", "腰かける人", "Sitter", "4-2 の椅子に座る", "stat:sits>=1");
            T("s_sitmin", "くつろぐ人", "Lounger", "椅子に1分座る", "stat:sit_min>=1");
            T("s_uses", "使い手", "User", "物を持ってトリガーを3回引く", "stat:uses>=3");
            T("s_near", "そばにいる人", "Close By", "ほかの人の2 m以内に1分いる", "stat:near_min>=1");
            T("s_welcome", "出迎えの人", "Greeter", "自分がいる間に1人入ってくる", "stat:welcomes>=1");
            T("s_holder", "先輩と会った", "Met a Senior", "「はじめの一歩」を持つ人と会う", "stat:met_title_holders>=1");
            T("s_creator", "作者に会った", "Met the Creator", "作者と会う（マネージャーの「会うと数える人の表示名」に名前を入れる）", "stat:met_creator>=1");
            T("s_pats", "なでる人", "Patter", "ほかの人の頭を撫でる", "stat:pats>=1");
            T("s_patted", "なでられる人", "Patted", "ほかの人に頭を撫でられる", "stat:patted>=1");
            T("s_hifive", "ハイタッチ", "High Five", "ほかの人とハイタッチする", "stat:high_fives>=1");
            T("s_received", "受け取り上手", "Good Catch", "4-2 のバトンをほかの人から手渡しで受け取る", "stat:received_items>=1");
            // 19章（2026-10-28）
            db.rows.Add(new TitleDatabase.Row { key = "best_time", kind = TitleDatabase.Kind.記録, word = "最速タイム", wordEn = "Best Time", recordFormat = TitleDatabase.RecordFormat.時間, recordSuffix = "秒", recordSuffixEn = "s", recordLowerBetter = true, descAfter = "19-1 のスタートからゴールまでの一番速い時間" });
            T("speedster", "俊足", "Speedster", "19-1 を15秒以内で走る", "record:best_time>=1500");
            T("solo", "ひとり旅", "Solo Traveler", "インスタンスに1人だけのときに 19-2 の左の床に乗る");
            T("season", "季節の来訪者", "Seasonal Visitor", "期間の間に 19-2 の右の床に乗る（試し用で毎日）");
            T("quiet", "忍び足", "Sneaky", "19-3 の床に乗る（知らせは出ない）");
            T("cheer", "応援団", "Cheer Squad", "19-4 の枠の中にいるときに、ボールが枠に入る");
            T("together2", "集合", "Gathered", "19-5 の枠の中に2人以上そろう");
            T("bell3", "鈴の見習い", "Bell Novice", "鈴を3回鳴らす（19-6）");
            T("bell6", "鈴の名人", "Bell Master", "鈴を6回鳴らす（19-6）");
            T("hit", "的当て", "Bullseye", "ボールを的に当てる（19-7）");
            T("keyholder", "鍵の持ち主", "Key Holder", "19-8 のボタンでもらう");
            T("chest", "宝箱を開けた", "Chest Opener", "「鍵の持ち主」を持って 19-8 の箱を開ける");
            T("tap3", "三連打", "Triple Tap", "19-9 のボタンを3回押す（入り直すと0から）");
            T("visit1", "訪問者", "Caller", "1日来る（短い書き方 visit>=1）", "visit>=1");
            T("stay1", "ひと休み", "Short Rest", "1分いる（短い書き方 stay>=1）", "stay>=1");
            T("collector", "コレクター", "Collector", "称号を10個集める", "owned>=10");
            T("basement", "地下の探検家", "Basement Explorer", "地下に入る");
            T("updown", "上下を制した人", "Up and Down", "屋上（1-1）と地下の両方に行く", "all:rooftop,basement");
            T("jump100", "よく跳ぶ人", "Jumper", "ジャンプを5回する", "stat:jumps>=5");
            T("walk1k", "歩く人", "Walker", "20 m歩く", "stat:walk_m>=20");
            T("athlete", "アスリート", "Athlete", "「よく跳ぶ人」と「歩く人」をそろえる", "all:jump100,walk1k");
            T("halloween", "かぼちゃ", "Pumpkin", "ハロウィンの週（10/25〜10/31）に来る", "date:1025-1031");
            T("today_demo", "今日の来訪者", "Today's Visitor", "期間限定の試し用（毎日：date:0101-1231）", "date:0101-1231");
            // 接続語・5章
            C("no", "の", "'s");
            C("star", "☆");
            C("dot", "・");
            C("space", "（空白）", "（空白）");
            C("crown", "♛", "", true, "owned>=3", TitleDatabase.NameMode.隠す, "称号を3つ集める");
            C("note", "♪", "", true, "", TitleDatabase.NameMode.見せる, "ステージに5秒いる");
            C("crown2", "♚", "", true, "all:secret,collector", TitleDatabase.NameMode.隠す, "隠し称号とコレクターをそろえる");
            // 6章
            T("squire", "見習い騎士", "Squire", "ボタンでもらう");
            T("knight", "騎士", "Knight", "見習い騎士を持って闘技場に入る");
            T("curse", "呪い", "Curse", "ボタンでもらう");
            T("pure", "清らかな人", "Pure Soul", "呪いを持たずに泉に入る");
            T("hero", "勇者", "Hero", "ボタンでもらう");
            T("maou_slayer", "魔王を倒した者", "Demon Slayer", "勇者を装備して魔王の間に入る");
            T("romantic", "ロマンチスト", "Romantic", "花束を持って展望台に入る");
            T("party", "パーティーピープル", "Party People", "2人以上いるときにフロアに入る");
            T("gymnast", "体操選手", "Gymnast", "VR で鉄棒に入る");
            T("desktop_fan", "デスクトップ派", "Desktop Fan", "VR でなくエリアに入る");
            T("legend_hero", "伝説の勇者", "Legendary Hero", "勇者を装備・聖剣を持つ・呪いなし で祭壇へ");
            // 8章
            T("reikan", "霊感持ち", "Medium", "ボタンでもらう");
            T("sora", "空の住人", "Sky Dweller", "ボタンでもらう");
            T("cook", "料理人", "Cook", "ボタンでもらう");
            T("pass", "通行証", "Pass", "ボタンでもらう");
            T("wizard", "魔法使い", "Wizard", "ボタンでもらう");
            T("kage", "影", "Shadow", "ボタンでもらう");
            for (int i = 1; i <= 5; i++) T("h" + i, "手がかり" + i, "Hint " + i, "ボタンでもらう");
            T("clue_a", "月", "Moon", "どこかで見つける", "", TitleDatabase.NameMode.隠す, "どこかにある");
            T("clue_b", "鍵", "Key", "どこかで見つける", "", TitleDatabase.NameMode.隠す, "どこかにある");
            T("clue_c", "星", "Star", "どこかで見つける", "", TitleDatabase.NameMode.隠す, "どこかにある");
            T("door", "扉", "Door", "ボタンでもらう");
            T("dj", "DJ", "DJ", "ボタンでもらう");
            // 9〜12章
            T("locksmith", "鍵師", "Locksmith", "ボタンでもらう");
            T("advanced", "上級者", "Advanced", "ボタンでもらう（肩書きの枠4〜6が解禁）");
            T("coins_title", "コイン集め", "Coin Collector", "コインを5回拾う", "count:coins>=5");
            T("lever", "レバーを引いた", "Lever Puller", "レバーを Interact する");
            // 13章
            T("idaten", "韋駄天", "Swift Runner", "ボタンでもらう（本当なら stat:walk_m>=10000）");
            T("tsuki", "月の住人", "Moon Dweller", "ボタンでもらう");
            T("oukan", "王冠", "Crown", "ボタンでもらう");
            // 13E（ヒント：名前・取得条件を明かす）
            T("hint_lord", "迷宮の主", "Labyrinth Lord", "地下迷宮の宝箱を開ける（見本ではボタンでもらう）", "", TitleDatabase.NameMode.隠す, "どこかの部屋で何かを開ける");
            T("hint_star", "星読み", "Stargazer", "望遠鏡で星を3回のぞく（見本ではボタンでもらう）", "", TitleDatabase.NameMode.一覧に出さない);
            T("hint_night", "夜の番人", "Night Watch", "夜に見張り台へ登る（見本ではボタンでもらう）", "", TitleDatabase.NameMode.隠す, "？？？");
            // 15章
            string[] stamps = { "時計台", "噴水", "図書館", "港", "森" };
            string[] stampsEn = { "Clock Tower", "Fountain", "Library", "Harbor", "Forest" };
            for (int i = 0; i < 5; i++) T("st_" + (i + 1), stamps[i], stampsEn[i], stamps[i] + "に行く", "", TitleDatabase.NameMode.隠す, "どこかの場所");
            T("st_all", "スタンプコンプリート", "Stamp Complete", "5か所を回る", "all:st_1,st_2,st_3,st_4,st_5");
            T("deep", "奥の部屋の到達者", "Deep Explorer", "奥の部屋に着く", "", TitleDatabase.NameMode.隠す, "？？？");
            T("shuukai", "集会の参加者", "Gathering Member", "2人以上で広場に10秒いる");
            T("dan1", "初段", "First Dan", "的に2回当てる", "count:target>=2");
            T("dan2", "達人", "Expert", "的に4回当てる", "count:target>=4");
            T("dan3", "的の名人", "Target Master", "的に6回当てる", "count:target>=6");
            T("light", "光の道", "Path of Light", "光の祭壇に入る");
            T("dark", "闇の道", "Path of Darkness", "闇の祭壇に入る");
            T("secret", "秘密を知る者", "Secret Keeper", "隠し場所を見つける", "", TitleDatabase.NameMode.一覧に出さない);
            T("shokunin", "職人", "Craftsman", "ボタンでもらう");
            T("smith_title", "鍛冶師", "Smith", "職人が鍛冶を3回する", "count:smith>=3");
            T("smith2_title", "鍛冶の名手", "Master Smith", "ボタン（職人だけに見える）を3回押す");
            // 18章（「内部用」はボード・知らせ・獲得数に出ない印）
            const TitleDatabase.NameMode inner = TitleDatabase.NameMode.内部用;
            T("cp1", "中継地点1", "Checkpoint 1", "中継地点に入る（内部用）", "", inner);
            T("runner", "完走者", "Finisher", "ゴールに着く");
            T("seen_intro", "案内を見た", "Saw Intro", "案内の先に進む（内部用）", "", inner);
            for (int i = 1; i <= 3; i++) T("seen_art" + i, "作品" + i + "を見た", "Saw Work " + i, "作品" + i + "を調べる（内部用）", "", inner);
            T("kansho", "鑑賞者", "Art Lover", "作品を3つ全部見る", "all:seen_art1,seen_art2,seen_art3");
            T("swordsman", "剣士", "Swordsman", "ボタンでもらう");
            T("pref_dark", "暗くする", "Dark Mode", "暗くするボタンを押す（内部用）", "", inner);
            // A-0 はじめの5つの型（説明書 00 の 8章）。キーはほかの区画と重ならないよう qs_ で始める。
            T("qs_regular", "常連さん", "Regular", "7日来る（00 の 8-1）", "visit>=7");
            T("qs_resident", "長居の人", "Long Stayer", "合計10時間いる（00 の 8-1）", "stay>=600");
            T("qs_talker", "おしゃべり好き", "Chatterbox", "ほかの人と合計5時間いる（00 の 8-1）", "stat:together_min>=300");
            T("qs_patter", "なでなで係", "Head Patter", "ほかの人の頭を10回撫でる（00 の 8-1）", "stat:pats>=10");
            string[] spots = { "見晴らし台", "泉", "古木" };
            string[] spotsEn = { "Lookout", "Spring", "Old Tree" };
            string[] spotsHint = { "どこかの高い所", "水の音がする所", "木の多い所" };
            for (int i = 0; i < 3; i++) T("qs_spot" + (i + 1), spots[i], spotsEn[i], spots[i] + "に行く（00 の 8-2）", "", TitleDatabase.NameMode.隠す, spotsHint[i]);
            T("qs_explorer", "冒険家", "Adventurer", "3か所を回った（00 の 8-2）", "all:qs_spot1,qs_spot2,qs_spot3", TitleDatabase.NameMode.見せる, "3か所を回る");
            T("qs_clear", "ゴールした人", "Goal Reacher", "ゴールに着く（00 の 8-3）");
            T("qs_clear10", "常連ランナー", "Regular Runner", "ゴールに3回着く（説明書の例は10回。00 の 8-3）", "count:qs_clears>=3");
            T("qs_expo", "2026年の来場者", "2026 Visitor", "2026年の展示会（11/3〜11/5）に来た（00 の 8-4）", "date:20261103-20261105");
            T("qs_game", "ミニゲームの勝者", "Minigame Winner", "ミニゲームをクリアする（プログラムから渡す。00 の 8-5）");
            T("qs_game3", "ミニゲームの常連", "Minigame Regular", "ミニゲームを3回クリアする（00 の 8-5）", "count:qs_games>=3");
            // 19-11（外す・入れ替える）。ほかの行の ID がずれないよう最後に足す。
            T("lost", "迷子", "Lost", "19-11 のボタンでもらう（案内所に入ると外れる）");
            T("apprentice", "見習い", "Apprentice", "19-11 のボタンでもらう");
            T("journeyman", "一人前", "Journeyman", "「見習い」を持って 19-11 の修業場に入る（見習いと入れ替わる）");
            db.AssignIds();
            AssetDatabase.CreateAsset(db, DatabasePath);
            AssetDatabase.SaveAssets();
            return db;
        }

        // ---- 区画と部品の作り方 ----

        private static void World()
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(WorldPrefab);
            GameObject world = prefab != null ? (GameObject)PrefabUtility.InstantiatePrefab(prefab) : new GameObject("VRCWorld", typeof(VRCSceneDescriptor));
            world.transform.position = new Vector3(0, 0, -6);
            world.transform.rotation = Quaternion.identity;
        }

        private static Material Mat(string name, UnityEngine.Color color, bool transparent = false)
        {
            string key = name + (transparent ? "_t" : "");
            if (materials.TryGetValue(key, out Material cached)) return cached;
            string path = MaterialFolder + "/" + key + ".mat";
            var material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                Shader shader = transparent ? Shader.Find("Legacy Shaders/Transparent/Diffuse") : Shader.Find("Standard");
                material = new Material(shader != null ? shader : Shader.Find("Standard"));
                AssetDatabase.CreateAsset(material, path);
            }
            material.color = color;
            EditorUtility.SetDirty(material);
            materials[key] = material;
            return material;
        }

        private static Material Paint(string name) { return Mat(name, ColorOf(name)); }

        private static UnityEngine.Color ColorOf(string name)
        {
            switch (name)
            {
                case "Red": return new UnityEngine.Color(.85f, .25f, .22f);
                case "Blue": return new UnityEngine.Color(.25f, .45f, .85f);
                case "Green": return new UnityEngine.Color(.30f, .70f, .35f);
                case "Yellow": return new UnityEngine.Color(.95f, .80f, .25f);
                case "Purple": return new UnityEngine.Color(.60f, .35f, .80f);
                case "White": return new UnityEngine.Color(.92f, .92f, .92f);
                case "Dark": return new UnityEngine.Color(.18f, .18f, .22f);
                case "Brown": return new UnityEngine.Color(.50f, .35f, .22f);
                case "Wall": return new UnityEngine.Color(.62f, .58f, .52f);
                case "Button": return new UnityEngine.Color(.95f, .55f, .20f);
                case "Revoke": return new UnityEngine.Color(.55f, .55f, .60f);
                default: return new UnityEngine.Color(.7f, .7f, .7f);
            }
        }

        private static GameObject Cube(Transform parent, string name, Vector3 local, Vector3 scale, Material material, bool collider = true, PrimitiveType type = PrimitiveType.Cube)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = local;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = material;
            if (!collider) Object.DestroyImmediate(go.GetComponent<Collider>());
            return go;
        }

        // 列の並び：0・1 は A（具体例：15章 組み合わせ・18章 ワールドでの使い方＝応用）、2 は境目、3 から B（条件の一覧：1〜13章）。
        private const int BorderRow = 3;

        private static Vector3 RowOrigin(int row, int col) { return new Vector3(col * BoothStep, 0, 10 + row * RowStep); }

        // 1つの例の区画：床と看板。看板は区画の奥（+z）にあり、手前（-z）から読む。
        // parts：具体例（A のエリア）で使っている部品と、条件の一覧（B のエリア）の番号。空なら出さない。
        private static Transform Booth(int row, int col, string id, string title, string howTo, string parts = "")
        {
            var go = new GameObject(id + " " + title);
            go.transform.SetParent(sceneRoot, false);
            go.transform.position = RowOrigin(row, col);
            if (!lastColumn.TryGetValue(row, out int last) || col > last) lastColumn[row] = col;
            booths.Add(new KeyValuePair<string, Transform>(id, go.transform));
            Cube(go.transform, "Floor", new Vector3((BoothStep - BoothSize) / 2, 0.05f, 0), new Vector3(BoothStep - 1, 0.1f, BoothSize - 1), Mat("Floor" + (row % 2), row % 2 == 0 ? new UnityEngine.Color(.55f, .58f, .62f) : new UnityEngine.Color(.50f, .54f, .50f)));
            if (string.IsNullOrEmpty(parts)) Sign(go.transform, new Vector3(0, 3.1f, 4.4f), id + "　" + title, howTo, 860, 300);
            else Sign(go.transform, new Vector3(0, 3.3f, 4.4f), id + "　" + title, howTo + "\n<color=#8fd8ff>使っている部品：" + parts + "</color>", 860, 380);
            return go.transform;
        }

        private static void RowTitle(int row, string text)
        {
            var go = new GameObject("Row " + text);
            go.transform.SetParent(sceneRoot, false);
            go.transform.position = RowOrigin(row, 0) + new Vector3(-7, 0, 0);
            Sign(go.transform, new Vector3(0, 2.2f, 0), text, "", 300, 200);
        }

        private static Text Sign(Transform parent, Vector3 local, string title, string body, float width, float height)
        {
            Transform canvas = TitleSystemBuilder.Canvas(parent, "Sign", new Vector2(width, height), .01f, false);
            canvas.localPosition = local;
            Text head = TitleSystemBuilder.Label(canvas, "Title", title, 15, 8, width - 30, 56, 40, TextAnchor.MiddleLeft);
            head.color = new UnityEngine.Color(.95f, .76f, .25f);
            head.fontStyle = FontStyle.Bold;
            Text text = TitleSystemBuilder.Label(canvas, "Body", body, 15, 70, width - 30, height - 80, 26, TextAnchor.UpperLeft);
            text.resizeTextMinSize = 14;
            return text;
        }

        // 物の上に出す小さな札。
        private static void Tag(Transform parent, Vector3 local, string text)
        {
            Transform canvas = TitleSystemBuilder.Canvas(parent, "Tag", new Vector2(400, 90), .005f, false);
            canvas.localPosition = local;
            canvas.GetComponent<Image>().color = new UnityEngine.Color(0, 0, 0, .6f);
            TitleSystemBuilder.Label(canvas, "Text", text, 8, 5, 384, 80, 30);
        }

        private static TitleArea Area(Transform parent, string name, Vector3 local, Vector3 size, params string[] grants)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = local;
            var box = go.AddComponent<BoxCollider>();
            box.isTrigger = true;
            box.size = size;
            Cube(go.transform, "Visual", Vector3.zero, size, Mat("Area", new UnityEngine.Color(.3f, .8f, 1f, .25f), true), false);
            TitleArea area = go.AddUdonSharpComponent<TitleArea>();
            area.grantKeys = grants;
            return area;
        }

        private static GameObject Pickup(Transform parent, string name, Vector3 local, Vector3 scale, Material material, bool sync, PrimitiveType type = PrimitiveType.Cube)
        {
            GameObject go = Cube(parent, name, local, scale, material, true, type);
            go.AddComponent<Rigidbody>();
            var pickup = go.AddComponent<VRCPickup>();
            pickup.AutoHold = VRC.SDKBase.VRC_Pickup.AutoHoldMode.Yes;
            if (sync) go.AddComponent<VRCObjectSync>();
            return go;
        }

        private static TitleAction Action(GameObject target, int action, params string[] grants)
        {
            TitleAction a = target.AddUdonSharpComponent<TitleAction>();
            a.action = action;
            a.grantKeys = grants;
            return a;
        }

        // 押すと称号をもらえるボタン（前提の称号を用意するため）。何度でも押せる。
        private static void GrantButton(Transform parent, Vector3 local, string key, string word)
        {
            GameObject button = Cube(parent, "Grant " + key, local, new Vector3(.6f, .6f, .6f), Paint("Button"));
            TitleAction a = Action(button, TitleAction.ActInteract, key);
            a.once = false;
            a.interactText = "「" + word + "」をもらう";
            Tag(button.transform.parent, local + new Vector3(0, .7f, 0), "「" + word + "」をもらう");
        }

        // 押すと決めた称号を外すボタン（何度も試すため）。
        private static void RevokeButton(Transform parent, Vector3 local, string label, params string[] keys)
        {
            GameObject button = Cube(parent, "Revoke", local, new Vector3(.6f, .6f, .6f), Paint("Revoke"));
            TitleReset reset = button.AddUdonSharpComponent<TitleReset>();
            reset.mode = TitleReset.ModeKeys;
            reset.revokeKeys = keys;
            reset.confirmSeconds = 0f;
            reset.interactText = label;
            Tag(button.transform.parent, local + new Vector3(0, .7f, 0), label);
        }

        private static TitleGate Gate(Transform parent, string name, params string[] keys)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            TitleGate gate = go.AddUdonSharpComponent<TitleGate>();
            gate.titleKeys = keys;
            return gate;
        }

        // 区画の奥半分を囲う部屋（左右と奥の壁）。手前（z=0）に扉の壁を置くと、扉を通らないと入れない。
        private static void Room(Transform parent)
        {
            Material wall = Paint("Wall");
            // 奥の壁は看板（z=4.4）の後ろに置く（看板が隠れないように）。
            Cube(parent, "Room Left", new Vector3(-4.4f, 1.25f, 2.35f), new Vector3(.2f, 2.5f, 4.7f), wall);
            Cube(parent, "Room Right", new Vector3(4.4f, 1.25f, 2.35f), new Vector3(.2f, 2.5f, 4.7f), wall);
            Cube(parent, "Room Back", new Vector3(0, 1.25f, 4.7f), new Vector3(9f, 2.5f, .2f), wall);
        }

        private static GameObject DoorWall(Transform parent, string name, float z = 0f, Material material = null)
        {
            return Cube(parent, name, new Vector3(0, 1.25f, z), new Vector3(8.6f, 2.5f, .3f), material != null ? material : Paint("Red"));
        }

        // +z へ上る階段。最後の段の上に台を置き、台の中心（上面）を返す。
        private static Vector3 Stairs(Transform parent, Vector3 start, int steps, float rise = .3f, float run = .5f, float width = 1.6f)
        {
            Material m = Paint("White");
            for (int i = 0; i < steps; i++)
            {
                float h = rise * (i + 1);
                Cube(parent, "Step " + i, start + new Vector3(0, h / 2, run * i + run / 2), new Vector3(width, h, run), m);
            }
            float top = rise * steps;
            Vector3 deck = start + new Vector3(0, top - .1f, run * steps + 1.2f);
            Cube(parent, "Deck", deck, new Vector3(2.4f, .2f, 2.4f), m);
            return deck + new Vector3(0, .1f, 0);
        }

        private static ExampleEventLog EventLog(Transform parent, Vector3 local)
        {
            Transform canvas = TitleSystemBuilder.Canvas(parent, "Event Log", new Vector2(500, 260), .005f, false);
            canvas.localPosition = local;
            Text text = TitleSystemBuilder.Label(canvas, "Text", "", 10, 10, 480, 240, 28, TextAnchor.UpperLeft);
            ExampleEventLog log = canvas.gameObject.AddUdonSharpComponent<ExampleEventLog>();
            log.label = text;
            GameObject flash = Cube(parent, "Flash", local + new Vector3(0, 1f, 0), new Vector3(.4f, .4f, .4f), Paint("Yellow"), false, PrimitiveType.Sphere);
            log.flash = flash;
            return log;
        }

        private static UdonBehaviour Backing(UdonSharpBehaviour behaviour) { return UdonSharpEditorUtility.GetBackingUdonBehaviour(behaviour); }

        private static void PlaceBoard(Transform system, string name, Vector3 position)
        {
            Transform board = TitleSystemBuilder.Board(system, manager, name);
            board.position = position;
        }

        // ---- ロビー ----

        private static void Lobby(Transform system)
        {
            Transform board = system.Find("Title Board");
            if (board != null) board.position = new Vector3(-4, 1.5f, 1.5f);
            var lobby = new GameObject("Lobby").transform;
            lobby.SetParent(sceneRoot, false);
            Sign(lobby, new Vector3(4, 2.2f, 1.5f), "称号の見本（説明書 03）",
                "奥へ進むと、まず A「具体例」（A-0 はじめの5つの型＝説明書 00 の 8章・A-1 組み合わせ・A-2 ワールドでの使い方＝応用）、その奥に B「使える条件の一覧」（説明書 03 の 1〜13章）があります。\n" +
                "A の看板の「使っている部品」の番号で、B の区画を探せます。各区画の看板の「試し方」のとおりに試してください。右の青いボタンで B の入口へ行けます。\n" +
                "橙のボタン＝前提の称号をもらう／灰のボタン＝外す。左の称号ボードで肩書きを作って「決定」すると、装備の例が試せます。\n" +
                "やり直しは右のボタン（3秒以内に2回押す）。Play 中はメニュー「World Title Gimmick/テスト用パネル」でも渡せます。", 760, 300);
            GameObject reset = Cube(lobby, "Reset All", new Vector3(8.5f, .5f, 0), new Vector3(.8f, 1f, .8f), Paint("Red"));
            TitleReset r = reset.AddUdonSharpComponent<TitleReset>();
            r.mode = TitleReset.ModeAll;
            r.interactText = "全部やり直す（2回押す）";
            Tag(lobby, new Vector3(8.5f, 1.4f, 0), "全部やり直す");
        }

        // ---- 設定の画像の看板 ----
        // 2026-10-28（ユーザー指摘「上部分が身長より高すぎて見れない。画像に合ったボードを、その物の横にそれぞれ置けないか」）：
        // 画像1枚ごとに、画像の大きさに合った小さな看板を作り、その設定が付いている物の横（下端 0.5 m、高さ 1.5 m まで）に立てる。
        // どの画像をどの物の横に置くかは Screenshots/ShotPlaces.txt（「15-1_2 = 表」の形）。称号ゲートなど見えない物は、切り替える物の横。
        // 撮影のリスト（ShotList.txt）も書き出す：区画ごとに、ファイル名と、その区画で部品の付いた物。

        private const float ShotBottom = .5f;      // 看板の下端の高さ（m）
        private const float ShotMaxHeight = 1.5f;  // 看板の高さの上限（m）
        private const float ShotMaxScale = .004f;  // 画像 1px あたりの大きさの上限（m）

        private static void ShotBoards()
        {
            bool dev = TitleSystemBuilder.IsDevProject;
            if (dev) Directory.CreateDirectory(ShotFolder);
            Dictionary<string, string> places = ReadShotPlaces();
            var list = new System.Text.StringBuilder();
            list.AppendLine("見本のシーンの設定の画像（「見本のシーンを作る」で作るたびに書き直す）");
            list.AppendLine("画像をこのフォルダに置いて、もう一度「見本のシーンを作る」を押すと、その設定が付いている物の横に看板が立ちます。");
            list.AppendLine("名前は 区画の番号.png（例 1-1.png）。2枚目からは 1-1_2.png、1-1_3.png … _" + MaxShots + " まで。置く場所は ShotPlaces.txt。");
            list.AppendLine("[済] は置いてあるもの。（前提）は前提の称号のボタンなので撮らなくてよい。");
            list.AppendLine("インスペクターのどこを撮るかは、開発用の撮影リスト Docs/ScreenshotList.md に区画ごとに書いてある。");
            list.AppendLine();
            foreach (KeyValuePair<string, Transform> booth in booths)
            {
                string id = booth.Key;
                var placed = new List<Rect>(); // 区画の中に立てた看板（x の幅と z）。重ならないように横へずらす
                int count = 0;
                for (int i = 1; i <= MaxShots; i++)
                {
                    string file = id + (i == 1 ? "" : "_" + i);
                    Texture2D texture = LoadShot(ShotFolder + "/" + file + ".png");
                    if (texture == null) continue; // 抜けている番号は飛ばす（撮り直し待ちなど）
                    places.TryGetValue(file, out string place);
                    PlaceShot(booth.Value, file, texture, place, placed);
                    count++;
                }
                string targets = ShotTargets(id, booth.Value);
                list.AppendLine((count > 0 ? "[済] " : "[  ] ") + id + "　" + booth.Value.name.Substring(id.Length).Trim() + "（" + count + "枚）");
                list.AppendLine("      撮る物：" + targets);
                list.AppendLine();
                if (count > 0 || !dev) continue;
                // 画像がまだない区画：手前の右に、小さな札で撮る物を書く（開発用のプロジェクトだけ）。
                Transform note = TitleSystemBuilder.Canvas(booth.Value, "Settings Shots (none)", new Vector2(420, 200), .004f, false);
                note.localPosition = new Vector3(3.2f, ShotBottom + .4f, -4.2f);
                TitleSystemBuilder.Label(note, "Body", "設定の画像はまだありません（Screenshots/" + id + ".png）\n撮る物：" + targets,
                    10, 10, 400, 180, 20, TextAnchor.UpperLeft);
            }
            if (!dev) return;
            File.WriteAllText(ShotFolder + "/ShotList.txt", list.ToString(), new System.Text.UTF8Encoding(false));
            AssetDatabase.ImportAsset(ShotFolder + "/ShotList.txt");
        }

        // ShotPlaces.txt を読む（「ファイル名 = 物の名前」。# から後は読まない）。
        private static Dictionary<string, string> ReadShotPlaces()
        {
            var map = new Dictionary<string, string>();
            string path = ShotFolder + "/ShotPlaces.txt";
            if (!File.Exists(path)) return map;
            foreach (string raw in File.ReadAllLines(path, System.Text.Encoding.UTF8))
            {
                string line = raw.Trim();
                if (line.Length == 0 || line.StartsWith("#")) continue;
                int at = line.IndexOf('=');
                if (at <= 0) continue;
                map[line.Substring(0, at).Trim()] = line.Substring(at + 1).Trim();
            }
            return map;
        }

        // 画像1枚の看板を、place の物の右に立てる（看板は -z から読む向き。区画の中の座標で置く）。
        private static void PlaceShot(Transform booth, string file, Texture2D texture, string place, List<Rect> placed)
        {
            float scale = Mathf.Min(ShotMaxScale, ShotMaxHeight / texture.height);
            float pad = 6f;
            float w = (texture.width + pad * 2) * scale, h = (texture.height + pad * 2) * scale;

            // 置く目安：物の見た目の範囲。「表」「区画」・見つからない物は、区画の看板の手前の左から。
            bool found = ShotAnchor(booth, place, out Bounds bounds);
            float x, z;
            if (found) { x = bounds.max.x + .15f + w / 2; z = bounds.center.z; }
            else { x = -3.6f + w / 2; z = 3.4f; }
            // 立てた看板と重なるときは右へずらす（前後が近いと、手前から見て後ろの看板が隠れるので、前後 2.5 m 以内も重なりとみなす）。
            bool moved = true;
            while (moved)
            {
                moved = false;
                foreach (Rect r in placed)
                {
                    if (Mathf.Abs(r.y - z) > 2.5f || x - w / 2 >= r.xMax + .05f || x + w / 2 <= r.xMin - .05f) continue;
                    x = r.xMax + .1f + w / 2;
                    moved = true;
                }
            }
            placed.Add(new Rect(x - w / 2, z, w, 0));

            Transform canvas = TitleSystemBuilder.Canvas(booth, "Shot " + file, new Vector2(texture.width + pad * 2, texture.height + pad * 2), scale, false);
            canvas.localPosition = new Vector3(x, ShotBottom + h / 2, z);
            var go = new GameObject("Image", typeof(RectTransform), typeof(RawImage));
            var rect = go.GetComponent<RectTransform>();
            rect.SetParent(canvas, false);
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(.5f, .5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(texture.width, texture.height);
            var image = go.GetComponent<RawImage>();
            image.texture = texture;
            image.raycastTarget = false;
        }

        // place の物の見た目の範囲（区画の中の座標）。称号ゲート・称号の効果は、切り替える物の範囲。
        private static bool ShotAnchor(Transform booth, string place, out Bounds bounds)
        {
            bounds = default;
            if (string.IsNullOrEmpty(place) || place == "表" || place == "区画") return false;
            Transform target = FindChild(booth, place);
            if (target == null) { Debug.LogWarning("[World Title Gimmick] 設定の画像を置く物がありません：" + booth.name + " / " + place); return false; }
            var gate = target.GetComponent<TitleGate>();
            var perk = target.GetComponent<TitlePerk>();
            GameObject controlled = null;
            if (gate != null)
            {
                if (gate.objectsWhenNot.Length > 0) controlled = gate.objectsWhenNot[0];
                else if (gate.objects.Length > 0) controlled = gate.objects[0];
                else if (gate.renderers.Length > 0 && gate.renderers[0] != null) controlled = gate.renderers[0].gameObject;
                else if (gate.colliders.Length > 0 && gate.colliders[0] != null) controlled = gate.colliders[0].gameObject;
                else if (gate.pickupObjects.Length > 0) controlled = gate.pickupObjects[0];
            }
            else if (perk != null && perk.objects.Length > 0) controlled = perk.objects[0];
            if (controlled != null) target = controlled.transform;

            bool any = false;
            foreach (Renderer renderer in target.GetComponentsInChildren<Renderer>(true))
            {
                if (renderer.bounds.size == Vector3.zero) continue;
                if (!any) { bounds = renderer.bounds; any = true; } else bounds.Encapsulate(renderer.bounds);
            }
            if (!any) bounds = new Bounds(target.position, Vector3.one * .2f);
            bounds.center -= booth.position;
            return true;
        }

        private static Transform FindChild(Transform parent, string name)
        {
            foreach (Transform child in parent.GetComponentsInChildren<Transform>(true))
                if (child != parent && child.name == name) return child;
            return null;
        }

        // 画像を読む。文字が読めるように、2の累乗に縮めず・圧縮を弱くして読み込み直す。
        private static Texture2D LoadShot(string path)
        {
            if (!File.Exists(path)) return null;
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer != null && (importer.npotScale != TextureImporterNPOTScale.None || importer.textureCompression != TextureImporterCompression.CompressedHQ || importer.maxTextureSize != 2048))
            {
                importer.textureType = TextureImporterType.Default;
                importer.npotScale = TextureImporterNPOTScale.None;
                importer.textureCompression = TextureImporterCompression.CompressedHQ;
                importer.maxTextureSize = 2048;
                importer.mipmapEnabled = true;
                importer.SaveAndReimport();
            }
            return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }

        // 区画の中で、ギミックの部品が付いた物の一覧（撮る物）。見本だけのスクリプト（イベントの看板・ワープ）は除く。
        private static string ShotTargets(string id, Transform booth)
        {
            var parts = new List<string>();
            foreach (UdonSharpBehaviour behaviour in booth.GetComponentsInChildren<UdonSharpBehaviour>(true))
            {
                if (behaviour.GetType().Namespace != typeof(TitleManager).Namespace) continue;
                string name = behaviour.gameObject.name;
                // 前提の称号のボタン（橙の「もらう」と、灰の「外す」「全部外す」）は撮らなくてよい。「スタンプを外す」などは例の一部。
                var reset = behaviour as TitleReset;
                bool helper = name.StartsWith("Grant ") || (reset != null && name == "Revoke" && (reset.interactText == "外す" || reset.interactText == "全部外す"));
                parts.Add("「" + name + "」の" + PartName(behaviour) + (helper ? "（前提）" : ""));
            }
            if (parts.Count == 0) return "部品なし。称号の表（ExampleTitles）の行か、マネージャーの欄（看板の説明を参照）";
            return string.Join("、", parts) + "。表の条件を使う区画は、称号の表の行も";
        }

        private static string PartName(UdonSharpBehaviour behaviour)
        {
            switch (behaviour.GetType().Name)
            {
                case nameof(TitleArea): return "称号エリア";
                case nameof(TitleAction): return "称号アクション";
                case nameof(TitleGate): return "称号ゲート";
                case nameof(TitleCounter): return "カウンター";
                case nameof(TitleReset): return "やり直し";
                case nameof(TitlePerk): return "称号の効果";
                case nameof(TitleRoster): return "一覧ボード";
                case nameof(TitleRelay): return "イベント中継";
                case nameof(TitleAllOf): return "条件まとめ";
                default: return behaviour.GetType().Name;
            }
        }

        // ---- A（具体例）と B（条件の一覧）の境目 ----
        // A の3列の奥、B の1列目の手前（空けてある列 3）に大きな看板を置く。

        private static void Border()
        {
            var go = new GameObject("Border Catalog");
            go.transform.SetParent(sceneRoot, false);
            go.transform.position = RowOrigin(BorderRow, 0);
            Cube(go.transform, "Line", new Vector3(55, .06f, -2), new Vector3(130, .02f, .3f), Paint("Yellow"), false);
            Sign(go.transform, new Vector3(4, 2.6f, 0), "ここから先は「使える条件の一覧」（説明書 03 の 1〜13章）",
                "手前の A は、ワールドに置いたときの形の具体例でした。ここから先の B は、称号のもらい方と、称号でできることを全部並べています。\n" +
                "具体例の看板の「使っている部品」の番号（1-1・8-4 など）の区画を探してください。\n" +
                "B-1 1章 エリア／B-2 2章 アクション／B-3 3・7章 回数／B-4 4・5章 表の条件・接続語／B-5 6章 前提の条件／B-6・B-7 8章 ゲート／B-8 9〜12章／B-9 13章 見え方・効果", 1100, 330);
        }

        // ---- ワープ（2026-10-28、ユーザー指定「右端まで行くと戻るのが難しい」） ----
        // 各列の右端（一番右の区画の右）に「この列の左端へ」「ロビーへ」のボタンを置く。区画の前の通り（列の手前）に出る。

        private static void WarpButtons()
        {
            var warps = new GameObject("Warps").transform;
            warps.SetParent(sceneRoot, false);
            Transform lobby = WarpPoint(warps, "To Lobby", new Vector3(0, 0, -1), Vector3.forward);
            // ロビーから、B（条件の一覧）の入口（境目の看板の前）へ。
            Transform catalog = WarpPoint(warps, "To Catalog", RowOrigin(BorderRow, 0) + new Vector3(4, 0, -5), Vector3.forward);
            WarpButton(warps, "Lobby Warp Catalog", new Vector3(11, 0, 0), catalog, "条件の一覧（B）へ");
            foreach (KeyValuePair<int, int> pair in lastColumn)
            {
                int row = pair.Key;
                Vector3 street = RowOrigin(row, 0) + new Vector3(0, 0, -6.5f);
                Transform left = WarpPoint(warps, "Row " + row + " Left", street + new Vector3(-3, 0, 0), Vector3.right);
                Vector3 right = RowOrigin(row, pair.Value + 1) + new Vector3(-3.5f, 0, -5.5f);
                WarpButton(warps, "Row " + row + " Warp Left", right, left, "この列の左端へ");
                WarpButton(warps, "Row " + row + " Warp Lobby", right + new Vector3(1.4f, 0, 0), lobby, "ロビーへ");
            }
        }

        private static Transform WarpPoint(Transform parent, string name, Vector3 position, Vector3 facing)
        {
            var point = new GameObject(name).transform;
            point.SetParent(parent, false);
            point.position = position;
            point.rotation = Quaternion.LookRotation(facing, Vector3.up);
            return point;
        }

        private static void WarpButton(Transform parent, string name, Vector3 position, Transform target, string label)
        {
            GameObject button = Cube(parent, name, position + new Vector3(0, .6f, 0), new Vector3(.8f, 1.2f, .8f), Paint("Blue"));
            ExampleTeleport warp = button.AddUdonSharpComponent<ExampleTeleport>();
            warp.target = target;
            warp.interactText = label;
            Tag(parent, position + new Vector3(0, 1.5f, 0), label);
        }

        // ---- はじめの囲い（2026-10-28、ユーザー指定） ----
        // 出現地点を壁で囲む。入室すると「はじめの一歩」が自動で渡るので、称号の手帳でボードを出して装備すると壁が消える。
        // 壁は称号ゲートの「満たすまで出す物」（条件は装備している）。入室してすぐ（保存の読み込みの前）も壁は出ている。

        private static void StartRoom()
        {
            var room = new GameObject("Start Room").transform;
            room.SetParent(sceneRoot, false);
            room.position = new Vector3(0, 0, -6);
            Material wallMaterial = Mat("Start Wall", new UnityEngine.Color(.35f, .55f, .75f, .55f), true);
            var walls = new GameObject("Start Walls");
            walls.transform.SetParent(room, false);
            Cube(walls.transform, "Wall Front", new Vector3(0, 1.5f, 3), new Vector3(6.2f, 3, .2f), wallMaterial);
            Cube(walls.transform, "Wall Back", new Vector3(0, 1.5f, -3), new Vector3(6.2f, 3, .2f), wallMaterial);
            Cube(walls.transform, "Wall Left", new Vector3(-3, 1.5f, 0), new Vector3(.2f, 3, 6.2f), wallMaterial);
            Cube(walls.transform, "Wall Right", new Vector3(3, 1.5f, 0), new Vector3(.2f, 3, 6.2f), wallMaterial);
            Sign(room, new Vector3(0, 1.7f, 2.85f), "はじめに：称号を装備して外へ出よう",
                "1. 入室すると称号「はじめの一歩」がもらえます（知らせが出るまで数秒待つ）。\n" +
                "2. 称号の手帳を呼ぶ：デスクトップは T キー、VR は両手のトリガーを同時に1秒押す。\n" +
                "3. 手帳を掴んで「使う」（トリガー／クリック）と、目の前に称号ボードが出ます。\n" +
                "4. ボードの肩書きの枠1を押し、「はじめの一歩」を押して入れ、「決定」を押す。\n" +
                "→ 装備すると、まわりの壁が消えます（外すと、またここで囲まれます）。", 580, 300);
            TitleGate gate = Gate(room, "Gate Start Walls", "first_step");
            gate.mode = TitleGate.ModeEquipped;
            gate.objectsWhenNot = new[] { walls };
        }

        // ---- 1章 ----

        private static void Chapter1()
        {
            const int row = 4;
            RowTitle(row, "B-1　1章 称号エリア");
            Transform b = Booth(row, 0, "1-1", "エリアに入ったら", "階段を登って、屋上の水色の箱に入る → 「屋上の住人」");
            Vector3 deck = Stairs(b, new Vector3(-2.5f, 0, -3.5f), 10);
            Area(b, "Rooftop Area", deck + new Vector3(0, 1.1f, 0), new Vector3(2.2f, 2f, 2.2f), "rooftop");

            b = Booth(row, 1, "1-2", "エリアから出たら", "囲いの中に入って、開いた所から出る → 「脱出者」\n（入らずに外にいるだけでは出ない）");
            Material wall = Paint("Wall");
            Cube(b, "Maze Left", new Vector3(-2, 1, 0), new Vector3(.2f, 2, 4), wall);
            Cube(b, "Maze Right", new Vector3(2, 1, 0), new Vector3(.2f, 2, 4), wall);
            Cube(b, "Maze Back", new Vector3(0, 1, 2), new Vector3(4.2f, 2, .2f), wall);
            Cube(b, "Maze Front", new Vector3(-1.1f, 1, -2), new Vector3(2, 2, .2f), wall);
            TitleArea a = Area(b, "Maze Area", new Vector3(0, 1, 0), new Vector3(3.6f, 2, 3.6f), "escapee");
            a.trigger = TitleArea.OnExit;

            b = Booth(row, 2, "1-3", "続けてN秒いたら", "水色の箱に続けて5秒いる → 「滝行の人」\n途中で出ると数え直し");
            Cube(b, "Waterfall", new Vector3(0, 3, 1), new Vector3(2, .3f, 2), Paint("Blue"));
            a = Area(b, "Waterfall Area", new Vector3(0, 1, 1), new Vector3(2, 2, 2), "takigyo");
            a.trigger = TitleArea.OnStay;
            a.seconds = 5;

            b = Booth(row, 3, "1-4", "合計N秒いたら（保存）", "温泉に合計10秒いる → 「湯治客」\n5秒いて出て、また5秒でもよい。入り直しても続きから（Save Key onsen_sec）");
            a = Area(b, "Onsen Area", new Vector3(0, .5f, 0), new Vector3(3, 1, 3), "touji");
            a.trigger = TitleArea.OnStayTotal;
            a.seconds = 10;
            a.saveKey = "onsen_sec";

            b = Booth(row, 4, "1-5", "N回入ったら", "箱に3回出入りする → 「ジム通い」（Save Key gym_enter で保存）");
            a = Area(b, "Gym Area", new Vector3(0, 1, 0), new Vector3(2, 2, 2), "gym");
            a.trigger = TitleArea.OnEnterCount;
            a.count = 3;
            a.saveKey = "gym_enter";

            b = Booth(row, 5, "1-6", "物を持ったまま入れたら", "黄色のたいまつを手に持ったまま、奥の箱に入れる → 「灯り運び」\n手を離して投げ入れたときは出ない");
            GameObject torch = Pickup(b, "Torch", new Vector3(-2.5f, .8f, -3), new Vector3(.15f, .5f, .15f), Paint("Yellow"), false, PrimitiveType.Cylinder);
            Cube(b, "Torch Table", new Vector3(-2.5f, .25f, -3), new Vector3(1, .5f, 1), Paint("Brown"));
            a = Area(b, "Cave Area", new Vector3(2, 1, 2), new Vector3(2, 2, 2), "akari");
            a.who = TitleArea.WhoObjects;
            a.objects = new[] { torch };
            a.receiver = 0;

            b = Booth(row, 6, "1-7", "物を置いたら（持ち主）", "赤い宝石を掴んで、祭壇（奥の箱）に置く → 「供え人」\nReceiver＝最後に持った人。宝石は Object Sync つき");
            GameObject gem = Pickup(b, "Gem", new Vector3(-2.5f, .7f, -3), new Vector3(.3f, .3f, .3f), Paint("Red"), true);
            Cube(b, "Gem Table", new Vector3(-2.5f, .25f, -3), new Vector3(1, .5f, 1), Paint("Brown"));
            Cube(b, "Altar", new Vector3(2, .4f, 2), new Vector3(1.6f, .8f, 1.6f), Paint("White"));
            a = Area(b, "Altar Area", new Vector3(2, 1.3f, 2), new Vector3(1.6f, 1, 1.6f), "sonae");
            a.who = TitleArea.WhoObjects;
            a.objects = new[] { gem };
            a.receiver = 1;

            b = Booth(row, 7, "1-8", "何個かそろえて置いたら", "紫の宝石3つを全部祭壇に置く → 「宝石の守り手」\n2つでは出ない（Object Count 3）");
            Cube(b, "Gem Table", new Vector3(-2.5f, .25f, -3), new Vector3(2, .5f, 1), Paint("Brown"));
            var gems = new GameObject[3];
            for (int i = 0; i < 3; i++) gems[i] = Pickup(b, "Gem " + (i + 1), new Vector3(-3.2f + i * .7f, .7f, -3), new Vector3(.3f, .3f, .3f), Paint("Purple"), true);
            Cube(b, "Altar", new Vector3(2, .4f, 2), new Vector3(1.6f, .8f, 1.6f), Paint("White"));
            a = Area(b, "Altar Area", new Vector3(2, 1.3f, 2), new Vector3(1.6f, 1, 1.6f), "gem_keeper");
            a.who = TitleArea.WhoObjects;
            a.objects = gems;
            a.objectCount = 3;
            a.receiver = 1;

            b = Booth(row, 8, "1-9", "決めたレイヤーの物", "白いボール（レイヤー Pickup）のどれかを、奥のゴールに投げ入れる → 「ストライカー」");
            int layer = LayerMask.NameToLayer("Pickup");
            if (layer < 0) layer = 0;
            for (int i = 0; i < 3; i++)
            {
                GameObject ball = Pickup(b, "Ball " + (i + 1), new Vector3(-3 + i * .8f, .3f, -3), new Vector3(.4f, .4f, .4f), Paint("White"), true, PrimitiveType.Sphere);
                ball.layer = layer;
            }
            Cube(b, "Goal Back", new Vector3(2, 1, 3.4f), new Vector3(3, 2, .2f), Paint("White"));
            a = Area(b, "Goal Area", new Vector3(2, 1, 2.5f), new Vector3(3, 2, 1.6f), "striker");
            a.who = TitleArea.WhoLayer;
            a.layers = 1 << layer;
            a.receiver = 1;
        }

        // ---- 2章 ----

        private static void Chapter2()
        {
            const int row = 5;
            RowTitle(row, "B-2　2章 称号アクション");
            Transform b = Booth(row, 0, "2-1", "掴んだら", "剣を掴む → 「剣を抜いた者」");
            Action(Pickup(b, "Sword", new Vector3(0, 1, 0), new Vector3(.1f, 1.2f, .1f), Paint("White"), false), TitleAction.ActGrab, "sword");
            Cube(b, "Stone", new Vector3(0, .2f, 0), new Vector3(1, .4f, 1), Paint("Dark"));

            b = Booth(row, 1, "2-2", "離したら", "やかんを掴んで、手を離す → 「熱がり」");
            Action(Pickup(b, "Kettle", new Vector3(0, .7f, 0), new Vector3(.4f, .4f, .4f), Paint("Red"), false, PrimitiveType.Sphere), TitleAction.ActDrop, "atsugari");
            Cube(b, "Table", new Vector3(0, .25f, 0), new Vector3(1, .5f, 1), Paint("Brown"));

            b = Booth(row, 2, "2-3", "持って使ったら", "クラッカーを掴んで、トリガー（デスクトップは左クリック）→ 「お祝い係」\nAuto Hold は Yes");
            Action(Pickup(b, "Cracker", new Vector3(0, .7f, 0), new Vector3(.12f, .4f, .12f), Paint("Yellow"), false, PrimitiveType.Cylinder), TitleAction.ActUse, "oiwai");
            Cube(b, "Table", new Vector3(0, .25f, 0), new Vector3(1, .5f, 1), Paint("Brown"));

            b = Booth(row, 3, "2-4", "触ったら（Interact）", "石碑を「調べる」→ 「考古学者」");
            TitleAction act = Action(Cube(b, "Monument", new Vector3(0, 1, 0), new Vector3(1.2f, 2, .4f), Paint("Dark")), TitleAction.ActInteract, "kouko");
            act.interactText = "調べる";

            b = Booth(row, 4, "2-5", "持ったままN秒", "岩を5秒持ち続ける → 「力持ち」（途中で離すと数え直し）");
            act = Action(Pickup(b, "Rock", new Vector3(0, .4f, 0), new Vector3(.6f, .6f, .6f), Paint("Brown"), false, PrimitiveType.Sphere), TitleAction.ActHoldSeconds, "chikara");
            act.seconds = 5;

            b = Booth(row, 5, "2-6", "投げたら", "ボールを強く投げる（5 m/s 以上）→ 「豪腕」\nそっと離すと出ない");
            act = Action(Pickup(b, "Ball", new Vector3(0, .3f, -2), new Vector3(.35f, .35f, .35f), Paint("Blue"), false, PrimitiveType.Sphere), TitleAction.ActThrow, "gouwan");
            act.throwSpeed = 5;

            b = Booth(row, 6, "2-7", "持ったままN m 動く", "旗を持ったまま10 m歩く → 「旗手」");
            act = Action(Pickup(b, "Flag", new Vector3(0, .8f, 0), new Vector3(.08f, 1.6f, .08f), Paint("Red"), false, PrimitiveType.Cylinder), TitleAction.ActCarryMeters, "kishu");
            act.meters = 10;

            b = Booth(row, 7, "2-8", "N回したら（保存）", "太鼓を3回叩く（Interact）→ 「太鼓の達人」\n回数は Save Key taiko に保存。4-1 の段（5回・10回）にも使う");
            act = Action(Cube(b, "Taiko", new Vector3(0, .6f, 0), new Vector3(1, 1.2f, 1), Paint("Red"), true, PrimitiveType.Cylinder), TitleAction.ActInteract, "taiko_master");
            act.requiredCount = 3;
            act.saveKey = "taiko";
            act.once = false;
            act.cooldownSeconds = .2f;
            act.interactText = "叩く";
        }

        // ---- 3章・7章 ----

        private static void Chapter3And7()
        {
            const int row = 6;
            RowTitle(row, "B-3　3章 カウンター／7章");
            Transform b = Booth(row, 0, "3-1", "ボタンをN回押したら", "ボタンを3回押す → 「連打の人」（カウンター button）");
            GameObject button = Cube(b, "Button", new Vector3(0, .5f, 0), new Vector3(.8f, 1, .8f), Paint("Button"));
            TitleCounter c = button.AddUdonSharpComponent<TitleCounter>();
            c.counterKey = "button";
            c.steps = new[] { 3 };
            c.stepKeys = new[] { "renda" };
            c.interactText = "押す";

            b = Booth(row, 1, "3-2", "回数で段", "押した回数 2・4・6 で「押し見習い」「押し常連」「押し名人」");
            button = Cube(b, "Button", new Vector3(0, .5f, 0), new Vector3(.8f, 1, .8f), Paint("Button"));
            c = button.AddUdonSharpComponent<TitleCounter>();
            c.counterKey = "button2";
            c.steps = new[] { 2, 4, 6 };
            c.stepKeys = new[] { "oshi1", "oshi2", "oshi3" };
            c.interactText = "押す";

            b = Booth(row, 2, "3-3", "1回でたくさん", "赤い太鼓は1回、金の太鼓は1回で10回分。合計20で「どんどん」\n（同じカウンター drum）");
            c = Cube(b, "Drum", new Vector3(-1.5f, .5f, 0), new Vector3(1, 1, 1), Paint("Red"), true, PrimitiveType.Cylinder).AddUdonSharpComponent<TitleCounter>();
            c.counterKey = "drum"; c.addAmount = 1; c.steps = new[] { 20 }; c.stepKeys = new[] { "dondon" }; c.interactText = "叩く（1）";
            c = Cube(b, "Gold Drum", new Vector3(1.5f, .5f, 0), new Vector3(1, 1, 1), Paint("Yellow"), true, PrimitiveType.Cylinder).AddUdonSharpComponent<TitleCounter>();
            c.counterKey = "drum"; c.addAmount = 10; c.steps = new[] { 20 }; c.stepKeys = new[] { "dondon" }; c.interactText = "叩く（10）";

            b = Booth(row, 3, "3-4", "ほかの部品の回数", "3つの展望台（水色の箱）のどれかに入るたびに views を1足す。合計3回で「景色好き」\n（表の条件 count:views>=3）");
            for (int i = 0; i < 3; i++)
            {
                TitleArea view = Area(b, "View " + (i + 1), new Vector3(-3 + i * 3, 1, 1), new Vector3(1.6f, 2, 1.6f));
                view.counterKey = "views";
                view.once = false;
                view.cooldownSeconds = 1;
            }

            b = Booth(row, 4, "3-5", "ほかの Udon から数える", "緑のボタン（ミニゲームのクリアの代わり）が、カウンターへ Add を送る。3回で「ミニゲーム好き」\nカウンターは押せない（Interactable オフ）");
            GameObject counterObject = Cube(b, "Minigame Counter", new Vector3(2, .5f, 1), new Vector3(.8f, 1, .8f), Paint("Dark"));
            c = counterObject.AddUdonSharpComponent<TitleCounter>();
            c.counterKey = "minigame"; c.interactable = false; c.steps = new[] { 3 }; c.stepKeys = new[] { "minigame" };
            GameObject sender = Cube(b, "Clear Button", new Vector3(-1.5f, .5f, 0), new Vector3(.8f, 1, .8f), Paint("Green"));
            ExampleSendEvent send = sender.AddUdonSharpComponent<ExampleSendEvent>();
            send.target = Backing(c);
            send.eventName = "Add";
            send.interactText = "クリアした";
            Tag(b, new Vector3(-1.5f, 1.4f, 0), "クリアした");

            b = Booth(row, 5, "3-6", "全部満たしたら（条件まとめ）", "鐘を鳴らす（Interact）・石を井戸に入れる・台に登る、の3つで「村の英雄」\n別の入室に分けてもよい（これまでに全部）");
            TitleAction bell = Action(Cube(b, "Bell", new Vector3(-3, 1, -1), new Vector3(.8f, .8f, .8f), Paint("Yellow"), true, PrimitiveType.Sphere), TitleAction.ActInteract);
            bell.interactText = "鳴らす";
            GameObject stone = Pickup(b, "Stone", new Vector3(-1, .3f, -3), new Vector3(.3f, .3f, .3f), Paint("Dark"), true);
            Cube(b, "Well", new Vector3(-0.5f, .3f, 1.5f), new Vector3(1.4f, .6f, 1.4f), Paint("Wall"), true, PrimitiveType.Cylinder);
            TitleArea well = Area(b, "Well Area", new Vector3(-0.5f, 1f, 1.5f), new Vector3(1.4f, .8f, 1.4f));
            well.who = TitleArea.WhoObjects; well.objects = new[] { stone }; well.receiver = 1;
            Vector3 deck = Stairs(b, new Vector3(3, 0, -3.5f), 6);
            TitleArea tower = Area(b, "Tower Area", deck + new Vector3(0, 1.1f, 0), new Vector3(2.2f, 2f, 2.2f));
            TitleAllOf all = new GameObject("AllOf Village").AddUdonSharpComponent<TitleAllOf>();
            all.transform.SetParent(b, false);
            all.parts = new TitleTriggerBase[] { bell, well, tower };
            all.saved = true;
            all.saveKey = "village";
            all.grantKeys = new[] { "village_hero" };

            b = Booth(row, 6, "7", "何度も・間をあける", "ゲート（水色の箱）をくぐるたびに gates を1足す（5秒あける）。3回で「くぐり抜け」\n「一度だけ」オフ・Cooldown Seconds 5");
            Cube(b, "Gate Left", new Vector3(-1.2f, 1.25f, 0), new Vector3(.3f, 2.5f, .3f), Paint("Wall"));
            Cube(b, "Gate Right", new Vector3(1.2f, 1.25f, 0), new Vector3(.3f, 2.5f, .3f), Paint("Wall"));
            TitleArea gateArea = Area(b, "Gate Area", new Vector3(0, 1, 0), new Vector3(2, 2, .6f));
            gateArea.counterKey = "gates";
            gateArea.once = false;
            gateArea.cooldownSeconds = 5;
        }

        // ---- 19章 追加の設定（2026-10-28） ----

        private static void Chapter19()
        {
            const int row = 13;
            RowTitle(row, "B-10　19章 追加の設定");

            // 19-1 記録の称号：スタートのエリアに入ってからゴールに入るまでの時間を記録にする。
            Transform b = Booth(row, 0, "19-1", "記録の称号", "緑の床（スタート）に乗ってから赤い床（ゴール）に入るまでの時間が「最速タイム」になる。速くなるたびに更新\n15秒以内で「俊足」（表の条件 record:best_time>=1500）、10秒以内で金の看板が出る（ゲートの記録の値）");
            Cube(b, "Start Pad", new Vector3(-3, .05f, -3), new Vector3(1.6f, .1f, 1.6f), Paint("Green"), false);
            TitleArea start = Area(b, "Start Area", new Vector3(-3, 1, -3), new Vector3(1.6f, 2, 1.6f));
            start.once = false;
            start.cooldownSeconds = 1f;
            Cube(b, "Goal Pad", new Vector3(3, .05f, 3), new Vector3(1.6f, .1f, 1.6f), Paint("Red"), false);
            var goal = new GameObject("Goal Area");
            goal.transform.SetParent(b, false);
            goal.transform.localPosition = new Vector3(3, 1, 3);
            var goalBox = goal.AddComponent<BoxCollider>();
            goalBox.isTrigger = true;
            goalBox.size = new Vector3(1.6f, 2, 1.6f);
            ExampleRace race = goal.AddUdonSharpComponent<ExampleRace>();
            race.manager = manager;
            race.recordKey = "best_time";
            start.eventTargets = new[] { UdonSharpEditorUtility.GetBackingUdonBehaviour(race) };
            start.eventNames = new[] { "_StartRace" };
            GameObject gold = Cube(b, "Gold Sign", new Vector3(0, 1.5f, 3.8f), new Vector3(1.2f, .6f, .1f), Paint("Button"), false);
            TitleGate fast = Gate(b, "Gate Record");
            fast.recordKey = "best_time";
            fast.recordMin = 1000;
            fast.objects = new[] { gold };

            // 19-2 人数の上限・期間。
            b = Booth(row, 1, "19-2", "人数の上限・期間", "左の床：インスタンスに1人だけのときに乗ると「ひとり旅」（前提の人数の上限 1）\n右の床：期間 0101-1231（試し用で毎日）の間に乗ると「季節の来訪者」");
            TitleArea solo = Area(b, "Solo Area", new Vector3(-2, 1, 0), new Vector3(2, 2, 2), "solo");
            solo.maxPlayers = 1;
            TitleArea season = Area(b, "Season Area", new Vector3(2, 1, 0), new Vector3(2, 2, 2), "season");
            season.period = "0101-1231";

            // 19-3 知らせを出さない・効果音。
            b = Booth(row, 2, "19-3", "知らせを出さない・効果音", "床に乗ると「忍び足」をもらうが、獲得の知らせは出ない（結果の「獲得の知らせを出す」がオフ）。ボードで確かめる\n効果音は結果の「効果音」に AudioClip を入れる（空なら知らせの音）");
            TitleArea quiet = Area(b, "Quiet Area", new Vector3(0, 1, 0), new Vector3(2, 2, 2), "quiet");
            quiet.showPopup = false;

            // 19-4 エリアの中にいる人に渡す。
            b = Booth(row, 3, "19-4", "中にいる人に渡す", "青い枠の中に人が入った状態で、ボールを枠に入れると、枠の中にいる人みんなが「応援団」をもらう（入れた人が外にいてもよい）\n2人で試すときは Build & Test");
            TitleArea cheer = Area(b, "Cheer Area", new Vector3(0, 1, 1), new Vector3(4, 2, 3), "cheer");
            GameObject ball = Pickup(b, "Cheer Ball", new Vector3(-3, .5f, -2.5f), new Vector3(.4f, .4f, .4f), Paint("Purple"), true, PrimitiveType.Sphere);
            cheer.who = TitleArea.WhoObjects;
            cheer.objects = new[] { ball };
            cheer.receiver = TitleArea.ReceiverInside;

            // 19-5 中の人数。
            b = Booth(row, 4, "19-5", "中の人数", "枠の中に2人以上そろうと、中にいる人が「集合」をもらう（Build & Test で2人）");
            TitleArea crowd = Area(b, "Crowd Area", new Vector3(0, 1, 0), new Vector3(4, 2, 4), "together2");
            crowd.trigger = TitleArea.OnCrowd;
            crowd.crowdCount = 2;

            // 19-6 アクションの段。
            b = Booth(row, 5, "19-6", "アクションの段", "鈴を持ってトリガーを引く。3回で「鈴の見習い」、6回で「鈴の名人」（段。回数は保存する）");
            TitleAction bell = Action(Pickup(b, "Bell", new Vector3(0, .8f, 0), new Vector3(.3f, .3f, .3f), Paint("Button"), false, PrimitiveType.Sphere), TitleAction.ActUse);
            bell.saveKey = "bell";
            bell.once = false;
            bell.cooldownSeconds = 0f;
            bell.steps = new[] { 3, 6 };
            bell.stepKeys = new[] { "bell3", "bell6" };

            // 19-7 ほかの物に当てる。
            b = Booth(row, 6, "19-7", "ほかの物に当てる", "ボールを持って、または投げて的（赤い板）に当てると「的当て」");
            GameObject target = Cube(b, "Target", new Vector3(0, 1.2f, 3), new Vector3(1.5f, 1.5f, .2f), Paint("Red"));
            TitleAction hit = Action(Pickup(b, "Throw Ball", new Vector3(0, .5f, -2.5f), new Vector3(.3f, .3f, .3f), Paint("Green"), false, PrimitiveType.Sphere), TitleAction.ActHit, "hit");
            hit.hitObjects = new[] { target };

            // 19-8 ゲートで Interact を切り替える。
            b = Booth(row, 7, "19-8", "押せるかを切り替える", "「鍵の持ち主」を持っている人だけ、右の箱を押して「宝箱を開けた」をもらえる（ゲートの「満たしたら押せる Udon」）");
            GrantButton(b, new Vector3(-2, .3f, -2), "keyholder", "鍵の持ち主");
            GameObject chest = Cube(b, "Chest", new Vector3(2, .4f, 0), new Vector3(1, .8f, .7f), Paint("Purple"));
            TitleAction open = Action(chest, TitleAction.ActInteract, "chest");
            open.interactText = "開ける";
            TitleGate chestGate = Gate(b, "Gate Chest", "keyholder");
            chestGate.interactTargets = new[] { UdonSharpEditorUtility.GetBackingUdonBehaviour(open) };

            // 19-9 保存しないカウンター。
            b = Booth(row, 8, "19-9", "保存しないカウンター", "ボタンを3回押すと「三連打」。入り直すと回数は0から（カウンターの「保存する」がオフ）");
            GameObject tap = Cube(b, "Tap Button", new Vector3(0, .4f, 0), new Vector3(.8f, .8f, .8f), Paint("Button"));
            TitleCounter counter = tap.AddUdonSharpComponent<TitleCounter>();
            counter.counterKey = "tap_session";
            counter.saved = false;
            counter.steps = new[] { 3 };
            counter.stepKeys = new[] { "tap3" };

            // 19-10 短い書き方・テスト。
            Booth(row, 9, "19-10", "visit>=・stay>=・テスト", "「訪問者」は visit>=1、「ひと休み」は stay>=1（stat:visit_days・stat:stay_min と同じ）\nマネージャーの「Editor で始めたとき全称号を持つ」をオンにすると、Play で全部の称号を持って始まる（保存しない）");

            // 19-11 エリアに入ったら称号を外す・入れ替える。
            b = Booth(row, 10, "19-11", "称号を外す・入れ替える", "「迷子」をもらって左の案内所に入ると「迷子」が外れる\n「見習い」をもらって右の修業場に入ると「見習い」が外れて「一人前」になる（外す称号・渡す称号）");
            GrantButton(b, new Vector3(-3, .3f, -3), "lost", "迷子");
            TitleArea info = Area(b, "Info Desk Area", new Vector3(-2, 1, 1), new Vector3(2.5f, 2, 2.5f));
            info.revokeKeys = new[] { "lost" };
            info.requiredKeys = new[] { "lost" };
            info.once = false;
            GrantButton(b, new Vector3(1, .3f, -3), "apprentice", "見習い");
            RevokeButton(b, new Vector3(2, .3f, -3), "外す", "apprentice", "journeyman");
            TitleArea training = Area(b, "Training Area", new Vector3(2, 1, 1), new Vector3(2.5f, 2, 2.5f), "journeyman");
            training.revokeKeys = new[] { "apprentice" };
            training.requiredKeys = new[] { "apprentice" };
            training.once = false;
        }

        // ---- 4章・5章 ----

        private static void Chapter4And5()
        {
            const int row = 7;
            RowTitle(row, "B-4　4章 表の条件／5章 接続語");
            Booth(row, 0, "4-1", "カウンターの値（count:）", "2-8 の太鼓を5回で「太鼓の見習い」、10回で「太鼓の名人」\n表の条件 count:taiko>=5 / >=10");

            Transform b = Booth(row, 1, "4-2", "行動の値（stat:）", "ジャンプ3回・30 m歩く・階段で高さ3 m・上から落ちる・物を3回掴む・椅子に座る・1分いる などで自動でもらえる（30個。称号の表の s_ の行）\n2人・VR・アバター・撫でる・ハイタッチ・バトンの手渡しの例は Build & Test で");
            Vector3 deck = Stairs(b, new Vector3(-3, 0, -3.5f), 10);
            for (int i = 0; i < 3; i++) Pickup(b, "Cube " + (i + 1), new Vector3(2 + i * .6f, .2f, -2), new Vector3(.3f, .3f, .3f), Paint("Green"), false);
            // 椅子（座った回数・時間）。押すと座る（ExampleSit）。
            GameObject chair = Cube(b, "Chair", new Vector3(3, .25f, 1.5f), new Vector3(.6f, .5f, .6f), Paint("Purple"));
            chair.AddComponent<VRCStation>();
            chair.AddUdonSharpComponent<TitleSeat>();
            chair.AddUdonSharpComponent<ExampleSit>();
            // バトン（ほかの人から手渡しで受け取ると数える。相手が持っている様子が見えるよう、同期する物にする）。
            Action(Pickup(b, "Baton", new Vector3(2.4f, .8f, -.5f), new Vector3(.05f, .3f, .05f), Paint("Red"), true, PrimitiveType.Cylinder), TitleAction.ActReceive);

            Booth(row, 2, "4-3", "持っている数（owned>=）", "称号を10個集めると「コレクター」（ほかの区画で集める）");

            b = Booth(row, 3, "4-4", "全部そろったら（all:）", "暗い部屋（地下）に入る → 「地下の探検家」。1-1 の屋上とそろえると「上下を制した人」");
            Cube(b, "Basement Roof", new Vector3(0, 2.6f, 1), new Vector3(4, .2f, 4), Paint("Dark"));
            Area(b, "Basement Area", new Vector3(0, 1, 1), new Vector3(3.6f, 2, 3.6f), "basement");

            Booth(row, 4, "4-5", "条件をつなげる", "ジャンプ5回で「よく跳ぶ人」、20 m歩くと「歩く人」、2つそろうと続けて「アスリート」");
            Booth(row, 5, "4-6", "期間限定（date:）", "「今日の来訪者」は date:0101-1231（試し用で毎日）なので入室してすぐもらえる\n「かぼちゃ」は 10/25〜10/31 だけ");
            Booth(row, 6, "4-7", "見本のパック", "Project の ExampleTitles（称号の表）を選び、インスペクターの「見本の称号を足す」から足す（Play していないとき）");
            Booth(row, 7, "5-1", "表の条件で解禁", "称号を3つ集めると接続語「♛」が使えるようになる（ボードの接続語の一覧で確かめる）");

            b = Booth(row, 8, "5-2", "部品の結果で解禁", "ステージ（水色の箱）に5秒いる → 接続語「♪」が使えるようになる");
            Cube(b, "Stage", new Vector3(0, .2f, 1), new Vector3(3, .4f, 2), Paint("Purple"));
            TitleArea stage = Area(b, "Stage Area", new Vector3(0, 1.4f, 1), new Vector3(3, 2, 2), "note");
            stage.trigger = TitleArea.OnStay;
            stage.seconds = 5;
        }

        // ---- 6章 ----

        private static void Chapter6()
        {
            const int row = 8;
            RowTitle(row, "B-5　6章 前提の条件");
            Transform b = Booth(row, 0, "6-1", "持っている人だけ", "「見習い騎士」をもらってから闘技場（水色の箱）に入る → 「騎士」\nないときは何も出ない");
            GrantButton(b, new Vector3(-3, .3f, -3), "squire", "見習い騎士");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "squire", "knight");
            TitleArea a = Area(b, "Arena Area", new Vector3(1.5f, 1, 1), new Vector3(3, 2, 3), "knight");
            a.requiredKeys = new[] { "squire" };

            b = Booth(row, 1, "6-2", "持っている人には渡さない", "「呪い」がない人が泉に入ると「清らかな人」。呪いをもらってから入っても出ない");
            GrantButton(b, new Vector3(-3, .3f, -3), "curse", "呪い");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "curse", "pure");
            a = Area(b, "Spring Area", new Vector3(1.5f, 1, 1), new Vector3(3, 2, 3), "pure");
            a.forbiddenKeys = new[] { "curse" };

            b = Booth(row, 2, "6-3", "装備している人だけ", "「勇者」をもらい、ボード（この列の左）で肩書きに入れて「決定」してから魔王の間に入る → 「魔王を倒した者」");
            GrantButton(b, new Vector3(-3, .3f, -3), "hero", "勇者");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "maou_slayer");
            a = Area(b, "Demon Area", new Vector3(1.5f, 1, 1), new Vector3(3, 2, 3), "maou_slayer");
            a.equippedKeys = new[] { "hero" };

            b = Booth(row, 3, "6-4", "物を持っている人だけ", "花束を持って展望台（水色の箱）に入る → 「ロマンチスト」。持たずに入っても出ない");
            GameObject flowers = Pickup(b, "Bouquet", new Vector3(-3, .7f, -3), new Vector3(.25f, .4f, .25f), Paint("Red"), false, PrimitiveType.Capsule);
            Cube(b, "Table", new Vector3(-3, .25f, -3), new Vector3(1, .5f, 1), Paint("Brown"));
            a = Area(b, "Viewpoint Area", new Vector3(1.5f, 1, 1), new Vector3(3, 2, 3), "romantic");
            a.heldObjects = new[] { flowers };

            b = Booth(row, 4, "6-5", "N人以上いるときだけ", "2人以上いるときにフロアに入る → 「パーティーピープル」（Min Players 2。Build & Test で2人）");
            a = Area(b, "Dance Area", new Vector3(0, 1, 1), new Vector3(4, 2, 3), "party");
            a.minPlayers = 2;

            b = Booth(row, 5, "6-6", "VR だけ・デスクトップだけ", "左の箱：VR の人だけ「体操選手」／右の箱：VR でない人だけ「デスクトップ派」");
            a = Area(b, "VR Area", new Vector3(-2, 1, 1), new Vector3(2.4f, 2, 2.4f), "gymnast");
            a.device = 1;
            a = Area(b, "Desktop Area", new Vector3(2, 1, 1), new Vector3(2.4f, 2, 2.4f), "desktop_fan");
            a.device = 2;

            b = Booth(row, 6, "6-7", "組み合わせる", "「勇者」を装備し、聖剣を手に持ち、「呪い」なしで祭壇に入る → 「伝説の勇者」\n（勇者・呪いのボタンは 6-2・6-3）");
            GameObject holy = Pickup(b, "Holy Sword", new Vector3(-3, .9f, -3), new Vector3(.1f, 1f, .1f), Paint("Yellow"), false);
            Cube(b, "Table", new Vector3(-3, .2f, -3), new Vector3(1, .4f, 1), Paint("Brown"));
            a = Area(b, "Altar Area", new Vector3(1.5f, 1, 1), new Vector3(3, 2, 3), "legend_hero");
            a.equippedKeys = new[] { "hero" };
            a.heldObjects = new[] { holy };
            a.forbiddenKeys = new[] { "curse" };
            a.minPlayers = 1;
        }

        // ---- 8章（前半） ----

        private static void Chapter8a()
        {
            const int row = 9;
            RowTitle(row, "B-6　8章 称号ゲート（1）");
            Transform b = Booth(row, 0, "8-1", "持つ人にだけ見せる", "「霊感持ち」をもらうと幽霊が見える");
            GrantButton(b, new Vector3(-3, .3f, -3), "reikan", "霊感持ち");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "reikan");
            GameObject ghost = Cube(b, "Ghost", new Vector3(1.5f, 1.2f, 1), new Vector3(.8f, 1.4f, .8f), Mat("Ghost", new UnityEngine.Color(.9f, .95f, 1f, .6f), true), false, PrimitiveType.Capsule);
            TitleGate g = Gate(b, "Gate Ghost", "reikan");
            g.renderers = new[] { ghost.GetComponent<Renderer>() };

            b = Booth(row, 1, "8-2", "持つ人だけ乗れる床", "「空の住人」を持つと、階段の先の雲に乗れる（ないとすり抜けて落ちる）");
            GrantButton(b, new Vector3(-3, .3f, -3), "sora", "空の住人");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "sora");
            Vector3 deck = Stairs(b, new Vector3(2, 0, -3.5f), 5);
            GameObject cloud = Cube(b, "Cloud", deck + new Vector3(0, 0, 2.6f), new Vector3(2.4f, .2f, 2.4f), Paint("White"));
            g = Gate(b, "Gate Cloud", "sora");
            g.colliders = new[] { cloud.GetComponent<Collider>() };

            b = Booth(row, 2, "8-3", "持つ人にだけ物を出す", "「料理人」をもらうと、台の上にレシピ本が出る");
            GrantButton(b, new Vector3(-3, .3f, -3), "cook", "料理人");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "cook");
            Cube(b, "Table", new Vector3(1.5f, .4f, 1), new Vector3(1.4f, .8f, 1), Paint("Brown"));
            GameObject book = Cube(b, "Recipe Book", new Vector3(1.5f, .9f, 1), new Vector3(.5f, .1f, .7f), Paint("Green"));
            g = Gate(b, "Gate Book", "cook");
            g.objects = new[] { book };

            b = Booth(row, 3, "8-4", "ない人には壁（満たすまで出す物）", "「通行証」がないと赤い壁で奥に入れない。もらうと壁が消える");
            GrantButton(b, new Vector3(-3, .3f, -3), "pass", "通行証");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "pass");
            Room(b);
            GameObject wall = DoorWall(b, "Door Wall");
            g = Gate(b, "Gate Door", "pass");
            g.objectsWhenNot = new[] { wall };

            b = Booth(row, 4, "8-5", "反転（壁1つで）", "8-4 と同じ。「通行証」を持つ人の画面で壁が消える（Invert）。入室してすぐも壁は出ている");
            GrantButton(b, new Vector3(-3, .3f, -3), "pass", "通行証");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "pass");
            Room(b);
            wall = DoorWall(b, "Door Wall", 0, Paint("Purple"));
            g = wall.AddUdonSharpComponent<TitleGate>();
            g.titleKeys = new[] { "pass" };
            g.invert = true;
            g.renderers = new[] { wall.GetComponent<Renderer>() };
            g.colliders = new[] { wall.GetComponent<Collider>() };

            b = Booth(row, 5, "8-6", "持つ人だけ掴める", "「魔法使い」を持つと杖を掴める（ないと掴めない）");
            GrantButton(b, new Vector3(-3, .3f, -3), "wizard", "魔法使い");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "wizard");
            GameObject wand = Pickup(b, "Wand", new Vector3(1.5f, .9f, 1), new Vector3(.06f, .8f, .06f), Paint("Purple"), true, PrimitiveType.Cylinder);
            Cube(b, "Table", new Vector3(1.5f, .25f, 1), new Vector3(1, .5f, 1), Paint("Brown"));
            g = Gate(b, "Gate Wand", "wizard");
            g.pickupObjects = new[] { wand };

            b = Booth(row, 6, "8-7", "装備している人だけ", "「影」をもらい、ボード（この列の左）で肩書きに入れて決定すると、隠し通路（緑の板）が出る");
            GrantButton(b, new Vector3(-3, .3f, -3), "kage", "影");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "kage");
            GameObject passage = Cube(b, "Hidden Passage", new Vector3(1.5f, .15f, 1), new Vector3(2, .1f, 3), Paint("Green"));
            g = Gate(b, "Gate Passage", "kage");
            g.mode = TitleGate.ModeEquipped;
            g.objects = new[] { passage };
        }

        // ---- 8章（後半） ----

        private static void Chapter8b(Transform system)
        {
            const int row = 10;
            RowTitle(row, "B-7　8章 称号ゲート（2）");
            PlaceBoard(system, "Title Board (Gates)", RowOrigin(row - 1, 0) + new Vector3(-13, 1.5f, 6));

            Transform b = Booth(row, 0, "8-8", "5つのうち3つ", "手がかり1〜5のうち3つをもらうと壁が消える（Required Count 3）");
            for (int i = 1; i <= 5; i++) GrantButton(b, new Vector3(-4 + i * 1.1f, .3f, -3.5f), "h" + i, "手がかり" + i);
            RevokeButton(b, new Vector3(3.5f, .3f, -2.5f), "全部外す", "h1", "h2", "h3", "h4", "h5");
            Room(b);
            GameObject wall = DoorWall(b, "Door Wall");
            TitleGate g = Gate(b, "Gate Hints", "h1", "h2", "h3", "h4", "h5");
            g.requiredCount = 3;
            g.objectsWhenNot = new[] { wall };

            b = Booth(row, 1, "8-9", "並び順（合言葉）", "「月」「鍵」をもらい、ボードで「月」「の」「鍵」と並べて決定すると壁が消える（続けて並べる）");
            GrantButton(b, new Vector3(-3, .3f, -3), "clue_a", "月");
            GrantButton(b, new Vector3(-2, .3f, -3), "clue_b", "鍵");
            RevokeButton(b, new Vector3(-1, .3f, -3), "外す", "clue_a", "clue_b");
            Room(b);
            wall = DoorWall(b, "Door Wall");
            g = Gate(b, "Gate Sequence");
            g.sequenceKeys = new[] { "clue_a", "no", "clue_b" };
            g.sequenceContiguous = true;
            g.objectsWhenNot = new[] { wall };

            b = Booth(row, 2, "8-10", "枠の位置", "「星」「扉」をもらい、枠1に「星」、枠3に「扉」を入れて決定すると階段が出る");
            GrantButton(b, new Vector3(-3, .3f, -3), "clue_c", "星");
            GrantButton(b, new Vector3(-2, .3f, -3), "door", "扉");
            RevokeButton(b, new Vector3(-1, .3f, -3), "外す", "clue_c", "door");
            GameObject stairs = new GameObject("Star Stairs");
            stairs.transform.SetParent(b, false);
            Stairs(stairs.transform, new Vector3(2, 0, -1.5f), 4);
            g = Gate(b, "Gate Slots");
            g.slotCheckSlots = new[] { 1, 3 };
            g.slotCheckKeys = new[] { "clue_c", "door" };
            g.objects = new[] { stairs };

            b = Booth(row, 3, "8-11", "持っている数", "称号を5個以上持つと壁が消える（Min Owned 5）");
            Room(b);
            wall = DoorWall(b, "Door Wall");
            g = Gate(b, "Gate Owned");
            g.minOwned = 5;
            g.objectsWhenNot = new[] { wall };

            b = Booth(row, 4, "8-12", "行動の値", "ジャンプを5回すると「常連席」の札が出る（Stat Name jumps・Stat Min 5）");
            GameObject seat = Cube(b, "Seat Sign", new Vector3(1.5f, 1, 1), new Vector3(1.2f, .8f, .1f), Paint("Yellow"));
            g = Gate(b, "Gate Stat");
            g.statName = "jumps";
            g.statMin = 5;
            g.objects = new[] { seat };

            b = Booth(row, 5, "8-13", "イベントを送る", "「DJ」をもらい、肩書きに入れて決定すると OnDjOn、外して決定すると OnDjOff が右の看板に出る");
            GrantButton(b, new Vector3(-3, .3f, -3), "dj", "DJ");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "dj");
            ExampleEventLog log = EventLog(b, new Vector3(2, 1.5f, 1));
            g = Gate(b, "Gate DJ", "dj");
            g.mode = TitleGate.ModeEquipped;
            g.eventTargets = new[] { Backing(log) };
            g.metEvent = "OnDjOn";
            g.unmetEvent = "OnDjOff";

            b = Booth(row, 6, "8-14", "条件を重ねる", "「騎士」を装備し（6-1 で取る）、称号5個以上、ジャンプ10回で門が開く");
            GrantButton(b, new Vector3(-3, .3f, -3), "knight", "騎士");
            Room(b);
            wall = DoorWall(b, "Castle Gate", 0, Paint("Dark"));
            g = Gate(b, "Gate Castle", "knight");
            g.mode = TitleGate.ModeEquipped;
            g.minOwned = 5;
            g.statName = "jumps";
            g.statMin = 10;
            g.objectsWhenNot = new[] { wall };
        }

        // ---- 9〜12章 ----

        private static void Chapter9To12()
        {
            const int row = 11;
            RowTitle(row, "B-8　9〜12章");
            Transform b = Booth(row, 0, "9", "称号を鍵にする", "「鍵師」を持つ人だけ、宝箱を Interact すると中身（金の玉）が出る（本人の画面だけ）");
            GrantButton(b, new Vector3(-3, .3f, -3), "locksmith", "鍵師");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "locksmith");
            GameObject chest = Cube(b, "Chest", new Vector3(1.5f, .4f, 1), new Vector3(1.2f, .8f, .8f), Paint("Brown"));
            GameObject treasure = Cube(b, "Treasure", new Vector3(1.5f, 1.2f, 1), new Vector3(.4f, .4f, .4f), Paint("Yellow"), false, PrimitiveType.Sphere);
            treasure.SetActive(false);
            TitleAction act = Action(chest, TitleAction.ActInteract);
            act.requiredKeys = new[] { "locksmith" };
            act.enableObjects = new[] { treasure };
            act.interactText = "開ける";

            b = Booth(row, 1, "10", "肩書きの枠を解禁", "最初は枠1〜3だけ。「上級者」をもらうとボードの枠4〜6が使える（枠7〜10は使わない設定）");
            GrantButton(b, new Vector3(-3, .3f, -3), "advanced", "上級者");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "advanced");

            b = Booth(row, 2, "11-1", "カウンターを足す", "コインを拾う（掴む）たびに coins を1足す。5回で「コイン集め」（表の条件 count:coins>=5）");
            for (int i = 0; i < 3; i++)
            {
                GameObject coin = Pickup(b, "Coin " + (i + 1), new Vector3(-1 + i, .2f, 0), new Vector3(.3f, .05f, .3f), Paint("Yellow"), false, PrimitiveType.Cylinder);
                act = Action(coin, TitleAction.ActGrab);
                act.counterKey = "coins";
                act.once = false;
            }

            b = Booth(row, 3, "11-2", "イベントを送る", "ゴール（水色の箱）に入ると、右の看板に OnGoal が出て、黄色の玉が出たり消えたりする（花火の代わり）");
            ExampleEventLog log = EventLog(b, new Vector3(2.5f, 1.5f, 2));
            TitleArea goal = Area(b, "Goal Area", new Vector3(-1, 1, 1), new Vector3(2.4f, 2, 2.4f));
            goal.eventTargets = new[] { Backing(log) };
            goal.eventNames = new[] { "OnGoal" };
            goal.once = false;
            goal.cooldownSeconds = 2;

            b = Booth(row, 4, "11-3", "物を出す・消す", "レバーを Interact すると、橋（緑）が出て柵（赤）が消える。「レバーを引いた」ももらえる\n戻すのは 12-3 のボタン");
            GameObject bridge = Cube(b, "Bridge", new Vector3(1.5f, .15f, 1.5f), new Vector3(1.5f, .1f, 3), Paint("Green"));
            bridge.SetActive(false);
            GameObject fence = Cube(b, "Fence", new Vector3(1.5f, .6f, 0), new Vector3(2, 1.2f, .2f), Paint("Red"));
            act = Action(Cube(b, "Lever", new Vector3(-2, .6f, 0), new Vector3(.2f, 1.2f, .2f), Paint("Dark")), TitleAction.ActInteract, "lever");
            act.enableObjects = new[] { bridge };
            act.disableObjects = new[] { fence };
            act.once = false;
            act.interactText = "レバーを引く";

            b = Booth(row, 5, "12-1", "全部やり直す", "このボタンを3秒以内に2回押すと、称号・肩書き・カウンター・行動の値が全部消える");
            GameObject reset = Cube(b, "Reset All", new Vector3(0, .5f, 0), new Vector3(.8f, 1, .8f), Paint("Red"));
            TitleReset r = reset.AddUdonSharpComponent<TitleReset>();
            r.mode = TitleReset.ModeAll;
            r.interactText = "全部やり直す（2回押す）";

            b = Booth(row, 6, "12-2", "決めた称号だけ外す", "謎解きの称号（月・鍵・星・奥の部屋の到達者）だけを外す。ほかの称号は残る");
            reset = Cube(b, "Reset Puzzle", new Vector3(0, .5f, 0), new Vector3(.8f, 1, .8f), Paint("Revoke"));
            r = reset.AddUdonSharpComponent<TitleReset>();
            r.mode = TitleReset.ModeKeys;
            r.revokeKeys = new[] { "clue_a", "clue_b", "clue_c", "deep" };
            r.interactText = "謎解きをやり直す（2回押す）";

            b = Booth(row, 7, "12-3", "やり直したあとに物を戻す", "このボタン（2回押す）で「レバーを引いた」を外し、11-3 の橋を消して柵を戻す");
            reset = Cube(b, "Reset Lever", new Vector3(0, .5f, 0), new Vector3(.8f, 1, .8f), Paint("Revoke"));
            r = reset.AddUdonSharpComponent<TitleReset>();
            r.mode = TitleReset.ModeKeys;
            r.revokeKeys = new[] { "lever" };
            r.enableObjects = new[] { fence };
            r.disableObjects = new[] { bridge };
            r.interactText = "レバーを戻す（2回押す）";
        }

        // ---- 13章 ----

        private static void Chapter13(Transform system)
        {
            const int row = 12;
            RowTitle(row, "B-9　13章 見え方・効果・一覧・中継・ヒント");
            PlaceBoard(system, "Title Board (Plates)", RowOrigin(row, 0) + new Vector3(-13, 1.5f, 0));
            Booth(row, 0, "13-1", "名札を軽くする・色", "Hierarchy の World Title Gimmick → Title Nameplates の Hide Meters・Max Shown・Text Color・Back Color（名札はほかの人の頭上。Build & Test で2人）");
            Booth(row, 1, "13-2", "自分の名札を見せない", "ボードの「自分の名札：見せる／見せない」を押す。2人で試すと、相手の画面の名札と一覧（13B）から消える");
            Booth(row, 2, "13-3", "日本語と英語", "マネージャーの言語は「自動」。ClientSim の言語を英語にして Play すると、称号が英語で出る");

            Transform b = Booth(row, 3, "13A-1", "装備で足が速くなる", "「韋駄天」をもらい、肩書きに入れて決定すると走るのが速くなる（外すと戻る）\n13A-3：装備中は近道の看板（緑）が出る");
            GrantButton(b, new Vector3(-3, .3f, -3), "idaten", "韋駄天");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "idaten");
            GameObject shortcut = Cube(b, "Shortcut Sign", new Vector3(2, 1.2f, 1), new Vector3(1.2f, .6f, .1f), Paint("Green"));
            TitlePerk perk = new GameObject("Perk Idaten").AddUdonSharpComponent<TitlePerk>();
            perk.transform.SetParent(b, false);
            perk.titleKeys = new[] { "idaten" };
            perk.mode = TitlePerk.ModeEquipped;
            perk.changeSpeed = true;
            perk.walkSpeed = 4; perk.runSpeed = 7; perk.strafeSpeed = 4;
            perk.objects = new[] { shortcut };

            b = Booth(row, 4, "13A-2", "装備でふわっと跳ぶ", "「月の住人」をもらい、肩書きに入れて決定してジャンプすると、高く・ゆっくり落ちる");
            GrantButton(b, new Vector3(-3, .3f, -3), "tsuki", "月の住人");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "tsuki");
            perk = new GameObject("Perk Moon").AddUdonSharpComponent<TitlePerk>();
            perk.transform.SetParent(b, false);
            perk.titleKeys = new[] { "tsuki" };
            perk.mode = TitlePerk.ModeEquipped;
            perk.changeSpeed = false;
            perk.changeJump = true; perk.jumpImpulse = 4;
            perk.changeGravity = true; perk.gravityStrength = .3f;

            b = Booth(row, 5, "13B", "いまいる人の一覧", "右の板に、部屋にいる人の名前と肩書きが出る（肩書きを決定すると変わる）");
            TitleRoster roster = TitleSystemBuilder.Roster(b, manager, 6);
            roster.transform.localPosition = new Vector3(1.5f, 1.4f, 1);
            roster.transform.localScale = Vector3.one * .0025f;

            b = Booth(row, 6, "13C", "もらったら知らせる（中継）", "どれかの称号をもらうと OnTitleGranted（キーつき）が看板に出る。「王冠」を装備・外すと CrownOn・CrownOff");
            GrantButton(b, new Vector3(-3, .3f, -3), "oukan", "王冠");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "oukan");
            ExampleEventLog log = EventLog(b, new Vector3(2, 1.5f, 1));
            TitleRelay relay = new GameObject("Relay Any").AddUdonSharpComponent<TitleRelay>();
            relay.transform.SetParent(b, false);
            relay.eventTargets = new[] { Backing(log) };
            relay.grantedEvent = "OnTitleGranted";
            relay.keyVariable = "titleKey";
            relay = new GameObject("Relay Crown").AddUdonSharpComponent<TitleRelay>();
            relay.transform.SetParent(b, false);
            relay.watchKeys = new[] { "oukan" };
            relay.eventTargets = new[] { Backing(log) };
            relay.grantedEvent = "";
            relay.equippedEvent = "CrownOn";
            relay.unequippedEvent = "CrownOff";

            b = Booth(row, 7, "13E-1", "ヒントのボタン（名前と取得条件）", "本を「読む」→「迷宮の主」（隠す）と「星読み」（一覧に出さない）の名前と取得条件が、ボード（この列の左）で見える\n13E-3：2人で、片方が「迷宮の主」を装備すると、もう片方にも明かされる（マネージャーの「ほかの人の装備で明かす」）");
            GameObject book = Cube(b, "Hint Book", new Vector3(0, 1, 0), new Vector3(.8f, .2f, .6f), Paint("Button"));
            TitleAction hint = Action(book, TitleAction.ActInteract);
            hint.revealKeys = new[] { "hint_lord", "hint_star" };
            hint.revealWhat = 0;
            hint.once = false;
            hint.interactText = "ヒントを読む";
            GrantButton(b, new Vector3(-3, .3f, -3), "hint_lord", "迷宮の主");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "hint_lord");

            b = Booth(row, 8, "13E-2", "段階のヒント（名前 → 取得条件）", "左の石板で「夜の番人」の名前だけ、右の石板で取得条件も見える（ボードで「？？？」→ 名前 → 取得条件の順に変わる）\nやり直しのボタン（12-1）で明かした分も消える");
            GameObject stone = Cube(b, "Hint Name", new Vector3(-1, 1, 0), new Vector3(.8f, 1.2f, .2f), Paint("Dark"));
            hint = Action(stone, TitleAction.ActInteract);
            hint.revealKeys = new[] { "hint_night" };
            hint.revealWhat = 1;
            hint.once = false;
            hint.interactText = "名前のヒント";
            stone = Cube(b, "Hint Condition", new Vector3(1, 1, 0), new Vector3(.8f, 1.2f, .2f), Paint("Dark"));
            hint = Action(stone, TitleAction.ActInteract);
            hint.revealKeys = new[] { "hint_night" };
            hint.revealWhat = 2;
            hint.once = false;
            hint.interactText = "取得条件のヒント";
            GrantButton(b, new Vector3(-3, .3f, -3), "hint_night", "夜の番人");
        }

        // ---- A-0 はじめの5つの型（説明書 00 の 8章、2026-10-28） ----
        // 00 の手順どおり、右クリックのメニューで作ったときと同じ形にする（壁は「称号を持つ人だけ通れる壁にする」と同じ反転のゲート）。

        private static void QuickStart(Transform system)
        {
            const int row = 0;
            RowTitle(row, "A-0　はじめの5つの型（説明書 00 の 8章）");
            PlaceBoard(system, "Title Board (Quick Start)", RowOrigin(row, 0) + new Vector3(-13, 1.5f, 0));

            Transform b = Booth(row, 0, "00-8-1", "交流：常連さんと常連だけの部屋", "部品なし。表に visit>=7（常連さん）・stay>=600・together_min・pats を書くだけ。「常連さん」を持つと紫の壁が消える\n試すときはテスト用パネルで visit_days を 7 にする", "表の条件 4-2・19-10／称号を持つ人だけ通れる壁 8-5");
            Room(b);
            WallGate(DoorWall(b, "Lounge Door", 0, Paint("Purple")), "qs_regular");

            b = Booth(row, 1, "00-8-2", "探索：スタンプと全部回った人の部屋", "3つの水色を回る（途中はボードで「？？？」）。3つ目で「冒険家」がもらえ、赤い壁が消える\n灰のボタンでスタンプを外す", "エリア（入ったら）1-1／Name Mode「隠す」／表の all: 4-4／称号を持つ人だけ通れる壁 8-5");
            Vector3[] spots = { new Vector3(-3, 1, -2), new Vector3(0, 1, -3), new Vector3(3, 1, -2) };
            for (int i = 0; i < 3; i++) Area(b, "Spot " + (i + 1), spots[i], new Vector3(1.4f, 2, 1.4f), "qs_spot" + (i + 1));
            Room(b);
            WallGate(DoorWall(b, "Explorer Door", 0), "qs_explorer");
            RevokeButton(b, new Vector3(-3.5f, .3f, -4.2f), "スタンプを外す", "qs_spot1", "qs_spot2", "qs_spot3", "qs_explorer");

            b = Booth(row, 2, "00-8-3", "ゲーム：ゴールと段位と近道", "左の水色（ゴール）に入ると「ゴールした人」、黄色の壁が消えて近道が通れる。10秒あけて3回入ると「常連ランナー」\n灰のボタンで称号を外す（回数は残る）", "エリア（入ったら・一度だけオフ・Counter Key・Cooldown Seconds）1-1・7・11-1／表の count: 4-1／称号を持つ人だけ通れる壁 8-5");
            TitleArea goal = Area(b, "Goal", new Vector3(-2.5f, 1, -2), new Vector3(2, 2, 1.6f), "qs_clear");
            goal.counterKey = "qs_clears";
            goal.counterAdd = 1;
            goal.once = false;
            goal.cooldownSeconds = 10f;
            Tag(b, new Vector3(-2.5f, 2.3f, -2), "ゴール");
            Room(b);
            WallGate(DoorWall(b, "Shortcut Door", 0, Paint("Yellow")), "qs_clear");
            RevokeButton(b, new Vector3(-3.5f, .3f, -4.2f), "称号を外す", "qs_clear", "qs_clear10");

            b = Booth(row, 3, "00-8-4", "イベント：開催日の記念と記念の部屋", "部品なし。表に date:20261103-20261105 を書くと、その期間に来た人に「2026年の来場者」が渡る。持つ人だけ緑の壁が消える\n期間外は橙のボタンでもらって試す（本番ではボタンを置かない）", "表の date: 4-6／称号を持つ人だけ通れる壁 8-5");
            Room(b);
            WallGate(DoorWall(b, "Expo Door", 0, Paint("Green")), "qs_expo");
            GrantButton(b, new Vector3(-3, .3f, -3), "qs_expo", "2026年の来場者");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "qs_expo");

            b = Booth(row, 4, "00-8-5", "プログラム：自分の判定で渡す", "白い箱を押すと、見本のスクリプト（ExampleGrant）が _GrantKey で「ミニゲームの勝者」を渡し、_AddCount で回数を1足す。3回で「ミニゲームの常連」", "UdonSharp の _GrantKey・_AddCount（02 の 5-1）／表の count: 4-1");
            GameObject game = Cube(b, "Minigame", new Vector3(0, .6f, -1), new Vector3(1.2f, 1.2f, 1.2f), Paint("White"));
            ExampleGrant grant = game.AddUdonSharpComponent<ExampleGrant>();
            grant.titles = manager;
            RevokeButton(b, new Vector3(-3.5f, .3f, -4.2f), "称号を外す", "qs_game", "qs_game3");
        }

        // 右クリックの「称号を持つ人だけ通れる壁にする」と同じ：壁に反転のゲートを付け、持つ人の画面で見た目と当たり判定を消す。
        private static void WallGate(GameObject wall, string key)
        {
            TitleGate gate = wall.AddUdonSharpComponent<TitleGate>();
            gate.manager = manager;
            gate.titleKeys = new[] { key };
            gate.invert = true;
            gate.renderers = wall.GetComponentsInChildren<Renderer>(true);
            gate.colliders = wall.GetComponentsInChildren<Collider>(true);
        }

        // ---- 15章 ----

        private static void Chapter15(Transform system)
        {
            const int row = 1;
            RowTitle(row, "A-1　15章 組み合わせ");
            PlaceBoard(system, "Title Board (Combos)", RowOrigin(row, 0) + new Vector3(-13, 1.5f, 0));

            Transform b = Booth(row, 0, "15-1", "スタンプラリー", "5つの箱を回る（途中はボードで「？？？」）。5つ目で「スタンプコンプリート」\n灰のボタンでスタンプだけ外す", "エリア（入ったら）1-1／Name Mode「隠す」13／表の all: 4-4／やり直し（指定の称号）12-2");
            Vector3[] spots = { new Vector3(-3, 1, -1), new Vector3(-1.5f, 1, 2), new Vector3(0, 1, -1), new Vector3(1.5f, 1, 2), new Vector3(3, 1, -1) };
            for (int i = 0; i < 5; i++) Area(b, "Stamp " + (i + 1), spots[i], new Vector3(1.2f, 2, 1.2f), "st_" + (i + 1));
            RevokeButton(b, new Vector3(-3.5f, .3f, -3.5f), "スタンプを外す", "st_1", "st_2", "st_3", "st_4", "st_5", "st_all");

            b = Booth(row, 1, "15-2", "謎解き", "手がかり（白い玉3つ）のうち2つを調べると扉1（赤）が消える。ボードで「月の鍵」と並べると扉2（紫）が消える。奥に着くと枠4〜6が解禁", "アクション（触ったら）2-4／ゲート（N個・並び順）8-8・8-9／エリア 1-1／枠の解禁 10");
            string[] clues = { "clue_a", "clue_b", "clue_c" };
            for (int i = 0; i < 3; i++)
            {
                TitleAction clue = Action(Cube(b, "Clue " + (i + 1), new Vector3(-3 + i * 3, .4f, -3), new Vector3(.4f, .4f, .4f), Paint("White"), true, PrimitiveType.Sphere), TitleAction.ActInteract, clues[i]);
                clue.interactText = "調べる";
            }
            Room(b);
            GameObject door1 = DoorWall(b, "Door 1", 0);
            GameObject door2 = DoorWall(b, "Door 2", 1.6f, Paint("Purple"));
            TitleGate g = Gate(b, "Gate Door 1", clues);
            g.requiredCount = 2;
            g.objectsWhenNot = new[] { door1 };
            g = Gate(b, "Gate Door 2");
            g.sequenceKeys = new[] { "clue_a", "no", "clue_b" };
            g.sequenceContiguous = true;
            g.objectsWhenNot = new[] { door2 };
            Area(b, "Deep Area", new Vector3(0, 1, 3.2f), new Vector3(8, 2, 1.6f), "deep", "advanced");

            b = Booth(row, 2, "15-3", "みんなで集まったら", "2人以上いるときに広場（水色）に10秒いる → 「集会の参加者」。もらうと記念の柱が見える", "エリア（続けてN秒）1-3／N人以上 6-5／ゲート（満たしたら出す物）8-3");
            TitleArea a = Area(b, "Plaza Area", new Vector3(0, 1, 0), new Vector3(4, 2, 4), "shuukai");
            a.trigger = TitleArea.OnStay;
            a.seconds = 10;
            a.minPlayers = 2;
            GameObject monument = Cube(b, "Monument", new Vector3(3, 1.5f, 3), new Vector3(.6f, 3, .6f), Paint("Yellow"), true, PrimitiveType.Cylinder);
            g = Gate(b, "Gate Monument", "shuukai");
            g.objects = new[] { monument };

            b = Booth(row, 3, "15-4", "段位と、段位で開く部屋", "白いボールを的（水色の箱）に入れるたびに target を1足す。2・4・6回で初段・達人・的の名人。名人で壁が消える", "エリア（物を置いたら）1-7／カウンターを足す 11-1／表の count: 4-1／ゲート（満たすまで出す物）8-4");
            for (int i = 0; i < 2; i++) Pickup(b, "Ball " + (i + 1), new Vector3(-3 + i, .3f, -3.5f), new Vector3(.35f, .35f, .35f), Paint("White"), true, PrimitiveType.Sphere);
            var balls = new[] { b.Find("Ball 1").gameObject, b.Find("Ball 2").gameObject };
            a = Area(b, "Target Area", new Vector3(-3, 1, -1), new Vector3(1.6f, 1.6f, .8f));
            a.who = TitleArea.WhoObjects; a.objects = balls; a.receiver = 1;
            a.counterKey = "target"; a.once = false; a.cooldownSeconds = 1;
            Room(b);
            GameObject wall = DoorWall(b, "Master Wall", 0, Paint("Dark"));
            g = Gate(b, "Gate Master", "dan3");
            g.objectsWhenNot = new[] { wall };

            b = Booth(row, 4, "15-5", "分かれ道", "左の光の祭壇か、右の闇の祭壇の、どちらか一方だけもらえる。選んだ道の飾りが見える。灰のボタンで選び直し", "エリア（入ったら）1-1／持っている人には渡さない 6-2／ゲート 8-3／やり直し 12-2");
            a = Area(b, "Light Altar", new Vector3(-2.5f, 1, 1), new Vector3(2, 2, 2), "light");
            a.forbiddenKeys = new[] { "dark" };
            a = Area(b, "Dark Altar", new Vector3(2.5f, 1, 1), new Vector3(2, 2, 2), "dark");
            a.forbiddenKeys = new[] { "light" };
            GameObject lightDecor = Cube(b, "Light Decor", new Vector3(-2.5f, 2.6f, 1), new Vector3(.6f, .6f, .6f), Paint("Yellow"), false, PrimitiveType.Sphere);
            GameObject darkDecor = Cube(b, "Dark Decor", new Vector3(2.5f, 2.6f, 1), new Vector3(.6f, .6f, .6f), Paint("Purple"), false, PrimitiveType.Sphere);
            Gate(b, "Gate Light", "light").objects = new[] { lightDecor };
            Gate(b, "Gate Dark", "dark").objects = new[] { darkDecor };
            RevokeButton(b, new Vector3(0, .3f, -3), "選び直す", "light", "dark");

            b = Booth(row, 5, "15-6", "隠し称号と特別な接続語", "柱の裏の小さな箱に入ると「秘密を知る者」（それまでボードに出ない）。「コレクター」もそろうと接続語「♚」", "エリア（入ったら）1-1／Name Mode「一覧に出さない」13／接続語の解禁 5-1／表の all: 4-4");
            Cube(b, "Pillar", new Vector3(0, 1.5f, 1), new Vector3(1.5f, 3, 1.5f), Paint("Wall"));
            Area(b, "Secret Area", new Vector3(0, .6f, 2.4f), new Vector3(1.2f, 1.2f, .8f), "secret");

            b = Booth(row, 6, "15-7", "称号を持つ人だけ押せるボタン", "A（左）：「職人」がないと押しても数えない。3回で「鍛冶師」\nB（右）：「職人」を持つ人にだけボタンが見える。3回で「鍛冶の名手」", "アクション＋持っている人だけ 6-1／カウンター 3-1／表の count: 4-1／ゲート 8-3");
            GrantButton(b, new Vector3(-3, .3f, -3), "shokunin", "職人");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "shokunin");
            TitleAction smith = Action(Cube(b, "Anvil A", new Vector3(-1.5f, .5f, 1), new Vector3(1, 1, .6f), Paint("Dark")), TitleAction.ActInteract);
            smith.requiredKeys = new[] { "shokunin" };
            smith.counterKey = "smith";
            smith.once = false;
            smith.interactText = "鍛える";
            GameObject anvilB = Cube(b, "Anvil B", new Vector3(2, .5f, 1), new Vector3(1, 1, .6f), Paint("Dark"));
            TitleCounter c = anvilB.AddUdonSharpComponent<TitleCounter>();
            c.counterKey = "smith2"; c.steps = new[] { 3 }; c.stepKeys = new[] { "smith2_title" }; c.interactText = "鍛える";
            g = Gate(b, "Gate Anvil B", "shokunin");
            g.objects = new[] { anvilB };

            b = Booth(row, 7, "15-8", "ハロウィンの部屋", "「かぼちゃ」（10/25〜10/31 に来るともらえる）を持つ人だけ壁が消え、中のかぼちゃが見える。期間外はテスト用パネルで渡して試す", "表の date: 4-6／ゲート（反転）8-5／ゲート（見せる）8-1");
            Room(b);
            wall = DoorWall(b, "Costume Door", 0, Paint("Button"));
            g = wall.AddUdonSharpComponent<TitleGate>();
            g.titleKeys = new[] { "halloween" };
            g.invert = true;
            g.renderers = new[] { wall.GetComponent<Renderer>() };
            g.colliders = new[] { wall.GetComponent<Collider>() };
            GameObject pumpkin = Cube(b, "Pumpkin", new Vector3(0, .5f, 2.5f), new Vector3(1, .8f, 1), Paint("Button"), true, PrimitiveType.Sphere);
            g = pumpkin.AddUdonSharpComponent<TitleGate>();
            g.titleKeys = new[] { "halloween" };
            g.renderers = new[] { pumpkin.GetComponent<Renderer>() };
        }

        // ---- 18章 ----

        private static void Chapter18(Transform system)
        {
            const int row = 2;
            RowTitle(row, "A-2　18章 ワールドでの使い方（応用）");
            PlaceBoard(system, "Title Board (Worlds)", RowOrigin(row, 0) + new Vector3(-13, 1.5f, 0));

            Transform b = Booth(row, 0, "18-1", "途中セーブと近道", "左手前の水色（中継地点）に入るとセーブ。知らせもボードにも出ない。セーブすると奥への柵が消え、黄色の近道が出る。再入室しても残る。奥でゴール\n灰のボタンでセーブを消す（知らせは出ない）", "エリア（入ったら）1-1／ゲート（満たしたら出す物・満たすまで出す物）8-3・8-4／やり直し（指定の称号）12-2／内部用の称号（01 の 10章）");
            Area(b, "Checkpoint", new Vector3(-3, 1, -2.5f), new Vector3(1.6f, 2, 1.6f), "cp1");
            Tag(b, new Vector3(-3, 2.3f, -2.5f), "中継地点");
            Room(b);
            GameObject fence = DoorWall(b, "Fence", 0);
            GameObject shortcut = Cube(b, "Shortcut", new Vector3(2.5f, .15f, -1.5f), new Vector3(1.2f, .1f, 2.4f), Paint("Yellow"));
            TitleGate g = Gate(b, "Gate Shortcut", "cp1");
            g.objects = new[] { shortcut };
            g.objectsWhenNot = new[] { fence };
            Area(b, "Goal", new Vector3(0, 1, 3), new Vector3(4, 2, 1.6f), "runner");
            RevokeButton(b, new Vector3(-3.5f, .3f, -4f), "セーブを消す", "cp1", "runner");

            b = Booth(row, 1, "18-3", "一度見た案内を飛ばす", "初めての人には黄色の案内が出る。奥の水色に入ると、次からは出ない（再入室しても）\n灰のボタンで最初の状態に戻す", "エリア（入ったら）1-1／ゲート（満たすまで出す物）8-4／やり直し（指定の称号）12-2／内部用の称号");
            var intro = new GameObject("Intro");
            intro.transform.SetParent(b, false);
            Cube(intro.transform, "Intro Board", new Vector3(0, 1.2f, -1), new Vector3(3, 1.6f, .1f), Paint("Yellow"), false);
            Tag(intro.transform, new Vector3(0, 2.3f, -1), "ようこそ（初回だけの案内）");
            Area(b, "Intro Done", new Vector3(0, 1, 2.5f), new Vector3(4, 2, 1.6f), "seen_intro");
            Gate(b, "Gate Intro", "seen_intro").objectsWhenNot = new[] { intro };
            RevokeButton(b, new Vector3(-3.5f, .3f, -4f), "最初に戻す", "seen_intro");

            b = Booth(row, 2, "18-4", "常連だけ入れる部屋", "来た日数（visit_days）が3日以上で壁が消える。試すときはテスト用パネルで visit_days を3にする", "ゲート（行動の値）8-12／行動の値 visit_days 4-2");
            Room(b);
            GameObject lounge = DoorWall(b, "Lounge Door", 0, Paint("Purple"));
            g = Gate(b, "Gate Lounge");
            g.statName = "visit_days";
            g.statMin = 3;
            g.objectsWhenNot = new[] { lounge };

            b = Booth(row, 3, "18-6", "展示の既読の印", "3つの作品（白い箱）を調べると、上に緑の印が出る（再入室しても残る）。3つ全部で「鑑賞者」\n灰のボタンで印を消す", "アクション（触ったら）2-4／ゲート（満たしたら出す物）8-3／表の all: 4-4／内部用の称号");
            for (int i = 1; i <= 3; i++)
            {
                Vector3 at = new Vector3(-6 + i * 3, .75f, 1);
                TitleAction look = Action(Cube(b, "Work " + i, at, new Vector3(1.2f, 1.5f, .3f), Paint("White")), TitleAction.ActInteract, "seen_art" + i);
                look.interactText = "作品" + i + "を見る";
                GameObject mark = Cube(b, "Seen Mark " + i, at + new Vector3(0, 1.1f, 0), new Vector3(.3f, .3f, .3f), Paint("Green"), false, PrimitiveType.Sphere);
                Gate(b, "Gate Mark " + i, "seen_art" + i).objects = new[] { mark };
            }
            RevokeButton(b, new Vector3(-3.5f, .3f, -4f), "印を消す", "seen_art1", "seen_art2", "seen_art3", "kansho");

            b = Booth(row, 4, "18-8", "職業の道具", "橙のボタンで「剣士」をもらい、ボードで装備した人だけ剣（灰の棒）を掴める", "アクション（触ったら）2-4／ゲート（掴める・装備している）8-6・8-7");
            GrantButton(b, new Vector3(-3, .3f, -3), "swordsman", "剣士");
            RevokeButton(b, new Vector3(-2, .3f, -3), "外す", "swordsman");
            GameObject sword = Pickup(b, "Sword", new Vector3(1.5f, .8f, 0), new Vector3(.1f, 1.2f, .1f), Paint("Revoke"), true);
            sword.GetComponent<Rigidbody>().isKinematic = true;
            g = Gate(b, "Gate Sword", "swordsman");
            g.mode = TitleGate.ModeEquipped;
            g.pickupObjects = new[] { sword };

            b = Booth(row, 5, "18-9", "好みの設定を覚える", "左のボタンで暗くする（黄色の明かりが消え、黒い幕が出る）。右のボタンで戻す。再入室しても覚えている。知らせは出ない", "アクション（触ったら・一度だけオフ）2-4・7／やり直し（指定の称号・確認なし）12-2／ゲート 8-3・8-4／内部用の称号");
            GameObject darkButton = Cube(b, "Dark Button", new Vector3(-1.5f, .3f, -3), new Vector3(.6f, .6f, .6f), Paint("Dark"));
            TitleAction dark = Action(darkButton, TitleAction.ActInteract, "pref_dark");
            dark.once = false;
            dark.interactText = "暗くする";
            Tag(b, new Vector3(-1.5f, 1f, -3), "暗くする");
            GameObject lightButton = Cube(b, "Light Button", new Vector3(1.5f, .3f, -3), new Vector3(.6f, .6f, .6f), Paint("Yellow"));
            TitleReset back = lightButton.AddUdonSharpComponent<TitleReset>();
            back.mode = TitleReset.ModeKeys;
            back.revokeKeys = new[] { "pref_dark" };
            back.confirmSeconds = 0f;
            back.interactText = "明るくする";
            Tag(b, new Vector3(1.5f, 1f, -3), "明るくする");
            GameObject lamp = Cube(b, "Lamp", new Vector3(0, 2.5f, 1), new Vector3(.8f, .8f, .8f), Paint("Yellow"), false, PrimitiveType.Sphere);
            GameObject curtain = Cube(b, "Curtain", new Vector3(0, 1.5f, 2), new Vector3(6, 3, .1f), Paint("Dark"), false);
            g = Gate(b, "Gate Dark", "pref_dark");
            g.objects = new[] { curtain };
            g.objectsWhenNot = new[] { lamp };
        }
    }
}
