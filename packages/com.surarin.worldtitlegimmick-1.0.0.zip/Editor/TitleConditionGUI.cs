using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace WorldTitleGimmick.EditorTools
{
    // 称号エディタの「条件を選んで作る」（2026-10-28、ユーザー指定「最初から使えるジャンプなどの値で、UI で称号を作りたい」）。
    // 条件の文字（stat:jumps>=100 など）を、種類・一覧・数を選んで作る。今の条件を読んで選んだ状態で出し、選び直すとすぐ条件の欄に書く。
    // エディタだけの機能で、ワールドの処理・保存は変わらない。
    public static class TitleConditionGUI
    {
        private enum Kind { なし, 行動の値, カウンター, 称号の数, 全部持っている, 期間, 記録, 読めない }

        private static readonly string[] KindLabels =
        {
            "なし（部品から渡す）", "行動の値（ジャンプした回数など）", "カウンター（count:）", "持っている称号の数",
            "この称号を全部持っている", "期間（日付）", "記録の称号", "（手で書いた条件・読めない）",
        };

        private static string[] counterCache = new string[0];
        private static double nextScan;

        public static void Draw(TitleDatabase db, TitleDatabase.Row row)
        {
            EditorGUILayout.Space();
            EditorGUILayout.LabelField(new GUIContent("条件を選んで作る", "選ぶと、上の「条件」の欄に書き込みます。手で書いてもかまいません"), EditorStyles.boldLabel);
            string current = (row.condition ?? "").Trim();
            Parse(current, out Kind kind, out string name, out int number, out List<string> keys, out string from, out string to);

            EditorGUI.indentLevel++;
            string next = current;
            int picked = EditorGUILayout.Popup("種類", (int)kind, KindLabels);
            if (picked != (int)kind && picked != (int)Kind.読めない) next = DefaultFor((Kind)picked, db);
            else
            {
                switch (kind)
                {
                    case Kind.行動の値:
                    {
                        int index = Mathf.Max(0, TitleBake.StatIndex(name));
                        var labels = TitleBake.StatNames.Select((s, i) => TitleBake.StatLabels[i] + "　[" + s + "]").ToArray();
                        index = EditorGUILayout.Popup("行動の値", index, labels);
                        number = EditorGUILayout.IntField("これ以上になったら", number);
                        next = "stat:" + TitleBake.StatNames[index] + ">=" + number;
                        break;
                    }
                    case Kind.カウンター:
                    {
                        name = EditorGUILayout.TextField(new GUIContent("カウンターの名前（英数字）", "称号カウンター・部品の「足すカウンターの名前」と同じ名前"), name);
                        string[] known = KnownCounters(db);
                        if (known.Length > 0)
                        {
                            int at = EditorGUILayout.Popup("シーン・表にある名前から選ぶ", Array.IndexOf(known, name) + 1, new[] { "（選ぶ）" }.Concat(known).ToArray());
                            if (at > 0) name = known[at - 1];
                        }
                        number = EditorGUILayout.IntField("これ以上になったら", number);
                        next = "count:" + name + ">=" + number;
                        break;
                    }
                    case Kind.称号の数:
                        number = EditorGUILayout.IntField("持っている数がこれ以上", number);
                        next = "owned>=" + number;
                        break;
                    case Kind.全部持っている:
                    {
                        for (int i = 0; i < keys.Count; i++)
                        {
                            EditorGUILayout.BeginHorizontal();
                            keys[i] = TitleGUI.KeyField("　" + (i + 1), keys[i], db);
                            bool remove = GUILayout.Button("－", GUILayout.Width(24));
                            EditorGUILayout.EndHorizontal();
                            if (remove) { keys.RemoveAt(i); break; }
                        }
                        EditorGUILayout.BeginHorizontal();
                        GUILayout.Space(EditorGUI.indentLevel * 15);
                        if (GUILayout.Button("＋ 称号を足す")) keys.Add("");
                        EditorGUILayout.EndHorizontal();
                        next = "all:" + string.Join(",", keys);
                        break;
                    }
                    case Kind.期間:
                        from = EditorGUILayout.TextField(new GUIContent("始まり", "月日の4けた（1025＝毎年10月25日）か、年月日の8けた（20261025＝その年だけ）"), from);
                        to = EditorGUILayout.TextField(new GUIContent("終わり", "始まりとけた数をそろえる。1日だけなら始まりと同じ"), to);
                        next = "date:" + from + "-" + to;
                        break;
                    case Kind.記録:
                    {
                        var records = db.rows.Where(r => r != null && r.kind == TitleDatabase.Kind.記録 && !string.IsNullOrEmpty(r.key)).ToList();
                        if (records.Count == 0)
                        {
                            EditorGUILayout.HelpBox("記録の称号がありません。先に「記録を足す」で記録の行を作ってください。", MessageType.Info);
                            break;
                        }
                        int index = Mathf.Max(0, records.FindIndex(r => r.key == name));
                        index = EditorGUILayout.Popup("記録の称号", index, records.Select(r => (string.IsNullOrEmpty(r.word) ? "（語なし）" : r.word) + "　[" + r.key + "]").ToArray());
                        number = EditorGUILayout.IntField(new GUIContent("この値に届いたら", "大きいほど良い記録なら以上、小さいほど良い記録（タイムなど）なら以下。値は記録の数のまま（小数の書式なら 12.34 秒は 1234）"), number);
                        next = "record:" + records[index].key + ">=" + number;
                        break;
                    }
                    case Kind.読めない:
                        EditorGUILayout.HelpBox("上の「条件」の書き方を読めません。種類を選ぶと、選んだ種類で作り直します。", MessageType.None);
                        break;
                }
            }

            string sentence = Describe(next, db);
            if (!string.IsNullOrEmpty(sentence)) EditorGUILayout.HelpBox(sentence, MessageType.None);
            EditorGUI.indentLevel--;

            if (next != current)
            {
                Undo.RecordObject(db, "条件を選んで作る");
                row.condition = next;
                EditorUtility.SetDirty(db);
            }
        }

        // 条件の文字を、種類と値に分ける。
        private static void Parse(string text, out Kind kind, out string name, out int number, out List<string> keys, out string from, out string to)
        {
            kind = Kind.読めない;
            name = "";
            number = 0;
            keys = new List<string>();
            from = to = "";
            if (text.Length == 0) { kind = Kind.なし; return; }
            if (text.StartsWith("date:"))
            {
                string[] parts = text.Substring(5).Split('-');
                from = parts[0].Trim();
                to = parts.Length > 1 ? parts[1].Trim() : from;
                kind = parts.Length <= 2 ? Kind.期間 : Kind.読めない;
                return;
            }
            if (text.StartsWith("all:"))
            {
                keys = text.Substring(4).Split(',').Select(k => k.Trim()).ToList();
                kind = Kind.全部持っている;
                return;
            }
            int at = text.IndexOf(">=");
            if (at < 0 || !int.TryParse(text.Substring(at + 2).Trim(), out number)) return;
            string head = text.Substring(0, at).Trim();
            if (head == "visit") head = "stat:visit_days";
            if (head == "stay") head = "stat:stay_min";
            if (head == "owned") kind = Kind.称号の数;
            else if (head.StartsWith("count:")) { kind = Kind.カウンター; name = head.Substring(6).Trim(); }
            else if (head.StartsWith("record:")) { kind = Kind.記録; name = head.Substring(7).Trim(); }
            else if (head.StartsWith("stat:") && TitleBake.StatIndex(head.Substring(5).Trim()) >= 0) { kind = Kind.行動の値; name = head.Substring(5).Trim(); }
        }

        // 種類を選び直したときの初めの条件。
        private static string DefaultFor(Kind kind, TitleDatabase db)
        {
            switch (kind)
            {
                case Kind.行動の値: return "stat:jumps>=100";
                case Kind.カウンター:
                {
                    string[] known = KnownCounters(db);
                    return "count:" + (known.Length > 0 ? known[0] : "counter") + ">=10";
                }
                case Kind.称号の数: return "owned>=5";
                case Kind.全部持っている: return "all:";
                case Kind.期間:
                {
                    string today = DateTime.Now.ToString("MMdd");
                    return "date:" + today + "-" + today;
                }
                case Kind.記録:
                {
                    TitleDatabase.Row first = db.rows.FirstOrDefault(r => r != null && r.kind == TitleDatabase.Kind.記録 && !string.IsNullOrEmpty(r.key));
                    return "record:" + (first != null ? first.key : "") + ">=1";
                }
                default: return "";
            }
        }

        // 条件を日本語の文に（選んだ結果を確かめる用）。
        private static string Describe(string text, TitleDatabase db)
        {
            Parse(text, out Kind kind, out string name, out int number, out List<string> keys, out string from, out string to);
            string Word(string key)
            {
                TitleDatabase.Row r = db.Find(key);
                return "『" + (r != null && !string.IsNullOrEmpty(r.word) ? r.word : key) + "』";
            }
            switch (kind)
            {
                case Kind.なし: return "条件なし：部品（エリア・アクションなど）やコードから渡します。";
                case Kind.行動の値: return "「" + TitleBake.StatLabels[TitleBake.StatIndex(name)] + "」が " + number + " 以上になったら渡します（部品は要りません）。";
                case Kind.カウンター: return "カウンター「" + name + "」が " + number + " 以上になったら渡します。";
                case Kind.称号の数: return "称号を " + number + " 個以上持ったら渡します（内部用の称号は数えません）。";
                case Kind.全部持っている:
                    var picked = keys.Where(k => !string.IsNullOrEmpty(k)).ToList();
                    return picked.Count == 0 ? "称号を選んでください。" : string.Join("", picked.Select(Word)) + "を全部持ったら渡します。";
                case Kind.期間: return from + "〜" + to + " の期間に来たら渡します（見る人の端末の日付。4けたは毎年、8けたはその年だけ）。";
                case Kind.記録: return "記録 " + Word(name) + " が " + number + " に届いたら渡します。";
                default: return null;
            }
        }

        // カウンターの名前の候補：表の count: の条件と、シーンの部品が使う名前（2秒ごとに見直す）。
        private static string[] KnownCounters(TitleDatabase db)
        {
            if (EditorApplication.timeSinceStartup < nextScan) return counterCache;
            nextScan = EditorApplication.timeSinceStartup + 2;
            var names = new SortedSet<string>();
            foreach (TitleDatabase.Row r in db.rows)
            {
                if (r == null || string.IsNullOrEmpty(r.condition)) continue;
                string c = r.condition.Trim();
                int at = c.IndexOf(">=");
                if (c.StartsWith("count:") && at > 6) names.Add(c.Substring(6, at - 6).Trim());
            }
            foreach (TitleCounter c in UnityEngine.Object.FindObjectsOfType<TitleCounter>(true)) if (!string.IsNullOrEmpty(c.counterKey)) names.Add(c.counterKey);
            foreach (TitleTriggerBase c in UnityEngine.Object.FindObjectsOfType<TitleTriggerBase>(true)) if (!string.IsNullOrEmpty(c.counterKey)) names.Add(c.counterKey);
            foreach (TitleArea c in UnityEngine.Object.FindObjectsOfType<TitleArea>(true)) if (!string.IsNullOrEmpty(c.saveKey)) names.Add(c.saveKey);
            foreach (TitleAction c in UnityEngine.Object.FindObjectsOfType<TitleAction>(true)) if (!string.IsNullOrEmpty(c.saveKey)) names.Add(c.saveKey);
            names.Remove("");
            counterCache = names.ToArray();
            return counterCache;
        }
    }
}
