using System.Collections.Generic;

namespace WorldTitleGimmick.EditorTools
{
    // 見本の称号のパック（2026-10-28、ユーザー指定）。部品なしで動く称号（行動の値・獲得数の条件）を、まとめて表に足す。
    // どのワールドでも使えるものだけを入れる（高さなど、ワールドの形で変わるものは入れない）。
    public static class TitlePacks
    {
        public class Item
        {
            public string key, word, wordEn, descAfter, descAfterEn, condition;
            public bool connector;
        }

        public class Pack
        {
            public string name, about;
            public Item[] items;
        }

        private static Item T(string key, string word, string wordEn, string desc, string descEn, string condition)
        {
            return new Item { key = key, word = word, wordEn = wordEn, descAfter = desc, descAfterEn = descEn, condition = condition };
        }

        private static Item C(string key, string word, string wordEn = "")
        {
            return new Item { key = key, word = word, wordEn = wordEn, connector = true };
        }

        public static readonly Pack[] All =
        {
            new Pack
            {
                name = "来訪・滞在", about = "何日来たか・何回入ったか・合計で何分いたか",
                items = new[]
                {
                    T("pack_visits10", "おかえり", "Welcome Back", "10回入室する", "Join this world 10 times", "stat:visits>=10"),
                    T("pack_days3", "顔なじみ", "Familiar Face", "3日来る", "Visit on 3 different days", "stat:visit_days>=3"),
                    T("pack_days7", "常連さん", "Regular", "7日来る", "Visit on 7 different days", "stat:visit_days>=7"),
                    T("pack_days30", "住人", "Resident", "30日来る", "Visit on 30 different days", "stat:visit_days>=30"),
                    T("pack_days100", "ぬし", "Local Legend", "100日来る", "Visit on 100 different days", "stat:visit_days>=100"),
                    T("pack_streak7", "皆勤賞", "Perfect Attendance", "7日続けて来る", "Visit 7 days in a row", "stat:visit_streak_max>=7"),
                    T("pack_stay60", "まったり", "Laid-back", "合計60分いる", "Stay 60 minutes in total", "stat:stay_min>=60"),
                    T("pack_stay600", "入り浸り", "Fixture", "合計10時間いる", "Stay 10 hours in total", "stat:stay_min>=600"),
                },
            },
            new Pack
            {
                name = "体を動かす", about = "ジャンプ・歩いた距離・リスポーン・物を掴んだ回数",
                items = new[]
                {
                    T("pack_jump100", "ジャンパー", "Jumper", "ジャンプを100回する", "Jump 100 times", "stat:jumps>=100"),
                    T("pack_jump1000", "跳躍王", "Jump King", "ジャンプを1000回する", "Jump 1000 times", "stat:jumps>=1000"),
                    T("pack_walk1k", "お散歩", "Stroller", "合計1 km歩く", "Walk 1 km in total", "stat:walk_m>=1000"),
                    T("pack_walk10k", "旅人", "Traveler", "合計10 km歩く", "Walk 10 km in total", "stat:walk_m>=10000"),
                    T("pack_walk42k", "マラソンランナー", "Marathoner", "合計42.195 km歩く", "Walk 42.195 km in total", "stat:walk_m>=42195"),
                    T("pack_respawn10", "不死鳥", "Phoenix", "10回リスポーンする", "Respawn 10 times", "stat:respawns>=10"),
                    T("pack_grab50", "なんでも掴む", "Grabby", "物を50回掴む", "Pick things up 50 times", "stat:pickups>=50"),
                },
            },
            new Pack
            {
                name = "交流", about = "会った人数・一緒にいた人数・アバターの着替え",
                items = new[]
                {
                    T("pack_met10", "人見知り卒業", "Socialite", "のべ10人と会う", "Meet 10 people in total", "stat:met_people>=10"),
                    T("pack_met100", "顔が広い", "Well-Connected", "のべ100人と会う", "Meet 100 people in total", "stat:met_people>=100"),
                    T("pack_crowd5", "にぎやか好き", "Party Goer", "5人以上で一緒にいる", "Be here with 5 or more people", "stat:crowd_max>=5"),
                    T("pack_crowd20", "大にぎわい", "Crowd Lover", "20人以上で一緒にいる", "Be here with 20 or more people", "stat:crowd_max>=20"),
                    T("pack_avatar10", "着せ替え上手", "Quick Change", "アバターを10回変える", "Change avatars 10 times", "stat:avatar_changes>=10"),
                },
            },
            new Pack
            {
                name = "称号集め", about = "持っている称号の数",
                items = new[]
                {
                    T("pack_owned10", "称号ハンター", "Title Hunter", "称号を10個集める", "Collect 10 titles", "owned>=10"),
                    T("pack_owned20", "称号マスター", "Title Master", "称号を20個集める", "Collect 20 titles", "owned>=20"),
                },
            },
            new Pack
            {
                name = "よく使う接続語", about = "の・・・☆・★・〜・♪・＆・（空白）",
                items = new[]
                {
                    C("pack_no", "の", "'s"), C("pack_dot", "・"), C("pack_star", "☆"), C("pack_blackstar", "★"),
                    C("pack_wave", "〜"), C("pack_note", "♪"), C("pack_and", "＆", "&"), C("pack_space", "（空白）", "（空白）"),
                },
            },
        };

        // パックを表に足す。キーか語（同じ種類）がもうある行は足さない。足した数を返す。
        public static int AddTo(TitleDatabase db, Pack pack, List<string> skipped)
        {
            int added = 0;
            foreach (Item item in pack.items)
            {
                TitleDatabase.Kind kind = item.connector ? TitleDatabase.Kind.接続語 : TitleDatabase.Kind.通常;
                bool exists = db.Find(item.key) != null;
                if (!exists)
                    foreach (TitleDatabase.Row row in db.rows)
                        if (row != null && row.kind == kind && row.word == item.word) { exists = true; break; }
                if (exists) { skipped?.Add(item.word + "（" + item.key + "）"); continue; }
                db.rows.Add(new TitleDatabase.Row
                {
                    key = item.key, kind = kind, word = item.word, wordEn = item.wordEn,
                    descAfter = item.descAfter ?? "", descAfterEn = item.descAfterEn ?? "", condition = item.condition ?? "",
                });
                added++;
            }
            db.AssignIds();
            return added;
        }
    }
}
