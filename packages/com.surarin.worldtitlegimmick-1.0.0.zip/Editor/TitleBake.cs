using System.Collections.Generic;
using System.Linq;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace WorldTitleGimmick.EditorTools
{
    // 焼き込み（仕様書 4-1）：称号の表（TitleDatabase）を TitleManager の配列へ書き込む。
    // メニューのほか、Play の前とビルドの前（シーンの処理）にも自動で行うので、実行し忘れがない。
    [InitializeOnLoad]
    public static class TitleBake
    {
        static TitleBake()
        {
            EditorApplication.playModeStateChanged += state =>
            {
                if (state == PlayModeStateChange.ExitingEditMode) BakeOpenScenes(false);
            };
        }

        public static int BakeOpenScenes(bool log)
        {
            int count = 0;
            foreach (TitleManager manager in Object.FindObjectsOfType<TitleManager>(true))
            {
                Bake(manager, log);
                count++;
            }
            return count;
        }

        public static TitleDatabase DatabaseOf(TitleManager manager)
        {
            if (manager == null || string.IsNullOrEmpty(manager.databaseGuid)) return null;
            string path = AssetDatabase.GUIDToAssetPath(manager.databaseGuid);
            return string.IsNullOrEmpty(path) ? null : AssetDatabase.LoadAssetAtPath<TitleDatabase>(path);
        }

        // problems を渡すと、警告をログに出す代わりにそこへ集める（シーンの点検で使う）。
        public static void Bake(TitleManager manager, bool log, List<string> problems = null)
        {
            collected = problems;
            try { BakeInner(manager, log || problems != null); }
            finally { collected = null; }
        }

        private static List<string> collected;

        private static void Warn(string text, Object context)
        {
            if (collected != null) collected.Add(text);
            else Debug.LogWarning("[World Title Gimmick] " + text, context);
        }

        private static void BakeInner(TitleManager manager, bool log)
        {
            TitleDatabase db = DatabaseOf(manager);
            if (db == null)
            {
                if (log) Warn("称号の表が設定されていません：" + manager.name, manager);
                return;
            }
            db.AssignIds();
            EditorUtility.SetDirty(db);
            if (log) foreach (string problem in db.Problems()) Warn(problem, db);
            bool english = manager.language == TitleManager.LangEnglish;
            var rows = db.rows.Where(r => r != null && !string.IsNullOrEmpty(r.key))
                .OrderBy(r => r.kind == TitleDatabase.Kind.接続語 ? 1 : 0).ThenBy(r => r.order).ThenBy(r => r.id).ToList();
            int n = rows.Count;
            manager.ids = new int[n];
            manager.keys = new string[n];
            manager.kinds = new int[n];
            manager.words = new string[n];
            manager.descBefore = new string[n];
            manager.descAfter = new string[n];
            manager.wordsJa = new string[n];
            manager.wordsEn = new string[n];
            manager.descBeforeJa = new string[n];
            manager.descBeforeEn = new string[n];
            manager.descAfterJa = new string[n];
            manager.descAfterEn = new string[n];
            manager.condEnds = new int[n];
            manager.nameModes = new int[n];
            manager.actives = new bool[n];
            manager.locks = new bool[n];
            manager.orders = new int[n];
            manager.condTypes = new int[n];
            manager.condKeys = new string[n];
            manager.condStats = new int[n];
            manager.condValues = new int[n];
            manager.recordSaveKeys = new string[n];
            manager.recordFormats = new int[n];
            manager.recordDigits = new int[n];
            manager.recordLower = new bool[n];
            manager.recordSuffixJa = new string[n];
            manager.recordSuffixEn = new string[n];
            manager.condAllStart = new int[n];
            manager.condAllCount = new int[n];
            var allIds = new List<int>();
            bool[] statOn = new bool[TitleManager.StatCount];
            for (int i = 0; i < n; i++)
            {
                TitleDatabase.Row row = rows[i];
                manager.ids[i] = row.id;
                manager.keys[i] = row.key;
                manager.kinds[i] = (int)row.kind;
                manager.words[i] = Pick(english, row.word, row.wordEn);
                manager.descBefore[i] = Pick(english, row.descBefore, row.descBeforeEn);
                manager.descAfter[i] = Pick(english, row.descAfter, row.descAfterEn);
                manager.wordsJa[i] = Pick(false, row.word, row.wordEn);
                manager.wordsEn[i] = Pick(true, row.word, row.wordEn);
                manager.descBeforeJa[i] = Pick(false, row.descBefore, row.descBeforeEn);
                manager.descBeforeEn[i] = Pick(true, row.descBefore, row.descBeforeEn);
                manager.descAfterJa[i] = Pick(false, row.descAfter, row.descAfterEn);
                manager.descAfterEn[i] = Pick(true, row.descAfter, row.descAfterEn);
                manager.nameModes[i] = (int)row.nameMode;
                manager.actives[i] = row.state == TitleDatabase.State.使用;
                manager.locks[i] = row.kind == TitleDatabase.Kind.接続語 && row.lockedConnector;
                manager.orders[i] = row.order;
                // 記録の称号（2026-10-28）。
                bool record = row.kind == TitleDatabase.Kind.記録;
                manager.recordSaveKeys[i] = record ? RecordSaveKey(manager, row) : "";
                manager.recordFormats[i] = record ? (int)row.recordFormat : 0;
                manager.recordDigits[i] = record ? Mathf.Clamp(row.recordDigits, 0, 6) : 0;
                manager.recordLower[i] = record && row.recordLowerBetter;
                manager.recordSuffixJa[i] = record ? Pick(false, row.recordSuffix, row.recordSuffixEn) : "";
                manager.recordSuffixEn[i] = record ? Pick(true, row.recordSuffix, row.recordSuffixEn) : "";
                manager.condKeys[i] = "";
                manager.condAllStart[i] = allIds.Count;
                ParseCondition(manager, db, row, i, allIds, statOn, log);
                manager.condAllCount[i] = allIds.Count - manager.condAllStart[i];
            }
            manager.condAllIds = allIds.ToArray();
            // 称号ゲートが見る行動の値も数える。
            foreach (TitleGate gate in Object.FindObjectsOfType<TitleGate>(true))
            {
                int stat = StatIndex(gate.statName);
                if (stat >= 0) statOn[stat] = true;
            }
            // 続けて来た日数の最高は、今の続けて来た日数から作るので、両方数える。
            if (statOn[TitleManager.StatVisitStreakMax]) statOn[TitleManager.StatVisitStreak] = true;
            manager.statOn = statOn;
            manager.slotFixedIds = new int[TitleManager.SlotCount];
            manager.slotUnlockIds = new int[TitleManager.SlotCount];
            if (manager.slotUnlockKeys == null || manager.slotUnlockKeys.Length != TitleManager.SlotCount)
                System.Array.Resize(ref manager.slotUnlockKeys, TitleManager.SlotCount);
            if (manager.slotFixedKeys == null || manager.slotFixedKeys.Length != TitleManager.SlotCount)
                System.Array.Resize(ref manager.slotFixedKeys, TitleManager.SlotCount);
            if (manager.slotTypes == null || manager.slotTypes.Length != TitleManager.SlotCount)
                System.Array.Resize(ref manager.slotTypes, TitleManager.SlotCount);
            for (int s = 0; s < TitleManager.SlotCount; s++)
            {
                TitleDatabase.Row fixedRow = db.Find(manager.slotFixedKeys[s]);
                manager.slotFixedIds[s] = fixedRow != null && fixedRow.kind == TitleDatabase.Kind.接続語 ? fixedRow.id : 0;
                TitleDatabase.Row unlockRow = db.Find(manager.slotUnlockKeys[s]);
                manager.slotUnlockIds[s] = unlockRow != null ? unlockRow.id : 0;
                if (!string.IsNullOrEmpty(manager.slotUnlockKeys[s]) && unlockRow == null && log)
                    Warn("枠 " + (s + 1) + " の解禁の称号が表にありません：" + manager.slotUnlockKeys[s], manager);
                if (manager.slotTypes[s] == TitleManager.SlotFixed && manager.slotFixedIds[s] == 0 && log)
                    Warn("枠 " + (s + 1) + " は「固定の語」ですが、接続語が選ばれていません", manager);
            }
            manager.uiTexts = TitleTextTable.Texts(english ? 1 : 0);
            manager.uiTextsJa = TitleTextTable.Texts(0);
            manager.uiTextsEn = TitleTextTable.Texts(1);
            manager.knownCounters = KnownCounters(manager);
            // テスト：Editor の Play の前だけ「全称号を持つ」を写す（ビルドの前は必ず false）。
            manager.editorAllOwned = manager.testAllOwned && EditorApplication.isPlayingOrWillChangePlaymode && !BuildPipeline.isBuildingPlayer;
            BakePeriods(log);
            LinkAllOf();
            UdonSharpEditorUtility.CopyProxyToUdon(manager);
            EditorUtility.SetDirty(manager);
            AssignManager(manager);
        }

        // 部品の前提の「期間」（date: と同じ書き方）を数に直す（2026-10-28）。
        private static void BakePeriods(bool log)
        {
            foreach (TitleTriggerBase c in Object.FindObjectsOfType<TitleTriggerBase>(true))
            {
                int start = 0, end = 0;
                string text = (c.period ?? "").Trim();
                if (text.StartsWith("date:")) text = text.Substring(5);
                if (text.Length > 0 && !ParseDateRange(text, out start, out end, out string why))
                {
                    if (log) Warn("前提の「期間」を読めません（" + c.name + "）：" + c.period + "　" + why, c);
                    start = end = 0;
                }
                if (c.periodStart == start && c.periodEnd == end) continue;
                c.periodStart = start;
                c.periodEnd = end;
                Save(c);
            }
        }

        // 記録の保存のキー：表で指定があればそのまま（ほかの仕組みのキーを読む）、なければ <頭>rec.<キー>。版があれば .v<版> を付ける。
        public static string RecordSaveKey(TitleManager manager, TitleDatabase.Row row)
        {
            string key = string.IsNullOrEmpty(row.recordSaveKey) ? manager.keyPrefix + "rec." + row.key : row.recordSaveKey.Trim();
            return row.recordVersion > 0 ? key + ".v" + row.recordVersion : key;
        }

        // 条件の短い書き方（2026-10-28）：visit>=N は stat:visit_days>=N、stay>=N は stat:stay_min>=N と同じ。
        private static string Alias(string head)
        {
            if (head == "visit") return "stat:visit_days";
            if (head == "stay") return "stat:stay_min";
            return head;
        }

        // やり直しで 0 に戻すカウンター：表の count: の条件と、シーンの部品が使うカウンターの名前。
        private static string[] KnownCounters(TitleManager manager)
        {
            var names = new HashSet<string>();
            if (manager.condKeys != null) foreach (string key in manager.condKeys) if (!string.IsNullOrEmpty(key)) names.Add(key);
            foreach (TitleTriggerBase c in Object.FindObjectsOfType<TitleTriggerBase>(true)) if (!string.IsNullOrEmpty(c.counterKey)) names.Add(c.counterKey);
            foreach (TitleArea c in Object.FindObjectsOfType<TitleArea>(true)) if (!string.IsNullOrEmpty(c.saveKey)) names.Add(c.saveKey);
            foreach (TitleAction c in Object.FindObjectsOfType<TitleAction>(true)) if (!string.IsNullOrEmpty(c.saveKey)) names.Add(c.saveKey);
            foreach (TitleCounter c in Object.FindObjectsOfType<TitleCounter>(true)) if (!string.IsNullOrEmpty(c.counterKey)) names.Add(c.counterKey);
            foreach (TitleAllOf c in Object.FindObjectsOfType<TitleAllOf>(true))
                if (c.saved && !string.IsNullOrEmpty(c.saveKey) && c.parts != null)
                    for (int i = 0; i < c.parts.Length; i++) names.Add(c.saveKey + "." + (i + 1));
            return names.OrderBy(x => x).ToArray();
        }

        // 条件まとめ（TitleAllOf）の部品に、知らせる先を入れる（部品の reportTo）。
        private static void LinkAllOf()
        {
            var map = new Dictionary<TitleTriggerBase, List<TitleAllOf>>();
            foreach (TitleAllOf all in Object.FindObjectsOfType<TitleAllOf>(true))
                if (all.parts != null)
                    foreach (TitleTriggerBase part in all.parts)
                    {
                        if (part == null || part == all) continue;
                        if (!map.TryGetValue(part, out List<TitleAllOf> list)) map[part] = list = new List<TitleAllOf>();
                        if (!list.Contains(all)) list.Add(all);
                    }
            foreach (TitleTriggerBase c in Object.FindObjectsOfType<TitleTriggerBase>(true))
            {
                TitleAllOf[] next = map.TryGetValue(c, out List<TitleAllOf> list) ? list.ToArray() : new TitleAllOf[0];
                bool same = c.reportTo != null && c.reportTo.Length == next.Length && c.reportTo.SequenceEqual(next);
                if (same) continue;
                c.reportTo = next;
                Save(c);
            }
        }

        private static string Pick(bool english, string ja, string en)
        {
            if (english) return string.IsNullOrEmpty(en) ? ja ?? "" : en;
            return string.IsNullOrEmpty(ja) ? en ?? "" : ja;
        }

        public static readonly string[] StatNames = { "jumps", "respawns", "walk_m", "visits", "visit_days", "stay_min", "met_people", "crowd_max", "avatar_changes", "pickups", "height_max_m",
            "visit_streak", "visit_streak_max", "vr_min", "desktop_min", "together_min",
            "fall_max_m", "airtime_s", "afk_count", "sits", "sit_min", "uses", "near_min", "welcomes", "met_title_holders", "met_creator",
            "pats", "patted", "high_fives", "received_items" };
        public static readonly string[] StatLabels = { "ジャンプした回数", "リスポーンした回数", "歩いた距離（m）", "入室した回数", "来訪した日数", "滞在時間（分）", "会った人数（延べ）", "一緒にいた一番多い人数", "アバターを変えた回数", "物を掴んだ回数", "一番高く登った高さ（m）",
            "続けて来ている日数", "続けて来た日数の最高", "VR で過ごした時間（分）", "VR でなく過ごした時間（分）", "ほかの人と一緒にいた時間（分）",
            "一番高く落ちた高さ（m）", "空中にいた時間（秒）", "放置した回数", "席に座った回数", "座っていた時間（分）", "物を使った回数", "ほかの人の近くにいた時間（分）", "自分がいる間に人が入ってきた回数", "称号を持つ人と会った回数", "作者などと会った回数",
            "撫でた回数", "撫でられた回数", "ハイタッチした回数", "手渡しで受け取った回数" };

        public static int StatIndex(string name)
        {
            if (string.IsNullOrEmpty(name)) return -1;
            return System.Array.IndexOf(StatNames, name.Trim());
        }

        // 条件の書き方（仕様書 5-1）：count:名前>=N / stat:名前>=N / owned>=N / all:キー,キー / date:始まり-終わり
        private static void ParseCondition(TitleManager manager, TitleDatabase db, TitleDatabase.Row row, int i, List<int> allIds, bool[] statOn, bool log)
        {
            string text = (row.condition ?? "").Trim();
            if (text.Length == 0) return;
            if (row.kind == TitleDatabase.Kind.接続語 && !row.lockedConnector) { if (log) TitleBake.Warn("接続語「" + row.key + "」に条件がありますが「解禁で使う」がオフです（最初から使えるので条件は使いません）", db); return; }
            if (row.kind == TitleDatabase.Kind.記録) { if (log) TitleBake.Warn("記録の称号「" + row.key + "」に条件があります（記録の称号は記録があれば持っているので、条件は使いません）", db); return; }
            void Warn(string why) { if (log) TitleBake.Warn("条件を読めません（" + row.key + "）：" + text + "　" + why, db); }
            if (text.StartsWith("date:"))
            {
                // 期間限定（2026-10-28）：date:1025-1031（毎年）/ date:20261025-20261031（その年だけ）/ date:1031（1日だけ）
                if (!ParseDateRange(text.Substring(5), out int start, out int end, out string why)) { Warn(why); return; }
                manager.condTypes[i] = TitleManager.CondDate;
                manager.condValues[i] = start;
                manager.condEnds[i] = end;
                return;
            }
            if (text.StartsWith("all:"))
            {
                foreach (string part in text.Substring(4).Split(','))
                {
                    TitleDatabase.Row target = db.Find(part.Trim());
                    if (target == null) { Warn("キーがありません：" + part.Trim()); continue; }
                    allIds.Add(target.id);
                }
                manager.condTypes[i] = TitleManager.CondAll;
                return;
            }
            int at = text.IndexOf(">=");
            if (at < 0 || !int.TryParse(text.Substring(at + 2).Trim(), out int value)) { Warn("「>=数」がありません"); return; }
            string head = Alias(text.Substring(0, at).Trim());
            manager.condValues[i] = value;
            if (head == "owned") { manager.condTypes[i] = TitleManager.CondOwned; return; }
            if (head.StartsWith("count:")) { manager.condTypes[i] = TitleManager.CondCount; manager.condKeys[i] = head.Substring(6).Trim(); return; }
            if (head.StartsWith("record:"))
            {
                TitleDatabase.Row target = db.Find(head.Substring(7).Trim());
                if (target == null || target.kind != TitleDatabase.Kind.記録) { Warn("記録の称号のキーがありません"); return; }
                manager.condTypes[i] = TitleManager.CondRecord;
                manager.condKeys[i] = target.key;
                return;
            }
            if (head.StartsWith("stat:"))
            {
                int stat = StatIndex(head.Substring(5));
                if (stat < 0) { Warn("行動の値の名前がありません"); return; }
                manager.condTypes[i] = TitleManager.CondStat;
                manager.condStats[i] = stat;
                statOn[stat] = true;
                return;
            }
            Warn("count: / stat: / owned / all: / date: / record: / visit / stay のどれかで書いてください");
        }

        // 条件の書き間違いを調べる（称号エディタの窓で使う）。問題がなければ空の文字。焼き込みと同じ決まり。
        public static string CheckCondition(TitleDatabase db, TitleDatabase.Row row)
        {
            string text = (row.condition ?? "").Trim();
            if (text.Length == 0) return "";
            if (row.kind == TitleDatabase.Kind.接続語 && !row.lockedConnector) return "接続語で「解禁で使う」がオフなので、条件は使いません";
            if (text.StartsWith("date:")) return ParseDateRange(text.Substring(5), out _, out _, out string why) ? "" : why;
            if (text.StartsWith("all:"))
            {
                var missing = new List<string>();
                foreach (string part in text.Substring(4).Split(','))
                    if (db.Find(part.Trim()) == null) missing.Add(part.Trim());
                return missing.Count > 0 ? "キーがありません：" + string.Join("、", missing) : "";
            }
            int at = text.IndexOf(">=");
            if (at < 0 || !int.TryParse(text.Substring(at + 2).Trim(), out _)) return "「>=数」がありません";
            string head = Alias(text.Substring(0, at).Trim());
            if (head == "owned") return "";
            if (head.StartsWith("count:")) return head.Substring(6).Trim().Length > 0 ? "" : "カウンターの名前がありません";
            if (head.StartsWith("record:"))
            {
                TitleDatabase.Row target = db.Find(head.Substring(7).Trim());
                return target != null && target.kind == TitleDatabase.Kind.記録 ? "" : "記録の称号のキーがありません";
            }
            if (head.StartsWith("stat:")) return StatIndex(head.Substring(5)) >= 0 ? "" : "行動の値の名前がありません（" + string.Join("・", StatNames) + "）";
            return "count: / stat: / owned / all: / date: / record: / visit / stay のどれかで書いてください";
        }

        // 「1025-1031」「20261025-20261031」「1031」を読む。MMDD どうし（毎年）か YYYYMMDD どうし（その年）にそろえる。
        public static bool ParseDateRange(string text, out int start, out int end, out string why)
        {
            start = end = 0;
            why = "";
            string[] parts = text.Trim().Split('-');
            if (parts.Length < 1 || parts.Length > 2) { why = "「月日-月日」で書いてください（例：date:1025-1031）"; return false; }
            string a = parts[0].Trim();
            string b = parts.Length == 2 ? parts[1].Trim() : a;
            if (a.Length != b.Length || (a.Length != 4 && a.Length != 8)) { why = "日付は4けた（月日：1025）か8けた（年月日：20261025）で、始まりと終わりをそろえてください"; return false; }
            if (!int.TryParse(a, out start) || !int.TryParse(b, out end)) { why = "日付が数ではありません"; return false; }
            if (!ValidDate(start) || !ValidDate(end)) { why = "ない日付です"; return false; }
            if (a.Length == 8 && start > end) { why = "始まりが終わりより後です"; return false; }
            return true;
        }

        private static bool ValidDate(int value)
        {
            int monthDay = value % 10000;
            int month = monthDay / 100, day = monthDay % 100;
            return month >= 1 && month <= 12 && day >= 1 && day <= 31;
        }

        // シーンの部品で、マネージャーが空のものに入れる。
        private static void AssignManager(TitleManager manager)
        {
            foreach (TitleTriggerBase c in Object.FindObjectsOfType<TitleTriggerBase>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleGate c in Object.FindObjectsOfType<TitleGate>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleCounter c in Object.FindObjectsOfType<TitleCounter>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleBoard c in Object.FindObjectsOfType<TitleBoard>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleNameplates c in Object.FindObjectsOfType<TitleNameplates>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleReset c in Object.FindObjectsOfType<TitleReset>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleRoster c in Object.FindObjectsOfType<TitleRoster>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitlePerk c in Object.FindObjectsOfType<TitlePerk>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleRelay c in Object.FindObjectsOfType<TitleRelay>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleNotebook c in Object.FindObjectsOfType<TitleNotebook>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleSeat c in Object.FindObjectsOfType<TitleSeat>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
            foreach (TitleTouch c in Object.FindObjectsOfType<TitleTouch>(true)) if (c.manager == null) { c.manager = manager; Save(c); }
        }

        private static void Save(UdonSharp.UdonSharpBehaviour behaviour)
        {
            UdonSharpEditorUtility.CopyProxyToUdon(behaviour);
            EditorUtility.SetDirty(behaviour);
        }
    }

    // ビルド（アップロード）の前にも焼き込む。
    public class TitleBakeOnBuild : IProcessSceneWithReport
    {
        public int callbackOrder => -100;
        public void OnProcessScene(Scene scene, BuildReport report)
        {
            foreach (GameObject root in scene.GetRootGameObjects())
                foreach (TitleManager manager in root.GetComponentsInChildren<TitleManager>(true))
                    TitleBake.Bake(manager, false);
        }
    }
}
