using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;

namespace WorldTitleGimmick.EditorTools
{
    // 称号の表の CSV（2026-10-28）。表計算ソフトでまとめて編集するため。
    // 書き出し：全部の行（BOM 付き UTF-8。Excel でそのまま開ける）。
    // 読み込み：キーで行を合わせ、ある行は書き換え、ない行は足す。ID は CSV から読まない（自動で振る。保存が入れ替わるのを防ぐ）。
    // CSV にない行は消さない（やめるときは State を「廃止」に）。
    public static class TitleCsv
    {
        public static readonly string[] Columns =
        {
            "id", "key", "kind", "word", "wordEn", "descBefore", "descBeforeEn", "descAfter", "descAfterEn",
            "condition", "nameMode", "lockedConnector", "state", "order",
            // 記録の設定（2026-10-28。記録の行だけ使う）。
            "recordFormat", "recordDigits", "recordSuffix", "recordSuffixEn", "recordLowerBetter", "recordSaveKey", "recordVersion",
        };

        // 保存先を聞いて書き出す（表のインスペクターと称号エディタの両方から使う）。やめたら null。
        public static string ExportWithDialog(TitleDatabase db)
        {
            string path = EditorUtility.SaveFilePanel("称号の表を CSV に書き出す", "", db.name + ".csv", "csv");
            if (string.IsNullOrEmpty(path)) return null;
            Export(db, path);
            return "書き出しました：" + path;
        }

        // ファイルを選んで確かめてから読み込む（Undo できる）。やめたら null。
        public static string ImportWithDialog(TitleDatabase db)
        {
            string path = EditorUtility.OpenFilePanel("称号の表を CSV から読み込む", "", "csv");
            if (string.IsNullOrEmpty(path) || !EditorUtility.DisplayDialog("World Title Gimmick",
                "キーで行を合わせて、ある行は書き換え、ない行は足します。\nID と種類（称号・接続語・記録）は変えません。CSV にない行は消しません。", "読み込む", "やめる")) return null;
            Undo.RecordObject(db, "Import Titles CSV");
            Result result = Import(db, path);
            EditorUtility.SetDirty(db);
            return "読み込みました：書き換え " + result.updated + " 行・追加 " + result.added + " 行"
                + (result.warnings.Count > 0 ? "\n" + string.Join("\n", result.warnings) : "");
        }

        public static void Export(TitleDatabase db, string path)
        {
            var text = new StringBuilder();
            text.AppendLine(string.Join(",", Columns));
            foreach (TitleDatabase.Row r in db.rows)
            {
                if (r == null) continue;
                string[] cells =
                {
                    r.id.ToString(), r.key, r.kind.ToString(), r.word, r.wordEn, r.descBefore, r.descBeforeEn, r.descAfter, r.descAfterEn,
                    r.condition, r.nameMode.ToString(), r.lockedConnector ? "1" : "0", r.state.ToString(), r.order.ToString(),
                    r.recordFormat.ToString(), r.recordDigits.ToString(), r.recordSuffix, r.recordSuffixEn, r.recordLowerBetter ? "1" : "0", r.recordSaveKey, r.recordVersion.ToString(),
                };
                var quoted = new List<string>();
                foreach (string c in cells) quoted.Add(Quote(c ?? ""));
                text.AppendLine(string.Join(",", quoted));
            }
            File.WriteAllText(path, text.ToString(), new UTF8Encoding(true));
        }

        public class Result
        {
            public int updated, added;
            public List<string> warnings = new List<string>();
        }

        public static Result Import(TitleDatabase db, string path)
        {
            var result = new Result();
            // UTF-8 で読めなければ、日本語の Excel の「CSV（コンマ区切り）」（Shift_JIS）として読む。
            string content;
            byte[] bytes = File.ReadAllBytes(path);
            try { content = new UTF8Encoding(false, true).GetString(bytes); }
            catch (DecoderFallbackException)
            {
                try
                {
                    content = Encoding.GetEncoding(932).GetString(bytes);
                    result.warnings.Add("UTF-8 ではなかったので Shift_JIS として読みました。次からは Excel の「CSV UTF-8（コンマ区切り）」で保存してください");
                }
                catch (Exception)
                {
                    result.warnings.Add("文字コードが UTF-8 ではないので読めません。Excel の「CSV UTF-8（コンマ区切り）」で保存し直してください");
                    return result;
                }
            }
            if (content.Length > 0 && content[0] == '\uFEFF') content = content.Substring(1);
            List<List<string>> table = Parse(content);
            if (table.Count == 0) { result.warnings.Add("CSV が空です"); return result; }
            List<string> header = table[0];
            var at = new Dictionary<string, int>();
            for (int i = 0; i < header.Count; i++) at[header[i].Trim().TrimStart('\uFEFF')] = i;
            if (!at.ContainsKey("key")) { result.warnings.Add("1行目に key の列がありません"); return result; }
            for (int line = 1; line < table.Count; line++)
            {
                List<string> cells = table[line];
                string Cell(string name) => at.TryGetValue(name, out int i) && i < cells.Count ? cells[i] : null;
                string key = (Cell("key") ?? "").Trim();
                if (key.Length == 0) { if (cells.Exists(c => c.Trim().Length > 0)) result.warnings.Add((line + 1) + "行目：key が空なので読みません"); continue; }
                TitleDatabase.Row row = db.Find(key);
                bool isNew = row == null;
                if (isNew) row = new TitleDatabase.Row { key = key };
                string where = (line + 1) + "行目（" + key + "）：";
                if (Cell("kind") != null)
                {
                    if (TryEnum(Cell("kind"), out TitleDatabase.Kind kind))
                    {
                        if (!isNew && kind != row.kind) result.warnings.Add(where + "種類（kind）は読み込みでは変えません。表で直してください");
                        else row.kind = kind;
                    }
                    else result.warnings.Add(where + "kind が読めません：" + Cell("kind"));
                }
                if (Cell("word") != null) row.word = Cell("word");
                if (Cell("wordEn") != null) row.wordEn = Cell("wordEn");
                if (Cell("descBefore") != null) row.descBefore = Cell("descBefore");
                if (Cell("descBeforeEn") != null) row.descBeforeEn = Cell("descBeforeEn");
                if (Cell("descAfter") != null) row.descAfter = Cell("descAfter");
                if (Cell("descAfterEn") != null) row.descAfterEn = Cell("descAfterEn");
                if (Cell("condition") != null) row.condition = Cell("condition").Trim();
                if (Cell("nameMode") != null)
                {
                    if (TryEnum(Cell("nameMode"), out TitleDatabase.NameMode mode)) row.nameMode = mode;
                    else result.warnings.Add(where + "nameMode が読めません：" + Cell("nameMode"));
                }
                if (Cell("lockedConnector") != null) row.lockedConnector = IsTrue(Cell("lockedConnector"));
                if (Cell("state") != null)
                {
                    if (TryEnum(Cell("state"), out TitleDatabase.State state)) row.state = state;
                    else result.warnings.Add(where + "state が読めません：" + Cell("state"));
                }
                if (Cell("order") != null && Cell("order").Trim().Length > 0)
                {
                    if (int.TryParse(Cell("order").Trim(), out int order)) row.order = order;
                    else result.warnings.Add(where + "order が数ではありません：" + Cell("order"));
                }
                if (Cell("recordFormat") != null && Cell("recordFormat").Trim().Length > 0)
                {
                    if (TryEnum(Cell("recordFormat"), out TitleDatabase.RecordFormat format)) row.recordFormat = format;
                    else result.warnings.Add(where + "recordFormat が読めません：" + Cell("recordFormat"));
                }
                if (Cell("recordDigits") != null && int.TryParse(Cell("recordDigits").Trim(), out int digits)) row.recordDigits = digits;
                if (Cell("recordSuffix") != null) row.recordSuffix = Cell("recordSuffix");
                if (Cell("recordSuffixEn") != null) row.recordSuffixEn = Cell("recordSuffixEn");
                if (Cell("recordLowerBetter") != null) row.recordLowerBetter = IsTrue(Cell("recordLowerBetter"));
                if (Cell("recordSaveKey") != null) row.recordSaveKey = Cell("recordSaveKey").Trim();
                if (Cell("recordVersion") != null && int.TryParse(Cell("recordVersion").Trim(), out int version)) row.recordVersion = version;
                if (Cell("id") != null && int.TryParse(Cell("id").Trim(), out int csvId) && !isNew && csvId != row.id && csvId != 0)
                    result.warnings.Add(where + "id が表（" + row.id + "）と違います。ID は読み込みでは変えません");
                if (isNew) { db.rows.Add(row); result.added++; }
                else result.updated++;
            }
            db.AssignIds();
            return result;
        }

        // 種類・名前の出し方・状態：日本語の名前（通常・接続語など）か番号。
        private static bool TryEnum<T>(string text, out T value) where T : struct
        {
            text = (text ?? "").Trim();
            if (int.TryParse(text, out int n) && Enum.IsDefined(typeof(T), n)) { value = (T)Enum.ToObject(typeof(T), n); return true; }
            return Enum.TryParse(text, out value) && Enum.IsDefined(typeof(T), value);
        }

        private static bool IsTrue(string text)
        {
            text = (text ?? "").Trim().ToLowerInvariant();
            return text == "1" || text == "true" || text == "yes" || text == "on" || text == "オン";
        }

        private static string Quote(string cell)
        {
            if (cell.IndexOfAny(new[] { ',', '"', '\n', '\r' }) < 0) return cell;
            return "\"" + cell.Replace("\"", "\"\"") + "\"";
        }

        // RFC 4180 の CSV（"" で囲んだセルの中の , と改行も読む）。
        public static List<List<string>> Parse(string text)
        {
            var rows = new List<List<string>>();
            var row = new List<string>();
            var cell = new StringBuilder();
            bool quoted = false;
            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];
                if (quoted)
                {
                    if (c == '"')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '"') { cell.Append('"'); i++; }
                        else quoted = false;
                    }
                    else cell.Append(c);
                    continue;
                }
                if (c == '"') quoted = true;
                else if (c == ',') { row.Add(cell.ToString()); cell.Clear(); }
                else if (c == '\r') { }
                else if (c == '\n') { row.Add(cell.ToString()); cell.Clear(); rows.Add(row); row = new List<string>(); }
                else cell.Append(c);
            }
            if (cell.Length > 0 || row.Count > 0) { row.Add(cell.ToString()); rows.Add(row); }
            return rows;
        }
    }
}
