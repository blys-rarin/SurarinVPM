using System.Collections.Generic;
using System.Linq;
using UdonSharpEditor;
using UnityEditor;
using UnityEngine;
using VRC.Udon;

namespace WorldTitleGimmick.EditorTools
{
    // 「World Title Gimmick/テスト用パネル」（2026-10-28）：Play 中（ClientSim）に、本人の称号・カウンター・行動の値を書き換えて試す窓。
    // マネージャーの Udon に、Udon Graph 向けの入口（grantKey → Grant など）を送るだけ。ワールドには何も足さない。
    public class TitleTestPanel : EditorWindow
    {
        private Vector2 scroll;
        private string filter = "";
        private string counterName = "";
        private int counterAmount = 1;
        private int statIndex;
        private int statValue = 100;
        private int recordIndex;
        private int recordValue = 100;

        [MenuItem("World Title Gimmick/テスト用パネル（Test Panel）")]
        public static void Open() { GetWindow<TitleTestPanel>("称号のテスト"); }

        // Play 中は値が変わるので、ときどき描き直す。
        private void OnInspectorUpdate() { if (Application.isPlaying) Repaint(); }

        private void OnGUI()
        {
            if (!Application.isPlaying)
            {
                EditorGUILayout.HelpBox("Play 中に使います。Play を押してから開いてください（ClientSim）。\n称号を渡す・外す、カウンター・行動の値を書き換える、全部やり直す、ができます。書き換えた値は ClientSim の保存に残ります。", MessageType.Info);
                return;
            }
            TitleManager manager = Object.FindObjectOfType<TitleManager>(true);
            UdonBehaviour udon = manager != null ? UdonSharpEditorUtility.GetBackingUdonBehaviour(manager) : null;
            if (udon == null) { EditorGUILayout.HelpBox("シーンに TitleManager がありません。", MessageType.Warning); return; }
            bool restored = udon.GetProgramVariable("restored") is bool b && b;
            if (!restored) { EditorGUILayout.HelpBox("保存の読み込み（復元）を待っています…", MessageType.Info); return; }
            byte[] own = udon.GetProgramVariable("own") as byte[];
            int[] ids = udon.GetProgramVariable("ids") as int[] ?? manager.ids;
            string[] keys = udon.GetProgramVariable("keys") as string[] ?? manager.keys;
            string[] words = udon.GetProgramVariable("words") as string[] ?? manager.words;
            int[] kinds = udon.GetProgramVariable("kinds") as int[] ?? manager.kinds;
            bool[] locks = udon.GetProgramVariable("locks") as bool[] ?? manager.locks;

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("全部やり直す", GUILayout.Width(120)) && EditorUtility.DisplayDialog("World Title Gimmick", "本人の称号・肩書き・カウンター・行動の値を全部消します（ClientSim の保存）。", "やり直す", "やめる"))
                udon.SendCustomEvent("ResetAll");
            if (GUILayout.Button("全部渡す", GUILayout.Width(100)))
                for (int i = 0; i < ids.Length; i++) Send(udon, "grantKey", keys[i], "Grant");
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("カウンター", EditorStyles.boldLabel);
            EditorGUILayout.BeginHorizontal();
            counterName = EditorGUILayout.TextField("名前", counterName);
            counterAmount = EditorGUILayout.IntField(counterAmount, GUILayout.Width(60));
            if (GUILayout.Button("足す", GUILayout.Width(50)) && !string.IsNullOrEmpty(counterName))
            {
                udon.SetProgramVariable("countKey", counterName);
                udon.SetProgramVariable("countAdd", counterAmount);
                udon.SendCustomEvent("AddCount");
            }
            EditorGUILayout.EndHorizontal();
            string[] known = udon.GetProgramVariable("knownCounters") as string[];
            if (known != null && known.Length > 0) EditorGUILayout.LabelField("この表・シーンのカウンター：" + string.Join("、", known), EditorStyles.miniLabel);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("行動の値", EditorStyles.boldLabel);
            int[] stats = udon.GetProgramVariable("statValues") as int[];
            EditorGUILayout.BeginHorizontal();
            statIndex = EditorGUILayout.Popup(statIndex, TitleBake.StatLabels);
            statValue = EditorGUILayout.IntField(statValue, GUILayout.Width(80));
            if (GUILayout.Button("書き込む", GUILayout.Width(70)))
            {
                udon.SetProgramVariable("debugStatName", TitleBake.StatNames[statIndex]);
                udon.SetProgramVariable("debugStatValue", statValue);
                udon.SendCustomEvent("DebugSetStat");
            }
            EditorGUILayout.EndHorizontal();
            if (stats != null && statIndex < stats.Length) EditorGUILayout.LabelField("今の値：" + stats[statIndex], EditorStyles.miniLabel);

            // 記録の称号（2026-10-28）：良くなくても書く（テスト用）。0 で記録なしに戻す。
            var recordRows = new List<int>();
            for (int i = 0; i < kinds.Length && i < keys.Length; i++) if (kinds[i] == TitleManager.KindRecord) recordRows.Add(i);
            if (recordRows.Count > 0)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("記録", EditorStyles.boldLabel);
                int[] records = udon.GetProgramVariable("recordValues") as int[];
                EditorGUILayout.BeginHorizontal();
                recordIndex = Mathf.Clamp(recordIndex, 0, recordRows.Count - 1);
                recordIndex = EditorGUILayout.Popup(recordIndex, recordRows.Select(i => keys[i]).ToArray());
                recordValue = EditorGUILayout.IntField(recordValue, GUILayout.Width(80));
                if (GUILayout.Button("書き込む", GUILayout.Width(70)))
                {
                    udon.SetProgramVariable("debugRecordKey", keys[recordRows[recordIndex]]);
                    udon.SetProgramVariable("debugRecordValue", recordValue);
                    udon.SendCustomEvent("DebugSetRecord");
                }
                EditorGUILayout.EndHorizontal();
                int at = recordRows[recordIndex];
                if (records != null && at < records.Length) EditorGUILayout.LabelField("今の値：" + records[at] + "（0 は記録なし）", EditorStyles.miniLabel);
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("称号", EditorStyles.boldLabel);
            filter = EditorGUILayout.TextField("絞り込み", filter);
            scroll = EditorGUILayout.BeginScrollView(scroll);
            for (int i = 0; i < ids.Length; i++)
            {
                string word = i < words.Length ? words[i] : "";
                string key = i < keys.Length ? keys[i] : "";
                if (!string.IsNullOrEmpty(filter) && !word.Contains(filter) && !key.Contains(filter)) continue;
                // 記録の称号は上の「記録」で書く。
                if (i < kinds.Length && kinds[i] == TitleManager.KindRecord) continue;
                bool connector = i < kinds.Length && kinds[i] == TitleManager.KindConnector;
                bool locked = connector && i < locks.Length && locks[i];
                if (connector && !locked) continue;
                bool has = Has(own, ids[i]);
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.LabelField((has ? "✔ " : "　 ") + word + "　[" + key + "]" + (connector ? "（接続語）" : ""));
                using (new EditorGUI.DisabledScope(has))
                    if (GUILayout.Button("渡す", GUILayout.Width(50))) Send(udon, "grantKey", key, "Grant");
                using (new EditorGUI.DisabledScope(!has))
                    if (GUILayout.Button("外す", GUILayout.Width(50))) Send(udon, "revokeKey", key, "Revoke");
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();
        }

        private static void Send(UdonBehaviour udon, string variable, string value, string eventName)
        {
            udon.SetProgramVariable(variable, value);
            udon.SendCustomEvent(eventName);
        }

        private static bool Has(byte[] bits, int id)
        {
            if (bits == null || id <= 0 || (id >> 3) >= bits.Length) return false;
            return (bits[id >> 3] & (1 << (id & 7))) != 0;
        }
    }
}
