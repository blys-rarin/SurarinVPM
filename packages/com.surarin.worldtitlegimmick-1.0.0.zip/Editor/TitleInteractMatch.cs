using UdonSharp;
using UdonSharpEditor;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;
using VRC.Udon;

namespace WorldTitleGimmick.EditorTools
{
    // 「ほかの押せる部品に合わせる」（2026-10-29、ユーザー指定）。
    // 元からあるスイッチなどに称号アクション・カウンター・やり直しを足したとき、同じ物のほかの押せる Udon の
    // 押せる距離と出る文字を、この部品の Udon に写す。Udon からはほかの Udon の距離・文字を読めないので、エディタで写す。
    // 写すのは、インスペクターを開いたとき・Play の前・ビルドの前。
    [InitializeOnLoad]
    public static class TitleInteractMatch
    {
        static TitleInteractMatch()
        {
            EditorApplication.playModeStateChanged += state =>
            {
                if (state != PlayModeStateChange.ExitingEditMode) return;
                foreach (TitleAction c in Object.FindObjectsOfType<TitleAction>(true)) Apply(c, true);
                foreach (TitleCounter c in Object.FindObjectsOfType<TitleCounter>(true)) Apply(c, true);
                foreach (TitleReset c in Object.FindObjectsOfType<TitleReset>(true)) Apply(c, true);
            };
        }

        // この部品の設定（オン・オフと、自分の文字）。合わせる部品でなければ false。
        private static bool Settings(UdonSharpBehaviour component, out bool match, out string text)
        {
            match = false; text = "";
            if (component is TitleAction a) { match = a.matchOtherInteract; text = a.interactText; return true; }
            if (component is TitleCounter c) { match = c.matchOtherInteract; text = c.interactText; return true; }
            if (component is TitleReset r) { match = r.matchOtherInteract; text = r.interactText; return true; }
            return false;
        }

        // 同じ物にある、称号の部品でない押せる Udon（UdonSharp・Udon Graph・CyanTrigger など）。なければ null。
        public static UdonBehaviour FindOther(UdonSharpBehaviour component)
        {
            if (component == null) return null;
            UdonBehaviour self = UdonSharpEditorUtility.GetBackingUdonBehaviour(component);
            foreach (UdonBehaviour b in component.GetComponents<UdonBehaviour>())
            {
                if (b == null || b == self || IsTitlePart(b)) continue;
                if (HasInteract(b)) return b;
            }
            return null;
        }

        private static bool IsTitlePart(UdonBehaviour b)
        {
            if (!(b.programSource is UdonSharpProgramAsset program) || program.sourceCsScript == null) return false;
            System.Type type = program.sourceCsScript.GetClass();
            return type != null && type.Namespace == "WorldTitleGimmick";
        }

        private static bool HasInteract(UdonBehaviour b)
        {
            if (b.programSource == null) return false;
            if (b.programSource is UdonSharpProgramAsset sharp) return sharp.hasInteractEvent;
            try
            {
                var program = b.programSource.SerializedProgramAsset != null ? b.programSource.SerializedProgramAsset.RetrieveProgram() : null;
                return program != null && program.EntryPoints.HasExportedSymbol("_interact");
            }
            catch (System.Exception) { return false; }
        }

        // オンなら写す。オンでほかがなければ、自分の文字を Udon の欄に入れる（Start で文字を上書きしないため）。
        // 写した先の部品（なければ null）を返す。
        public static UdonBehaviour Apply(UdonSharpBehaviour component, bool undo)
        {
            if (!Settings(component, out bool match, out string text) || !match) return null;
            UdonBehaviour self = UdonSharpEditorUtility.GetBackingUdonBehaviour(component);
            if (self == null) return null;
            UdonBehaviour other = FindOther(component);
            string nextText = other != null ? other.interactText : text;
            float nextProximity = other != null ? other.proximity : self.proximity;
            if (self.interactText == nextText && Mathf.Approximately(self.proximity, nextProximity)) return other;
            if (undo) Undo.RecordObject(self, "ほかの押せる部品に合わせる");
            self.interactText = nextText;
            self.proximity = nextProximity;
            EditorUtility.SetDirty(self);
            if (PrefabUtility.IsPartOfPrefabInstance(self)) PrefabUtility.RecordPrefabInstancePropertyModifications(self);
            return other;
        }
    }

    // ビルド（アップロード）の前にも写す。
    public class TitleInteractMatchOnBuild : IProcessSceneWithReport
    {
        public int callbackOrder => -100;
        public void OnProcessScene(Scene scene, BuildReport report)
        {
            foreach (GameObject root in scene.GetRootGameObjects())
            {
                foreach (TitleAction c in root.GetComponentsInChildren<TitleAction>(true)) TitleInteractMatch.Apply(c, false);
                foreach (TitleCounter c in root.GetComponentsInChildren<TitleCounter>(true)) TitleInteractMatch.Apply(c, false);
                foreach (TitleReset c in root.GetComponentsInChildren<TitleReset>(true)) TitleInteractMatch.Apply(c, false);
            }
        }
    }
}
