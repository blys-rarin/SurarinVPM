using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace WorldTitleGimmick.EditorTools
{
    // インスペクターで書き換えられない欄（見るだけ）。
    public class TitleReadOnlyAttribute : PropertyAttribute { }

    [CustomPropertyDrawer(typeof(TitleReadOnlyAttribute))]
    public class TitleReadOnlyDrawer : PropertyDrawer
    {
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            using (new EditorGUI.DisabledScope(true)) EditorGUI.PropertyField(position, property, label, true);
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label) { return EditorGUI.GetPropertyHeight(property, label, true); }
    }

    // 称号の表のインスペクター：次に振る ID・表の問題・見本の称号のパック・行の一覧。
    // 表の1行の欄の日本語の名前と、分類ごとに出す・出さないの決まり（2026-10-28、ユーザー指定「称号エディタ内部も日本語化」）。
    // 称号エディタの右側と、表のインスペクターの行の両方で使う。英語の名前はツールチップの最後に出す。
    public static class TitleRowGUI
    {
        private static readonly Dictionary<string, string> Labels = new Dictionary<string, string>
        {
            { "id", "ID（自動）" },
            { "key", "キー（英数字と _）" },
            { "kind", "分類" },
            { "word", "語（日本語）" },
            { "wordEn", "語（英語。空なら日本語）" },
            { "descBefore", "持っていないときの説明" },
            { "descBeforeEn", "持っていないときの説明（英語）" },
            { "descAfter", "持っているときの説明" },
            { "descAfterEn", "持っているときの説明（英語）" },
            { "condition", "条件（表だけで渡す。空なら部品から）" },
            { "nameMode", "名前の見せ方" },
            { "lockedConnector", "最初は使えない（解禁する接続語）" },
            { "state", "状態" },
            { "order", "ボードでの並び順" },
            { "recordFormat", "記録の書式" },
            { "recordDigits", "小数のけた数" },
            { "recordSuffix", "値のあとに付ける語" },
            { "recordSuffixEn", "値のあとに付ける語（英語）" },
            { "recordLowerBetter", "小さいほど良い記録（タイムなど）" },
            { "recordSaveKey", "保存のキー（空なら自動）" },
            { "recordVersion", "記録の版" },
        };

        public static GUIContent Label(SerializedProperty p)
        {
            Labels.TryGetValue(p.name, out string label);
            string tip = (string.IsNullOrEmpty(p.tooltip) ? "" : p.tooltip + "\n") + "［" + p.displayName + " / " + p.name + "］";
            return new GUIContent(label ?? p.displayName, tip);
        }

        // 分類（通常・接続語・記録）と記録の書式で、使わない欄を出さない。
        public static bool Visible(SerializedProperty row, string name, bool showId)
        {
            int kind = row.FindPropertyRelative("kind").intValue;
            if (name == "id") return showId;
            if (name == "lockedConnector") return kind == (int)TitleDatabase.Kind.接続語;
            // 内部用はボードに出さないので、名前の見せ方・持っていないときの説明・並び順は使わない。
            if (kind == (int)TitleDatabase.Kind.内部用 && (name == "nameMode" || name.StartsWith("descBefore") || name == "order")) return false;
            if (name == "condition") return kind != (int)TitleDatabase.Kind.記録;
            if (name.StartsWith("record"))
            {
                if (kind != (int)TitleDatabase.Kind.記録) return false;
                if (name == "recordDigits") return row.FindPropertyRelative("recordFormat").intValue == (int)TitleDatabase.RecordFormat.小数;
            }
            return true;
        }

        public static IEnumerable<SerializedProperty> Children(SerializedProperty row)
        {
            SerializedProperty it = row.Copy();
            SerializedProperty end = row.GetEndProperty();
            bool enter = true;
            while (it.NextVisible(enter) && !SerializedProperty.EqualContents(it, end))
            {
                enter = false;
                yield return it.Copy();
            }
        }
    }

    // 表のインスペクターの1行（折りたたみの見出しは「ID 語 [キー]」）。
    [CustomPropertyDrawer(typeof(TitleDatabase.Row))]
    public class TitleRowDrawer : PropertyDrawer
    {
        private const float Gap = 2f;

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            float h = EditorGUIUtility.singleLineHeight;
            if (!property.isExpanded) return h;
            foreach (SerializedProperty p in TitleRowGUI.Children(property))
                if (TitleRowGUI.Visible(property, p.name, true)) h += Gap + EditorGUI.GetPropertyHeight(p, TitleRowGUI.Label(p), true);
            return h;
        }

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            string word = property.FindPropertyRelative("word").stringValue;
            string key = property.FindPropertyRelative("key").stringValue;
            string head = property.FindPropertyRelative("id").intValue + "　" + (string.IsNullOrEmpty(word) ? "（語なし）" : word) + "　[" + key + "]";
            var line = new Rect(position.x, position.y, position.width, EditorGUIUtility.singleLineHeight);
            property.isExpanded = EditorGUI.Foldout(line, property.isExpanded, head, true);
            if (!property.isExpanded) return;
            EditorGUI.indentLevel++;
            float y = line.yMax;
            foreach (SerializedProperty p in TitleRowGUI.Children(property))
            {
                if (!TitleRowGUI.Visible(property, p.name, true)) continue;
                GUIContent content = TitleRowGUI.Label(p);
                float h = EditorGUI.GetPropertyHeight(p, content, true);
                EditorGUI.PropertyField(new Rect(position.x, y + Gap, position.width, h), p, content, true);
                y += Gap + h;
            }
            EditorGUI.indentLevel--;
        }
    }

    [CustomEditor(typeof(TitleDatabase))]
    public class TitleDatabaseEditor : Editor
    {
        private static bool openPacks;
        private string packMessage = "";

        // 「消した行の番号を使い直す（公開前だけ）」（2026-10-29）。表のインスペクターと称号エディタで使う。オンにするときは確かめる。
        public static void FillGapsToggle(TitleDatabase db)
        {
            bool next = EditorGUILayout.ToggleLeft(new GUIContent("消した行の番号を使い直す（公開前だけ）",
                "オンなら、新しい行に、範囲の中でいちばん小さい空いた番号を振る（消した行の番号を詰めて使う）。公開したあとはオフにする（消した称号を持っていた人に、新しい称号を持っているように見えてしまう）"), db.fillGaps);
            if (next == db.fillGaps) return;
            if (next && !EditorUtility.DisplayDialog("World Title Gimmick",
                "新しい行に、消した行の番号（空いた番号）を使い直します。\n\n公開したワールドでは使わないでください。消した称号を持っていた人に、その番号の新しい称号を持っているように見えてしまいます。公開前なら問題ありません。",
                "使い直す", "やめる")) return;
            Undo.RecordObject(db, "消した行の番号を使い直す");
            db.fillGaps = next;
            EditorUtility.SetDirty(db);
        }

        public override void OnInspectorGUI()
        {
            var db = (TitleDatabase)target;
            serializedObject.Update();

            // ID の範囲（2026-10-29）。変えると ID を振り直すので、確かめてから変える。
            var names = new[] { TitleDatabase.IdRange.小, TitleDatabase.IdRange.中, TitleDatabase.IdRange.大 };
            int picked = EditorGUILayout.Popup(new GUIContent("ID の範囲", "分類ごとの ID の範囲。所持の保存は「持っている一番大きい ID ÷ 8」バイトなので、小さいほど保存が小さい。公開したあとは変えない"),
                (int)db.idRange, names.Select(n => n + "：" + TitleDatabase.RangeText(n)).ToArray());
            if (picked != (int)db.idRange && EditorUtility.DisplayDialog("World Title Gimmick",
                "ID の範囲を「" + names[picked] + "」にします。\n" + TitleDatabase.RangeText(names[picked]) + "\n\n範囲に合わない行の ID を振り直します。公開したワールドでは変えないでください（遊んだ人の保存と称号がずれます）。公開前なら問題ありません。",
                "変える", "やめる"))
            {
                Undo.RecordObject(db, "ID の範囲を変える");
                db.idRange = names[picked];
                db.AssignIds();
                EditorUtility.SetDirty(db);
                serializedObject.Update();
            }

            FillGapsToggle(db);

            int maxNormal = db.MaxIdInRows(TitleDatabase.Kind.通常);
            int maxConnector = db.MaxIdInRows(TitleDatabase.Kind.接続語);
            EditorGUILayout.HelpBox("ID は自動で振ります（書き換えられません）。次に振る ID：称号 " + (Mathf.Max(db.lastNormalId, 0) + 1) + "　接続語 " + (Mathf.Max(db.lastConnectorId, db.Min(TitleDatabase.Kind.接続語) - 1) + 1)
                + "　内部用 " + (Mathf.Max(db.lastInternalId, db.Min(TitleDatabase.Kind.内部用) - 1) + 1) + "　記録 " + (Mathf.Max(db.lastRecordId, db.Min(TitleDatabase.Kind.記録) - 1) + 1)
                + "\nやめたい称号は行を消さず、状態を「廃止」にしてください。", MessageType.None);
            if (db.lastNormalId > maxNormal || db.lastConnectorId > maxConnector)
            {
                EditorGUILayout.HelpBox("次に振る ID が、表にある一番大きい ID（称号 " + maxNormal + "・接続語 " + maxConnector + "）より先に進んでいます。"
                    + "ID を手で入れたか、行を消したためです。", MessageType.Info);
                if (GUILayout.Button("次に振る ID を表に合わせて詰める"))
                {
                    if (EditorUtility.DisplayDialog("World Title Gimmick",
                        "次に振る ID を、表にある一番大きい ID の次に戻します。\n\n公開済みのワールドで行を消していた場合、その ID を持っているプレイヤーには、次に足す称号が入れ替わって見えます。公開前なら問題ありません。",
                        "詰める", "やめる"))
                    {
                        Undo.RecordObject(db, "次に振る ID を詰める");
                        db.ResetLastIds();
                        EditorUtility.SetDirty(db);
                    }
                }
            }

            List<string> problems = db.Problems();
            if (problems.Count > 0) EditorGUILayout.HelpBox("表の問題：\n・" + string.Join("\n・", problems), MessageType.Warning);

            openPacks = EditorGUILayout.Foldout(openPacks, "見本の称号を足す（部品なしで動く称号のパック）", true);
            if (openPacks)
            {
                EditorGUI.indentLevel++;
                EditorGUILayout.HelpBox("置くだけで動く称号（来訪の日数・ジャンプの回数など）をまとめて足します。キーか語が同じ行がもうあれば足しません。足したあとで語・説明・条件は自由に変えてください。", MessageType.None);
                foreach (TitlePacks.Pack pack in TitlePacks.All)
                {
                    EditorGUILayout.BeginHorizontal();
                    EditorGUILayout.LabelField(pack.name + "（" + pack.items.Length + "）", pack.about);
                    if (GUILayout.Button("足す", GUILayout.Width(60)))
                    {
                        Undo.RecordObject(db, "見本の称号を足す");
                        var skipped = new List<string>();
                        int added = TitlePacks.AddTo(db, pack, skipped);
                        EditorUtility.SetDirty(db);
                        packMessage = "「" + pack.name + "」から " + added + " 行を足しました。" + (skipped.Count > 0 ? "\nもうあるので足さなかったもの：" + string.Join("、", skipped) : "");
                        serializedObject.Update();
                    }
                    EditorGUILayout.EndHorizontal();
                }
                if (!string.IsNullOrEmpty(packMessage)) EditorGUILayout.HelpBox(packMessage, MessageType.Info);
                EditorGUI.indentLevel--;
            }

            if (GUILayout.Button("称号エディタで開く（一覧・検索・並べ替え）")) TitleEditorWindow.OpenWith(db);
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("CSV に書き出す"))
            {
                string message = TitleCsv.ExportWithDialog(db);
                if (message != null) packMessage = message;
            }
            if (GUILayout.Button("CSV から読み込む"))
            {
                string message = TitleCsv.ImportWithDialog(db);
                if (message != null)
                {
                    serializedObject.Update();
                    packMessage = message;
                }
            }
            EditorGUILayout.EndHorizontal();
            if (!openPacks && !string.IsNullOrEmpty(packMessage)) EditorGUILayout.HelpBox(packMessage, MessageType.Info);

            EditorGUILayout.Space();
            SerializedProperty it = serializedObject.GetIterator();
            bool enter = true;
            while (it.NextVisible(enter))
            {
                enter = false;
                if (it.name == "m_Script") continue;
                EditorGUILayout.PropertyField(it, new GUIContent(it.name == "rows" ? "称号の行（" + it.arraySize + "）" : it.displayName, "［" + it.displayName + " / " + it.name + "］"), true);
            }
            serializedObject.ApplyModifiedProperties();
        }
    }
}
