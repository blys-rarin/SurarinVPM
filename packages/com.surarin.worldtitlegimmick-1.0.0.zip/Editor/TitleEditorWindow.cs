using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace WorldTitleGimmick.EditorTools
{
    // 「World Title Gimmick/Title Editor」（仕様書の称号エディタ、2026-10-28）：称号の表を一覧で見て、検索・並べ替え・編集する窓。
    // 一覧には、条件の書き間違いと、シーンでその称号を渡す部品の数も出す。行を選ぶと右に全部の欄が出る。
    public class TitleEditorWindow : EditorWindow
    {
        private enum Sort { ID, 並び順, キー, 語 }
        private enum KindFilter { すべて, 称号, 接続語, 内部用, 記録 }

        private TitleDatabase db;
        private string search = "";
        private Sort sort = Sort.ID;
        private KindFilter kindFilter = KindFilter.すべて;
        private bool showRetired = true;
        private int selected = -1;
        private Vector2 listScroll, detailScroll;
        private Dictionary<string, List<Object>> granters = new Dictionary<string, List<Object>>();
        private double nextScan;
        private string csvMessage = "";

        [MenuItem("World Title Gimmick/称号エディタ（Title Editor）")]
        public static void Open() { OpenWith(null); }

        public static void OpenWith(TitleDatabase database)
        {
            var window = GetWindow<TitleEditorWindow>("称号エディタ");
            if (database != null) window.db = database;
            window.Show();
        }

        private void OnEnable()
        {
            if (db == null) db = TitleGUI.SceneDatabase();
        }

        private void OnGUI()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            db = (TitleDatabase)EditorGUILayout.ObjectField(db, typeof(TitleDatabase), false, GUILayout.Width(220));
            GUILayout.Space(8);
            search = EditorGUILayout.TextField(search, EditorStyles.toolbarSearchField, GUILayout.MinWidth(120));
            kindFilter = (KindFilter)EditorGUILayout.EnumPopup(kindFilter, EditorStyles.toolbarPopup, GUILayout.Width(70));
            sort = (Sort)EditorGUILayout.EnumPopup(sort, EditorStyles.toolbarPopup, GUILayout.Width(70));
            showRetired = GUILayout.Toggle(showRetired, "廃止も出す", EditorStyles.toolbarButton, GUILayout.Width(70));
            EditorGUILayout.EndHorizontal();
            if (db == null)
            {
                EditorGUILayout.HelpBox("称号の表（Title Database）を上で選んでください。", MessageType.Info);
                return;
            }

            TitleDatabaseEditor.FillGapsToggle(db);

            // 表の場所と CSV（2026-10-28。表のインスペクターと同じ処理）。
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("表の場所：" + AssetDatabase.GetAssetPath(db), EditorStyles.miniLabel, GUILayout.MinWidth(120));
            if (GUILayout.Button("Project で見る", EditorStyles.miniButton, GUILayout.Width(100)))
            {
                Selection.activeObject = db;
                EditorGUIUtility.PingObject(db);
            }
            if (GUILayout.Button("CSV に書き出す", EditorStyles.miniButton, GUILayout.Width(100)))
            {
                string message = TitleCsv.ExportWithDialog(db);
                if (message != null) csvMessage = message;
                GUIUtility.ExitGUI();
            }
            if (GUILayout.Button("CSV から読み込む", EditorStyles.miniButton, GUILayout.Width(110)))
            {
                string message = TitleCsv.ImportWithDialog(db);
                if (message != null) { csvMessage = message; selected = -1; }
                GUIUtility.ExitGUI();
            }
            EditorGUILayout.EndHorizontal();
            if (!string.IsNullOrEmpty(csvMessage))
            {
                EditorGUILayout.BeginHorizontal();
                EditorGUILayout.HelpBox(csvMessage, MessageType.Info);
                if (GUILayout.Button("×", GUILayout.Width(22))) csvMessage = "";
                EditorGUILayout.EndHorizontal();
            }
            if (EditorApplication.timeSinceStartup > nextScan) { ScanGranters(); nextScan = EditorApplication.timeSinceStartup + 2; }

            EditorGUILayout.BeginHorizontal();
            DrawList();
            DrawDetail();
            EditorGUILayout.EndHorizontal();
        }

        // シーンの部品が渡す称号（キー → 部品）。
        private void ScanGranters()
        {
            granters.Clear();
            void Add(string key, Object owner)
            {
                if (string.IsNullOrEmpty(key)) return;
                if (!granters.TryGetValue(key, out List<Object> list)) granters[key] = list = new List<Object>();
                if (!list.Contains(owner)) list.Add(owner);
            }
            foreach (TitleTriggerBase c in Object.FindObjectsOfType<TitleTriggerBase>(true)) if (c.grantKeys != null) foreach (string k in c.grantKeys) Add(k, c);
            foreach (TitleCounter c in Object.FindObjectsOfType<TitleCounter>(true)) if (c.stepKeys != null) foreach (string k in c.stepKeys) Add(k, c);
        }

        private List<int> VisibleRows()
        {
            var rows = new List<int>();
            for (int i = 0; i < db.rows.Count; i++)
            {
                TitleDatabase.Row r = db.rows[i];
                if (r == null) continue;
                if (kindFilter == KindFilter.称号 && r.kind != TitleDatabase.Kind.通常) continue;
                if (kindFilter == KindFilter.接続語 && r.kind != TitleDatabase.Kind.接続語) continue;
                if (kindFilter == KindFilter.記録 && r.kind != TitleDatabase.Kind.記録) continue;
                if (kindFilter == KindFilter.内部用 && r.kind != TitleDatabase.Kind.内部用) continue;
                if (!showRetired && r.state == TitleDatabase.State.廃止) continue;
                if (!string.IsNullOrEmpty(search))
                {
                    string all = (r.key + " " + r.word + " " + r.wordEn + " " + r.condition + " " + r.descAfter + " " + r.id).ToLowerInvariant();
                    if (!all.Contains(search.ToLowerInvariant())) continue;
                }
                rows.Add(i);
            }
            IEnumerable<int> sorted = rows;
            if (sort == Sort.ID) sorted = rows.OrderBy(i => db.rows[i].id);
            else if (sort == Sort.並び順) sorted = rows.OrderBy(i => db.rows[i].kind).ThenBy(i => db.rows[i].order).ThenBy(i => db.rows[i].id);
            else if (sort == Sort.キー) sorted = rows.OrderBy(i => db.rows[i].key);
            else sorted = rows.OrderBy(i => db.rows[i].word);
            return sorted.ToList();
        }

        private void DrawList()
        {
            EditorGUILayout.BeginVertical(GUILayout.Width(Mathf.Max(360, position.width * 0.55f)));
            EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
            GUILayout.Label("ID", EditorStyles.boldLabel, GUILayout.Width(40));
            GUILayout.Label("語", EditorStyles.boldLabel, GUILayout.Width(120));
            GUILayout.Label("キー", EditorStyles.boldLabel, GUILayout.Width(110));
            GUILayout.Label("もらい方", EditorStyles.boldLabel);
            EditorGUILayout.EndHorizontal();
            listScroll = EditorGUILayout.BeginScrollView(listScroll);
            List<int> rows = VisibleRows();
            var keyCount = db.rows.Where(r => r != null && !string.IsNullOrEmpty(r.key)).GroupBy(r => r.key).ToDictionary(g => g.Key, g => g.Count());
            foreach (int i in rows)
            {
                TitleDatabase.Row r = db.rows[i];
                string problem = TitleBake.CheckCondition(db, r);
                if (string.IsNullOrEmpty(r.key)) problem = "キーが空です";
                else if (keyCount.TryGetValue(r.key, out int n) && n > 1) problem = "キーが重複しています";
                string how = !string.IsNullOrEmpty(r.condition) ? r.condition
                    : r.kind == TitleDatabase.Kind.記録 ? "（記録：_SetRecord で書く）"
                    : granters.TryGetValue(r.key ?? "", out List<Object> list) ? "部品 " + list.Count + " 個" : r.kind == TitleDatabase.Kind.接続語 && !r.lockedConnector ? "（最初から使える）" : "（渡すものなし）";
                var style = new GUIStyle(EditorStyles.label);
                if (r.state == TitleDatabase.State.廃止) style.normal.textColor = Color.gray;
                if (!string.IsNullOrEmpty(problem)) style.normal.textColor = new Color(1f, .45f, .35f);
                Rect line = EditorGUILayout.BeginHorizontal();
                if (i == selected && Event.current.type == EventType.Repaint) EditorGUI.DrawRect(line, new Color(.24f, .48f, .90f, .35f));
                GUILayout.Label(r.id.ToString(), style, GUILayout.Width(40));
                GUILayout.Label((r.kind == TitleDatabase.Kind.接続語 ? "◇ " : r.kind == TitleDatabase.Kind.記録 ? "♯ " : r.kind == TitleDatabase.Kind.内部用 ? "（内）" : "") + r.word, style, GUILayout.Width(120));
                GUILayout.Label(r.key, style, GUILayout.Width(110));
                GUILayout.Label(string.IsNullOrEmpty(problem) ? how : "⚠ " + problem, style);
                EditorGUILayout.EndHorizontal();
                if (Event.current.type == EventType.MouseDown && line.Contains(Event.current.mousePosition))
                {
                    selected = i;
                    GUI.FocusControl(null);
                    Event.current.Use();
                }
            }
            EditorGUILayout.EndScrollView();
            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("称号を足す")) AddRow(TitleDatabase.Kind.通常, null);
            if (GUILayout.Button("接続語を足す")) AddRow(TitleDatabase.Kind.接続語, null);
            if (GUILayout.Button("内部用を足す")) AddRow(TitleDatabase.Kind.内部用, null);
            if (GUILayout.Button("記録を足す")) AddRow(TitleDatabase.Kind.記録, null);
            using (new EditorGUI.DisabledScope(selected < 0 || selected >= db.rows.Count))
                if (GUILayout.Button("選んだ行を写す")) AddRow(db.rows[selected].kind, db.rows[selected]);
            EditorGUILayout.EndHorizontal();
            // 削除・番号の入れ替えは、持っている人の保存と食い違うので「消した行の番号を使い直す（公開前だけ）」がオンのときだけ（2026-10-29、ユーザー指定）。
            TitleDatabase.Row picked = selected >= 0 && selected < db.rows.Count ? db.rows[selected] : null;
            EditorGUILayout.BeginHorizontal();
            using (new EditorGUI.DisabledScope(!db.fillGaps || picked == null))
            {
                using (new EditorGUI.DisabledScope(db.IdNeighbor(picked, true) == null))
                    if (GUILayout.Button(new GUIContent("▲ 番号を前と入れ替え", "同じ分類で、すぐ前の番号の行と ID を入れ替える"))) SwapWith(picked, true);
                using (new EditorGUI.DisabledScope(db.IdNeighbor(picked, false) == null))
                    if (GUILayout.Button(new GUIContent("▼ 番号を後と入れ替え", "同じ分類で、すぐ後の番号の行と ID を入れ替える"))) SwapWith(picked, false);
                if (GUILayout.Button("削除")) { DeleteRow(selected); GUIUtility.ExitGUI(); }
            }
            EditorGUILayout.EndHorizontal();
            if (!db.fillGaps) EditorGUILayout.LabelField("削除・番号の入れ替えは、上の「消した行の番号を使い直す（公開前だけ）」をオンにすると使えます。", EditorStyles.miniLabel);
            EditorGUILayout.LabelField("全部 " + db.rows.Count + " 行・表示 " + rows.Count + " 行。公開したあとは行を消さず、やめるときは状態を「廃止」に。", EditorStyles.miniLabel);
            EditorGUILayout.EndVertical();
        }

        private void AddRow(TitleDatabase.Kind kind, TitleDatabase.Row from)
        {
            Undo.RecordObject(db, "称号の行を足す");
            string baseKey = from != null ? from.key + "_copy" : kind == TitleDatabase.Kind.通常 ? "new_title" : kind == TitleDatabase.Kind.記録 ? "new_record" : kind == TitleDatabase.Kind.内部用 ? "new_internal" : "new_connector";
            string key = baseKey;
            for (int n = 2; db.Find(key) != null; n++) key = baseKey + n;
            var row = from == null ? new TitleDatabase.Row { kind = kind } : JsonUtility.FromJson<TitleDatabase.Row>(JsonUtility.ToJson(from));
            row.id = 0;
            row.key = key;
            if (from != null) row.word = from.word + "（写し）";
            db.rows.Add(row);
            db.AssignIds();
            EditorUtility.SetDirty(db);
            selected = db.rows.Count - 1;
            sort = Sort.ID;
            search = "";
        }

        private void SwapWith(TitleDatabase.Row row, bool up)
        {
            TitleDatabase.Row other = db.IdNeighbor(row, up);
            if (other == null) return;
            Undo.RecordObject(db, "称号の番号を入れ替える");
            db.SwapIds(row, other);
            db.AssignIds();
            EditorUtility.SetDirty(db);
            GUI.FocusControl(null);
        }

        // 選んだ行を消す（2026-10-29、ユーザー指定）。公開前（fillGaps オン）だけ押せるので、確認は出さずにすぐ消す（Undo で戻せる）。
        // 部品が渡している・ほかの行の条件に出てくるときは、Console に知らせる。
        private void DeleteRow(int index)
        {
            if (index < 0 || index >= db.rows.Count || db.rows[index] == null) return;
            TitleDatabase.Row r = db.rows[index];
            string uses = "";
            if (granters.TryGetValue(r.key ?? "", out List<Object> list) && list.Count > 0)
                uses += " シーンの部品 " + list.Count + " 個がこの称号を渡しています（その部品は何も渡さなくなります）。";
            int refs = db.rows.Count(o => o != null && o != r && !string.IsNullOrEmpty(o.condition) && !string.IsNullOrEmpty(r.key) && o.condition.Contains(r.key));
            if (refs > 0) uses += " ほかの " + refs + " 行の条件にこのキーが出てきます。";
            if (uses.Length > 0) Debug.LogWarning("[World Title Gimmick] 称号「" + r.word + "」（キー " + r.key + "）を消しました。" + uses + "（Ctrl+Z で戻せます）");
            Undo.RecordObject(db, "称号の行を消す");
            db.rows.RemoveAt(index);
            EditorUtility.SetDirty(db);
            selected = -1;
            GUI.FocusControl(null);
        }

        private void DrawDetail()
        {
            EditorGUILayout.BeginVertical();
            if (selected < 0 || selected >= db.rows.Count || db.rows[selected] == null)
            {
                EditorGUILayout.HelpBox("左の一覧から行を選ぶと、ここで編集できます。", MessageType.None);
                EditorGUILayout.EndVertical();
                return;
            }
            detailScroll = EditorGUILayout.BeginScrollView(detailScroll);
            var so = new SerializedObject(db);
            so.Update();
            SerializedProperty row = so.FindProperty("rows").GetArrayElementAtIndex(selected);
            TitleDatabase.Row r = db.rows[selected];
            EditorGUILayout.LabelField("ID " + r.id + "（自動。変えられません）", EditorStyles.boldLabel);
            // 欄は日本語の名前で出す。記録の設定は記録の行だけ・記録の行には条件を出さない（TitleRowGUI.Visible）。
            foreach (SerializedProperty p in TitleRowGUI.Children(row))
                if (TitleRowGUI.Visible(row, p.name, false)) EditorGUILayout.PropertyField(p, TitleRowGUI.Label(p), true);
            so.ApplyModifiedProperties();
            // 条件を種類・一覧・数で選んで作る（記録の行と、解禁しない接続語には条件がないので出さない）。
            if (r.kind == TitleDatabase.Kind.通常 || r.kind == TitleDatabase.Kind.内部用 || (r.kind == TitleDatabase.Kind.接続語 && r.lockedConnector)) TitleConditionGUI.Draw(db, r);
            string problem = TitleBake.CheckCondition(db, r);
            if (!string.IsNullOrEmpty(problem)) EditorGUILayout.HelpBox("条件：" + problem, MessageType.Warning);
            if (r.kind == TitleDatabase.Kind.記録)
                EditorGUILayout.HelpBox("記録の称号：語が前置きになります（例：語「最速タイム」・書式「時間」・後ろ「秒」→「最速タイム 12.34秒」）。値は _SetRecord(\"" + r.key + "\", 値) で書きます（01 の 6-6）。", MessageType.None);
            else EditorGUILayout.HelpBox("条件の書き方：count:名前>=N / stat:名前>=N / owned>=N / all:キー,キー / date:1025-1031 / record:キー>=N / visit>=N / stay>=N（01 の 8章）", MessageType.None);

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("この称号を渡す部品（シーン）", EditorStyles.boldLabel);
            if (granters.TryGetValue(r.key ?? "", out List<Object> list))
            {
                foreach (Object owner in list)
                    if (owner != null && GUILayout.Button(owner.name + "（" + owner.GetType().Name + "）", EditorStyles.linkLabel))
                    {
                        Selection.activeObject = owner;
                        EditorGUIUtility.PingObject(owner);
                    }
            }
            else EditorGUILayout.LabelField(string.IsNullOrEmpty(r.condition) ? "なし（表の条件もない。コードから渡すなら問題なし）" : "なし（表の条件で渡す）", EditorStyles.miniLabel);
            EditorGUILayout.EndScrollView();
            EditorGUILayout.EndVertical();
        }
    }
}
