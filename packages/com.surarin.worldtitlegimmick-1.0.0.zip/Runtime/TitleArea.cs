using UdonSharp;
using UnityEngine;
using VRC.SDK3.Data;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // 称号エリア（仕様書 7-2）。Is Trigger のコライダーに付ける。
    // 本人か、指定した物がエリアに入った・出た・N秒いた・N回入ったときに、前提の条件を満たしていれば結果（称号など）を出す。
    // 物のときは、その物を持っている人・最後に持った人（持ち主）が本人なら、本人の端末で判定する。同期しない。
    // 2026-10-28：物のとき「エリアの中にいる人に渡す」（各人が自分の端末で、自分が中にいるかを見る）と、
    //   きっかけ「中の人数がN人以上」（全員の出入りを各端末で数える。出入りの出来事のときだけ動く）を足した。
    [AddComponentMenu("World Title Gimmick/称号エリア（TitleArea）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleArea : TitleTriggerBase
    {
        public const int WhoPlayer = 0;
        public const int WhoObjects = 1;
        public const int WhoLayer = 2;
        public const int OnEnter = 0;
        public const int OnExit = 1;
        public const int OnStay = 2;
        public const int OnStayTotal = 3;
        public const int OnEnterCount = 4;
        public const int OnCrowd = 5;
        public const int ReceiverHolder = 0;
        public const int ReceiverOwner = 1;
        public const int ReceiverInside = 2;

        [Tooltip("0 本人 / 1 指定した物 / 2 指定したレイヤーの物")]
        public int who = WhoPlayer;
        [Tooltip("who が 1 のときの物")]
        public GameObject[] objects = new GameObject[0];
        [Tooltip("who が 2 のときのレイヤー")]
        public LayerMask layers;
        [Tooltip("物のとき：0 その物を持っている人 / 1 最後に持った人（持ち主） / 2 エリアの中にいる人")]
        public int receiver = 0;
        [Tooltip("物のとき：同時にこの数だけ入ったら")]
        public int objectCount = 1;

        [Tooltip("0 入ったら / 1 出たら / 2 続けてN秒いたら / 3 合計N秒いたら（保存） / 4 N回入ったら / 5 中の人数がN人以上（本人のとき）")]
        public int trigger = OnEnter;
        public float seconds = 10f;
        public int count = 5;
        [Tooltip("中の人数（trigger 5）：この人数以上が中にいたら、中にいる人それぞれに渡す（自分を含む）")]
        public int crowdCount = 2;
        [Tooltip("合計の秒・入った回数を保存するカウンターの名前（空なら保存しない）")]
        public string saveKey = "";

        private bool inside;
        private int insideObjects;
        private float stayed;
        private int entered;
        // 1秒ごとの数え上げが動いているか（入り直しで二重にしない）。
        private bool ticking;
        // 本人が中にいるか（物のときの「中にいる人に渡す」で使う）。
        private bool localInside;
        // 中にいる人（playerId）。中の人数のきっかけのときだけ使う。
        private DataDictionary crowd = new DataDictionary();
        private bool crowdMet;

        // ---- 本人 ----

        public override void OnPlayerTriggerEnter(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player)) return;
            if (player.isLocal) localInside = true;
            // 物が先に置いてあるエリアに、あとから本人が入ったとき。
            if (who != WhoPlayer && player.isLocal && receiver == ReceiverInside && insideObjects >= Mathf.Max(1, objectCount)) Enter();
            if (who != WhoPlayer) return;
            if (trigger == OnCrowd) { crowd.SetValue(player.playerId, true); CheckCrowd(); return; }
            if (player.isLocal) Enter();
        }

        public override void OnPlayerTriggerExit(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player)) return;
            if (player.isLocal) localInside = false;
            if (who != WhoPlayer && player.isLocal && receiver == ReceiverInside) Exit();
            if (who != WhoPlayer) return;
            if (trigger == OnCrowd) { crowd.Remove(player.playerId); CheckCrowd(); return; }
            if (player.isLocal) Exit();
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            if (trigger != OnCrowd || player == null) return;
            crowd.Remove(player.playerId);
            CheckCrowd();
        }

        // 中の人数がN人以上になったら、中にいる本人に渡す。人数が減ったら、また数え直せるようにする。
        private void CheckCrowd()
        {
            bool met = localInside && crowd.Count >= Mathf.Max(1, crowdCount);
            if (met && !crowdMet) TryFire();
            crowdMet = met;
        }

        // ---- 物 ----

        private void OnTriggerEnter(Collider other)
        {
            if (who == WhoPlayer || other == null || !Matches(other.gameObject)) return;
            insideObjects++;
            if (insideObjects >= Mathf.Max(1, objectCount) && Receives(other.gameObject)) Enter();
        }

        private void OnTriggerExit(Collider other)
        {
            if (who == WhoPlayer || other == null || !Matches(other.gameObject)) return;
            insideObjects = Mathf.Max(0, insideObjects - 1);
            if (insideObjects < Mathf.Max(1, objectCount)) Exit();
        }

        private bool Matches(GameObject target)
        {
            if (who == WhoLayer) return (layers.value & (1 << target.layer)) != 0;
            for (int i = 0; i < objects.Length; i++) if (objects[i] == target) return true;
            return false;
        }

        // その物の結果を本人が受け取るか。
        private bool Receives(GameObject target)
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return false;
            VRC_Pickup pickup = (VRC_Pickup)target.GetComponent(typeof(VRC_Pickup));
            if (receiver == ReceiverInside) return localInside;
            if (receiver == ReceiverHolder) return pickup != null && pickup.IsHeld && pickup.currentPlayer == local;
            VRCPlayerApi owner = Networking.GetOwner(target);
            return Utilities.IsValid(owner) && owner.isLocal;
        }

        // ---- きっかけ ----

        private void Enter()
        {
            if (inside) return;
            inside = true;
            if (trigger == OnEnter) TryFire();
            else if (trigger == OnEnterCount)
            {
                int total = CountUp(1);
                if (total >= count) TryFire();
            }
            else if (trigger == OnStay || trigger == OnStayTotal)
            {
                stayed = 0f;
                if (!ticking)
                {
                    ticking = true;
                    SendCustomEventDelayedSeconds(nameof(_StayTick), 1f);
                }
            }
        }

        private void Exit()
        {
            if (!inside) return;
            inside = false;
            if (trigger == OnExit) TryFire();
        }

        // 中にいる間だけ1秒ごとに数える。
        public void _StayTick()
        {
            if (!inside) { ticking = false; return; }
            SendCustomEventDelayedSeconds(nameof(_StayTick), 1f);
            if (trigger == OnStay)
            {
                stayed += 1f;
                if (stayed >= seconds) { TryFire(); stayed = 0f; }
                return;
            }
            int total = CountUp(1);
            if (total >= Mathf.RoundToInt(seconds)) TryFire();
        }

        // 回数・秒を足す（saveKey があれば保存するカウンター）。
        private int CountUp(int amount)
        {
            if (string.IsNullOrEmpty(saveKey) || manager == null) { entered += amount; return entered; }
            manager._AddCount(saveKey, amount);
            return manager._GetCount(saveKey);
        }

        private void TryFire()
        {
            if (once && _AllOwned()) return;
            if (_Ready()) _Fire();
        }
    }
}
