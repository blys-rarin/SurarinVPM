using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

namespace WorldTitleGimmick
{
    // 称号ゲート（仕様書 7-4）。称号を持っている・装備している（ほかに獲得数・行動の値）ときだけ、
    // 表示・当たり判定・物の有効・掴めるかを切り替える。切り替えるのは本人の画面の中だけ。
    // 見直すのは TitleManager から変わったと知らされたときだけ（毎フレームは見ない）。
    [AddComponentMenu("World Title Gimmick/称号ゲート（TitleGate）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleGate : UdonSharpBehaviour
    {
        public const int ModeOwned = 0;
        public const int ModeEquipped = 1;

        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;

        public string[] titleKeys = new string[0];
        [Tooltip("0 持っている / 1 装備している")]
        public int mode = ModeOwned;
        [Tooltip("オンなら全部、オフならどれか（「必要な数」が1以上ならそちらを使う）")]
        public bool matchAll = false;
        [Tooltip("titleKeys のうち、これだけの数を満たせばよい（0 なら「全部／どれか」で決める）")]
        public int requiredCount = 0;
        [Tooltip("肩書きにこの順番で並んでいること（空なら見ない）。装備しているかで見る")]
        public string[] sequenceKeys = new string[0];
        [Tooltip("オンなら、並びの間にほかの語を挟まない（空の枠は詰めて数える）")]
        public bool sequenceContiguous = false;
        [Tooltip("枠の番号（1〜10）。slotCheckKeys と同じ並びで、その枠にその称号・接続語が入っていること")]
        public int[] slotCheckSlots = new int[0];
        public string[] slotCheckKeys = new string[0];
        [Tooltip("獲得数がこれ以上（0 なら見ない）")]
        public int minOwned = 0;
        [Tooltip("行動の値の名前（例：jumps。空なら見ない）")]
        public string statName = "";
        public int statMin = 0;
        [Tooltip("記録の称号のキー（空なら見ない）。記録が recordMin に届いていること（小さいほど良い記録なら recordMin 以下）")]
        public string recordKey = "";
        public int recordMin = 0;
        [Tooltip("オンなら、条件を満たさないときに切り替える")]
        public bool invert = false;

        public Renderer[] renderers = new Renderer[0];
        public Collider[] colliders = new Collider[0];
        public GameObject[] objects = new GameObject[0];
        [Tooltip("enabled を切り替えるコンポーネント（AudioSource・Light・Animator・Canvas・ほかの Udon など）。物ごとではなく、そのコンポーネントだけを切り替える")]
        public Behaviour[] behaviours = new Behaviour[0];
        [Tooltip("掴めるかを切り替える物（Pickup の付いた物）")]
        public GameObject[] pickupObjects = new GameObject[0];
        [Tooltip("Interact できるかを切り替える Udon（満たさないときは押せない）")]
        public UdonBehaviour[] interactTargets = new UdonBehaviour[0];
        [Tooltip("満たさないときに有効にするもの（「称号がない人には壁」など）")]
        public GameObject[] objectsWhenNot = new GameObject[0];
        [Tooltip("満たしたら enabled をオフにするコンポーネント（満たさないときはオン）")]
        public Behaviour[] behavioursWhenNot = new Behaviour[0];

        public UdonBehaviour[] eventTargets = new UdonBehaviour[0];
        public string metEvent = "";
        public string unmetEvent = "";

        private int state = -1;

        private void Start()
        {
            // 復元の前は「条件を満たしていない」として扱う。反転なら、切り替える側（壁など）を出しておく（2026-10-28：入室直後に壁が消えて通れた）。
            Apply(invert);
            // 行動の値の知らせ（歩いている間は1秒に1回ほど）は、行動の値を条件にしたときだけ受ける。
            if (manager != null) manager._ListenFor(this, TitleManager.ListenTitles + (string.IsNullOrEmpty(statName) ? 0 : TitleManager.ListenStats));
        }

        public void _OnTitlesChanged() { Apply(Met()); }

        private bool Met()
        {
            if (manager == null || !manager._Restored()) return invert;
            bool ok = true;
            if (titleKeys.Length > 0)
            {
                int hits = 0;
                int used = 0;
                for (int i = 0; i < titleKeys.Length; i++)
                {
                    if (string.IsNullOrEmpty(titleKeys[i])) continue;
                    used++;
                    bool hit = mode == ModeEquipped ? manager._EquippedKey(titleKeys[i]) : manager._HasKey(titleKeys[i]);
                    if (hit) hits++;
                }
                if (used > 0) ok = requiredCount > 0 ? hits >= requiredCount : matchAll ? hits == used : hits > 0;
            }
            if (ok && sequenceKeys.Length > 0) ok = SequenceOk();
            if (ok && slotCheckSlots.Length > 0) ok = SlotsOk();
            if (minOwned > 0 && manager._OwnedCount() < minOwned) ok = false;
            if (!string.IsNullOrEmpty(statName) && manager._GetStat(statName) < statMin) ok = false;
            if (!string.IsNullOrEmpty(recordKey) && !manager._RecordReaches(recordKey, recordMin)) ok = false;
            return invert ? !ok : ok;
        }

        // 肩書きの枠（空の枠は詰める）に、sequenceKeys がこの順番で入っているか。
        private bool SequenceOk()
        {
            int[] plate = manager._Plate();
            int[] packed = new int[plate.Length];
            int n = 0;
            for (int i = 0; i < plate.Length; i++)
                if (plate[i] > 0 && manager._SlotOpen(i) && manager._SlotType(i) != TitleManager.SlotUnused) packed[n++] = plate[i];
            int want = 0;
            int start = -1;
            for (int i = 0; i < n && want < sequenceKeys.Length; i++)
            {
                if (packed[i] == manager._IdOf(sequenceKeys[want]))
                {
                    if (want == 0) start = i;
                    want++;
                    continue;
                }
                if (sequenceContiguous && want > 0)
                {
                    // 続きでなくなったら、この位置から数え直す。
                    i = start;
                    want = 0;
                }
            }
            return want == sequenceKeys.Length;
        }

        // 指定の枠に指定の語が入っているか。
        private bool SlotsOk()
        {
            int[] plate = manager._Plate();
            for (int i = 0; i < slotCheckSlots.Length; i++)
            {
                int slot = slotCheckSlots[i] - 1;
                string key = i < slotCheckKeys.Length ? slotCheckKeys[i] : "";
                if (slot < 0 || slot >= plate.Length) return false;
                if (plate[slot] != manager._IdOf(key) || !manager._SlotOpen(slot)) return false;
            }
            return true;
        }

        private void Apply(bool met)
        {
            int next = met ? 1 : 0;
            if (next == state) return;
            bool first = state < 0;
            state = next;
            for (int i = 0; i < renderers.Length; i++) if (renderers[i] != null) renderers[i].enabled = met;
            for (int i = 0; i < colliders.Length; i++) if (colliders[i] != null) colliders[i].enabled = met;
            for (int i = 0; i < objects.Length; i++) if (objects[i] != null) objects[i].SetActive(met);
            for (int i = 0; i < behaviours.Length; i++) if (behaviours[i] != null) behaviours[i].enabled = met;
            // VRC_Pickup の配列は Udon のプログラムの保存で壊れるので、物から Pickup を探す。
            for (int i = 0; i < pickupObjects.Length; i++)
            {
                if (pickupObjects[i] == null) continue;
                VRC_Pickup pickup = (VRC_Pickup)pickupObjects[i].GetComponent(typeof(VRC_Pickup));
                if (pickup != null) pickup.pickupable = met;
            }
            for (int i = 0; i < interactTargets.Length; i++) if (interactTargets[i] != null) interactTargets[i].DisableInteractive = !met;
            for (int i = 0; i < objectsWhenNot.Length; i++) if (objectsWhenNot[i] != null) objectsWhenNot[i].SetActive(!met);
            for (int i = 0; i < behavioursWhenNot.Length; i++) if (behavioursWhenNot[i] != null) behavioursWhenNot[i].enabled = !met;
            if (first) return;
            string name = met ? metEvent : unmetEvent;
            if (string.IsNullOrEmpty(name)) return;
            for (int i = 0; i < eventTargets.Length; i++) if (eventTargets[i] != null) eventTargets[i].SendCustomEvent(name);
        }
    }
}
