using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // 席（2026-10-28）。VRC Station と同じ物に付けると、本人が座った回数（sits）と座っていた時間（sit_min）を数える。
    // 座る・立つの出来事のときだけ動く。同期しない。
    // シーンの点検（Check Scene）で sits・sit_min を使っているのに付いていない席があると、「すべての席に付ける」ボタンで全部の席に付けられる。
    [AddComponentMenu("World Title Gimmick/席（座った回数・時間）（TitleSeat）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleSeat : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;

        private bool seated;

        public override void OnStationEntered(VRCPlayerApi player)
        {
            if (seated || manager == null || !Utilities.IsValid(player) || !player.isLocal) return;
            seated = true;
            manager._SeatEnter();
        }

        public override void OnStationExited(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            Leave();
        }

        // 座ったまま席が消えたときも、立ったことにする。
        private void OnDisable() { Leave(); }

        private void Leave()
        {
            if (!seated) return;
            seated = false;
            if (manager != null) manager._SeatExit();
        }
    }
}
