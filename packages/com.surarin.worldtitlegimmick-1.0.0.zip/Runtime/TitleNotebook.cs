using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon.Common;

namespace WorldTitleGimmick
{
    // 称号の手帳（2026-10-28、ユーザー指定「場所まで行って装備するのが面倒なので、その場で称号ボードを出したい」）。
    // 持ち歩ける小物（Pickup）。使う（トリガー／クリック）と、目の前に持ち運び用の称号ボードを出す・消す。
    // 手帳はキー（デスクトップ）か、両手のトリガーの長押し（VR）で目の前に呼び寄せられる。
    // 同期しない（手帳もボードも本人の画面だけ。ほかの人には、その人の手帳が見える）。
    // 毎フレームの処理はデスクトップのキーを見るだけ（ユーザー了承済み）。VR の長押しはトリガーのイベントと遅延の呼び出しで見る。
    [AddComponentMenu("World Title Gimmick/称号の手帳（TitleNotebook）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleNotebook : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）。マネージャーの「その場で出すボード（手帳）を使う」がオフなら、手帳とボードを消す")]
        public TitleManager manager;
        [Tooltip("出し入れする持ち運び用の称号ボード")]
        public GameObject board;

        [Tooltip("オンなら、デスクトップでキーを押すと手帳が目の前に来る")]
        public bool keySummon = true;
        public KeyCode summonKey = KeyCode.T;
        [Tooltip("オンなら、VR で両手のトリガーを同時に長押しすると手帳が目の前に来る")]
        public bool vrSummon = true;
        [Tooltip("両手のトリガーを押し続ける秒数")]
        public float vrHoldSeconds = 1f;

        [Tooltip("呼び寄せた手帳を置く、目からの距離（m）")]
        public float notebookDistance = .45f;
        [Tooltip("ボードを出す、目からの距離（m）")]
        public float boardDistance = 1f;
        [Tooltip("ボードの中心を目の高さから下げる長さ（m）")]
        public float boardDown = .15f;

        private bool leftDown;
        private bool rightDown;
        private float bothSince;
        private VRC_Pickup pickup;

        private void Start()
        {
            pickup = (VRC_Pickup)GetComponent(typeof(VRC_Pickup));
            if (board != null) board.SetActive(false);
            if (manager != null && !manager.usePortableBoard) gameObject.SetActive(false);
        }

        // デスクトップ：キーで呼び寄せる。
        private void Update()
        {
            if (keySummon && Input.GetKeyDown(summonKey)) _Summon();
        }

        // VR：両手のトリガーを同時に押したら、vrHoldSeconds 後にまだ押していれば呼び寄せる。
        public override void InputUse(bool value, UdonInputEventArgs args)
        {
            if (!vrSummon) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local) || !local.IsUserInVR()) return;
            if (args.handType == HandType.LEFT) leftDown = value;
            else rightDown = value;
            if (leftDown && rightDown)
            {
                bothSince = Time.time;
                SendCustomEventDelayedSeconds(nameof(_CheckHold), vrHoldSeconds);
            }
        }

        public void _CheckHold()
        {
            if (leftDown && rightDown && Time.time - bothSince >= vrHoldSeconds - .05f) _Summon();
        }

        // 手帳を目の前に呼び寄せる（手に持っているときは動かさない）。
        public void _Summon()
        {
            if (pickup != null && pickup.IsHeld) return;
            ReadHead();
            transform.SetPositionAndRotation(headPosition + headForward * notebookDistance + Vector3.down * .2f, Quaternion.LookRotation(headForward, Vector3.up));
        }

        // 手帳を使う：ボードを出す・消す。
        public override void OnPickupUseDown() { _ToggleBoard(); }

        public void _ToggleBoard()
        {
            if (board == null) return;
            if (board.activeSelf) { board.SetActive(false); return; }
            ReadHead();
            board.transform.SetPositionAndRotation(headPosition + headForward * boardDistance + Vector3.down * boardDown, Quaternion.LookRotation(headForward, Vector3.up));
            board.SetActive(true);
        }

        // 目の位置と、水平の前の向き（U# の自作メソッドは out 引数を避け、フィールドに入れる）。
        private Vector3 headPosition;
        private Vector3 headForward = Vector3.forward;

        private void ReadHead()
        {
            headPosition = transform.position;
            headForward = Vector3.forward;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            VRCPlayerApi.TrackingData data = local.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            Vector3 f = data.rotation * Vector3.forward;
            f.y = 0f;
            if (f.sqrMagnitude > .0001f) headForward = f.normalized;
            headPosition = data.position;
        }
    }
}
