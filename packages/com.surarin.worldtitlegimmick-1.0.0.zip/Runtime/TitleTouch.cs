using UdonSharp;
using UnityEngine;
using VRC.Dynamics;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // 撫でる・ハイタッチ（2026-10-28、ユーザー了承「使うときだけ毎フレーム」）。
    // コンタクトの受け手（VRC Contact Receiver）と同じ物に付け、本人の頭か手に毎フレーム付いていく。
    // ほかの人のアバターのコンタクト（手・頭）が触れたら、マネージャーに数えさせる。
    //   頭：ほかの人の手・指が触れた → 撫でられた（patted）
    //   手：ほかの人の頭に触れた → 撫でた（pats）／ほかの人の手に触れた → ハイタッチ（high_fives）
    // 撫でる・撫でられる・ハイタッチのどれも称号の条件に使っていなければ、始めに消える（毎フレームの処理もなくなる）。
    // 同期しない。アバターのコンタクトをワールドの受け手で受けられるかは、実機で要確認。
    [AddComponentMenu("World Title Gimmick/撫でる・ハイタッチ（TitleTouch）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleTouch : UdonSharpBehaviour
    {
        public const int PartHead = 0;
        public const int PartLeftHand = 1;
        public const int PartRightHand = 2;

        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;
        [Tooltip("付いていく所。0 頭 / 1 左手 / 2 右手")]
        public int part = PartHead;
        [Tooltip("一度数えたら、この秒数は同じ所で数えない（触れたまま何回も数えないように）")]
        public float cooldownSeconds = 2f;

        private float lastCounted = -100f;

        private void Start()
        {
            if (manager == null || !manager._TouchUsed()) gameObject.SetActive(false);
        }

        // アバターの動きのあと（その前に動かすと1フレーム遅れる）。
        public override void PostLateUpdate()
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            HumanBodyBones bone = part == PartHead ? HumanBodyBones.Head : part == PartLeftHand ? HumanBodyBones.LeftHand : HumanBodyBones.RightHand;
            Vector3 position = local.GetBonePosition(bone);
            // 骨のないアバターでは、追跡の位置を使う。
            if (position == Vector3.zero)
            {
                VRCPlayerApi.TrackingDataType tracking = part == PartHead ? VRCPlayerApi.TrackingDataType.Head
                    : part == PartLeftHand ? VRCPlayerApi.TrackingDataType.LeftHand : VRCPlayerApi.TrackingDataType.RightHand;
                position = local.GetTrackingData(tracking).position;
            }
            transform.position = position;
        }

        public override void OnContactEnter(ContactEnterInfo contactInfo)
        {
            if (manager == null || Time.time - lastCounted < cooldownSeconds) return;
            ContactSenderProxy sender = contactInfo.contactSender;
            if (sender == null || !sender.isValid) return;
            VRCPlayerApi player = sender.player;
            // ほかの人のアバターだけ（自分の体・ワールドの物は数えない）。
            if (!Utilities.IsValid(player) || player.isLocal) return;
            int what = -1;
            string[] tags = contactInfo.matchingTags;
            if (tags == null) return;
            for (int i = 0; i < tags.Length; i++)
            {
                string tag = tags[i];
                if (string.IsNullOrEmpty(tag)) continue;
                if (part == PartHead)
                {
                    if (tag.StartsWith("Hand") || tag.StartsWith("Finger")) { what = 1; break; }
                }
                else if (tag == "Head") { what = 0; break; }
                else if (tag.StartsWith("Hand")) what = 2;
            }
            if (what < 0) return;
            lastCounted = Time.time;
            manager._CountTouch(what);
        }
    }
}
