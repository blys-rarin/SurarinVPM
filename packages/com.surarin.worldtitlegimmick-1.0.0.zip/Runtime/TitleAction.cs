using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // 称号アクション（仕様書 7-3）。Pickup の物、または Interact で使う物に付ける。
    // 掴む・離す・使う・Interact・持ったままN秒・投げる・持ったままN m動く・ほかの人から受け取る を数え、N回で結果（称号など）を出す。
    // 掴んだとき、手渡しなら行動の値「受け取った回数」（received_items）も数える（マネージャーが判定する）。
    // 判定は、その物を持っている本人の端末。同期しない。
    // 「持ったまま指定のエリアに入る」「指定のエリアに置く」は称号エリア（TitleArea）の設定で作る。
    [AddComponentMenu("World Title Gimmick/称号アクション（TitleAction）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleAction : TitleTriggerBase
    {
        public const int ActGrab = 0;
        public const int ActDrop = 1;
        public const int ActUse = 2;
        public const int ActInteract = 3;
        public const int ActHoldSeconds = 4;
        public const int ActThrow = 5;
        public const int ActCarryMeters = 6;
        // 2026-10-28：ほかの人から受け取る（掴んだとき、ほかの人の手が物の近くにある＝手渡し）。
        public const int ActReceive = 7;
        // 2026-10-28：ほかの物に当てる（持っている間か、投げてから hitSeconds 秒の間に、指定した物・レイヤーにぶつかったら）。
        public const int ActHit = 8;

        [Tooltip("0 掴む / 1 離す / 2 使う（トリガー） / 3 Interact / 4 持ったままN秒 / 5 投げる / 6 持ったままN m動く / 7 ほかの人から受け取る（手渡し） / 8 ほかの物に当てる")]
        public int action = ActGrab;
        [Tooltip("この回数で結果を出す")]
        public int requiredCount = 1;
        [Tooltip("回数を保存するカウンターの名前（空なら保存しない）")]
        public string saveKey = "";
        [Tooltip("持ったままの秒（action 4）")]
        public float seconds = 10f;
        [Tooltip("投げたと数える速さ m/s（action 5）")]
        public float throwSpeed = 5f;
        [Tooltip("持ったまま動く距離 m（action 6）")]
        public float meters = 50f;
        [Tooltip("Interact のときに出す文字")]
        public string interactText = "Use";
        [Tooltip("オンなら、同じ物にほかの押せる Udon（元からあるスイッチなど）があるとき、押せる距離と出る文字をそちらに合わせる（エディタが Play・ビルドの前に写す）")]
        public bool matchOtherInteract = true;
        [Tooltip("当てる物（action 8）。hitLayers と合わせて、どちらかに当たれば数える")]
        public GameObject[] hitObjects = new GameObject[0];
        [Tooltip("当てるレイヤー（action 8）")]
        public LayerMask hitLayers;
        [Tooltip("投げてから当たるまで待つ秒数（action 8）")]
        public float hitSeconds = 3f;

        [Tooltip("この回数に届いたら（stepKeys と同じ並び）。「N回で称号A、M回で称号B」。回数は上の行動の回数")]
        public int[] steps = new int[0];
        [Tooltip("段で渡す称号（steps と同じ並び）")]
        public string[] stepKeys = new string[0];

        private int counted;
        private bool holding;
        private bool ticking;
        private float heldTime;
        private float carried;
        private Vector3 lastPosition;
        private Rigidbody body;
        private float droppedAt = -1000f;
        private float lastHit = -1000f;

        private void Start()
        {
            body = (Rigidbody)GetComponent(typeof(Rigidbody));
            // Interact を使わない設定では、触れる表示を出さない。
            DisableInteractive = action != ActInteract;
            // 「ほかの押せる部品に合わせる」がオンなら、エディタが写した文字（Udon の欄）をそのまま使う。
            if (action == ActInteract && !matchOtherInteract) InteractionText = interactText;
        }

        public override void Interact() { if (action == ActInteract) Count(); }

        public override void OnPickup()
        {
            holding = true;
            heldTime = 0f;
            carried = 0f;
            lastPosition = transform.position;
            if (action == ActGrab) Count();
            // 手渡し：ほかの人の手が近くにあるか（全員を回るのは掴んだときだけ）。
            bool handed = manager != null && manager._Handoff(transform.position, action == ActReceive);
            if (action == ActReceive && handed) Count();
            if ((action == ActHoldSeconds || action == ActCarryMeters) && !ticking)
            {
                ticking = true;
                SendCustomEventDelayedSeconds(nameof(_HoldTick), HoldStep);
            }
        }

        public override void OnDrop()
        {
            holding = false;
            droppedAt = Time.time;
            if (action == ActDrop) Count();
            // 手を離した次のフレームの速さを見る。
            if (action == ActThrow) SendCustomEventDelayedFrames(nameof(_CheckThrow), 2);
        }

        public override void OnPickupUseDown() { if (action == ActUse) Count(); }

        // 当てる：持っている間か、本人が投げてから hitSeconds 秒の間だけ（ぶつかった出来事のときだけ動く）。
        private void OnCollisionEnter(Collision collision)
        {
            if (action == ActHit && collision != null) Hit(collision.gameObject);
        }

        private void OnTriggerEnter(Collider other)
        {
            if (action == ActHit && other != null) Hit(other.gameObject);
        }

        private void Hit(GameObject target)
        {
            if (target == null || target == gameObject) return;
            if (!holding && Time.time - droppedAt > hitSeconds) return;
            // 跳ね返りで何回も数えない。
            if (Time.time - lastHit < .3f) return;
            bool match = (hitLayers.value & (1 << target.layer)) != 0;
            for (int i = 0; i < hitObjects.Length && !match; i++) if (hitObjects[i] == target) match = true;
            if (!match) return;
            lastHit = Time.time;
            Count();
        }

        public void _CheckThrow()
        {
            if (body != null && body.velocity.magnitude >= throwSpeed) Count();
        }

        // 持っている間だけ 0.25 秒ごとに数える（仕様書 19章の仮の間隔）。
        private const float HoldStep = 0.25f;
        public void _HoldTick()
        {
            if (!holding) { ticking = false; return; }
            SendCustomEventDelayedSeconds(nameof(_HoldTick), HoldStep);
            if (action == ActHoldSeconds)
            {
                heldTime += HoldStep;
                if (heldTime >= seconds) { heldTime = 0f; Count(); }
                return;
            }
            Vector3 position = transform.position;
            float step = (position - lastPosition).magnitude;
            lastPosition = position;
            // テレポートのような大きな動きは数えない。
            if (step < 5f) carried += step;
            if (carried >= meters) { carried = 0f; Count(); }
        }

        private void Count()
        {
            if (manager == null || !manager._Restored()) return;
            if (once && _AllOwned()) return;
            int total;
            if (string.IsNullOrEmpty(saveKey)) total = ++counted;
            else
            {
                manager._AddCount(saveKey, 1);
                total = manager._GetCount(saveKey);
            }
            GrantSteps(total);
            if (total >= Mathf.Max(1, requiredCount) && _Ready()) _Fire();
        }

        // 段：届いた段の称号のうち、まだ持っていないものをまとめて渡す（前提の条件は見る。一度だけ・待ち時間は見ない）。
        private void GrantSteps(int total)
        {
            int count = Mathf.Min(steps.Length, stepKeys.Length);
            if (count == 0 || !_Allowed()) return;
            int n = 0;
            for (int i = 0; i < count; i++)
                if (total >= steps[i] && manager._IdOf(stepKeys[i]) > 0 && !manager._HasKey(stepKeys[i])) n++;
            if (n == 0) return;
            int[] list = new int[n];
            int at = 0;
            for (int i = 0; i < count; i++)
                if (total >= steps[i] && manager._IdOf(stepKeys[i]) > 0 && !manager._HasKey(stepKeys[i])) list[at++] = manager._IdOf(stepKeys[i]);
            manager._GrantIdsWith(list, showPopup, sound);
        }
    }
}
