using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;
using VRC.SDK3.UdonNetworkCalling;

namespace WorldTitleGimmick
{
    // 称号ボード（仕様書 12-1）。称号の一覧・接続語・肩書きの枠・決定を1枚の板で行う。
    // ボタンには Udon を付けず、このボードの1つで受ける：ボタンのクリックは「自分の Button を無効にする」→「_Clicked を呼ぶ」の順で、
    // _Clicked が無効になったボタンを探して種類と番号を知る（UI ボタンの SendCustomEvent は引数を渡せないため）。
    // 板・ボタンは Editor の「Add Title System To Scene」が作る。同期しない。
    // 負荷（2026-10-28）：ほかの部品の関数を呼ぶのは重いので、一覧・枠の状態は変わったときにまとめて写し、描き直しはボードの中の値だけで行う。
    // 操作（2026-10-29、ユーザー指定）：先に称号か接続語を押して選ぶ → 入れられる枠だけ元の色で残り、ほかは灰色 → 枠を押すと入る。
    // 何も選ばずに中身のある枠を押すと空にする。
    [AddComponentMenu("World Title Gimmick/称号ボード（TitleBoard）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleBoard : UdonSharpBehaviour
    {
        public const int PressCard = 0;
        public const int PressConnector = 1;
        public const int PressSlot = 2;
        public const int PressPrev = 3;
        public const int PressNext = 4;
        public const int PressConnectorPrev = 5;
        public const int PressConnectorNext = 6;
        public const int PressApply = 7;
        public const int PressRevert = 8;
        public const int PressClear = 9;
        public const int PressNameplate = 10;
        public const int PressMyPlate = 11;
        public const int PressFilter = 12;
        public const int PressClose = 13;
        public const int PressLanguage = 14;
        // 絞り込み：0 全部 / 1 持っている / 2 まだ（2026-10-28）。
        public const int FilterAll = 0;
        public const int FilterOwned = 1;
        public const int FilterLocked = 2;

        public TitleManager manager;
        public Button[] pressButtons = new Button[0];
        public int[] pressKinds = new int[0];
        public int[] pressIndexes = new int[0];

        public Text[] cardTexts = new Text[0];
        public Image[] cardImages = new Image[0];
        public Text[] connectorTexts = new Text[0];
        public Image[] connectorImages = new Image[0];
        public GameObject[] slotRoots = new GameObject[0];
        public Text[] slotTexts = new Text[0];
        public Text[] slotTypeTexts = new Text[0];
        public Image[] slotImages = new Image[0];
        public Text titleText;
        public Text ownedText;
        public Text pageText;
        public Text descText;
        public Text previewText;
        public Text countText;
        public Text statusText;
        public Text nameplateText;
        [Tooltip("「自分の名札：見せる／見せない」のボタンの文字（空ならボタンなし）")]
        public Text myPlateText;
        [Tooltip("絞り込みのボタンの文字（全部・持っている・まだ の順。空ならボタンなし）")]
        public Text[] filterTexts = new Text[0];
        public Image[] filterImages = new Image[0];
        [Tooltip("「閉じる」で消す物（持ち運び用のボードの本体。空なら閉じるボタンなし）")]
        public GameObject closeRoot;
        public Text closeText;
        [Tooltip("言語のボタンの文字（日本語 ⇔ English。空ならボタンなし）")]
        public Text languageText;
        [Tooltip("決定のボタンの絵（決定していない変更があるとき色を変える。空なら変えない）")]
        public Image applyImage;
        public Text connectorsLabel;
        public Text plateLabel;
        [Tooltip("肩書きの区画の説明の行（空なら出さない）")]
        public Text plateHintText;
        [Tooltip("称号一覧の区画の見出し（空なら出さない）")]
        public Text listLabel;
        public Text applyText;
        public Text revertText;
        public Text clearText;
        public Text prevText;
        public Text nextText;

        public Color cardOwned = new Color(.20f, .27f, .42f, 1f);
        public Color cardLocked = new Color(.12f, .14f, .20f, 1f);
        public Color cardSelected = new Color(.85f, .62f, .15f, 1f);
        public Color textOwned = Color.white;
        public Color textLocked = new Color(.55f, .58f, .65f, 1f);
        // 肩書きの枠は、肩書きの区画（暖色）に合わせた色（2026-10-28）。
        public Color slotNormal = new Color(.32f, .24f, .11f, 1f);
        public Color slotFixed = new Color(.18f, .14f, .08f, 1f);
        [Tooltip("称号・接続語を選んでいる間、それを入れられない枠の色（灰色）")]
        public Color slotDimmed = new Color(.16f, .16f, .17f, 1f);
        [Tooltip("選んでいない絞り込みのボタンの色")]
        public Color filterNormal = new Color(.16f, .20f, .30f, 1f);
        [Tooltip("文字数が上限を超えたときの文字数の色")]
        public Color textWarn = new Color(1f, .45f, .40f, 1f);

        // 一覧（絞り込み後）の称号と接続語。語と持っているかもマネージャーから写しておく。
        private int[] listed = new int[0];
        private string[] listedWords = new string[0];
        private bool[] listedOwned = new bool[0];
        private int listedCount;
        private int[] connectors = new int[0];
        private string[] connectorWords = new string[0];
        private bool[] connectorOwned = new bool[0];
        private int connectorCount;
        // 枠の種類・解禁・固定の語（所持か言語が変わったときに写す）。
        private int[] slotTypeOf = new int[TitleManager.SlotCount];
        private bool[] slotOpenOf = new bool[TitleManager.SlotCount];
        private string[] slotFixedWord = new string[TitleManager.SlotCount];

        private int page;
        private int connectorPage;
        private int[] draft = new int[TitleManager.SlotCount];
        // 保存済みの肩書き（決定していない変更があるかを見比べる）。
        private int[] saved = new int[TitleManager.SlotCount];
        // 説明を出している札（持っていない札も押せば説明が出る）。
        private int selectedCard;
        // 枠に入れるために選んでいる語（0 なら選んでいない）と、それが接続語か。
        private int pickedId;
        private bool pickedConnector;
        private int seenOwnVersion = -1;
        private bool draftLoaded;
        private int seenReset;
        // マネージャーの _BoardVersion を最後に見たときの値（変わっていなければ何もしない）。
        private int seenBoardVersion = -1;

        private int seenLanguage = -1;
        private int filter = FilterAll;
        // 肩書きの決定（ほかのボードでの決定も）・名札の設定を、最後に見たときの値。
        private int seenSavedPlate = -1;
        private bool seenShow;
        private bool seenPublish;
        // 状態の文（文言の番号。-1 なら出さない）。言語が変わっても描き直せるように番号で持つ。
        private int status = -1;
        // 文字数・決定のボタンの元の色。
        private bool baseColorsTaken;
        private Color countBase = Color.white;
        private Color applyBase = Color.white;
        private Color[] slotTextBase = new Color[0];
        // 描き直しで毎回使う文言（言語が変わったときに読み直す）。
        private string uiLocked = "";
        private string uiSlotTitle = "";
        private string uiSlotConnector = "";
        private string uiFixed = "";
        private string uiChars = "";
        private string uiOwned = "";
        private string uiNameplateOn = "";
        private string uiNameplateOff = "";
        private string uiMyPlateOn = "";
        private string uiMyPlateOff = "";
        private string localName = "";
        // 肩書きの見本・枠の語・文字数（作りかけ・所持・言語が変わったときだけ作り直す。ページ送りなどでは使い回す）。
        private bool plateDirty = true;
        private string[] slotWords = new string[TitleManager.SlotCount];
        private string previewCache = "";
        private int previewLength;
        private int maxChars;

        private void Start()
        {
            if (manager == null) return;
            TakeBaseColors();
            ApplyTexts();
            TakeLocalName();
            // 初めて出したとき、OnEnable が Start より先に描いていることがある（隠れていた手帳のボード）。
            // そのときは「読み込み中」で上書きせず、版の番号を忘れて _Listen の知らせで描き直す（名前の入った見本にするため）。
            if (!draftLoaded) SetText(statusText, manager._Ui(TitleManager.TextLoading));
            seenBoardVersion = -1;
            // 所持・言語・やり直し・肩書きの決定が変わったらマネージャーが知らせる（毎フレームは見ない）。行動の値の知らせは受けない。
            manager._ListenFor(this, TitleManager.ListenTitles);
        }

        private void TakeLocalName()
        {
            if (localName.Length > 0) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            localName = Utilities.IsValid(local) ? local.displayName : "";
        }

        // 隠していたボード（手帳で出すボードなど）を出したときにも見直す（隠れている間の知らせは飛ばしている）。
        private void OnEnable() { _OnTitlesChanged(); }

        // 決まった文言（言語が変わったときにも描き直す）。
        private void ApplyTexts()
        {
            seenLanguage = manager._LanguageVersion();
            SetText(titleText, manager._Ui(TitleManager.TextBoardTitle));
            SetText(connectorsLabel, manager._Ui(TitleManager.TextConnectors));
            SetText(plateLabel, manager._Ui(TitleManager.TextPlate));
            SetText(plateHintText, manager._Ui(TitleManager.TextPlateHint));
            SetText(listLabel, manager._Ui(TitleManager.TextListTitle));
            SetText(applyText, manager._Ui(TitleManager.TextApply));
            SetText(revertText, manager._Ui(TitleManager.TextRevert));
            SetText(clearText, manager._Ui(TitleManager.TextClear));
            SetText(prevText, manager._Ui(TitleManager.TextPrev));
            SetText(nextText, manager._Ui(TitleManager.TextNext));
            if (filterTexts.Length > 0) SetText(filterTexts[0], manager._Ui(TitleManager.TextFilterAll));
            if (filterTexts.Length > 1) SetText(filterTexts[1], manager._Ui(TitleManager.TextFilterOwned));
            if (filterTexts.Length > 2) SetText(filterTexts[2], manager._Ui(TitleManager.TextFilterLocked));
            SetText(closeText, manager._Ui(TitleManager.TextClose));
            SetText(languageText, manager._Ui(TitleManager.TextLanguage));
            uiLocked = manager._Ui(TitleManager.TextLocked);
            uiSlotTitle = manager._Ui(TitleManager.TextSlotTitle);
            uiSlotConnector = manager._Ui(TitleManager.TextSlotConnector);
            uiFixed = manager._Ui(TitleManager.TextFixed);
            uiChars = manager._Ui(TitleManager.TextChars);
            uiOwned = manager._Ui(TitleManager.TextOwned);
            uiNameplateOn = manager._Ui(TitleManager.TextNameplateOn);
            uiNameplateOff = manager._Ui(TitleManager.TextNameplateOff);
            uiMyPlateOn = manager._Ui(TitleManager.TextMyPlateOn);
            uiMyPlateOff = manager._Ui(TitleManager.TextMyPlateOff);
        }

        private void TakeBaseColors()
        {
            if (baseColorsTaken) return;
            baseColorsTaken = true;
            if (countText != null) countBase = countText.color;
            if (applyImage != null) applyBase = applyImage.color;
            slotTextBase = new Color[slotTexts.Length];
            for (int i = 0; i < slotTexts.Length; i++) slotTextBase[i] = slotTexts[i] != null ? slotTexts[i].color : Color.white;
        }

        // マネージャーからの知らせ。ボードに関わること（所持・言語・やり直し・肩書きの決定・名札の設定）が変わったときだけ描き直す。
        // 行動の値（歩いた距離など）が変わっただけの知らせは、版の番号を1回聞くだけで終わる。
        public void _OnTitlesChanged()
        {
            if (manager == null || !gameObject.activeInHierarchy) return;
            int version = manager._BoardVersion();
            if (version < 0 || version == seenBoardVersion) return;
            seenBoardVersion = version;
            TakeBaseColors();
            TakeLocalName();
            // 所持・言語・肩書きのどれかが変わったので、肩書きの見本も作り直す。
            plateDirty = true;
            if (seenLanguage != manager._LanguageVersion())
            {
                ApplyTexts();
                seenOwnVersion = -1;
            }
            if (!draftLoaded)
            {
                draftLoaded = true;
                seenSavedPlate = manager._SavedPlateVersion();
                // 開く前にあったやり直しを、今起きたものと取り違えない。
                seenReset = manager._ResetVersion();
                draft = manager._Plate();
                status = TitleManager.TextPickWord;
            }
            if (seenReset != manager._ResetVersion())
            {
                seenReset = manager._ResetVersion();
                draft = manager._Plate();
                pickedId = 0;
                status = TitleManager.TextResetDone;
            }
            // 肩書きが決定された（このボードか、ほかのボードで）。古い作りかけで上書きしないよう読み直す。
            if (seenSavedPlate != manager._SavedPlateVersion())
            {
                seenSavedPlate = manager._SavedPlateVersion();
                draft = manager._Plate();
                pickedId = 0;
            }
            seenShow = manager._ShowNameplates();
            seenPublish = manager._PublishPlate();
            if (seenOwnVersion != manager._OwnVersion())
            {
                seenOwnVersion = manager._OwnVersion();
                // 外した称号・解禁されていない枠は、作りかけの肩書きからも外す。
                for (int i = 0; i < draft.Length; i++)
                    if (draft[i] > 0 && (!manager._Has(draft[i]) || !manager._SlotOpen(i))) draft[i] = 0;
                BuildLists();
            }
            // マネージャーが持っていない称号を肩書きから外すこともあるので、保存済みの肩書きは毎回読み直す。
            saved = manager._Plate();
            Redraw();
        }

        public void _Clicked()
        {
            int found = -1;
            for (int i = 0; i < pressButtons.Length; i++)
            {
                Button button = pressButtons[i];
                if (button == null || button.enabled) continue;
                button.enabled = true;
                if (found < 0) found = i;
            }
            if (found < 0 || NetworkCalling.InNetworkCall) return;
            _Press(pressKinds[found], pressIndexes[found]);
        }

        public void _Press(int kind, int index)
        {
            if (manager == null || !manager._Restored()) return;
            // 名札の設定・言語はマネージャーの知らせでこのボードも描き直すので、ここでは描き直さない。
            if (kind == PressNameplate) { manager._SetShowNameplates(!seenShow); return; }
            if (kind == PressMyPlate) { manager._SetPublishPlate(!seenPublish); return; }
            if (kind == PressLanguage) { manager._ToggleLanguage(); return; }
            if (kind == PressClose) { if (closeRoot != null) closeRoot.SetActive(false); return; }
            // 作りかけの肩書きが変わりうるボタンでは、肩書きの見本を作り直す（ページ送り・絞り込みでは作り直さない）。
            if (kind == PressCard || kind == PressConnector || kind == PressSlot || kind == PressApply || kind == PressRevert || kind == PressClear)
                plateDirty = true;
            if (kind == PressCard) PressTitle(page * cardTexts.Length + index);
            else if (kind == PressConnector) PressConnectorAt(connectorPage * connectorTexts.Length + index);
            else if (kind == PressSlot) PressSlotAt(index);
            // ページ送り・絞り込みでは、前の操作の文（「保存しました」など）を消す（未決定の変更・長すぎは Redraw が出す）。
            else if (kind == PressPrev) { page = Mathf.Max(0, page - 1); status = -1; }
            else if (kind == PressNext) { page = Mathf.Min(PageCount(listedCount, cardTexts.Length) - 1, page + 1); status = -1; }
            else if (kind == PressConnectorPrev) { connectorPage = Mathf.Max(0, connectorPage - 1); status = -1; }
            else if (kind == PressConnectorNext) { connectorPage = Mathf.Min(PageCount(connectorCount, connectorTexts.Length) - 1, connectorPage + 1); status = -1; }
            else if (kind == PressApply) Apply();
            else if (kind == PressRevert) { draft = manager._Plate(); pickedId = 0; status = -1; }
            else if (kind == PressClear) { for (int i = 0; i < draft.Length; i++) draft[i] = 0; pickedId = 0; status = -1; }
            else if (kind == PressFilter) { filter = index; page = 0; status = -1; BuildLists(); }
            Redraw();
        }

        // 称号と接続語は同じ扱い：押したら説明を出して選んだ色にし、持っていれば枠に入れる語として選ぶ。
        private void PressTitle(int at)
        {
            if (at < 0 || at >= listedCount) return;
            PressWord(listed[at], listedOwned[at], false);
        }

        private void PressConnectorAt(int at)
        {
            if (at < 0 || at >= connectorCount) return;
            PressWord(connectors[at], connectorOwned[at], true);
        }

        private void PressWord(int id, bool owned, bool connector)
        {
            selectedCard = id;
            // 選んでいる語をもう一度押すと、選ぶのをやめる（説明は残す）。
            if (pickedId == id && pickedConnector == connector) { pickedId = 0; status = TitleManager.TextPickWord; return; }
            pickedId = 0;
            if (!owned) { status = TitleManager.TextNotOwned; return; }
            pickedId = id;
            pickedConnector = connector;
            status = AnySlotTakes(connector) ? TitleManager.TextPickSlot : TitleManager.TextNoSlot;
        }

        private void PressSlotAt(int slot)
        {
            if (slot < 0 || slot >= TitleManager.SlotCount) return;
            if (!slotOpenOf[slot]) { status = TitleManager.TextSlotLocked; return; }
            if (!SlotEditable(slot)) { status = TitleManager.TextFixed; return; }
            // 語を選んでいなければ、中身のある枠は空にする。空の枠なら「先に語を選んでください」。
            if (pickedId <= 0)
            {
                if (draft[slot] > 0) { draft[slot] = 0; status = -1; }
                else status = TitleManager.TextPickWord;
                return;
            }
            if (!SlotTakes(slot, pickedConnector)) { status = TitleManager.TextNotAllowed; return; }
            // 同じ称号はほかの枠から移す（接続語は何度でも使える）。
            if (!pickedConnector)
                for (int i = 0; i < draft.Length; i++)
                    if (i != slot && draft[i] == pickedId) draft[i] = 0;
            draft[slot] = pickedId;
            // 入れたら語の選択を外す（続けて入れるときは語を押し直す）。文字数を超えたら Redraw が知らせる（決定はできない）。
            pickedId = 0;
            status = -1;
        }

        // 選んだ語（称号か接続語）を入れられる枠が1つでもあるか。
        private bool AnySlotTakes(bool connector)
        {
            for (int i = 0; i < TitleManager.SlotCount; i++)
                if (SlotEditable(i) && SlotTakes(i, connector)) return true;
            return false;
        }

        private bool SlotEditable(int slot)
        {
            int type = slotTypeOf[slot];
            return type != TitleManager.SlotFixed && type != TitleManager.SlotUnused && slotOpenOf[slot];
        }

        // その枠に称号（connector=false）か接続語を入れられるか（マネージャーの _SlotAllows と同じ決まり。一覧の語は使用中のものだけ）。
        private bool SlotTakes(int slot, bool connector)
        {
            if (slot < 0 || slot >= TitleManager.SlotCount || !slotOpenOf[slot]) return false;
            int type = slotTypeOf[slot];
            if (type == TitleManager.SlotBoth) return true;
            if (type == TitleManager.SlotTitle) return !connector;
            if (type == TitleManager.SlotConnector) return connector;
            return false;
        }

        private void Apply()
        {
            // 決定するとマネージャーの知らせで作りかけを読み直す（ほかのボードも同じ）。
            if (manager._SetPlate(draft))
            {
                draft = manager._Plate();
                saved = manager._Plate();
                pickedId = 0;
                status = TitleManager.TextSaved;
            }
            else status = TitleManager.TextTooLong;
        }

        // 作りかけが保存した肩書きと同じか。
        private bool SameAsSaved()
        {
            for (int i = 0; i < saved.Length; i++)
                if ((i < draft.Length ? draft[i] : 0) != saved[i]) return false;
            return true;
        }

        private int PageCount(int count, int per) { return per <= 0 ? 1 : Mathf.Max(1, (count + per - 1) / per); }

        // 一覧に出す称号（並び順）と接続語・枠の状態を写す。所持・言語・絞り込みが変わったときだけ。
        // マネージャーが並べた配列を受け取り、絞り込んで自分の配列に写す（行ごとにマネージャーを呼ばない）。
        private void BuildLists()
        {
            int[] ids = manager._BoardIds();
            string[] words = manager._BoardWords();
            bool[] owned = manager._BoardOwned();
            int titles = manager._BoardTitleCount();
            int total = titles + manager._BoardConnectorCount();
            if (listed.Length < titles)
            {
                listed = new int[titles];
                listedWords = new string[titles];
                listedOwned = new bool[titles];
            }
            if (connectors.Length < total - titles)
            {
                connectors = new int[total - titles];
                connectorWords = new string[total - titles];
                connectorOwned = new bool[total - titles];
            }
            listedCount = 0;
            bool selectedFound = false;
            // 選んでいる語は、絞り込みで見えなくなっても持っている限り選んだまま（外されたら選ぶのをやめる）。
            bool pickedOwned = false;
            for (int i = 0; i < titles; i++)
            {
                if (!pickedConnector && ids[i] == pickedId && owned[i]) pickedOwned = true;
                if (filter == FilterOwned && !owned[i]) continue;
                if (filter == FilterLocked && owned[i]) continue;
                listed[listedCount] = ids[i];
                listedWords[listedCount] = words[i];
                listedOwned[listedCount] = owned[i];
                if (ids[i] == selectedCard) selectedFound = true;
                listedCount++;
            }
            connectorCount = 0;
            for (int i = titles; i < total; i++)
            {
                connectors[connectorCount] = ids[i];
                connectorWords[connectorCount] = words[i];
                connectorOwned[connectorCount] = owned[i];
                if (ids[i] == selectedCard) selectedFound = true;
                if (pickedConnector && ids[i] == pickedId && owned[i]) pickedOwned = true;
                connectorCount++;
            }
            // 選んでいた札が一覧から消えたら（絞り込み・外したなど）、説明も消す。
            if (!selectedFound) selectedCard = 0;
            if (!pickedOwned) pickedId = 0;
            for (int i = 0; i < TitleManager.SlotCount; i++)
            {
                slotTypeOf[i] = manager._SlotType(i);
                slotOpenOf[i] = manager._SlotOpen(i);
                slotFixedWord[i] = slotTypeOf[i] == TitleManager.SlotFixed ? manager._Word(manager._SlotFixedId(i)) : "";
            }
            page = Mathf.Min(page, PageCount(listedCount, cardTexts.Length) - 1);
            connectorPage = Mathf.Min(connectorPage, PageCount(connectorCount, connectorTexts.Length) - 1);
            // 「獲得 n / m」の m は一覧に出す称号の数（持っている「一覧に出さない」も入る）。記録の称号は n・m とも数えない（_OwnedCount と同じ）。
            SetText(ownedText, uiOwned + " " + manager._BoardOwnedCount() + " / " + manager._BoardCountedTitles());
        }

        private void Redraw()
        {
            if (manager == null) return;
            for (int i = 0; i < cardTexts.Length; i++)
            {
                int at = page * cardTexts.Length + i;
                bool exists = at < listedCount;
                int id = exists ? listed[at] : 0;
                bool usable = exists && listedOwned[at];
                SetText(cardTexts[i], exists ? listedWords[at] : "");
                if (cardTexts[i] != null) cardTexts[i].color = usable ? textOwned : textLocked;
                if (i < cardImages.Length && cardImages[i] != null)
                {
                    cardImages[i].enabled = exists;
                    cardImages[i].color = id == selectedCard && exists ? cardSelected : usable ? cardOwned : cardLocked;
                }
            }
            SetText(pageText, (page + 1) + " / " + PageCount(listedCount, cardTexts.Length));
            for (int i = 0; i < filterImages.Length; i++) if (filterImages[i] != null) filterImages[i].color = i == filter ? cardSelected : filterNormal;
            for (int i = 0; i < connectorTexts.Length; i++)
            {
                int at = connectorPage * connectorTexts.Length + i;
                bool exists = at < connectorCount;
                int id = exists ? connectors[at] : 0;
                bool usable = exists && connectorOwned[at];
                SetText(connectorTexts[i], exists ? connectorWords[at] : "");
                if (connectorTexts[i] != null) connectorTexts[i].color = usable ? textOwned : textLocked;
                if (i < connectorImages.Length && connectorImages[i] != null)
                {
                    connectorImages[i].enabled = exists;
                    connectorImages[i].color = id == selectedCard && exists ? cardSelected : usable ? cardOwned : cardLocked;
                }
            }
            if (plateDirty) BuildPlatePreview();
            for (int i = 0; i < slotTexts.Length && i < TitleManager.SlotCount; i++)
            {
                int type = slotTypeOf[i];
                if (i < slotRoots.Length && slotRoots[i] != null && slotRoots[i].activeSelf != (type != TitleManager.SlotUnused))
                    slotRoots[i].SetActive(type != TitleManager.SlotUnused);
                bool open = slotOpenOf[i];
                SetText(slotTexts[i], slotWords[i]);
                string label = !open ? uiLocked
                    : type == TitleManager.SlotTitle ? uiSlotTitle
                    : type == TitleManager.SlotConnector ? uiSlotConnector
                    : type == TitleManager.SlotFixed ? uiFixed : "";
                if (i < slotTypeTexts.Length) SetText(slotTypeTexts[i], label);
                // 語を選んでいる間は、それを入れられない枠を灰色にする（入れられる枠だけ元の色で残る）。
                bool dimmed = pickedId > 0 && !(SlotEditable(i) && SlotTakes(i, pickedConnector));
                if (i < slotImages.Length && slotImages[i] != null)
                    slotImages[i].color = dimmed ? slotDimmed : !open || type == TitleManager.SlotFixed ? slotFixed : slotNormal;
                if (slotTexts[i] != null && i < slotTextBase.Length) slotTexts[i].color = dimmed ? textLocked : slotTextBase[i];
            }
            SetText(previewText, "［" + previewCache + "］ " + localName);
            bool tooLong = previewLength > maxChars;
            SetText(countText, uiChars + " " + previewLength + " / " + maxChars);
            if (countText != null) countText.color = tooLong ? textWarn : countBase;
            // 決定していない変更があれば、決定のボタンの色を変えて状態の文で知らせる。
            bool unsaved = !SameAsSaved();
            if (applyImage != null) applyImage.color = unsaved ? cardSelected : applyBase;
            int shown = status;
            if (shown < 0 && tooLong) shown = TitleManager.TextTooLong;
            else if (shown < 0 && unsaved) shown = TitleManager.TextUnsaved;
            SetText(statusText, shown < 0 ? "" : manager._Ui(shown));
            // 説明は言語が変わっても描き直せるように、選んだ札から毎回作る。
            SetText(descText, selectedCard > 0 ? manager._ShownWord(selectedCard) + "　" + manager._Desc(selectedCard) : "");
            SetText(nameplateText, seenShow ? uiNameplateOn : uiNameplateOff);
            SetText(myPlateText, seenPublish ? uiMyPlateOn : uiMyPlateOff);
        }

        // 枠の語・肩書きの見本・文字数を作る（マネージャーを呼ぶので、作りかけ・所持・言語が変わったときだけ）。
        private void BuildPlatePreview()
        {
            plateDirty = false;
            for (int i = 0; i < TitleManager.SlotCount; i++)
            {
                int type = slotTypeOf[i];
                slotWords[i] = !slotOpenOf[i] ? "" : type == TitleManager.SlotFixed ? slotFixedWord[i] : draft[i] > 0 ? manager._Word(draft[i]) : "";
            }
            previewCache = manager._PlateText(draft);
            previewLength = manager._VisibleLength(previewCache);
            maxChars = manager.maxPlateChars;
        }

        private void SetText(Text label, string text)
        {
            if (label != null && label.text != text) label.text = text;
        }
    }
}
