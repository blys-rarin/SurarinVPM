using UdonSharp;
using UnityEngine;

namespace WorldTitleGimmick
{
    // カウンター（仕様書 7-5）。回数を数えて保存し、「N回で称号A、M回で称号B」の段で称号を渡す。
    // 増やし方：Interact（interactable をオン）か、ほかの Udon から Add を SendCustomEvent する。
    // 表の条件「count:名前>=N」でも同じカウンターを使える。
    [AddComponentMenu("World Title Gimmick/称号カウンター（TitleCounter）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleCounter : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;
        [Tooltip("カウンターの名前（英数字）")]
        public string counterKey = "";
        public int addAmount = 1;
        [Tooltip("オンなら保存する（次に来たときも続きから）。オフなら、入室のたびに 0 から（同じ名前のカウンターは全部保存しなくなる）")]
        public bool saved = true;
        [Tooltip("オンなら Interact で増やす")]
        public bool interactable = true;
        public string interactText = "Push";
        [Tooltip("この回数に届いたら（stepKeys と同じ並び）")]
        public int[] steps = new int[0];
        [Tooltip("渡す称号（steps と同じ並び）")]
        public string[] stepKeys = new string[0];

        private void Start()
        {
            DisableInteractive = !interactable;
            InteractionText = interactText;
            if (!saved && manager != null) manager._MarkTemporaryCounter(counterKey);
            // ほかの部品（Counter Key）やコードが同じカウンターを足したときも段を見る（2026-10-28）。
            if (manager != null) manager._Listen(this);
        }

        public override void Interact() { if (interactable) Add(); }

        // ほかの Udon（Udon Graph など）から呼ぶ入口。
        public void Add()
        {
            if (manager == null || !manager._Restored() || string.IsNullOrEmpty(counterKey)) return;
            manager._AddCount(counterKey, addAmount);
            CheckSteps();
        }

        // マネージャーから：カウンター・所持などが変わった。
        public void _OnTitlesChanged() { CheckSteps(); }

        // 届いた段の称号のうち、まだ持っていないものをまとめて渡す（知らせは1回にまとめる）。
        private void CheckSteps()
        {
            if (manager == null || !manager._Restored() || string.IsNullOrEmpty(counterKey)) return;
            int total = manager._GetCount(counterKey);
            int n = 0;
            int count = Mathf.Min(steps.Length, stepKeys.Length);
            for (int i = 0; i < count; i++)
                if (total >= steps[i] && !manager._HasKey(stepKeys[i]) && manager._IdOf(stepKeys[i]) > 0) n++;
            if (n == 0) return;
            int[] ids = new int[n];
            int at = 0;
            for (int i = 0; i < count; i++)
                if (total >= steps[i] && !manager._HasKey(stepKeys[i]) && manager._IdOf(stepKeys[i]) > 0) ids[at++] = manager._IdOf(stepKeys[i]);
            manager._GrantIds(ids);
        }
    }
}
