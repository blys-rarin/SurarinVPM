using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // 獲得の知らせ（仕様書 12-3）。本人の画面にだけ、視界の下からせり上がる板で出す。同期しない。
    // 効果音は欄だけ。音源（clip）が空なら鳴らさない。
    // 2026-10-28：1つずつ出す形（_Enqueue）を足した。順番待ちに入れ、前の知らせが消えたら次を出す。称号の下に取得条件（desc）を出す。
    // 2026-10-28：渋滞の緩和（ユーザー指定「初回にジャンプや歩く距離などが一度に解禁されて通知が渋滞する」）。
    //   順番待ちがあるときは1つを busySeconds 秒にし、板を下げずに中身だけ替える。
    //   順番待ちが mergeAbove 個を超えたら、残りを1枚にまとめて出す（見出しに ×個数）。
    [AddComponentMenu("World Title Gimmick/獲得の知らせ（TitlePopup）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitlePopup : UdonSharpBehaviour
    {
        public GameObject root;
        public Text headline;
        public Text words;
        [Tooltip("称号の下に出す取得条件（空なら出さない）")]
        public Text desc;
        [Tooltip("鳴らす音を出す AudioSource（空なら鳴らさない）")]
        public AudioSource audioSource;
        [Tooltip("獲得の効果音（空なら鳴らさない）")]
        public AudioClip clip;
        public float showSeconds = 4f;
        [Tooltip("順番待ちがあるときの1つあたりの秒数（続けて出すときは板を下げない）")]
        public float busySeconds = 1.5f;
        [Tooltip("順番待ちがこの数を超えたら、残りを1枚にまとめて出す（0ならまとめない）")]
        public int mergeAbove = 2;
        public float slideSeconds = 0.3f;
        public float distance = 0.8f;
        public float downAngle = 20f;
        public float followRate = 4f;
        public float slideDistance = 0.25f;
        private float shownAt = -100f;
        private bool visible;
        private bool chained; // 続けて出した知らせ（せり上がりを飛ばす）
        private bool looping; // 出している間だけ、1フレームごとの処理を回す（Update は使わない）
        private Quaternion yaw = Quaternion.identity;

        // 順番待ち（1つずつ出す）。
        private string[] queueTitles = new string[32];
        private string[] queueWords = new string[32];
        private string[] queueDescs = new string[32];
        // 知らせごとの音（空なら clip）。部品の「効果音」（2026-10-28）。
        private AudioClip[] queueClips = new AudioClip[32];
        private int queueHead;
        private int queueCount;

        // 1つずつ出す：表示中なら順番待ちに入れ、前の知らせが消えたあとに出す。
        public void _Enqueue(string title, string word, string condition) { _EnqueueWith(title, word, condition, null); }

        // 音を指定して出す（sound が空なら、この部品の clip）。
        public void _EnqueueWith(string title, string word, string condition, AudioClip sound)
        {
            if (!visible) { Show(title, word, condition, sound); return; }
            if (queueCount >= queueTitles.Length) return;
            int at = (queueHead + queueCount) % queueTitles.Length;
            queueTitles[at] = title;
            queueWords[at] = word;
            queueDescs[at] = condition;
            queueClips[at] = sound;
            queueCount++;
        }

        // まとめて出す（今の知らせを差し替えて時間を延ばす）。説明の行は空にする。
        public void _ShowLines(string title, string text) { Show(title, text, "", null); }
        public void _ShowLinesWith(string title, string text, AudioClip sound) { Show(title, text, "", sound); }

        // 知らせを出さずに音だけ鳴らす（部品の「知らせを出す」がオフで、効果音があるとき）。
        public void _PlaySound(AudioClip sound)
        {
            if (audioSource != null && sound != null) audioSource.PlayOneShot(sound);
        }

        private void Show(string title, string text, string condition, AudioClip sound)
        {
            chained = visible;
            if (desc != null)
            {
                desc.text = condition;
                desc.gameObject.SetActive(!string.IsNullOrEmpty(condition));
            }
            if (words != null) words.text = text;
            if (headline != null) headline.text = title;
            shownAt = Time.time;
            if (!visible)
            {
                visible = true;
                yaw = HeadYaw();
                Place(0f);
                if (root != null) root.SetActive(true);
            }
            if (!looping)
            {
                looping = true;
                SendCustomEventDelayedFrames(nameof(_Frame), 1);
            }
            AudioClip play = sound != null ? sound : clip;
            if (audioSource != null && play != null) audioSource.PlayOneShot(play);
        }

        // 出している間だけ毎フレーム動く（消えたら止まる）。
        public void _Frame()
        {
            if (!visible) { looping = false; return; }
            SendCustomEventDelayedFrames(nameof(_Frame), 1);
            float t = Time.time - shownAt;
            float rising = chained ? 0f : slideSeconds;
            if (queueCount > 0 && t >= rising + Mathf.Min(showSeconds, busySeconds))
            {
                ShowNext();
                return;
            }
            float total = rising + showSeconds + slideSeconds;
            if (t >= total)
            {
                visible = false;
                chained = false;
                if (root != null) root.SetActive(false);
                return;
            }
            yaw = Quaternion.Slerp(yaw, HeadYaw(), Mathf.Clamp01(Time.deltaTime * followRate));
            float rise = slideSeconds <= 0f ? 1f : t < rising ? t / slideSeconds : t > total - slideSeconds ? (total - t) / slideSeconds : 1f;
            Place(Mathf.Clamp01(rise));
        }

        // 順番待ちの次を出す（板は上げたまま）。多すぎるときは残りを1枚にまとめる。
        private void ShowNext()
        {
            string title = queueTitles[queueHead];
            string word = queueWords[queueHead];
            string condition = queueDescs[queueHead];
            AudioClip sound = queueClips[queueHead];
            if (mergeAbove > 0 && queueCount > mergeAbove)
            {
                int count = queueCount;
                for (int i = 1; i < count; i++)
                {
                    int at = (queueHead + i) % queueTitles.Length;
                    if (queueTitles[at] == title) word += "　" + queueWords[at];
                }
                // 見出しの違う知らせ（やり直しの確認などは順番待ちに入らないが念のため）は、まとめずに捨てない。
                int kept = 0;
                for (int i = 1; i < count; i++)
                {
                    int from = (queueHead + i) % queueTitles.Length;
                    if (queueTitles[from] == title) continue;
                    int to = (queueHead + 1 + kept) % queueTitles.Length;
                    queueTitles[to] = queueTitles[from];
                    queueWords[to] = queueWords[from];
                    queueDescs[to] = queueDescs[from];
                    queueClips[to] = queueClips[from];
                    kept++;
                }
                queueHead = (queueHead + 1) % queueTitles.Length;
                queueCount = kept;
                Show(title + " ×" + (count - kept), word, "", sound);
                return;
            }
            queueHead = (queueHead + 1) % queueTitles.Length;
            queueCount--;
            Show(title, word, condition, sound);
        }

        private Quaternion HeadYaw()
        {
            VRCPlayerApi player = Networking.LocalPlayer;
            if (!Utilities.IsValid(player)) return yaw;
            VRCPlayerApi.TrackingData head = player.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            Vector3 forward = head.rotation * Vector3.forward;
            forward.y = 0f;
            if (forward.sqrMagnitude < 0.0001f) return yaw;
            return Quaternion.LookRotation(forward.normalized, Vector3.up);
        }

        // 板を頭の前・下へ置く。rise が0のときはさらに下（せり上がる前）。
        private void Place(float rise)
        {
            VRCPlayerApi player = Networking.LocalPlayer;
            if (!Utilities.IsValid(player)) return;
            VRCPlayerApi.TrackingData head = player.GetTrackingData(VRCPlayerApi.TrackingDataType.Head);
            float down = Mathf.Tan(downAngle * Mathf.Deg2Rad) * distance + (1f - rise) * slideDistance;
            Vector3 position = head.position + yaw * (Vector3.forward * distance) + Vector3.down * down;
            Vector3 away = position - head.position;
            if (away.sqrMagnitude < 0.0001f) away = yaw * Vector3.forward;
            transform.SetPositionAndRotation(position, Quaternion.LookRotation(away.normalized, Vector3.up));
        }
    }
}
