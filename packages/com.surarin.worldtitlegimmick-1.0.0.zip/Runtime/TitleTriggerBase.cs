using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

namespace WorldTitleGimmick
{
    // きっかけの部品（称号エリア・称号アクション・カウンター）に共通の「前提の条件」と「結果」（仕様書 7-1）。
    // どれも本人の端末だけで判定し、同期しない。称号はキーで持ち、インスペクターでは名前で選ぶ。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleTriggerBase : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;

        [Tooltip("全部持っているときだけ")]
        public string[] requiredKeys = new string[0];
        [Tooltip("どれか持っていたら動かない")]
        public string[] forbiddenKeys = new string[0];
        [Tooltip("どれかを装備しているときだけ（空なら見ない）")]
        public string[] equippedKeys = new string[0];
        [Tooltip("どれかを本人が手に持っているときだけ（Pickup の付いた物。空なら見ない）")]
        public GameObject[] heldObjects = new GameObject[0];
        [Tooltip("インスタンスの人数がこれ以上のときだけ（0 なら見ない）")]
        public int minPlayers = 0;
        [Tooltip("インスタンスの人数がこれ以下のときだけ（0 なら見ない）")]
        public int maxPlayers = 0;
        [Tooltip("この期間だけ（端末の日付。表の date: と同じ書き方：1025-1031 は毎年、20261025-20261031 はその年だけ。空なら見ない）")]
        public string period = "";
        // period を焼き込んだもの（Editor が書く）。0 なら期間を見ない。
        [HideInInspector] public int periodStart = 0;
        [HideInInspector] public int periodEnd = 0;
        [Tooltip("0 すべて / 1 VR だけ / 2 デスクトップだけ")]
        public int device = 0;

        [Tooltip("渡す称号")]
        public string[] grantKeys = new string[0];
        [Tooltip("明かす称号（ヒント）。持っていない称号の名前・取得条件を称号ボードで見えるようにする（保存する）")]
        public string[] revealKeys = new string[0];
        [Tooltip("明かすもの：0 名前と取得条件 / 1 名前だけ / 2 取得条件だけ")]
        public int revealWhat = 0;
        [Tooltip("明かしたとき、ヒントの知らせ（獲得の知らせの板）を出す")]
        public bool revealPopup = true;
        [Tooltip("足すカウンターの名前（空なら足さない）")]
        public string counterKey = "";
        public int counterAdd = 1;
        [Tooltip("イベントを送る先（Udon Graph など）。eventNames と同じ並び")]
        public UdonBehaviour[] eventTargets = new UdonBehaviour[0];
        public string[] eventNames = new string[0];
        [Tooltip("本人の画面で有効にする物")]
        public GameObject[] enableObjects = new GameObject[0];
        [Tooltip("本人の画面で無効にする物")]
        public GameObject[] disableObjects = new GameObject[0];
        [Tooltip("称号を渡したとき、獲得の知らせを出す（オフなら出さない。効果音は鳴らす）")]
        public bool showPopup = true;
        [Tooltip("称号を渡したときに鳴らす音（空なら獲得の知らせの音）")]
        public AudioClip sound;

        // 見出しは cooldownSeconds に付ける（once はインスペクターの「よく使う欄」に出るので、見出しがあると「回数」の欄と紛らわしい）。
        [Tooltip("一度結果を出したら、以後は何もしない")]
        public bool once = true;
        [Tooltip("次に反応するまでの秒数")]
        public float cooldownSeconds = 0.5f;

        // この部品をまとめている条件まとめ（TitleAllOf）。焼き込みが入れる。動いたら知らせる。
        [HideInInspector] public TitleAllOf[] reportTo = new TitleAllOf[0];

        private bool fired;
        // やり直し（TitleManager._ResetAll）のたびに「一度だけ」を戻す。
        private int seenReset;
        private float lastFire = -1000f;
        private int[] grantIds;
        private int[] revealIds;

        // 前提の条件を満たし、今動いてよいか。
        public bool _Ready()
        {
            if (manager == null || !manager._Restored()) return false;
            if (seenReset != manager._ResetVersion()) { seenReset = manager._ResetVersion(); fired = false; }
            if (once && fired) return false;
            if (Time.time - lastFire < cooldownSeconds) return false;
            return _Allowed();
        }

        // 前提の条件だけを見る（一度だけ・待ち時間は見ない。アクションの段で使う）。
        public bool _Allowed()
        {
            if (manager == null || !manager._Restored()) return false;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return false;
            if (device == 1 && !local.IsUserInVR()) return false;
            if (device == 2 && local.IsUserInVR()) return false;
            if (minPlayers > 0 && VRCPlayerApi.GetPlayerCount() < minPlayers) return false;
            if (maxPlayers > 0 && VRCPlayerApi.GetPlayerCount() > maxPlayers) return false;
            if (periodStart > 0 && !manager._InDateRange(periodStart, periodEnd)) return false;
            for (int i = 0; i < requiredKeys.Length; i++) if (!string.IsNullOrEmpty(requiredKeys[i]) && !manager._HasKey(requiredKeys[i])) return false;
            for (int i = 0; i < forbiddenKeys.Length; i++) if (!string.IsNullOrEmpty(forbiddenKeys[i]) && manager._HasKey(forbiddenKeys[i])) return false;
            if (equippedKeys.Length > 0)
            {
                bool any = false;
                for (int i = 0; i < equippedKeys.Length; i++) if (manager._EquippedKey(equippedKeys[i])) { any = true; break; }
                if (!any) return false;
            }
            if (heldObjects.Length > 0 && !HoldingAny(local)) return false;
            return true;
        }

        private bool HoldingAny(VRCPlayerApi local)
        {
            VRC_Pickup left = local.GetPickupInHand(VRC_Pickup.PickupHand.Left);
            VRC_Pickup right = local.GetPickupInHand(VRC_Pickup.PickupHand.Right);
            // VRC_Pickup の配列は Udon のプログラムの保存で壊れるので、物（GameObject）で比べる。
            GameObject leftObject = left != null ? left.gameObject : null;
            GameObject rightObject = right != null ? right.gameObject : null;
            for (int i = 0; i < heldObjects.Length; i++)
            {
                if (heldObjects[i] == null) continue;
                if (heldObjects[i] == leftObject || heldObjects[i] == rightObject) return true;
            }
            return false;
        }

        // 結果を出す（称号・カウンター・イベント・物の切り替え）。
        public void _Fire()
        {
            fired = true;
            lastFire = Time.time;
            if (grantIds == null || grantIds.Length != grantKeys.Length)
            {
                grantIds = new int[grantKeys.Length];
                for (int i = 0; i < grantKeys.Length; i++) grantIds[i] = manager._IdOf(grantKeys[i]);
            }
            if (grantIds.Length > 0) manager._GrantIdsWith(grantIds, showPopup, sound);
            if (revealIds == null || revealIds.Length != revealKeys.Length)
            {
                revealIds = new int[revealKeys.Length];
                for (int i = 0; i < revealKeys.Length; i++) revealIds[i] = manager._IdOf(revealKeys[i]);
            }
            if (revealIds.Length > 0)
            {
                int what = revealWhat == 1 ? TitleManager.RevealName : revealWhat == 2 ? TitleManager.RevealDesc : TitleManager.RevealName + TitleManager.RevealDesc;
                manager._RevealIds(revealIds, what, revealPopup);
            }
            if (!string.IsNullOrEmpty(counterKey)) manager._AddCount(counterKey, counterAdd);
            for (int i = 0; i < enableObjects.Length; i++) if (enableObjects[i] != null) enableObjects[i].SetActive(true);
            for (int i = 0; i < disableObjects.Length; i++) if (disableObjects[i] != null) disableObjects[i].SetActive(false);
            for (int i = 0; i < eventTargets.Length && i < eventNames.Length; i++)
                if (eventTargets[i] != null && !string.IsNullOrEmpty(eventNames[i])) eventTargets[i].SendCustomEvent(eventNames[i]);
            for (int i = 0; i < reportTo.Length; i++) if (reportTo[i] != null) reportTo[i]._PartFired(this);
        }

        // 一度だけの部品でも、渡す称号を全部持っていて、カウンター・イベントもなければ動かない。
        public bool _AllOwned()
        {
            if (manager == null || grantKeys.Length == 0) return false;
            if (!string.IsNullOrEmpty(counterKey) || eventTargets.Length > 0 || reportTo.Length > 0 || revealKeys.Length > 0) return false;
            for (int i = 0; i < grantKeys.Length; i++) if (!manager._HasKey(grantKeys[i])) return false;
            return true;
        }
    }
}
