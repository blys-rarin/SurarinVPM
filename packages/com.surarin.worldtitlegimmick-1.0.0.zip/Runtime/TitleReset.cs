using UdonSharp;
using UnityEngine;
using VRC.Udon;

namespace WorldTitleGimmick
{
    // やり直しのボタン（2026-10-28、ユーザー指定。遊び直し・テスト用）。Interact で押す。
    // 「全部やり直す」は所持・肩書き・カウンター・行動の値を消す。「指定の称号を外す」は選んだ称号だけを外す。
    // 押し間違いを防ぐため、confirmSeconds 以内にもう一度押したときだけ行う。本人の分だけで、同期しない。
    [AddComponentMenu("World Title Gimmick/やり直しのボタン（TitleReset）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleReset : UdonSharpBehaviour
    {
        public const int ModeAll = 0;
        public const int ModeKeys = 1;

        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;
        [Tooltip("0 全部やり直す / 1 指定の称号を外す")]
        public int mode = ModeAll;
        [Tooltip("mode が 1 のときに外す称号")]
        public string[] revokeKeys = new string[0];
        [Tooltip("この秒数以内にもう一度押したら行う（0 なら1回で行う）")]
        public float confirmSeconds = 3f;
        public string interactText = "Reset";
        [Tooltip("やり直したあとに有効にする物・無効にする物（扉を閉じ直すなど。本人の画面だけ）")]
        public GameObject[] enableObjects = new GameObject[0];
        public GameObject[] disableObjects = new GameObject[0];
        [Tooltip("やり直したあとにイベントを送る先（Udon Graph など）")]
        public UdonBehaviour[] eventTargets = new UdonBehaviour[0];
        public string eventName = "";

        private float firstPress = -100f;

        private void Start() { InteractionText = interactText; }

        public override void Interact() { Press(); }

        // ほかの Udon から呼ぶ入口（確認なしで行う）。
        public void Run()
        {
            if (manager == null || !manager._Restored()) return;
            if (mode == ModeAll) manager._ResetAll();
            else for (int i = 0; i < revokeKeys.Length; i++) manager._RevokeKey(revokeKeys[i]);
            for (int i = 0; i < enableObjects.Length; i++) if (enableObjects[i] != null) enableObjects[i].SetActive(true);
            for (int i = 0; i < disableObjects.Length; i++) if (disableObjects[i] != null) disableObjects[i].SetActive(false);
            if (!string.IsNullOrEmpty(eventName))
                for (int i = 0; i < eventTargets.Length; i++) if (eventTargets[i] != null) eventTargets[i].SendCustomEvent(eventName);
        }

        private void Press()
        {
            if (manager == null || !manager._Restored()) return;
            if (confirmSeconds > 0f && Time.time - firstPress > confirmSeconds)
            {
                firstPress = Time.time;
                if (manager.popup != null) manager.popup._ShowLines(manager._Ui(TitleManager.TextResetConfirm), "");
                return;
            }
            firstPress = -100f;
            Run();
            if (manager.popup != null && !OnlyInternal()) manager.popup._ShowLines(manager._Ui(TitleManager.TextResetDone), "");
        }

        // 外すのが「内部用」の称号だけなら、終わったことを知らせない（設定の切り替えなどに使うため）。
        private bool OnlyInternal()
        {
            if (mode != ModeKeys || revokeKeys.Length == 0) return false;
            for (int i = 0; i < revokeKeys.Length; i++) if (!manager._Internal(manager._IdOf(revokeKeys[i]))) return false;
            return true;
        }
    }
}
