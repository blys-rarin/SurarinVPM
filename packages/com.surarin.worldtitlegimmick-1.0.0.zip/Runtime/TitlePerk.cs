using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using VRC.Udon;

namespace WorldTitleGimmick
{
    // 称号の効果（2026-10-28、ユーザー指定）。称号を持っている・装備している本人の、移動の速さ・ジャンプ力・重力を変え、物を出す。
    // 見直すのは TitleManager から変わったと知らされたときだけ（毎フレームは見ない）。同期しない（速さなどは本人の体なので、ほかの人にもそのまま見える）。
    // 条件を満たさなくなったら、効果を出す前の値に戻す。効果の部品が複数あって同時に満たすときは、シーンで先に動き出した部品より
    // あとの部品の値になる（マネージャーの _RefreshPerks が決める）。
    [AddComponentMenu("World Title Gimmick/称号の効果（TitlePerk）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitlePerk : UdonSharpBehaviour
    {
        public const int ModeOwned = 0;
        public const int ModeEquipped = 1;

        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;

        public string[] titleKeys = new string[0];
        [Tooltip("0 持っている / 1 装備している")]
        public int mode = ModeEquipped;
        [Tooltip("オンなら全部、オフならどれか")]
        public bool matchAll = false;

        [Tooltip("オンなら移動の速さを変える")]
        public bool changeSpeed = true;
        [Tooltip("歩く速さ（VRChat の初期値 2）")]
        public float walkSpeed = 3f;
        [Tooltip("走る速さ（VRChat の初期値 4）")]
        public float runSpeed = 6f;
        [Tooltip("横歩きの速さ（VRChat の初期値 2）")]
        public float strafeSpeed = 3f;
        [Tooltip("オンならジャンプ力を変える")]
        public bool changeJump = false;
        [Tooltip("ジャンプ力（VRChat の初期値 3。0 で跳べない）")]
        public float jumpImpulse = 5f;
        [Tooltip("オンなら重力を変える")]
        public bool changeGravity = false;
        [Tooltip("重力の強さ（1 が普通。小さいほどふわっと跳ぶ）")]
        public float gravityStrength = 0.5f;
        [Tooltip("満たしたら本人の画面で出す物（満たさなくなったら消す）")]
        public GameObject[] objects = new GameObject[0];
        [Tooltip("満たしたら送るイベントの先と名前（満たさなくなったら unmetEvent）")]
        public UdonBehaviour[] eventTargets = new UdonBehaviour[0];
        public string metEvent = "";
        public string unmetEvent = "";

        private int state = -1;

        private void Start()
        {
            for (int i = 0; i < objects.Length; i++) if (objects[i] != null) objects[i].SetActive(false);
            if (manager == null) return;
            manager._RegisterPerk(this);
            manager._ListenFor(this, TitleManager.ListenTitles);
        }

        // 今、効果を出しているか（マネージャーが速さなどを決めるときに見る）。
        public bool _IsMet() { return state == 1; }

        public void _OnTitlesChanged() { Apply(Met()); }

        private bool Met()
        {
            if (manager == null || !manager._Restored()) return false;
            int used = 0;
            int hits = 0;
            for (int i = 0; i < titleKeys.Length; i++)
            {
                if (string.IsNullOrEmpty(titleKeys[i])) continue;
                used++;
                if (mode == ModeEquipped ? manager._EquippedKey(titleKeys[i]) : manager._HasKey(titleKeys[i])) hits++;
            }
            if (used == 0) return false;
            return matchAll ? hits == used : hits > 0;
        }

        private void Apply(bool met)
        {
            int next = met ? 1 : 0;
            if (next == state) return;
            bool first = state < 0;
            state = next;
            // 速さ・ジャンプ力・重力は、ほかの効果の部品と合わせてマネージャーが決める。
            if (manager != null && (met || !first)) manager._RefreshPerks();
            for (int i = 0; i < objects.Length; i++) if (objects[i] != null) objects[i].SetActive(met);
            if (first && !met) return;
            string name = met ? metEvent : unmetEvent;
            if (string.IsNullOrEmpty(name)) return;
            for (int i = 0; i < eventTargets.Length; i++) if (eventTargets[i] != null) eventTargets[i].SendCustomEvent(name);
        }
    }
}
