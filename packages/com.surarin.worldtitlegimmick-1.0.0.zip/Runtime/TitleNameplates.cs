using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // 頭上の名札（仕様書 12-2）。各端末が、ほかの人の頭の上に肩書きの板を置く。同期しない。
    // 肩書きは TitleManager が持つ値（各人の PlayerData から作ったもの）を refreshSeconds ごとに取り、位置は毎フレーム追う
    // （水平 farMeters より遠い人は 0.1 秒ごと）。自分の板は出さない。ON/OFF は見る人ごと（称号ボードのボタン）。
    // 2026-10-28：hideMeters より遠い人は出さない・出す人数の上限（近い人から）・文字と背景の色。人を選ぶのは refreshSeconds ごとだけ（毎フレームの処理は増やさない）。
    [AddComponentMenu("World Title Gimmick/頭上の名札（TitleNameplates）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleNameplates : UdonSharpBehaviour
    {
        public TitleManager manager;
        public GameObject[] roots = new GameObject[0];
        public Text[] labels = new Text[0];

        [Tooltip("頭からの高さ（m）")]
        public float height = 0.8f;
        [Tooltip("文字の色")]
        public Color textColor = Color.white;
        [Tooltip("板の背景の色（透明にするなら A を 0）")]
        public Color backColor = new Color(.06f, .08f, .13f, .85f);
        [Tooltip("1行に収まる文字数の目安。超えたら文字を小さくする")]
        public int oneLineChars = 16;
        [Tooltip("文字の大きさ")]
        public int normalSize = 56;
        [Tooltip("長い肩書きの文字の大きさ")]
        public int smallSize = 36;

        [Tooltip("これより遠い人（m）の名札は出さない（0 なら距離で消さない）")]
        public float hideMeters = 30f;
        [Tooltip("一度に出す名札の数の上限（近い人から。0 なら板の数まで）")]
        public int maxShown = 0;
        [Tooltip("誰に出すかを選び直す間隔（秒）")]
        public float refreshSeconds = 0.5f;
        [Tooltip("これより遠い人（m）の板は、位置を 0.1 秒ごとに追う（近い人は毎フレーム）")]
        public float farMeters = 15f;
        private const float FarFollowSeconds = .1f;
        private VRCPlayerApi[] players = new VRCPlayerApi[0];
        private float nextRefresh;
        private int[] shownIds = new int[0];
        // 出している板の数（0 なら毎フレームの追従を飛ばす）。
        private int shownCount;
        private VRCPlayerApi[] shownPlayers = new VRCPlayerApi[0];
        private string[] sources = new string[0];
        private float[] followAt = new float[0];
        // 選ぶときの作業用（近い順に並べた候補）。
        private VRCPlayerApi[] picked = new VRCPlayerApi[0];
        private float[] pickedDistance = new float[0];
        private string[] pickedPlate = new string[0];
        private bool[] slotTaken = new bool[0];
        private int[] slotOf = new int[0];

        private void Start()
        {
            int n = roots == null ? 0 : roots.Length;
            shownIds = new int[n];
            shownPlayers = new VRCPlayerApi[n];
            sources = new string[n];
            followAt = new float[n];
            picked = new VRCPlayerApi[n];
            pickedDistance = new float[n];
            pickedPlate = new string[n];
            slotTaken = new bool[n];
            slotOf = new int[n];
            for (int i = 0; i < n; i++)
            {
                if (roots[i] == null) continue;
                Image back = roots[i].GetComponent<Image>();
                if (back != null) back.color = backColor;
                if (i < labels.Length && labels[i] != null) labels[i].color = textColor;
                roots[i].SetActive(false);
            }
        }

        private void Update()
        {
            if (roots == null || roots.Length == 0 || manager == null) return;
            if (Time.time >= nextRefresh)
            {
                nextRefresh = Time.time + Mathf.Max(0.1f, refreshSeconds);
                Refresh();
            }
            // 出している板がなければ、頭の位置も取らずに抜ける（2026-10-29）。
            if (shownCount == 0) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            float now = Time.time;
            bool eyeRead = false;
            Vector3 eye = Vector3.zero;
            for (int i = 0; i < roots.Length; i++)
            {
                if (roots[i] == null || shownIds[i] <= 0 || now < followAt[i]) continue;
                if (!eyeRead) { eye = local.GetTrackingData(VRCPlayerApi.TrackingDataType.Head).position; eyeRead = true; }
                VRCPlayerApi player = shownPlayers[i];
                if (!Utilities.IsValid(player)) { Hide(i); continue; }
                Vector3 head = player.GetBonePosition(HumanBodyBones.Head);
                if (head == Vector3.zero) head = player.GetPosition() + Vector3.up * player.GetAvatarEyeHeightAsMeters();
                Vector3 position = head + Vector3.up * height;
                Vector3 away = position - eye;
                away.y = 0f;
                float distance = away.sqrMagnitude;
                if (distance < 0.0001f) away = Vector3.forward;
                roots[i].transform.SetPositionAndRotation(position, Quaternion.LookRotation(away.normalized, Vector3.up));
                followAt[i] = distance > farMeters * farMeters ? now + FarFollowSeconds : 0f;
            }
        }

        private void Hide(int index)
        {
            if (shownIds[index] > 0) shownCount--;
            shownIds[index] = 0;
            shownPlayers[index] = null;
            if (roots[index] != null && roots[index].activeSelf) roots[index].SetActive(false);
        }

        private void Refresh()
        {
            int count = VRCPlayerApi.GetPlayerCount();
            if (players.Length < count) players = new VRCPlayerApi[Mathf.Max(count, 8)];
            VRCPlayerApi.GetPlayers(players);
            int limit = maxShown > 0 ? Mathf.Min(maxShown, roots.Length) : roots.Length;
            int pickedCount = 0;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (manager._ShowNameplates() && Utilities.IsValid(local))
            {
                Vector3 me = local.GetPosition();
                float hide = hideMeters > 0f ? hideMeters * hideMeters : -1f;
                // 近い順に limit 人まで残す（遠い人は入れない）。
                for (int p = 0; p < count; p++)
                {
                    VRCPlayerApi player = players[p];
                    if (!Utilities.IsValid(player) || player.isLocal) continue;
                    float distance = (player.GetPosition() - me).sqrMagnitude;
                    if (hide > 0f && distance > hide) continue;
                    if (pickedCount == limit && distance >= pickedDistance[limit - 1]) continue;
                    string plate = manager._PlateOfPlayer(player.playerId);
                    if (string.IsNullOrEmpty(plate)) continue;
                    int at = pickedCount < limit ? pickedCount++ : limit - 1;
                    while (at > 0 && pickedDistance[at - 1] > distance)
                    {
                        picked[at] = picked[at - 1];
                        pickedDistance[at] = pickedDistance[at - 1];
                        pickedPlate[at] = pickedPlate[at - 1];
                        at--;
                    }
                    picked[at] = player;
                    pickedDistance[at] = distance;
                    pickedPlate[at] = plate;
                }
            }
            // 前から出していた人は同じ板のまま（板の持ち主が入れ替わると文字の作り直しとちらつきが出る）。新しい人は空いた板へ。
            for (int i = 0; i < roots.Length; i++) slotTaken[i] = false;
            for (int k = 0; k < pickedCount; k++)
            {
                slotOf[k] = -1;
                for (int i = 0; i < roots.Length; i++)
                    if (!slotTaken[i] && shownIds[i] == picked[k].playerId) { slotOf[k] = i; slotTaken[i] = true; break; }
            }
            for (int k = 0; k < pickedCount; k++)
            {
                if (slotOf[k] >= 0) continue;
                for (int i = 0; i < roots.Length; i++)
                    if (!slotTaken[i]) { slotOf[k] = i; slotTaken[i] = true; break; }
            }
            for (int i = 0; i < roots.Length; i++) if (!slotTaken[i]) Hide(i);
            for (int k = 0; k < pickedCount; k++)
            {
                int slot = slotOf[k];
                VRCPlayerApi player = picked[k];
                string plate = pickedPlate[k];
                if (shownIds[slot] != player.playerId) followAt[slot] = 0f;
                if (shownIds[slot] <= 0) shownCount++;
                shownIds[slot] = player.playerId;
                shownPlayers[slot] = player;
                if (slot < labels.Length && labels[slot] != null && sources[slot] != plate)
                {
                    sources[slot] = plate;
                    int size = manager._VisibleLength(plate) > oneLineChars ? smallSize : normalSize;
                    labels[slot].text = "<size=" + size + ">" + plate + "</size>";
                }
                if (roots[slot] != null && !roots[slot].activeSelf) roots[slot].SetActive(true);
            }
        }
    }
}
