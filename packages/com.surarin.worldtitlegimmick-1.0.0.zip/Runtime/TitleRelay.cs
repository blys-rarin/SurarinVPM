using UdonSharp;
using UnityEngine;
using VRC.Udon;

namespace WorldTitleGimmick
{
    // 称号イベント中継（2026-10-28）。本人が称号をもらった・外れた・装備した・装備を外した・肩書きを決定したときに、
    // ほかの Udon（Udon Graph など）へイベントを送る。見直すのは TitleManager から変わったと知らされたときだけ。同期しない。
    // 入室したとき（復元）に持っていた称号では送らない（「入室時にも送る」をオンにすると送る）。
    [AddComponentMenu("World Title Gimmick/称号イベント中継（TitleRelay）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleRelay : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;

        [Tooltip("この称号が変わったときに送る（空なら、もらったとき・肩書きのイベントだけ、どの称号でも送る）")]
        public string[] watchKeys = new string[0];

        public UdonBehaviour[] eventTargets = new UdonBehaviour[0];
        [Tooltip("送る前に、送り先のこの名前の変数（string）に称号のキーを入れる（例：titleKey。送り先にその変数を作っておく。空なら入れない）")]
        public string keyVariable = "";

        [Tooltip("称号をもらったとき")]
        public string grantedEvent = "OnTitleGranted";
        [Tooltip("称号が外れたとき（やり直し・外す）")]
        public string revokedEvent = "";
        [Tooltip("称号を肩書きに入れて決定したとき")]
        public string equippedEvent = "";
        [Tooltip("称号を肩書きから外して決定したとき")]
        public string unequippedEvent = "";
        [Tooltip("肩書きを決定して、並びが変わったとき（キーは空）")]
        public string plateChangedEvent = "";

        [Tooltip("オンなら、入室したときに持っている・装備している称号でも送る")]
        public bool fireOnJoin = false;

        private bool started;
        private bool[] had = new bool[0];
        private bool[] wore = new bool[0];
        private int[] lastPlate = new int[0];
        private int seenOwn = -1;
        // 送るイベントをためておく（見直しのループの中では送らない。送り先が称号を渡すと、ここへ入れ子で戻ってくるため）。
        private string[] queueEvents = new string[64];
        private string[] queueKeys = new string[64];
        private int queueCount;
        private bool sending;
        private bool again;

        private void Start()
        {
            if (manager != null) manager._ListenFor(this, TitleManager.ListenTitles);
        }

        public void _OnTitlesChanged()
        {
            // 送っている途中に呼ばれたら、送り終わってからもう一度見る。
            if (sending) { again = true; return; }
            Check();
            sending = true;
            int guard = 0;
            while (queueCount > 0 && guard < 8)
            {
                guard++;
                int count = queueCount;
                queueCount = 0;
                for (int q = 0; q < count; q++) Send(queueEvents[q], queueKeys[q]);
                if (again) { again = false; Check(); }
            }
            sending = false;
        }

        private void Check()
        {
            if (manager == null || !manager._Restored()) return;
            // 見る称号：決めた称号だけ、なければ表の全部の行。
            int n = watchKeys.Length > 0 ? watchKeys.Length : manager._TableCount();
            if (had.Length != n) { had = new bool[n]; wore = new bool[n]; started = false; }
            bool first = !started;
            started = true;
            bool fire = !first || fireOnJoin;
            int ownVersion = manager._OwnVersion();
            bool ownChanged = ownVersion != seenOwn;
            seenOwn = ownVersion;
            int[] plate = manager._Plate();
            int[] before = lastPlate;
            bool plateChanged = before.Length != plate.Length;
            if (!plateChanged) for (int i = 0; i < plate.Length; i++) if (plate[i] != before[i]) { plateChanged = true; break; }
            lastPlate = plate;
            // 所持も肩書きも変わっていなければ見ない（カウンター・行動の値だけが変わったとき）。
            if (!first && !ownChanged && !plateChanged) return;
            if (watchKeys.Length > 0) CheckWatched(n, first, fire, ownChanged, plate);
            else if (first || ownChanged) CheckTable(n, first, fire, plate);
            else CheckPlateRows(n, fire, plate, before);
            if (plateChanged && !first) Queue(plateChangedEvent, "");
        }

        // 決めた称号だけを見る（数が少ないので、1つずつマネージャーに聞く）。
        private void CheckWatched(int n, bool first, bool fire, bool ownChanged, int[] plate)
        {
            for (int i = 0; i < n; i++)
            {
                int id = manager._IdOf(watchKeys[i]);
                if (id <= 0) continue;
                bool has = ownChanged || first ? manager._Has(id) : had[i];
                Step(i, watchKeys[i], has, InPlate(plate, id), first, fire);
            }
        }

        // 表の全部の行を見る（所持が変わったとき）。所持はマネージャーから1回でまとめて受け取る（行ごとに呼ぶと重いため。2026-10-29）。
        private void CheckTable(int n, bool first, bool fire, int[] plate)
        {
            int[] tableIds = manager.ids;
            string[] tableKeys = manager.keys;
            bool[] has = manager._HasRows();
            bool[] free = manager._FreeConnectorRows();
            int count = Mathf.Min(n, Mathf.Min(tableIds.Length, Mathf.Min(has.Length, free.Length)));
            for (int i = 0; i < count; i++)
            {
                int id = tableIds[i];
                // 最初から使える接続語は「もらった」に数えない。
                if (id <= 0 || free[i]) continue;
                Step(i, i < tableKeys.Length ? tableKeys[i] : "", has[i], InPlate(plate, id), first, fire);
            }
        }

        // 肩書きだけが変わったとき：前と今の肩書きに入っている称号の行だけを見る（所持は変わっていない。2026-10-29）。
        // 送る順は表の行の順（全部の行を回っていたときと同じ）。
        private void CheckPlateRows(int n, bool fire, int[] plate, int[] before)
        {
            int[] tableIds = manager.ids;
            string[] tableKeys = manager.keys;
            bool[] free = manager._FreeConnectorRows();
            int[] rows = new int[plate.Length + before.Length];
            int count = 0;
            for (int k = 0; k < rows.Length; k++)
            {
                int id = k < plate.Length ? plate[k] : before[k - plate.Length];
                if (id <= 0) continue;
                int row = manager._Row(id);
                if (row < 0 || row >= n || row >= tableIds.Length || row >= free.Length) continue;
                // 行の順に並べて入れる（同じ行は1回だけ）。
                int at = count;
                bool same = false;
                while (at > 0 && rows[at - 1] >= row)
                {
                    if (rows[at - 1] == row) { same = true; break; }
                    at--;
                }
                if (same) continue;
                for (int m = count; m > at; m--) rows[m] = rows[m - 1];
                rows[at] = row;
                count++;
            }
            for (int k = 0; k < count; k++)
            {
                int i = rows[k];
                if (free[i]) continue;
                Step(i, i < tableKeys.Length ? tableKeys[i] : "", had[i], InPlate(plate, tableIds[i]), false, fire);
            }
        }

        private void Step(int i, string key, bool has, bool equipped, bool first, bool fire)
        {
            if (fire && has && !had[i]) Queue(grantedEvent, key);
            if (fire && !has && had[i] && !first) Queue(revokedEvent, key);
            if (fire && equipped && !wore[i]) Queue(equippedEvent, key);
            if (fire && !equipped && wore[i] && !first) Queue(unequippedEvent, key);
            had[i] = has;
            wore[i] = equipped;
        }

        private bool InPlate(int[] plate, int id)
        {
            if (id <= 0) return false;
            for (int i = 0; i < plate.Length; i++) if (plate[i] == id) return true;
            return false;
        }

        private void Queue(string eventName, string key)
        {
            if (string.IsNullOrEmpty(eventName) || queueCount >= queueEvents.Length) return;
            queueEvents[queueCount] = eventName;
            queueKeys[queueCount] = key;
            queueCount++;
        }

        private void Send(string eventName, string key)
        {
            for (int t = 0; t < eventTargets.Length; t++)
            {
                UdonBehaviour target = eventTargets[t];
                if (target == null) continue;
                if (!string.IsNullOrEmpty(keyVariable)) target.SetProgramVariable(keyVariable, key);
                target.SendCustomEvent(eventName);
            }
        }
    }
}
