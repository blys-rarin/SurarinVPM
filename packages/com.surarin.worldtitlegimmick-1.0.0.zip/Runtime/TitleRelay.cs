using UdonSharp;
using UnityEngine;
using VRC.Udon;

namespace WorldTitleGimmick
{
    // 称号イベント中継（2026-10-28）。本人が称号をもらった・外れた・装備した・装備を外した・肩書きを決定したときに、
    // ほかの Udon（Udon Graph など）へイベントを送る。見直すのは TitleManager から変わったと知らされたときだけ。同期しない。
    // 入室したとき（復元）に持っていた称号では送らない（「入室時にも送る」をオンにすると送る）。
    [AddComponentMenu("World Title Gimmick/称号イベント中継（TitleRelay）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleRelay : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;

        [Tooltip("この称号が変わったときに送る（空なら、もらったとき・肩書きのイベントだけ、どの称号でも送る）")]
        public string[] watchKeys = new string[0];

        public UdonBehaviour[] eventTargets = new UdonBehaviour[0];
        [Tooltip("送る前に、送り先のこの名前の変数（string）に称号のキーを入れる（例：titleKey。送り先にその変数を作っておく。空なら入れない）")]
        public string keyVariable = "";

        [Tooltip("称号をもらったとき")]
        public string grantedEvent = "OnTitleGranted";
        [Tooltip("称号が外れたとき（やり直し・外す）")]
        public string revokedEvent = "";
        [Tooltip("称号を肩書きに入れて決定したとき")]
        public string equippedEvent = "";
        [Tooltip("称号を肩書きから外して決定したとき")]
        public string unequippedEvent = "";
        [Tooltip("肩書きを決定して、並びが変わったとき（キーは空）")]
        public string plateChangedEvent = "";

        [Tooltip("オンなら、入室したときに持っている・装備している称号でも送る")]
        public bool fireOnJoin = false;

        private bool started;
        private bool[] had = new bool[0];
        private bool[] wore = new bool[0];
        private int[] lastPlate = new int[0];
        private int seenOwn = -1;
        // 送るイベントをためておく（見直しのループの中では送らない。送り先が称号を渡すと、ここへ入れ子で戻ってくるため）。
        private string[] queueEvents = new string[64];
        private string[] queueKeys = new string[64];
        private int queueCount;
        private bool sending;
        private bool again;

        private void Start()
        {
            if (manager != null) manager._Listen(this);
        }

        public void _OnTitlesChanged()
        {
            // 送っている途中に呼ばれたら、送り終わってからもう一度見る。
            if (sending) { again = true; return; }
            Check();
            sending = true;
            int guard = 0;
            while (queueCount > 0 && guard < 8)
            {
                guard++;
                int count = queueCount;
                queueCount = 0;
                for (int q = 0; q < count; q++) Send(queueEvents[q], queueKeys[q]);
                if (again) { again = false; Check(); }
            }
            sending = false;
        }

        private void Check()
        {
            if (manager == null || !manager._Restored()) return;
            // 見る称号：決めた称号だけ、なければ表の全部の行。
            int n = watchKeys.Length > 0 ? watchKeys.Length : manager._TableCount();
            if (had.Length != n) { had = new bool[n]; wore = new bool[n]; started = false; }
            bool first = !started;
            started = true;
            bool fire = !first || fireOnJoin;
            int ownVersion = manager._OwnVersion();
            bool ownChanged = ownVersion != seenOwn;
            seenOwn = ownVersion;
            int[] plate = manager._Plate();
            bool plateChanged = lastPlate.Length != plate.Length;
            if (!plateChanged) for (int i = 0; i < plate.Length; i++) if (plate[i] != lastPlate[i]) { plateChanged = true; break; }
            lastPlate = plate;
            // 所持も肩書きも変わっていなければ見ない（カウンター・行動の値だけが変わったとき）。
            if (!first && !ownChanged && !plateChanged) return;
            for (int i = 0; i < n; i++)
            {
                int id = watchKeys.Length > 0 ? manager._IdOf(watchKeys[i]) : manager._IdAt(i);
                if (id <= 0) continue;
                // 最初から使える接続語は「もらった」に数えない。
                if (watchKeys.Length == 0 && manager._IsConnector(id) && !manager._IsLockedConnector(id)) continue;
                string key = watchKeys.Length > 0 ? watchKeys[i] : manager.keys[i];
                bool has = ownChanged || first ? manager._Has(id) : had[i];
                bool equipped = manager._Equipped(id);
                if (fire && has && !had[i]) Queue(grantedEvent, key);
                if (fire && !has && had[i] && !first) Queue(revokedEvent, key);
                if (fire && equipped && !wore[i]) Queue(equippedEvent, key);
                if (fire && !equipped && wore[i] && !first) Queue(unequippedEvent, key);
                had[i] = has;
                wore[i] = equipped;
            }
            if (plateChanged && !first) Queue(plateChangedEvent, "");
        }

        private void Queue(string eventName, string key)
        {
            if (string.IsNullOrEmpty(eventName) || queueCount >= queueEvents.Length) return;
            queueEvents[queueCount] = eventName;
            queueKeys[queueCount] = key;
            queueCount++;
        }

        private void Send(string eventName, string key)
        {
            for (int t = 0; t < eventTargets.Length; t++)
            {
                UdonBehaviour target = eventTargets[t];
                if (target == null) continue;
                if (!string.IsNullOrEmpty(keyVariable)) target.SetProgramVariable(keyVariable, key);
                target.SendCustomEvent(eventName);
            }
        }
    }
}
