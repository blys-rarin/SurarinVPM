using UdonSharp;
using UnityEngine;

namespace WorldTitleGimmick
{
    // 条件まとめ（仕様書 7-6、2026-10-28）。並べた部品（称号エリア・称号アクションなど）が全部「動いた」ら、結果（渡す称号など）を出す。
    // 部品は動いたとき（_Fire）にこの部品へ知らせる（どの部品に知らせるかは焼き込みが入れる）。毎フレームは見ない。同期しない。
    // まとめ方：「これまでに全部」なら、動いた部品をカウンター（<保存の名前>.<番号>）に保存し、別の日に分けて満たしてもよい。
    // 「この入室で全部」なら、入室ごとに数え直す。
    [AddComponentMenu("World Title Gimmick/条件まとめ（TitleAllOf）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleAllOf : TitleTriggerBase
    {
        [Tooltip("全部が動いたら結果を出す部品（称号エリア・称号アクションなど）")]
        public TitleTriggerBase[] parts = new TitleTriggerBase[0];
        [Tooltip("オンなら「これまでに全部」（動いた部品を保存する）。オフなら「この入室で全部」")]
        public bool saved = true;
        [Tooltip("保存の名前（英数字。saved のとき要る。カウンター <名前>.1 〜 として保存する）")]
        public string saveKey = "";

        private bool[] doneNow = new bool[0];

        // 部品から：動いた。
        public void _PartFired(TitleTriggerBase part)
        {
            if (manager == null || !manager._Restored() || part == null) return;
            if (doneNow.Length != parts.Length) doneNow = new bool[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] != part) continue;
                doneNow[i] = true;
                if (saved && !string.IsNullOrEmpty(saveKey) && manager._GetCount(PartKey(i)) == 0) manager._AddCount(PartKey(i), 1);
            }
            if (AllDone() && _Ready()) _Fire();
        }

        private string PartKey(int index) { return saveKey + "." + (index + 1); }

        private bool AllDone()
        {
            if (parts.Length == 0) return false;
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i] == null) continue;
                bool done = i < doneNow.Length && doneNow[i];
                if (!done && saved && !string.IsNullOrEmpty(saveKey)) done = manager._GetCount(PartKey(i)) > 0;
                if (!done) return false;
            }
            return true;
        }

        // 何個そろったか（看板などに出すとき用）。
        public int _DoneCount()
        {
            if (manager == null || !manager._Restored()) return 0;
            int count = 0;
            for (int i = 0; i < parts.Length; i++)
            {
                bool done = i < doneNow.Length && doneNow[i];
                if (!done && saved && !string.IsNullOrEmpty(saveKey)) done = manager._GetCount(PartKey(i)) > 0;
                if (done) count++;
            }
            return count;
        }
    }
}
