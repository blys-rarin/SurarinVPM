using UdonSharp;
using UnityEngine;
using VRC.SDK3.Data;
using VRC.SDK3.Persistence;
using VRC.SDKBase;
using VRC.Udon.Common;

namespace WorldTitleGimmick
{
    // ワールド内称号ギミックの本体（シーンに1つ）。使い方は Documentation の説明書（00〜03）。
    // 称号の表は Editor の焼き込み（Play・ビルドの前に自動。マネージャーの「今すぐ焼き込む」でも）が配列へ書き込む。
    // 所持・肩書き・カウンター・行動の値・記録は本人の PlayerData に保存し、他の人の肩書きはその人の PlayerData から読む。同期は使わない。
    // 入れないもの：黄色（表の「黄色の条件」の列はあっても使わない）。
    // 明かす（2026-10-28）：持っていない称号の名前・取得条件を、ほかの人の装備やヒントの部品で見えるようにする（本人の PlayerData に保存）。
    [AddComponentMenu("World Title Gimmick/称号マネージャー（TitleManager）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleManager : UdonSharpBehaviour
    {
        // ---- 設定（インスペクター） ----
        [Header("全体")]
        [Tooltip("0 日本語 / 1 English / 2 自動（見る人の VRChat の言語。日本語なら日本語、ほかは英語）")]
        public int language = 2;
        [Tooltip("PlayerData のキーの頭。ほかのアセットとぶつからない名前にする")]
        public string keyPrefix = "wtg.";
        [Tooltip("称号の表のアセット（TitleDatabase）の GUID。インスペクターで表を選ぶと入る")]
        public string databaseGuid = "";

        [Header("肩書き")]
        [Tooltip("見える文字の上限（色のタグを除く）")]
        public int maxPlateChars = 50;
        [Tooltip("枠ごとの種類。0 どちらも / 1 称号だけ / 2 接続語だけ / 3 固定の語 / 4 使わない")]
        public int[] slotTypes = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        [Tooltip("固定の語の枠に出す接続語のキー（種類が3の枠だけ使う）")]
        public string[] slotFixedKeys = new string[10];
        [Tooltip("枠ごとの解禁の称号のキー（空なら最初から使える）。その称号を持つまで、その枠はボードで使えず、肩書きにも出ない")]
        public string[] slotUnlockKeys = new string[10];

        [Header("表示")]
        public TitlePopup popup;
        [Tooltip("獲得の知らせ：0 1つずつ出す（称号の下に取得条件）/ 1 まとめて出す")]
        public int popupMode = 0;
        [Tooltip("頭上の名札を出すか（見る人の最初の設定。見る人が切り替えたら保存する）")]
        public bool showNameplatesDefault = true;
        [Tooltip("称号の手帳（TitleNotebook）で、その場に称号ボードを出せるようにするか。オフなら手帳を消す")]
        public bool usePortableBoard = true;
        [Tooltip("同じインスタンスのほかの人が装備している称号を明かすか。0 明かさない / 1 名前だけ / 2 名前と取得条件")]
        public int revealEquipped = 0;

        [Header("行動の値")]
        [Tooltip("歩いた距離で、1秒にこれより大きく動いたら（テレポート）数えない（m）")]
        public float teleportMeters = 20f;
        [Tooltip("ほかの人の近くにいた時間（near_min）で、近いとみなす距離（m）")]
        public float nearMeters = 2f;
        [Tooltip("称号を持つ人と会った回数（met_title_holders）で数える称号のキー。どれか1つを持つ人と会うと1回（1人につき入室1回）")]
        public string[] holderKeys = new string[0];
        [Tooltip("作者などと会った回数（met_creator）で数える人の表示名。表示名は変えられるので、景品などには使わない")]
        public string[] creatorNames = new string[0];
        [Tooltip("手渡しで受け取った回数（received_items）：称号アクションの物を掴んだとき、ほかの人の手がこの距離（m）以内にあれば手渡しとみなす")]
        public float handoffMeters = .4f;

        [Header("テスト")]
        [Tooltip("オンなら、Editor の Play（ClientSim）で始めたとき全部の称号を持つ（保存しない）。アップロードしたワールドでは効かない")]
        public bool testAllOwned = false;
        // 焼き込みが書く：Editor の Play の前だけ testAllOwned を写し、ビルドの前は必ず false。
        [HideInInspector] public bool editorAllOwned = false;

        // ---- 焼き込み（Editor が書く。手で書き換えない） ----
        [HideInInspector] public int[] ids = new int[0];
        [HideInInspector] public string[] keys = new string[0];
        // 0 通常 / 1 接続語
        [HideInInspector] public int[] kinds = new int[0];
        // 今の言語の語・説明（Start と言語が変わったときに、下の日本語・英語のどちらかを入れる）。
        [HideInInspector] public string[] words = new string[0];
        [HideInInspector] public string[] descBefore = new string[0];
        [HideInInspector] public string[] descAfter = new string[0];
        // 日本語・英語の両方（2026-10-28：見る人の言語で切り替えるため、両方を焼き込む）。
        [HideInInspector] public string[] wordsJa = new string[0];
        [HideInInspector] public string[] wordsEn = new string[0];
        [HideInInspector] public string[] descBeforeJa = new string[0];
        [HideInInspector] public string[] descBeforeEn = new string[0];
        [HideInInspector] public string[] descAfterJa = new string[0];
        [HideInInspector] public string[] descAfterEn = new string[0];
        [HideInInspector] public string[] uiTextsJa = new string[0];
        [HideInInspector] public string[] uiTextsEn = new string[0];
        // 0 見せる / 1 隠す（？？？）/ 2 一覧に出さない
        [HideInInspector] public int[] nameModes = new int[0];
        [HideInInspector] public bool[] actives = new bool[0];
        // 接続語のうち、解禁するまで使えないもの（true）。通常の称号では使わない。
        [HideInInspector] public bool[] locks = new bool[0];
        [HideInInspector] public int[] orders = new int[0];
        // 条件：0 なし / 1 count / 2 stat / 3 owned / 4 all / 7 date（5・6 は次の版の visit・stay に空けておく）
        [HideInInspector] public int[] condTypes = new int[0];
        [HideInInspector] public string[] condKeys = new string[0];
        [HideInInspector] public int[] condStats = new int[0];
        [HideInInspector] public int[] condValues = new int[0];
        // date の条件の終わりの日（condValues が始まりの日）。MMDD なら毎年、YYYYMMDD ならその年だけ。
        [HideInInspector] public int[] condEnds = new int[0];
        // all の条件の称号ID（行ごとに condAllStart から condAllCount 個）。
        [HideInInspector] public int[] condAllStart = new int[0];
        [HideInInspector] public int[] condAllCount = new int[0];
        [HideInInspector] public int[] condAllIds = new int[0];
        // 記録の称号（行ごと。記録でない行は空・0）。保存のキーは頭・版まで付けた完全なキー。
        [HideInInspector] public string[] recordSaveKeys = new string[0];
        [HideInInspector] public int[] recordFormats = new int[0];
        [HideInInspector] public int[] recordDigits = new int[0];
        [HideInInspector] public bool[] recordLower = new bool[0];
        [HideInInspector] public string[] recordSuffixJa = new string[0];
        [HideInInspector] public string[] recordSuffixEn = new string[0];
        // 固定の語の枠のID（slotFixedKeys から焼き込む。0 なら固定の語なし）。
        [HideInInspector] public int[] slotFixedIds = new int[10];
        // 枠の解禁の称号のID（slotUnlockKeys から焼き込む。0 なら最初から使える）。
        [HideInInspector] public int[] slotUnlockIds = new int[10];
        // やり直し（_ResetAll）で 0 に戻すカウンターの名前（表の条件・部品で使っているもの。焼き込みで集める）。
        [HideInInspector] public string[] knownCounters = new string[0];
        // 数える行動の値（StatNames の順。どれかの称号の条件・ゲートに使われていれば true）。
        [HideInInspector] public bool[] statOn = new bool[StatCount];
        // 画面の文言（選んだ言語。TitleTexts の番号の順）。
        [HideInInspector] public string[] uiTexts = new string[0];

        // ---- 定数 ----
        public const int KindNormal = 0;
        public const int KindConnector = 1;
        // 2026-10-28：記録の称号（値から語を作る。仕様書 11章）。ID は 10000〜32767。保存した値が 0 でなければ持っている。
        public const int KindRecord = 2;
        public const int RecordMinId = 10000;
        // 書式：0 数（3けたごとに,）/ 1 小数（recordDigits けた）/ 2 時間（0.01秒単位 → 12.34）/ 3 分:秒（秒 → 1:05）
        public const int RecordNumber = 0;
        public const int RecordDecimal = 1;
        public const int RecordTime = 2;
        public const int RecordClock = 3;
        public const int NameShow = 0;
        public const int NameHide = 1;
        public const int NameUnlisted = 2;
        public const int NameInternal = 3;
        public const int CondNone = 0;
        public const int CondCount = 1;
        public const int CondStat = 2;
        public const int CondOwned = 3;
        public const int CondAll = 4;
        public const int CondDate = 7;
        // record:キー>=N（記録の称号の値が N に届いた。良い方向で比べる）。
        public const int CondRecord = 8;
        public const int LangJapanese = 0;
        public const int LangEnglish = 1;
        public const int LangAuto = 2;
        public const int SlotBoth = 0;
        public const int SlotTitle = 1;
        public const int SlotConnector = 2;
        public const int SlotFixed = 3;
        public const int SlotUnused = 4;
        public const int SlotCount = 10;
        public const int MaxNormalId = 8999;
        // 所持のビットを持てる一番大きいID。接続語（9001〜9999）も「解禁で使える」ものはビットで持つ。
        public const int ConnectorMinId = 9001;
        // 表の ID の一番大きいもの（記録の称号まで。肩書きの枠は15ビットで持つ）。
        public const int MaxId = 32767;
        public const int MaxOwnId = 9999;
        // 9999 ビット分。保存は持っている一番大きいIDまで短く書くので、接続語を解禁しないワールドは今までと同じ長さ。
        public const int OwnBytes = 1250;
        public const string SpaceWord = "（空白）";
        // 画面の文言の番号（uiTexts の並び。Editor の TitleTextTable と同じ順）。
        public const int TextUnknown = 0;
        public const int TextNewTitle = 1;
        public const int TextBoardTitle = 2;
        public const int TextOwned = 3;
        public const int TextConnectors = 4;
        public const int TextPlate = 5;
        public const int TextApply = 6;
        public const int TextRevert = 7;
        public const int TextClear = 8;
        public const int TextNameplateOn = 9;
        public const int TextNameplateOff = 10;
        public const int TextPrev = 11;
        public const int TextNext = 12;
        public const int TextChars = 13;
        public const int TextTooLong = 14;
        public const int TextSaved = 15;
        public const int TextPickSlot = 16;
        public const int TextNotOwned = 17;
        public const int TextNotAllowed = 18;
        public const int TextFixed = 19;
        public const int TextSlotTitle = 20;
        public const int TextSlotConnector = 21;
        public const int TextLoading = 22;
        public const int TextLocked = 23;
        public const int TextSlotLocked = 24;
        public const int TextResetConfirm = 25;
        public const int TextResetDone = 26;
        public const int TextMyPlateOn = 27;
        public const int TextMyPlateOff = 28;
        public const int TextRosterTitle = 29;
        public const int TextRosterNone = 30;
        public const int TextFilterAll = 31;
        public const int TextFilterOwned = 32;
        public const int TextFilterLocked = 33;
        public const int TextClose = 34;
        // 2026-10-28 追加：言語のボタン（今の言語を出す）・決定していない・枠を選んだときの案内。
        public const int TextLanguage = 35;
        public const int TextUnsaved = 36;
        public const int TextSlotPicked = 37;
        // 2026-10-28 追加：ヒントの部品で称号を明かしたときの知らせの見出し。
        public const int TextHint = 38;
        // 2026-10-28 追加：ボードの肩書きの説明の行（見出しの TextPlate と分けた）・称号一覧の見出し。
        public const int TextPlateHint = 39;
        public const int TextListTitle = 40;
        // 2026-10-28 追加：記録を更新したときの知らせの見出し。
        public const int TextRecord = 41;
        public const int TextCount = 42;
        // 明かすもの（_RevealIds に渡す値。足して使う：3 = 名前と取得条件）。
        public const int RevealName = 1;
        public const int RevealDesc = 2;

        // 行動の値（仕様書 5-3 のうち初版で数えるもの）。番号は StatNames の順で、保存のキーは <頭>st.<名前>。
        public const int StatJumps = 0;
        public const int StatRespawns = 1;
        public const int StatWalk = 2;
        public const int StatVisits = 3;
        public const int StatVisitDays = 4;
        public const int StatStay = 5;
        public const int StatMetPeople = 6;
        public const int StatCrowdMax = 7;
        public const int StatAvatarChanges = 8;
        public const int StatPickups = 9;
        public const int StatHeightMax = 10;
        // 2026-10-28 追加：続けて来た日数（今・最高）、VR・VR でない・ほかの人といた時間（分）。
        public const int StatVisitStreak = 11;
        public const int StatVisitStreakMax = 12;
        public const int StatVrMin = 13;
        public const int StatDesktopMin = 14;
        public const int StatTogetherMin = 15;
        // 2026-10-28 追加（仕様書 5-3 の残り）：落ちた高さ・空中の時間・放置・座った回数と時間・使った回数・近くにいた時間・迎えた回数・
        // 称号を持つ人と会った回数・作者と会った回数・撫でた・撫でられた・ハイタッチ・手渡しで受け取った回数。
        public const int StatFallMax = 16;
        public const int StatAirtime = 17;
        public const int StatAfk = 18;
        public const int StatSits = 19;
        public const int StatSitMin = 20;
        public const int StatUses = 21;
        public const int StatNearMin = 22;
        public const int StatWelcomes = 23;
        public const int StatMetHolders = 24;
        public const int StatMetCreator = 25;
        public const int StatPats = 26;
        public const int StatPatted = 27;
        public const int StatHighFives = 28;
        public const int StatReceived = 29;
        public const int StatCount = 30;
        // 「最大値を保存」する値（足すのではなく大きいほうを残す）。
        private bool IsMaxStat(int stat) { return stat == StatCrowdMax || stat == StatHeightMax || stat == StatVisitStreakMax || stat == StatFallMax; }
        private string[] statNames = new string[] { "jumps", "respawns", "walk_m", "visits", "visit_days", "stay_min", "met_people", "crowd_max", "avatar_changes", "pickups", "height_max_m",
            "visit_streak", "visit_streak_max", "vr_min", "desktop_min", "together_min",
            "fall_max_m", "airtime_s", "afk_count", "sits", "sit_min", "uses", "near_min", "welcomes", "met_title_holders", "met_creator",
            "pats", "patted", "high_fives", "received_items" };
        // 数える値か（古い焼き込みで配列が短くても止まらない）。
        private bool StatOn(int stat) { return stat >= 0 && stat < statOn.Length && statOn[stat]; }

        // ---- 状態 ----
        private byte[] own = new byte[OwnBytes];
        // 明かした称号（名前・取得条件。持っていない称号だけに効く）。保存のキーは <頭>rvn・<頭>rvd。
        private byte[] revealedName = new byte[OwnBytes];
        private byte[] revealedDesc = new byte[OwnBytes];
        private int[] plate = new int[SlotCount];
        private bool restored;
        private int ownVersion;
        private int plateVersion;
        private int[] plateIds = new int[128];
        private string[] plateTexts = new string[128];
        private int[] statValues = new int[StatCount];
        private bool statsDirty;
        // 値ごとの「保存がまだ」（60秒ごとの保存で、変わった値だけ書く。PlayerData は全員へ配られるため）。
        private bool[] statDirty = new bool[StatCount];
        // 所持数・「全部持つ」の条件を、新しい称号がなくても1回見直す（入室で保存を読んだあと）。
        private bool ownedCheckPending;
        // カウンター（名前と値。使われたものだけ覚える）。
        private string[] counterNames = new string[64];
        private int[] counterValues = new int[64];
        private bool[] counterDirty = new bool[64];
        private int counterUsed;
        // 復元の前に頼まれた称号（復元の直後に渡す）。
        private int[] pending = new int[32];
        private int pendingCount;
        // 今回もらった称号（知らせにまとめる）。
        private int[] fresh = new int[32];
        private int freshCount;
        // 変わったら知らせる部品（称号ゲートなど。Start で登録される）。
        private UdonSharpBehaviour[] listeners = new UdonSharpBehaviour[0];
        private bool showNameplates = true;
        private int[] rowOfId = new int[0];
        // キー → ID（部品が称号をキーで聞くたびに表を頭から探さないように）。
        private DataDictionary idOfKey;
        private bool avatarSeen;
        // 1秒ごとの処理。
        private Vector3 lastPosition;
        private bool hasLastPosition;
        private int ticks;
        // 今手に持っている物（左・右）。VRC_Pickup の配列は Udon のプログラムの保存で壊れるので、1つずつ持つ。
        private VRC_Pickup heldLeft;
        private VRC_Pickup heldRight;

        // ---- 起動 ----

        private void Start()
        {
            showNameplates = showNameplatesDefault;
            BuildLookup();
            ApplyLanguage();
            SendCustomEventDelayedSeconds(nameof(_TickSecond), 1f);
        }

        // ---- 言語（2026-10-28） ----

        private bool english;
        private int languageVersion;
        // 見る人がボードで選んだ言語（0 ワールドの設定どおり / 1 日本語 / 2 English）。保存のキーは <頭>lang。
        private int languageChoice;
        // 言語が変わるたびに進む（ボードが文言を描き直す合図）。
        public int _LanguageVersion() { return languageVersion; }
        public bool _English() { return english; }

        // 語・説明・画面の文言を、設定の言語（自動なら見る人の VRChat の言語）に切り替える。
        private void ApplyLanguage()
        {
            bool en = language == LangEnglish;
            if (languageChoice == 1) en = false;
            else if (languageChoice == 2) en = true;
            else if (language == LangAuto)
            {
                string current = VRCPlayerApi.GetCurrentLanguage();
                en = string.IsNullOrEmpty(current) || !current.StartsWith("ja");
            }
            english = en;
            // 古い焼き込み（日本語・英語の配列がない）なら、焼き込み済みの words などをそのまま使う。
            if (wordsJa != null && wordsJa.Length == ids.Length && wordsEn != null && wordsEn.Length == ids.Length)
            {
                words = en ? wordsEn : wordsJa;
                descBefore = en ? descBeforeEn : descBeforeJa;
                descAfter = en ? descAfterEn : descAfterJa;
            }
            if (uiTextsJa != null && uiTextsJa.Length > 0 && uiTextsEn != null && uiTextsEn.Length > 0) uiTexts = en ? uiTextsEn : uiTextsJa;
            recordSuffix = en ? recordSuffixEn : recordSuffixJa;
            languageVersion++;
        }

        public override void OnLanguageChanged(string newLanguage)
        {
            // ボードで言語を選んでいるなら、VRChat の言語が変わってもそのまま。
            if (language != LangAuto || languageChoice != 0) return;
            LanguageChanged();
        }

        private void LanguageChanged()
        {
            ApplyLanguage();
            // 肩書きの文字は見る人の言語で作るので、全員分を作り直す。
            RefreshAllPlates();
            ownVersion++;
            // 称号ボードなどが文言を描き直す（ボードは毎フレームではなく、この知らせで見る）。
            NotifyListeners();
        }

        // ボードの言語のボタン：日本語と English を切り替えて保存する（見る人ごと。2026-10-28）。
        public void _ToggleLanguage()
        {
            if (!restored) return;
            languageChoice = english ? 1 : 2;
            PlayerData.SetInt(keyPrefix + "lang", languageChoice);
            LanguageChanged();
        }

        private void RefreshAllPlates()
        {
            int count = VRCPlayerApi.GetPlayerCount();
            VRCPlayerApi[] players = new VRCPlayerApi[Mathf.Max(count, 1)];
            VRCPlayerApi.GetPlayers(players);
            for (int i = 0; i < count; i++) if (Utilities.IsValid(players[i])) RefreshPlate(players[i]);
        }

        private void BuildLookup()
        {
            rowOfId = new int[MaxId + 1];
            idOfKey = new DataDictionary();
            for (int i = 0; i < ids.Length; i++)
            {
                int id = ids[i];
                if (id > 0 && id <= MaxId && rowOfId[id] == 0) rowOfId[id] = i + 1;
                // 同じキーが2行あるときは上の行（これまでの頭から探す作りと同じ）。
                if (i < keys.Length && !string.IsNullOrEmpty(keys[i]) && !idOfKey.ContainsKey(keys[i])) idOfKey.SetValue(keys[i], id);
            }
        }

        // 部品の登録（称号ゲートなど。所持・肩書き・行動の値が変わったら _OnTitlesChanged を呼ぶ）。
        public void _Listen(UdonSharpBehaviour behaviour)
        {
            if (behaviour == null) return;
            for (int i = 0; i < listeners.Length; i++) if (listeners[i] == behaviour) return;
            UdonSharpBehaviour[] next = new UdonSharpBehaviour[listeners.Length + 1];
            for (int i = 0; i < listeners.Length; i++) next[i] = listeners[i];
            next[listeners.Length] = behaviour;
            listeners = next;
            if (restored) behaviour.SendCustomEvent("_OnTitlesChanged");
        }

        private void NotifyListeners()
        {
            for (int i = 0; i < listeners.Length; i++) if (listeners[i] != null) listeners[i].SendCustomEvent("_OnTitlesChanged");
        }

        // ---- 表 ----

        public int _Row(int id)
        {
            if (rowOfId.Length == 0) BuildLookup();
            if (id <= 0 || id > MaxId) return -1;
            return rowOfId[id] - 1;
        }

        public int _IdOf(string key)
        {
            if (string.IsNullOrEmpty(key)) return 0;
            if (idOfKey == null) BuildLookup();
            DataToken token;
            if (idOfKey.TryGetValue(key, TokenType.Int, out token)) return token.Int;
            return 0;
        }

        public int _TableCount() { return ids.Length; }
        public int _IdAt(int row) { return row >= 0 && row < ids.Length ? ids[row] : 0; }
        public int _KindAt(int row) { return row >= 0 && row < kinds.Length ? kinds[row] : -1; }

        public bool _IsConnector(int id) { int row = _Row(id); return row >= 0 && kinds[row] == KindConnector; }

        // 解禁するまで使えない接続語か。
        public bool _IsLockedConnector(int id) { int row = _Row(id); return row >= 0 && kinds[row] == KindConnector && row < locks.Length && locks[row]; }

        // その人が使えるか：通常の称号はビット、接続語は最初から使えるものか、解禁したもの。
        // ビット列で持つ称号・接続語を使えるか。記録の称号はビットで持たないので false（自分の記録は _Has、ほかの人は RecordOf で見る）。
        private bool UsableIn(byte[] bits, int id)
        {
            int row = _Row(id);
            if (row < 0 || kinds[row] == KindRecord) return false;
            if (kinds[row] == KindConnector && !(row < locks.Length && locks[row])) return true;
            return HasIn(bits, id);
        }
        public bool _Active(int id) { int row = _Row(id); return row >= 0 && actives[row]; }

        // 表の語（そのまま）。
        public string _Word(int id)
        {
            int row = _Row(id);
            if (row < 0) return "";
            // 記録の称号：持っていれば「前置き＋値＋後ろ」、なければ前置きだけ。
            if (kinds[row] == KindRecord) return row < recordValues.Length && recordValues[row] != 0 ? RecordText(row, recordValues[row]) : words[row];
            string word = words[row];
            return word == SpaceWord ? " " : word;
        }

        // 称号ボードに出す名前（持っていなくて、名前を明かしていない「隠す」「一覧に出さない」なら ？？？）。
        // 「一覧に出さない」が出るのは、取得条件だけ明かしたとき。
        public string _ShownWord(int id)
        {
            int row = _Row(id);
            if (row < 0) return "";
            if (!_NameKnown(id) && (nameModes[row] == NameHide || nameModes[row] == NameUnlisted)) return _Ui(TextUnknown);
            if (kinds[row] == KindRecord) return _Word(id);
            return words[row];
        }

        // 称号ボードに出す説明（持っているか取得条件を明かしていれば取得後、なければ取得前。空ならもう一方）。
        public string _Desc(int id)
        {
            int row = _Row(id);
            if (row < 0) return "";
            bool known = _DescKnown(id);
            string first = known ? descAfter[row] : descBefore[row];
            string second = known ? descBefore[row] : descAfter[row];
            return string.IsNullOrEmpty(first) ? second : first;
        }

        // 名前・取得条件が見えるか（持っている・明かした）。
        public bool _NameKnown(int id) { return _Has(id) || (!_Internal(id) && HasIn(revealedName, id)); }
        public bool _DescKnown(int id) { return _Has(id) || (!_Internal(id) && HasIn(revealedDesc, id)); }

        // 明かしたもの（RevealName・RevealDesc を足した値。持っているかは見ない）。
        public int _Revealed(int id)
        {
            if (_Internal(id)) return 0;
            return (HasIn(revealedName, id) ? RevealName : 0) + (HasIn(revealedDesc, id) ? RevealDesc : 0);
        }

        // 接続語の一覧に出すか（使用中。解禁で使える接続語のうち「一覧に出さない」は解禁するか明かしてから。「内部用」は出さない）。
        public bool _ConnectorListed(int id)
        {
            int row = _Row(id);
            if (row < 0 || kinds[row] != KindConnector || !actives[row] || nameModes[row] == NameInternal) return false;
            return nameModes[row] != NameUnlisted || _Has(id) || _Revealed(id) > 0;
        }

        // 称号ボードの一覧に出すか（通常の称号で、使用中。「一覧に出さない」は持つか明かしてから。「内部用」は出さない）。
        public bool _Listed(int id)
        {
            int row = _Row(id);
            if (row < 0 || (kinds[row] != KindNormal && kinds[row] != KindRecord) || !actives[row] || nameModes[row] == NameInternal) return false;
            return nameModes[row] != NameUnlisted || _Has(id) || _Revealed(id) > 0;
        }

        // 「内部用」の称号か（ボード・知らせ・獲得数・肩書きに出さない）。
        public bool _Internal(int id)
        {
            int row = _Row(id);
            return row >= 0 && nameModes[row] == NameInternal;
        }

        // 獲得数「獲得 n / m」の m（一覧に出す称号の数）。
        public int _ListedCount()
        {
            int count = 0;
            for (int i = 0; i < ids.Length; i++) if (_Listed(ids[i])) count++;
            return count;
        }

        public int _OwnedCount()
        {
            int count = 0;
            for (int i = 0; i < ids.Length; i++)
                if (kinds[i] == KindNormal && actives[i] && nameModes[i] != NameInternal && HasIn(own, ids[i])) count++;
            return count;
        }

        // ---- 称号ボード向けのまとめ（2026-10-28） ----
        // ボードが表の行ごとにマネージャーを呼ぶと重いので、一覧に出す称号・接続語をここで並べて配列で渡す。
        // 所持・言語が変わったときだけ作り直す。並びは先頭から称号、そのあとに接続語。
        // 返す配列は使い回すので、受け取った側は書き換えず、すぐ自分の配列に写すこと。
        private int boardListBuilt = -1;
        private int[] boardIds = new int[0];
        private string[] boardWords = new string[0];
        private bool[] boardOwned = new bool[0];
        private int boardTitleCount;
        private int boardConnectorCount;
        // 「獲得 n / m」の n・m（記録の称号は数えない。_OwnedCount と同じ決まり）。
        private int boardOwnedCount;
        private int boardCountedTitles;
        // 名札の表示の設定を変えたたびに進む（ボードの版の番号に入れる）。
        private int settingsVersion;

        // ボードが描き直すべきことが変わったら変わる番号（所持・言語・やり直し・肩書きの決定・名札の設定）。
        // 行動の値が変わっただけでは変わらない。復元の前は -1。
        public int _BoardVersion() { return restored ? ownVersion + languageVersion + resetVersion + savedPlateVersion + settingsVersion : -1; }

        public int[] _BoardIds() { BuildBoardList(); return boardIds; }
        public string[] _BoardWords() { BuildBoardList(); return boardWords; }
        public bool[] _BoardOwned() { BuildBoardList(); return boardOwned; }
        public int _BoardTitleCount() { BuildBoardList(); return boardTitleCount; }
        public int _BoardConnectorCount() { BuildBoardList(); return boardConnectorCount; }
        public int _BoardOwnedCount() { BuildBoardList(); return boardOwnedCount; }
        public int _BoardCountedTitles() { BuildBoardList(); return boardCountedTitles; }

        private void BuildBoardList()
        {
            // 所持か言語が変わったときだけ作り直す（どちらも増えるだけの番号なので、足した値で見分けられる）。
            int version = ownVersion + languageVersion;
            if (boardListBuilt == version) return;
            boardListBuilt = version;
            int n = ids.Length;
            if (boardIds.Length < n)
            {
                boardIds = new int[n];
                boardWords = new string[n];
                boardOwned = new bool[n];
            }
            int count = 0;
            boardOwnedCount = 0;
            boardCountedTitles = 0;
            for (int pass = 0; pass < 2; pass++)
            {
                for (int row = 0; row < n; row++)
                {
                    int id = ids[row];
                    bool listed = pass == 0 ? kinds[row] != KindConnector && _Listed(id) : kinds[row] == KindConnector && _ConnectorListed(id);
                    if (!listed) continue;
                    boardIds[count] = id;
                    boardWords[count] = _ShownWord(id);
                    boardOwned[count] = _Has(id);
                    if (pass == 0 && kinds[row] != KindRecord)
                    {
                        boardCountedTitles++;
                        if (boardOwned[count]) boardOwnedCount++;
                    }
                    count++;
                }
                if (pass == 0) boardTitleCount = count;
            }
            boardConnectorCount = count - boardTitleCount;
        }

        public string _Ui(int index) { return index >= 0 && index < uiTexts.Length ? uiTexts[index] : ""; }

        // ---- 所持 ----

        public bool _Restored() { return restored; }
        public int _OwnVersion() { return ownVersion; }
        // 自分の肩書きを読み込んだ・決定したたびに進む（ボードが2枚以上あるとき、ほかのボードが作りかけを読み直す合図）。
        // 名札の表示の設定は版を持たず、変わったら知らせるだけ（ボードは値を見比べる）。
        private int savedPlateVersion;
        public int _SavedPlateVersion() { return savedPlateVersion; }
        public int _PlateVersion() { return plateVersion; }

        public bool _Has(int id)
        {
            int row = _Row(id);
            if (row >= 0 && kinds[row] == KindRecord) return row < recordValues.Length && recordValues[row] != 0;
            return UsableIn(own, id);
        }

        public bool _HasKey(string key) { return _Has(_IdOf(key)); }

        public bool _Equipped(int id)
        {
            if (id <= 0) return false;
            for (int i = 0; i < SlotCount; i++) if (plate[i] == id) return true;
            return false;
        }

        public bool _EquippedKey(string key) { return _Equipped(_IdOf(key)); }

        // 他の人が持っているか・装備しているか（その人の PlayerData を読む）。
        public bool _PlayerHas(VRCPlayerApi player, int id)
        {
            if (!Utilities.IsValid(player)) return false;
            if (player.isLocal) return _Has(id);
            int row = _Row(id);
            if (row >= 0 && kinds[row] == KindRecord) return RecordOf(player, row) != 0;
            byte[] bits = null;
            PlayerData.TryGetBytes(player, keyPrefix + "own2", out bits);
            return UsableIn(bits, id);
        }

        public bool _PlayerEquipped(VRCPlayerApi player, int id)
        {
            if (!Utilities.IsValid(player) || id <= 0) return false;
            if (player.isLocal) return _Equipped(id);
            int[] slots = new int[SlotCount];
            ReadPlate(player, slots);
            for (int i = 0; i < SlotCount; i++) if ((slots[i] & 0x7FFF) == id) return true;
            return false;
        }

        private bool HasIn(byte[] bits, int id)
        {
            if (bits == null || id <= 0 || id > MaxOwnId || (id >> 3) >= bits.Length) return false;
            return ((int)bits[id >> 3] & (1 << (id & 7))) != 0;
        }

        // ---- 渡す（入口） ----

        // Udon Graph 向け：grantKey に入れて Grant を SendCustomEvent する。
        [HideInInspector] public string grantKey = "";
        public void Grant() { _GrantKey(grantKey); }

        public void _GrantKey(string key) { _Grant(_IdOf(key)); }

        public void _Grant(int id)
        {
            if (id <= 0 || id > MaxOwnId) return;
            if (!restored)
            {
                if (pendingCount < pending.Length) pending[pendingCount++] = id;
                return;
            }
            freshCount = 0;
            Give(id);
            Settle();
        }

        // 複数をまとめて渡す（部品の結果）。知らせは1回にまとめる。
        public void _GrantIds(int[] list)
        {
            if (list == null) return;
            if (!restored)
            {
                for (int i = 0; i < list.Length; i++) if (list[i] > 0 && pendingCount < pending.Length) pending[pendingCount++] = list[i];
                return;
            }
            freshCount = 0;
            for (int i = 0; i < list.Length; i++) Give(list[i]);
            Settle();
        }

        // 部品の結果（2026-10-28）：知らせを出すか・鳴らす音（空ならマネージャーの知らせの音）を指定して渡す。
        public void _GrantIdsWith(int[] list, bool showPopup, AudioClip sound)
        {
            popupQuiet = !showPopup;
            popupClip = sound;
            _GrantIds(list);
            popupQuiet = false;
            popupClip = null;
        }
        private bool popupQuiet;
        private AudioClip popupClip;

        private bool Give(int id)
        {
            int row = _Row(id);
            if (row < 0 || !actives[row] || id > MaxOwnId || kinds[row] == KindRecord || UsableIn(own, id)) return false;
            own[id >> 3] = (byte)((int)own[id >> 3] | (1 << (id & 7)));
            ownVersion++;
            if (freshCount < fresh.Length) fresh[freshCount++] = id;
            return true;
        }

        // 渡したあと：所持の条件（owned・all）を見直し、保存し、知らせる。
        private void Settle()
        {
            // 所持数・「全部持つ」は、新しく称号を渡したときだけ変わるので、そのときだけ見直す。
            if (freshCount > 0 || ownedCheckPending)
            {
                ownedCheckPending = false;
                int before = -1;
                while (before != freshCount)
                {
                    before = freshCount;
                    CheckConditions(CondOwned, -1, "");
                    CheckConditions(CondAll, -1, "");
                }
            }
            if (freshCount == 0) return;
            SaveOwn();
            FlushValues();
            // 「内部用」の称号は知らせない。部品の「知らせを出す」がオフなら、音だけ鳴らす。
            if (popup != null && popupQuiet)
            {
                bool any = false;
                for (int i = 0; i < freshCount; i++) if (!_Internal(fresh[i])) any = true;
                if (any) popup._PlaySound(popupClip);
            }
            else if (popup != null && popupMode == 0)
            {
                // 1つずつ：称号ごとに、語と取得条件（取得後の説明。空なら取得前の説明）を順に出す。
                for (int i = 0; i < freshCount; i++)
                    if (!_Internal(fresh[i])) popup._EnqueueWith(_Ui(TextNewTitle), _Word(fresh[i]), _Desc(fresh[i]), popupClip);
            }
            else if (popup != null)
            {
                string text = "";
                for (int i = 0; i < freshCount; i++)
                    if (!_Internal(fresh[i])) text += (text.Length > 0 ? "　" : "") + _Word(fresh[i]);
                if (text.Length > 0) popup._ShowLinesWith(_Ui(TextNewTitle), text, popupClip);
            }
            freshCount = 0;
            NotifyListeners();
        }

        private byte[] Trimmed(byte[] bits)
        {
            int length = 1;
            for (int i = bits.Length - 1; i > 0; i--) if (bits[i] != 0) { length = i + 1; break; }
            byte[] result = new byte[length];
            for (int i = 0; i < length; i++) result[i] = bits[i];
            return result;
        }

        // ---- 明かす（2026-10-28、ユーザー指定：ほかの人の装備・ヒントのボタンで、名前・取得条件を見られるようにする） ----

        // Udon Graph 向け：revealKey・revealWhat（RevealName・RevealDesc を足した値）を入れて Reveal を SendCustomEvent する。
        [HideInInspector] public string revealKey = "";
        [HideInInspector] public int revealWhat = 3;
        public void Reveal() { _RevealIds(new int[] { _IdOf(revealKey) }, revealWhat, true); }

        // 称号を明かす。what は RevealName・RevealDesc を足した値。popup がオンなら、新しく明かした称号をヒントの知らせで出す。
        // 持っている称号・「内部用」の称号は明かさない。保存と知らせは、変わったときだけ1回。
        public void _RevealIds(int[] list, int what, bool popupOn)
        {
            if (!restored || list == null || what <= 0) return;
            bool changed = false;
            for (int i = 0; i < list.Length; i++)
            {
                if (!RevealBits(list[i], what)) continue;
                changed = true;
                if (popupOn && popup != null) popup._Enqueue(_Ui(TextHint), _ShownWord(list[i]), _Desc(list[i]));
            }
            if (changed) RevealSaved();
        }

        // ビットを立てる（変わったら true）。
        private bool RevealBits(int id, int what)
        {
            int row = _Row(id);
            if (row < 0 || id > MaxOwnId || !actives[row] || kinds[row] == KindRecord || nameModes[row] == NameInternal || UsableIn(own, id)) return false;
            bool changed = false;
            int bit = 1 << (id & 7);
            if ((what & RevealName) != 0 && ((int)revealedName[id >> 3] & bit) == 0)
            {
                revealedName[id >> 3] = (byte)((int)revealedName[id >> 3] | bit);
                changed = true;
            }
            if ((what & RevealDesc) != 0 && ((int)revealedDesc[id >> 3] & bit) == 0)
            {
                revealedDesc[id >> 3] = (byte)((int)revealedDesc[id >> 3] | bit);
                changed = true;
            }
            return changed;
        }

        // 明かしたものを保存して、ボードなどに知らせる（ボードは所持の版で一覧を作り直すので、所持の版も進める）。
        private void RevealSaved()
        {
            PlayerData.SetBytes(keyPrefix + "rvn", Trimmed(revealedName));
            PlayerData.SetBytes(keyPrefix + "rvd", Trimmed(revealedDesc));
            ownVersion++;
            NotifyListeners();
        }

        // ほかの人の肩書きに出ている称号を明かす（revealEquipped がオンのとき。その人の肩書きを読み直すたび）。
        private void RevealFromPlate(int[] slots, byte[] bits)
        {
            if (!restored || revealEquipped <= 0) return;
            int what = revealEquipped >= 2 ? RevealName + RevealDesc : RevealName;
            bool changed = false;
            for (int i = 0; i < SlotCount; i++)
                if (SlotWord(i, slots[i], bits).Length > 0 && RevealBits(slots[i], what)) changed = true;
            if (changed) RevealSaved();
        }

        // ---- 表の条件 ----

        // type の条件の称号を見直す。stat は行動の値の番号（-1 なら見ない）、counter はカウンターの名前（空なら見ない）。
        private void CheckConditions(int type, int stat, string counter)
        {
            // 所持数は1回の見直しで1回だけ数える（この見直しで渡した分は、Settle の繰り返しで次に見る）。
            int ownedNow = -1;
            for (int i = 0; i < ids.Length; i++)
            {
                if (condTypes[i] != type || !actives[i] || UsableIn(own, ids[i])) continue;
                bool ok = false;
                if (type == CondRecord) ok = condKeys[i] == counter && _RecordReaches(counter, condValues[i]);
                if (type == CondCount) ok = condKeys[i] == counter && _GetCount(counter) >= condValues[i];
                else if (type == CondStat) ok = condStats[i] == stat && statValues[stat] >= condValues[i];
                else if (type == CondOwned)
                {
                    if (ownedNow < 0) ownedNow = _OwnedCount();
                    ok = ownedNow >= condValues[i];
                }
                else if (type == CondAll) ok = AllOwned(i);
                else if (type == CondDate) ok = InDateRange(condValues[i], condEnds != null && i < condEnds.Length ? condEnds[i] : condValues[i]);
                if (ok) Give(ids[i]);
            }
        }

        // 今日（端末の日付）が期間の中か。MMDD（4けた以下）なら毎年、YYYYMMDD ならその日付で見る。年をまたぐ毎年の期間（1225〜0105）も可。
        public bool _InDateRange(int start, int end) { return InDateRange(start, end); }

        private bool InDateRange(int start, int end)
        {
            System.DateTime now = System.DateTime.Now;
            int monthDay = now.Month * 100 + now.Day;
            if (start < 10000 && end < 10000)
            {
                if (start <= end) return monthDay >= start && monthDay <= end;
                return monthDay >= start || monthDay <= end;
            }
            int today = now.Year * 10000 + monthDay;
            return today >= start && today <= end;
        }

        // 期間限定の称号を見直す（入室したときと、60秒ごと）。
        private void CheckDates()
        {
            bool any = false;
            for (int i = 0; i < condTypes.Length; i++) if (condTypes[i] == CondDate) { any = true; break; }
            if (!any) return;
            freshCount = 0;
            CheckConditions(CondDate, -1, "");
            Settle();
        }

        private bool AllOwned(int row)
        {
            int start = condAllStart[row];
            int count = condAllCount[row];
            if (count <= 0) return false;
            // 記録の称号は、記録があれば持っているとみなす（_Has と同じ）。
            for (int k = 0; k < count; k++) if (!_Has(condAllIds[start + k])) return false;
            return true;
        }

        private void CheckAll()
        {
            freshCount = 0;
            for (int s = 0; s < StatCount; s++) if (StatOn(s)) CheckConditions(CondStat, s, "");
            for (int i = 0; i < ids.Length; i++)
                if (condTypes[i] == CondCount && !string.IsNullOrEmpty(condKeys[i])) CheckConditions(CondCount, -1, condKeys[i]);
            CheckConditions(CondDate, -1, "");
            for (int i = 0; i < ids.Length; i++)
                if (condTypes[i] == CondRecord && !string.IsNullOrEmpty(condKeys[i])) CheckConditions(CondRecord, -1, condKeys[i]);
            Settle();
        }

        // ---- 記録の称号（2026-10-28、仕様書 11章） ----

        // 自分の記録の値（行ごと。記録でない行は 0）。
        private int[] recordValues = new int[0];
        private string[] recordSuffix = new string[0];

        private bool IsRecordRow(int row) { return row >= 0 && row < kinds.Length && kinds[row] == KindRecord && row < recordSaveKeys.Length && !string.IsNullOrEmpty(recordSaveKeys[row]); }

        private void LoadRecords(VRCPlayerApi player)
        {
            recordValues = new int[ids.Length];
            for (int row = 0; row < ids.Length; row++)
            {
                if (!IsRecordRow(row)) continue;
                int value = 0;
                if (PlayerData.TryGetInt(player, recordSaveKeys[row], out value)) recordValues[row] = Mathf.Max(0, value);
            }
        }

        // その人の記録の値（ほかの人の名札で使う。データが読めなければ 0）。
        private int RecordOf(VRCPlayerApi player, int row)
        {
            if (!IsRecordRow(row) || !Utilities.IsValid(player)) return 0;
            if (player.isLocal) return row < recordValues.Length ? recordValues[row] : 0;
            int value = 0;
            if (!PlayerData.TryGetInt(player, recordSaveKeys[row], out value)) return 0;
            return Mathf.Max(0, value);
        }

        private int RecordRow(string key)
        {
            int row = _Row(_IdOf(key));
            return IsRecordRow(row) ? row : -1;
        }

        // 自分の記録（キーは表の行のキー）。記録がなければ 0。
        public int _GetRecord(string key)
        {
            int row = RecordRow(key);
            return row >= 0 && row < recordValues.Length ? recordValues[row] : 0;
        }

        public int _GetRecordOf(VRCPlayerApi player, string key) { return RecordOf(player, RecordRow(key)); }

        // 記録が N に届いているか（大きいほど良いなら N 以上、小さいほど良いなら N 以下。記録なしは届いていない）。
        public bool _RecordReaches(string key, int target)
        {
            int row = RecordRow(key);
            if (row < 0) return false;
            int value = row < recordValues.Length ? recordValues[row] : 0;
            if (value == 0) return false;
            return recordLower[row] ? value <= target : value >= target;
        }

        // Udon Graph 向け：recordKey・recordValue を入れて SetRecord を SendCustomEvent する。
        [HideInInspector] public string recordKey = "";
        [HideInInspector] public int recordValue = 0;
        public void SetRecord() { _SetRecord(recordKey, recordValue); }

        // 記録を書く。前より良いとき（初めての記録を含む）だけ保存して true。値は 1 以上（0 は記録なし）。
        // 保存はすぐ書く（記録はたまにしか変わらないので、60秒ごとにまとめない）。
        public bool _SetRecord(string key, int value)
        {
            if (!restored || value <= 0) return false;
            int row = RecordRow(key);
            if (row < 0 || !actives[row]) return false;
            int before = recordValues[row];
            bool better = before == 0 || (recordLower[row] ? value < before : value > before);
            if (!better) return false;
            WriteRecord(row, value);
            if (popup != null && nameModes[row] != NameInternal)
                popup._Enqueue(_Ui(before == 0 ? TextNewTitle : TextRecord), RecordText(row, value), _Desc(ids[row]));
            return true;
        }

        // テスト用（Editor の Test Panel から）：debugRecordKey・debugRecordValue を入れて DebugSetRecord を SendCustomEvent する。良くなくても書く。
        [HideInInspector] public string debugRecordKey = "";
        [HideInInspector] public int debugRecordValue = 0;
        public void DebugSetRecord()
        {
            int row = RecordRow(debugRecordKey);
            if (!restored || row < 0) return;
            WriteRecord(row, Mathf.Max(0, debugRecordValue));
        }

        private void WriteRecord(int row, int value)
        {
            // 初めての記録は「持っている」になるので、all: の条件を見直す。
            if (recordValues[row] == 0 && value != 0) ownedCheckPending = true;
            recordValues[row] = value;
            PlayerData.SetInt(recordSaveKeys[row], value);
            ownVersion++;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (Utilities.IsValid(local)) StorePlate(local.playerId, LocalPlateText());
            freshCount = 0;
            CheckConditions(CondRecord, -1, keys[row]);
            bool granted = freshCount > 0;
            Settle();
            if (!granted) NotifyListeners();
        }

        // 記録の語：前置き（表の語）＋値＋後ろ。
        private string RecordText(int row, int value)
        {
            string prefix = words[row];
            string suffix = row < recordSuffix.Length ? recordSuffix[row] : "";
            return (string.IsNullOrEmpty(prefix) ? "" : prefix + " ") + FormatRecord(row, value) + suffix;
        }

        private string FormatRecord(int row, int value)
        {
            int format = row < recordFormats.Length ? recordFormats[row] : RecordNumber;
            if (format == RecordTime) return (value / 100).ToString() + "." + Pad(value % 100, 2);
            if (format == RecordClock) return (value / 60).ToString() + ":" + Pad(value % 60, 2);
            if (format == RecordDecimal)
            {
                int digits = row < recordDigits.Length ? Mathf.Clamp(recordDigits[row], 0, 6) : 0;
                if (digits == 0) return Grouped(value);
                int scale = 1;
                for (int i = 0; i < digits; i++) scale *= 10;
                return Grouped(value / scale) + "." + Pad(value % scale, digits);
            }
            return Grouped(value);
        }

        // 0 を前に足して width けたにする。
        private string Pad(int value, int width)
        {
            string text = value.ToString();
            while (text.Length < width) text = "0" + text;
            return text;
        }

        // 3けたごとに「,」を入れる。
        private string Grouped(int value)
        {
            string text = value.ToString();
            string result = "";
            int count = 0;
            for (int i = text.Length - 1; i >= 0; i--)
            {
                result = text.Substring(i, 1) + result;
                count++;
                if (count % 3 == 0 && i > 0) result = "," + result;
            }
            return result;
        }

        // ---- カウンター ----

        // Udon Graph 向け：countKey・countAdd を入れて AddCount を SendCustomEvent する。
        [HideInInspector] public string countKey = "";
        [HideInInspector] public int countAdd = 1;
        public void AddCount() { _AddCount(countKey, countAdd); }

        private int CounterIndex(string name, bool create)
        {
            if (string.IsNullOrEmpty(name)) return -1;
            for (int i = 0; i < counterUsed; i++) if (counterNames[i] == name) return i;
            if (!create || counterUsed >= counterNames.Length) return -1;
            int index = counterUsed++;
            counterNames[index] = name;
            int value = 0;
            VRCPlayerApi local = Networking.LocalPlayer;
            // 保存しないカウンター（TitleCounter の「保存する」がオフ）は、入室のたびに 0 から。
            if (!IsTempCounter(name) && restored && Utilities.IsValid(local) && PlayerData.TryGetInt(local, keyPrefix + "cnt." + name, out value)) counterValues[index] = Mathf.Max(0, value);
            else counterValues[index] = 0;
            return index;
        }

        // 保存しないカウンターの名前（2026-10-28）。TitleCounter が Start で登録する。
        private string[] tempCounters = new string[0];
        public void _MarkTemporaryCounter(string name)
        {
            if (string.IsNullOrEmpty(name) || IsTempCounter(name)) return;
            string[] next = new string[tempCounters.Length + 1];
            for (int i = 0; i < tempCounters.Length; i++) next[i] = tempCounters[i];
            next[tempCounters.Length] = name;
            tempCounters = next;
        }
        private bool IsTempCounter(string name)
        {
            for (int i = 0; i < tempCounters.Length; i++) if (tempCounters[i] == name) return true;
            return false;
        }

        public int _GetCount(string name)
        {
            int index = CounterIndex(name, restored);
            return index < 0 ? 0 : counterValues[index];
        }

        // 回数を足す。保存は60秒ごとか、称号を渡したとき（6章）。
        public void _AddCount(string name, int amount)
        {
            if (!restored || amount == 0) return;
            int index = CounterIndex(name, true);
            if (index < 0) return;
            counterValues[index] = Clamp(counterValues[index], amount);
            counterDirty[index] = true;
            freshCount = 0;
            CheckConditions(CondCount, -1, name);
            bool granted = freshCount > 0;
            Settle();
            // 称号が渡らなくても、カウンターの段（TitleCounter）などに知らせる（Settle で知らせたときは重ねない）。
            if (!granted) NotifyListeners();
        }

        // ---- 行動の値 ----

        // 足して 0〜20億に収める（int のあふれを防ぐ）。
        private int Clamp(int value, int amount)
        {
            if (amount > 0 && value > ValueLimit - amount) return ValueLimit;
            int next = value + amount;
            return next < 0 ? 0 : next;
        }
        private const int ValueLimit = 2000000000;

        public int _StatIndex(string name)
        {
            for (int i = 0; i < statNames.Length; i++) if (statNames[i] == name) return i;
            return -1;
        }

        public int _GetStat(string name)
        {
            int index = _StatIndex(name);
            return index < 0 ? 0 : statValues[index];
        }

        private void AddStat(int stat, int amount)
        {
            if (!restored || !StatOn(stat) || amount <= 0) return;
            statValues[stat] = Clamp(statValues[stat], amount);
            ChangedStat(stat);
        }

        // テスト用（Editor の Test Panel から）：debugStatName・debugStatValue を入れて DebugSetStat を SendCustomEvent する。
        // 数えていない値（statOn がオフ）も書く。値は保存される。
        [HideInInspector] public string debugStatName = "";
        [HideInInspector] public int debugStatValue = 0;
        public void DebugSetStat()
        {
            int stat = _StatIndex(debugStatName);
            if (!restored || stat < 0) return;
            statValues[stat] = Mathf.Max(0, debugStatValue);
            PlayerData.SetInt(keyPrefix + "st." + statNames[stat], statValues[stat]);
            freshCount = 0;
            CheckConditions(CondStat, stat, "");
            Settle();
            NotifyListeners();
        }

        private void MaxStat(int stat, int value)
        {
            if (!restored || !StatOn(stat) || value <= statValues[stat]) return;
            statValues[stat] = value;
            ChangedStat(stat);
        }

        private void ChangedStat(int stat)
        {
            statsDirty = true;
            statDirty[stat] = true;
            freshCount = 0;
            CheckConditions(CondStat, stat, "");
            Settle();
            NotifyListeners();
        }

        public override void InputJump(bool value, UdonInputEventArgs args)
        {
            if (!value) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local) || !local.IsPlayerGrounded()) return;
            AddStat(StatJumps, 1);
            // 落ちた高さ・空中の時間：跳んだ高さから見始める（地面を離れるのを少し待つ）。
            if (AirUsed()) StartAir(local.GetPosition().y, false);
        }

        public override void OnPlayerRespawn(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            AddStat(StatRespawns, 1);
            // 落ちている途中のリスポーンは、落ちたことにしない。
            airReset = true;
        }

        // 放置（ヘッドセットを外した・ゲームが止まった）。止まったときに1回。
        public override void OnPlayerSuspendChanged(VRCPlayerApi player)
        {
            if (Utilities.IsValid(player) && player.isLocal && player.isSuspended) AddStat(StatAfk, 1);
        }

        // 物を使った回数：トリガーを押したとき、その手に物を持っていれば1回。
        public override void InputUse(bool value, UdonInputEventArgs args)
        {
            if (!value || !restored || !StatOn(StatUses)) return;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            VRC_Pickup held = local.GetPickupInHand(args.handType == HandType.LEFT ? VRC_Pickup.PickupHand.Left : VRC_Pickup.PickupHand.Right);
            if (held != null) AddStat(StatUses, 1);
        }

        // ---- 落ちた高さ・空中の時間（空中にいる間だけ 0.1 秒ごと。2026-10-28、ユーザー了承） ----

        private const float AirStep = .1f;
        private bool airTicking;
        private bool airborne;
        private bool airReset;
        private float airTop;
        private float airLastY;
        private float airStart;
        private float airWaitSince;
        private float airRemainder;
        private float lastGroundY;
        private bool hasGroundY;

        private bool AirUsed() { return restored && (StatOn(StatFallMax) || StatOn(StatAirtime)) && seatedCount == 0; }

        // 見始める。inAir は、もう地面を離れているか（1秒ごとの見回りで見つけたとき）。
        private void StartAir(float top, bool inAir)
        {
            if (airTicking) return;
            airTicking = true;
            airborne = inAir;
            airTop = top;
            airLastY = top;
            airStart = Time.time;
            airWaitSince = Time.time;
            SendCustomEventDelayedSeconds(nameof(_TickAir), AirStep);
        }

        public void _TickAir()
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local) || !AirUsed()) { airTicking = false; return; }
            float y = local.GetPosition().y;
            if (airReset)
            {
                airReset = false;
                airborne = false;
                airTop = y;
                airLastY = y;
                airWaitSince = Time.time;
            }
            if (!local.IsPlayerGrounded())
            {
                if (!airborne) { airborne = true; airStart = Time.time; }
                // テレポートのような大きな動きのあとは、そこから測り直す。
                if (Mathf.Abs(y - airLastY) >= teleportMeters) airTop = y;
                if (y > airTop) airTop = y;
                airLastY = y;
                SendCustomEventDelayedSeconds(nameof(_TickAir), AirStep);
                return;
            }
            if (!airborne)
            {
                // 跳ぼうとしたが、まだ地面にいる。少しだけ待つ。
                if (Time.time - airWaitSince < .5f) { SendCustomEventDelayedSeconds(nameof(_TickAir), AirStep); return; }
                airTicking = false;
                return;
            }
            // 着地。
            airTicking = false;
            airborne = false;
            lastGroundY = y;
            hasGroundY = true;
            float fall = airTop - y;
            if (fall >= 1f) MaxStat(StatFallMax, Mathf.FloorToInt(fall));
            airRemainder += Time.time - airStart;
            if (airRemainder >= 1f)
            {
                int whole = Mathf.FloorToInt(airRemainder);
                airRemainder -= whole;
                AddStat(StatAirtime, whole);
            }
        }

        // ---- 席（TitleSeat から呼ばれる） ----

        private int seatedCount;
        private int sitSeconds;

        public void _SeatEnter()
        {
            seatedCount++;
            AddStat(StatSits, 1);
        }

        public void _SeatExit()
        {
            if (seatedCount > 0) seatedCount--;
        }

        // ---- 撫でる・ハイタッチ（TitleTouch から呼ばれる） ----

        // 撫でる・撫でられる・ハイタッチのどれかを数えるか（数えないなら TitleTouch は消える）。
        public bool _TouchUsed() { return StatOn(StatPats) || StatOn(StatPatted) || StatOn(StatHighFives); }

        // 0 撫でた / 1 撫でられた / 2 ハイタッチ
        public void _CountTouch(int what)
        {
            if (what == 0) AddStat(StatPats, 1);
            else if (what == 1) AddStat(StatPatted, 1);
            else if (what == 2) AddStat(StatHighFives, 1);
        }

        // ---- 手渡し（TitleAction から呼ばれる） ----

        // 物を掴んだとき、ほかの人の手が at の近くにあれば手渡しとみなし、受け取った回数を数える。
        // force：数えない設定でも判定だけする（称号アクションの「ほかの人から受け取る」）。
        public bool _Handoff(Vector3 at, bool force)
        {
            bool counting = restored && StatOn(StatReceived);
            if (!counting && !force) return false;
            int count = FillPlayers();
            float limit = handoffMeters * handoffMeters;
            bool handed = false;
            for (int i = 0; i < count && !handed; i++)
            {
                VRCPlayerApi player = playerBuffer[i];
                if (!Utilities.IsValid(player) || player.isLocal) continue;
                if (NearHand(player.GetBonePosition(HumanBodyBones.LeftHand), at, limit)) handed = true;
                else if (NearHand(player.GetBonePosition(HumanBodyBones.RightHand), at, limit)) handed = true;
            }
            if (handed && counting) AddStat(StatReceived, 1);
            return handed;
        }

        // 骨のないアバターでは (0,0,0) が返るので数えない。
        private bool NearHand(Vector3 hand, Vector3 at, float limit) { return hand != Vector3.zero && (hand - at).sqrMagnitude <= limit; }

        // ---- ほかの人 ----

        private VRCPlayerApi[] playerBuffer = new VRCPlayerApi[16];

        // いる人を playerBuffer に入れて人数を返す（配列は使い回す）。
        private int FillPlayers()
        {
            int count = VRCPlayerApi.GetPlayerCount();
            if (playerBuffer.Length < count) playerBuffer = new VRCPlayerApi[count + 16];
            VRCPlayerApi.GetPlayers(playerBuffer);
            return Mathf.Min(count, playerBuffer.Length);
        }

        // 自分のほかに nearMeters 以内の人がいるか（1秒ごと。near_min を数えるときだけ）。
        private bool AnyoneNear(Vector3 position)
        {
            int count = FillPlayers();
            if (count < 2) return false;
            float limit = nearMeters * nearMeters;
            for (int i = 0; i < count; i++)
            {
                VRCPlayerApi player = playerBuffer[i];
                if (Utilities.IsValid(player) && !player.isLocal && (player.GetPosition() - position).sqrMagnitude <= limit) return true;
            }
            return false;
        }

        // この入室で数えた人（playerId）。退出したら消すので、入り直すとまた数える（met_people と同じ）。
        private DataDictionary holderCounted = new DataDictionary();
        private DataDictionary creatorCounted = new DataDictionary();
        private int[] holderIds;

        // 称号を持つ人と会った回数：その人の所持（PlayerData）を読み、holderKeys のどれかを持っていれば1回。
        private void CheckHolder(VRCPlayerApi player)
        {
            if (!restored || !StatOn(StatMetHolders) || !Utilities.IsValid(player) || player.isLocal) return;
            if (holderCounted.ContainsKey(player.playerId)) return;
            if (holderIds == null)
            {
                holderIds = new int[holderKeys != null ? holderKeys.Length : 0];
                for (int i = 0; i < holderIds.Length; i++) holderIds[i] = _IdOf(holderKeys[i]);
            }
            for (int i = 0; i < holderIds.Length; i++)
            {
                if (holderIds[i] <= 0 || !_PlayerHas(player, holderIds[i])) continue;
                holderCounted.SetValue(player.playerId, true);
                AddStat(StatMetHolders, 1);
                return;
            }
        }

        // 作者などと会った回数：表示名が creatorNames のどれかと同じなら1回。
        private void CheckCreator(VRCPlayerApi player)
        {
            if (!restored || !StatOn(StatMetCreator) || !Utilities.IsValid(player) || player.isLocal || creatorNames == null) return;
            if (creatorCounted.ContainsKey(player.playerId)) return;
            string name = player.displayName;
            for (int i = 0; i < creatorNames.Length; i++)
            {
                if (string.IsNullOrEmpty(creatorNames[i]) || creatorNames[i].Trim() != name) continue;
                creatorCounted.SetValue(player.playerId, true);
                AddStat(StatMetCreator, 1);
                return;
            }
        }

        // 入室したとき、先にいた人をまとめて見る。
        private void CheckPeopleHere()
        {
            if (!StatOn(StatMetHolders) && !StatOn(StatMetCreator)) return;
            int count = FillPlayers();
            for (int i = 0; i < count; i++)
            {
                CheckHolder(playerBuffer[i]);
                CheckCreator(playerBuffer[i]);
            }
        }

        public override void OnAvatarChanged(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || !player.isLocal) return;
            // 入室直後の1回は数えない。
            if (!avatarSeen) { avatarSeen = true; return; }
            AddStat(StatAvatarChanges, 1);
        }

        public override void OnPlayerJoined(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player) || player.isLocal || !restored) return;
            AddStat(StatMetPeople, 1);
            MaxStat(StatCrowdMax, VRCPlayerApi.GetPlayerCount());
            AddStat(StatWelcomes, 1);
            CheckCreator(player);
            // 称号の所持はその人のデータが読めてから（OnPlayerRestored）。読めていれば今数える。
            CheckHolder(player);
        }

        // 1秒ごと：歩いた距離・一番高い所・掴んだ物・空中に出たか・座っている時間・近くの人。60秒ごと：滞在時間と保存。
        public void _TickSecond()
        {
            SendCustomEventDelayedSeconds(nameof(_TickSecond), 1f);
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!restored || !Utilities.IsValid(local)) return;
            Vector3 position = local.GetPosition();
            if (StatOn(StatWalk))
            {
                if (hasLastPosition && local.IsPlayerGrounded())
                {
                    Vector3 move = position - lastPosition;
                    move.y = 0f;
                    float meters = move.magnitude;
                    if (meters < teleportMeters) walkRemainder += meters;
                    if (walkRemainder >= 1f)
                    {
                        int whole = Mathf.FloorToInt(walkRemainder);
                        walkRemainder -= whole;
                        AddStat(StatWalk, whole);
                    }
                }
                lastPosition = position;
                hasLastPosition = true;
            }
            if (StatOn(StatHeightMax)) MaxStat(StatHeightMax, Mathf.FloorToInt(position.y));
            if (StatOn(StatPickups)) CheckHands(local);
            if (AirUsed())
            {
                // 跳ばずに地面を離れた（段差から落ちた）ときは、前の見回りの地面の高さから測る。
                if (local.IsPlayerGrounded()) { lastGroundY = position.y; hasGroundY = true; }
                else if (!airTicking) StartAir(hasGroundY ? Mathf.Max(lastGroundY, position.y) : position.y, true);
            }
            if (seatedCount > 0 && StatOn(StatSitMin) && ++sitSeconds >= 60) { sitSeconds = 0; AddStat(StatSitMin, 1); }
            if (StatOn(StatNearMin) && AnyoneNear(position) && ++nearSeconds >= 60) { nearSeconds = 0; AddStat(StatNearMin, 1); }
            ticks++;
            if (ticks % 60 == 0)
            {
                AddStat(StatStay, 1);
                if (local.IsUserInVR()) AddStat(StatVrMin, 1);
                else AddStat(StatDesktopMin, 1);
                if (VRCPlayerApi.GetPlayerCount() > 1) AddStat(StatTogetherMin, 1);
                CheckDates();
                FlushValues();
            }
        }
        private float walkRemainder;
        private int nearSeconds;

        private void CheckHands(VRCPlayerApi local)
        {
            VRC_Pickup left = local.GetPickupInHand(VRC_Pickup.PickupHand.Left);
            VRC_Pickup right = local.GetPickupInHand(VRC_Pickup.PickupHand.Right);
            if (left != null && left != heldLeft && left != heldRight) AddStat(StatPickups, 1);
            if (right != null && right != heldLeft && right != heldRight && right != left) AddStat(StatPickups, 1);
            heldLeft = left;
            heldRight = right;
        }

        // カウンター・行動の値の保存（変わったものだけ）。ほかの人へ配られるので、行動のたびには書かない。
        private void FlushValues()
        {
            if (!restored) return;
            for (int i = 0; i < counterUsed; i++)
            {
                if (!counterDirty[i]) continue;
                counterDirty[i] = false;
                if (!IsTempCounter(counterNames[i])) PlayerData.SetInt(keyPrefix + "cnt." + counterNames[i], counterValues[i]);
            }
            if (!statsDirty) return;
            statsDirty = false;
            for (int s = 0; s < StatCount; s++)
            {
                if (!statDirty[s]) continue;
                statDirty[s] = false;
                if (StatOn(s)) PlayerData.SetInt(keyPrefix + "st." + statNames[s], statValues[s]);
            }
        }

        // ---- 復元・他の人の肩書き ----

        public override void OnPlayerRestored(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player)) return;
            if (player.isLocal)
            {
                LoadLocal(player);
                restored = true;
                // 入室時の持ち物を部品に知らせる（称号イベント中継が、このあと渡す称号と区別する基準にする）。
                NotifyListeners();
                CountVisit(player);
                MaxStat(StatCrowdMax, VRCPlayerApi.GetPlayerCount());
                if (VRCPlayerApi.GetPlayerCount() > 1) AddStat(StatMetPeople, VRCPlayerApi.GetPlayerCount() - 1);
                freshCount = 0;
                for (int i = 0; i < pendingCount; i++) Give(pending[i]);
                pendingCount = 0;
                Settle();
                CheckAll();
                FlushValues();
                NotifyListeners();
                // 自分より先に読み込んだ人の肩書きから、装備している称号を明かす。
                if (revealEquipped > 0) RefreshAllPlates();
                // 先にいた人のうち、称号を持つ人・作者などを数える。
                CheckPeopleHere();
            }
            else CheckHolder(player);
            RefreshPlate(player);
        }

        public override void OnPlayerDataUpdated(VRCPlayerApi player, PlayerData.Info[] infos)
        {
            if (!Utilities.IsValid(player) || player.isLocal) return;
            RefreshPlate(player);
            // 入室中に称号をもらった人も数える（所持のデータが変わったときだけ読む）。
            if (!StatOn(StatMetHolders) || infos == null) return;
            string ownKey = keyPrefix + "own2";
            for (int i = 0; i < infos.Length; i++)
                if (infos[i].Key == ownKey) { CheckHolder(player); return; }
        }

        public override void OnPlayerLeft(VRCPlayerApi player)
        {
            if (player == null) return;
            int index = PlateIndex(player.playerId);
            if (index >= 0) { plateIds[index] = 0; plateTexts[index] = ""; plateVersion++; }
            holderCounted.Remove(player.playerId);
            creatorCounted.Remove(player.playerId);
        }

        private void LoadLocal(VRCPlayerApi player)
        {
            for (int i = 0; i < own.Length; i++) own[i] = 0;
            byte[] bytes;
            if (PlayerData.TryGetBytes(player, keyPrefix + "own2", out bytes) && bytes != null)
                for (int i = 0; i < bytes.Length && i < own.Length; i++) own[i] = bytes[i];
            LoadBits(player, "rvn", revealedName);
            LoadBits(player, "rvd", revealedDesc);
            ReadPlate(player, plate);
            for (int s = 0; s < StatCount; s++)
            {
                int value = 0;
                statValues[s] = PlayerData.TryGetInt(player, keyPrefix + "st." + statNames[s], out value) ? Mathf.Max(0, value) : 0;
            }
            int show = 0;
            if (PlayerData.TryGetInt(player, keyPrefix + "show", out show)) showNameplates = show != 2;
            int pub = 0;
            publishPlate = !(PlayerData.TryGetInt(player, keyPrefix + "pub", out pub) && pub == 2);
            int lang = 0;
            if (PlayerData.TryGetInt(player, keyPrefix + "lang", out lang) && (lang == 1 || lang == 2) && lang != languageChoice)
            {
                languageChoice = lang;
                ApplyLanguage();
                RefreshAllPlates();
            }
            LoadRecords(player);
            if (editorAllOwned) GiveAllForTest();
            savedPlateVersion++;
            ownVersion++;
            ownedCheckPending = true;
        }

        // テスト（Editor の Play だけ）：全部の称号と解禁で使う接続語を持たせる。所持は保存しない。
        private bool editorAllOwnedActive;
        private void GiveAllForTest()
        {
            editorAllOwnedActive = true;
            for (int i = 0; i < ids.Length; i++)
            {
                int id = ids[i];
                if (id <= 0 || id > MaxOwnId || !actives[i]) continue;
                if (kinds[i] == KindConnector && !(i < locks.Length && locks[i])) continue;
                own[id >> 3] = (byte)((int)own[id >> 3] | (1 << (id & 7)));
            }
        }

        // 所持を保存する（テストで全部持たせているときは書かない）。
        private void SaveOwn()
        {
            if (!editorAllOwnedActive) PlayerData.SetBytes(keyPrefix + "own2", Trimmed(own));
        }

        private void LoadBits(VRCPlayerApi player, string name, byte[] target)
        {
            for (int i = 0; i < target.Length; i++) target[i] = 0;
            byte[] bytes;
            if (PlayerData.TryGetBytes(player, keyPrefix + name, out bytes) && bytes != null)
                for (int i = 0; i < bytes.Length && i < target.Length; i++) target[i] = bytes[i];
        }

        // 入室の回数と来訪の日数（端末の日付で1日1回）。
        private void CountVisit(VRCPlayerApi player)
        {
            AddStat(StatVisits, 1);
            System.DateTime now = System.DateTime.Now;
            int today = now.Year * 10000 + now.Month * 100 + now.Day;
            int last = 0;
            PlayerData.TryGetInt(player, keyPrefix + "visit.last", out last);
            if (last != today)
            {
                PlayerData.SetInt(keyPrefix + "visit.last", today);
                AddStat(StatVisitDays, 1);
                // 続けて来た日数：前に来たのが昨日なら1足し、そうでなければ1から。
                System.DateTime yesterday = now.AddDays(-1);
                int yesterdayValue = yesterday.Year * 10000 + yesterday.Month * 100 + yesterday.Day;
                int streak = last == yesterdayValue ? statValues[StatVisitStreak] + 1 : 1;
                SetStat(StatVisitStreak, streak);
                MaxStat(StatVisitStreakMax, streak);
            }
        }

        // 値をそのまま書く（減ることもある値：続けて来た日数）。
        private void SetStat(int stat, int value)
        {
            if (!restored || !StatOn(stat) || value == statValues[stat]) return;
            statValues[stat] = Mathf.Max(0, value);
            ChangedStat(stat);
        }

        private void ReadPlate(VRCPlayerApi player, int[] slots)
        {
            for (int i = 0; i < SlotCount; i++) slots[i] = 0;
            byte[] bytes;
            if (!PlayerData.TryGetBytes(player, keyPrefix + "plate2", out bytes) || bytes == null) return;
            for (int i = 0; i < SlotCount && i * 2 + 1 < bytes.Length; i++)
                slots[i] = ((int)bytes[i * 2] * 256 + (int)bytes[i * 2 + 1]) & 0x7FFF;
        }

        private int PlateIndex(int playerId)
        {
            if (playerId <= 0) return -1;
            for (int i = 0; i < plateIds.Length; i++) if (plateIds[i] == playerId) return i;
            return -1;
        }

        private void RefreshPlate(VRCPlayerApi player)
        {
            if (player.isLocal)
            {
                if (restored) StorePlate(player.playerId, LocalPlateText());
                return;
            }
            // 「自分の名札を出さない」にしている人の肩書きは、名札にも一覧にも出さない。
            int pub = 0;
            if (PlayerData.TryGetInt(player, keyPrefix + "pub", out pub) && pub == 2) { StorePlate(player.playerId, ""); return; }
            int[] slots = new int[SlotCount];
            ReadPlate(player, slots);
            byte[] bits = null;
            PlayerData.TryGetBytes(player, keyPrefix + "own2", out bits);
            plateOwner = player;
            StorePlate(player.playerId, BuildPlate(slots, bits));
            RevealFromPlate(slots, bits);
            plateOwner = null;
        }

        // 自分の肩書き。「見せない」はほかの人の端末が pub を読んで決めるので、自分の端末ではいつも出す（一覧ボードで自分の分が見える）。
        private string LocalPlateText() { return BuildPlate(plate, own); }

        private void StorePlate(int playerId, string text)
        {
            int index = PlateIndex(playerId);
            if (index < 0)
                for (int i = 0; i < plateIds.Length; i++) if (plateIds[i] == 0) { index = i; break; }
            if (index < 0) return;
            plateIds[index] = playerId;
            if (plateTexts[index] != text) plateVersion++;
            plateTexts[index] = text;
        }

        // ---- 肩書き ----

        // 枠が解禁されているか（自分）。解禁の称号がない枠はいつも使える。
        public bool _SlotOpen(int slot) { return SlotOpenFor(slot, own); }

        // bits はその人の所持（他の人の肩書きを作るときはその人の所持で見る）。
        private bool SlotOpenFor(int slot, byte[] bits)
        {
            int unlock = slotUnlockIds != null && slot >= 0 && slot < slotUnlockIds.Length ? slotUnlockIds[slot] : 0;
            return unlock <= 0 || HasIn(bits, unlock);
        }

        public int _SlotUnlockId(int slot) { return slotUnlockIds != null && slot >= 0 && slot < slotUnlockIds.Length ? slotUnlockIds[slot] : 0; }

        // その枠にその語を入れられるか（9-1）。解禁されていない枠には何も入れられない。
        public bool _SlotAllows(int slot, int id)
        {
            if (slot < 0 || slot >= SlotCount) return false;
            if (!_SlotOpen(slot)) return false;
            int type = slotTypes != null && slot < slotTypes.Length ? slotTypes[slot] : SlotBoth;
            if (id <= 0) return type != SlotFixed && type != SlotUnused;
            if (!_Active(id)) return false;
            bool connector = _IsConnector(id);
            if (type == SlotBoth) return true;
            if (type == SlotTitle) return !connector;
            if (type == SlotConnector) return connector;
            return false;
        }

        public int _SlotType(int slot) { return slotTypes != null && slot >= 0 && slot < slotTypes.Length ? slotTypes[slot] : SlotBoth; }
        public int _SlotFixedId(int slot) { return slotFixedIds != null && slot >= 0 && slot < slotFixedIds.Length ? slotFixedIds[slot] : 0; }

        // 枠の語（出さない枠は空）。bits はその人の所持（自分は own）。
        // 肩書きを作っている相手（null なら自分）。記録の称号の値をその人の PlayerData から読むため。
        private VRCPlayerApi plateOwner;

        private string SlotWord(int slot, int id, byte[] bits)
        {
            int type = _SlotType(slot);
            if (type == SlotUnused || type == SlotFixed || !SlotOpenFor(slot, bits)) return "";
            if (id <= 0 || !_Active(id) || _Internal(id) || !TypeAllows(type, id)) return "";
            int row = _Row(id);
            if (row >= 0 && kinds[row] == KindRecord)
            {
                int value = plateOwner == null ? (row < recordValues.Length ? recordValues[row] : 0) : RecordOf(plateOwner, row);
                return value != 0 ? RecordText(row, value) : "";
            }
            if (!UsableIn(bits, id)) return "";
            return _Word(id);
        }

        private bool TypeAllows(int type, int id)
        {
            bool connector = _IsConnector(id);
            if (type == SlotBoth) return true;
            if (type == SlotTitle) return !connector;
            if (type == SlotConnector) return connector;
            return false;
        }

        // 枠の並びから肩書きの文字を作る。固定の語は、ほかに語のある枠があるときだけ入れる。
        private string BuildPlate(int[] slots, byte[] bits)
        {
            bool any = false;
            for (int i = 0; i < SlotCount; i++) if (SlotWord(i, slots[i], bits).Length > 0) { any = true; break; }
            if (!any) return "";
            string text = "";
            for (int i = 0; i < SlotCount; i++)
            {
                if (_SlotType(i) == SlotFixed) { if (SlotOpenFor(i, bits)) text += _Word(_SlotFixedId(i)); continue; }
                text += SlotWord(i, slots[i], bits);
            }
            return text;
        }

        public string _PlateText(int[] slots) { return BuildPlate(slots, own); }

        // 見える文字の数（色のタグを除く）。
        public int _VisibleLength(string text)
        {
            if (string.IsNullOrEmpty(text)) return 0;
            // 「<」から「>」までを飛ばして数える（1文字ずつ切り出さない）。閉じていない「<」は文字として数える。
            int count = 0;
            int at = 0;
            while (at < text.Length)
            {
                int open = text.IndexOf("<", at);
                if (open < 0) { count += text.Length - at; break; }
                count += open - at;
                int close = text.IndexOf(">", open);
                if (close < 0) { count += text.Length - open; break; }
                at = close + 1;
            }
            return count;
        }

        public int[] _Plate()
        {
            int[] copy = new int[SlotCount];
            for (int i = 0; i < SlotCount; i++) copy[i] = plate[i];
            return copy;
        }

        // 肩書きを決定して保存する。合わない語の枠は空にする。長すぎる・復元前なら保存しない。
        public bool _SetPlate(int[] slots)
        {
            if (!restored || slots == null) return false;
            int[] clean = new int[SlotCount];
            for (int i = 0; i < SlotCount; i++)
            {
                int id = i < slots.Length ? slots[i] & 0x7FFF : 0;
                int type = _SlotType(i);
                if (type == SlotFixed || type == SlotUnused || !_SlotAllows(i, id) || !_Has(id) || _Internal(id)) id = 0;
                clean[i] = id;
            }
            if (_VisibleLength(BuildPlate(clean, own)) > maxPlateChars) return false;
            byte[] bytes = new byte[SlotCount * 2];
            for (int i = 0; i < SlotCount; i++)
            {
                plate[i] = clean[i];
                bytes[i * 2] = (byte)(clean[i] / 256);
                bytes[i * 2 + 1] = (byte)(clean[i] % 256);
            }
            PlayerData.SetBytes(keyPrefix + "plate2", bytes);
            VRCPlayerApi local = Networking.LocalPlayer;
            if (Utilities.IsValid(local)) StorePlate(local.playerId, LocalPlateText());
            savedPlateVersion++;
            NotifyListeners();
            return true;
        }

        public string _PlateOfPlayer(int playerId)
        {
            int index = PlateIndex(playerId);
            return index < 0 || plateTexts[index] == null ? "" : plateTexts[index];
        }

        public string _PlateOf(VRCPlayerApi player) { return Utilities.IsValid(player) ? _PlateOfPlayer(player.playerId) : ""; }

        // ---- 外す・やり直し（2026-10-28、ユーザー指定。遊び直し・テスト用） ----

        // やり直しのたびに進む値（部品の「一度だけ」を戻す合図）。
        private int resetVersion;
        public int _ResetVersion() { return resetVersion; }

        // Udon Graph 向け：revokeKey に入れて Revoke を SendCustomEvent する。ResetAll はそのまま呼ぶ。
        [HideInInspector] public string revokeKey = "";
        public void Revoke() { _RevokeKey(revokeKey); }
        public void ResetAll() { _ResetAll(); }

        public void _RevokeKey(string key) { _Revoke(_IdOf(key)); }

        // 称号を1つ外す。装備していたら肩書きからも外す。表の条件（行動の値など）を満たしたままなら、次に値が変わったときにまた渡される。
        public void _Revoke(int id)
        {
            if (!restored || id <= 0 || id > MaxOwnId || !HasIn(own, id)) return;
            // ~ を使わず、立っているビットを引いて消す（持っていることは上で確かめた）。
            own[id >> 3] = (byte)((int)own[id >> 3] - (1 << (id & 7)));
            ownVersion++;
            SaveOwn();
            RemoveFromPlate();
            NotifyListeners();
        }

        // 全部やり直す：所持・明かした称号・肩書き・カウンター（knownCounters と、この入室で使ったもの）・行動の値・来訪の日を消す。名札の表示の設定は残す。
        public void _ResetAll()
        {
            if (!restored) return;
            for (int i = 0; i < own.Length; i++) own[i] = 0;
            for (int i = 0; i < revealedName.Length; i++) { revealedName[i] = 0; revealedDesc[i] = 0; }
            ownVersion++;
            resetVersion++;
            SaveOwn();
            PlayerData.SetBytes(keyPrefix + "rvn", Trimmed(revealedName));
            PlayerData.SetBytes(keyPrefix + "rvd", Trimmed(revealedDesc));
            for (int i = 0; i < SlotCount; i++) plate[i] = 0;
            PlayerData.SetBytes(keyPrefix + "plate2", new byte[SlotCount * 2]);
            for (int i = 0; i < knownCounters.Length; i++)
                if (!string.IsNullOrEmpty(knownCounters[i]) && !IsTempCounter(knownCounters[i])) PlayerData.SetInt(keyPrefix + "cnt." + knownCounters[i], 0);
            for (int i = 0; i < counterUsed; i++)
            {
                counterValues[i] = 0;
                counterDirty[i] = false;
                if (!IsTempCounter(counterNames[i])) PlayerData.SetInt(keyPrefix + "cnt." + counterNames[i], 0);
            }
            for (int s = 0; s < StatCount; s++)
            {
                // 数えていない・0 の値は書かない（使っていない値の保存のキーを作らない）。
                if (StatOn(s) || statValues[s] != 0) PlayerData.SetInt(keyPrefix + "st." + statNames[s], 0);
                statValues[s] = 0;
                statDirty[s] = false;
            }
            statsDirty = false;
            // 記録：このギミックの頭（<頭>rec.）で保存したものだけ消す。表で別の保存のキーを指定した記録（ほかの仕組みの記録）は残す。
            string recordHead = keyPrefix + "rec.";
            for (int row = 0; row < recordValues.Length; row++)
            {
                if (!IsRecordRow(row) || recordValues[row] == 0 || !recordSaveKeys[row].StartsWith(recordHead)) continue;
                recordValues[row] = 0;
                PlayerData.SetInt(recordSaveKeys[row], 0);
            }
            PlayerData.SetInt(keyPrefix + "visit.last", 0);
            hasLastPosition = false;
            walkRemainder = 0f;
            airRemainder = 0f;
            sitSeconds = 0;
            nearSeconds = 0;
            VRCPlayerApi local = Networking.LocalPlayer;
            if (Utilities.IsValid(local)) StorePlate(local.playerId, "");
            NotifyListeners();
        }

        // 持っていない称号・解禁されていない枠を肩書きから外して保存する（外したときだけ書く）。
        private void RemoveFromPlate()
        {
            bool changed = false;
            for (int i = 0; i < SlotCount; i++)
            {
                int id = plate[i];
                if (id <= 0) continue;
                if (!_SlotOpen(i) || !_Has(id)) { plate[i] = 0; changed = true; }
            }
            if (!changed) return;
            byte[] bytes = new byte[SlotCount * 2];
            for (int i = 0; i < SlotCount; i++)
            {
                bytes[i * 2] = (byte)(plate[i] / 256);
                bytes[i * 2 + 1] = (byte)(plate[i] % 256);
            }
            PlayerData.SetBytes(keyPrefix + "plate2", bytes);
            VRCPlayerApi local = Networking.LocalPlayer;
            if (Utilities.IsValid(local)) StorePlate(local.playerId, LocalPlateText());
        }

        // ---- 称号の効果（TitlePerk。2026-10-28） ----
        // 効果の部品が複数あっても元に戻せるよう、元の値は最初の1回だけ覚え、変わるたびに満たしている部品から決め直す。

        private TitlePerk[] perks = new TitlePerk[0];
        private bool perkBaseSaved;
        private float baseWalk;
        private float baseRun;
        private float baseStrafe;
        private float baseJump;
        private float baseGravity;

        public void _RegisterPerk(TitlePerk perk)
        {
            if (perk == null) return;
            for (int i = 0; i < perks.Length; i++) if (perks[i] == perk) return;
            TitlePerk[] next = new TitlePerk[perks.Length + 1];
            for (int i = 0; i < perks.Length; i++) next[i] = perks[i];
            next[perks.Length] = perk;
            perks = next;
        }

        // 満たしている効果の部品から、速さ・ジャンプ力・重力を決め直す（あとに登録した部品が優先）。
        // どの部品も変えない種類（速さなど）には触らない。
        public void _RefreshPerks()
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (!Utilities.IsValid(local)) return;
            if (!perkBaseSaved)
            {
                perkBaseSaved = true;
                baseWalk = local.GetWalkSpeed();
                baseRun = local.GetRunSpeed();
                baseStrafe = local.GetStrafeSpeed();
                baseJump = local.GetJumpImpulse();
                baseGravity = local.GetGravityStrength();
            }
            bool usesSpeed = false;
            bool usesJump = false;
            bool usesGravity = false;
            float walk = baseWalk;
            float run = baseRun;
            float strafe = baseStrafe;
            float jump = baseJump;
            float gravity = baseGravity;
            for (int i = 0; i < perks.Length; i++)
            {
                TitlePerk perk = perks[i];
                if (perk == null) continue;
                if (perk.changeSpeed) usesSpeed = true;
                if (perk.changeJump) usesJump = true;
                if (perk.changeGravity) usesGravity = true;
                if (!perk._IsMet()) continue;
                if (perk.changeSpeed) { walk = perk.walkSpeed; run = perk.runSpeed; strafe = perk.strafeSpeed; }
                if (perk.changeJump) jump = perk.jumpImpulse;
                if (perk.changeGravity) gravity = perk.gravityStrength;
            }
            if (usesSpeed) { local.SetWalkSpeed(walk); local.SetRunSpeed(run); local.SetStrafeSpeed(strafe); }
            if (usesJump) local.SetJumpImpulse(jump);
            if (usesGravity) local.SetGravityStrength(gravity);
        }

        // ---- 名札の表示（見る人ごと。保存する） ----

        public bool _ShowNameplates() { return showNameplates; }

        public void _SetShowNameplates(bool value)
        {
            showNameplates = value;
            // 1 出す / 2 出さない（0 は保存なし）。
            if (restored) PlayerData.SetInt(keyPrefix + "show", value ? 1 : 2);
            settingsVersion++;
            NotifyListeners();
        }

        // 自分の肩書きをほかの人に見せるか（2026-10-28。保存する。見せないなら、ほかの人の名札・一覧に出ない）。
        private bool publishPlate = true;
        public bool _PublishPlate() { return publishPlate; }

        public void _SetPublishPlate(bool value)
        {
            if (!restored) return;
            publishPlate = value;
            // 1 見せる / 2 見せない（0 は保存なし＝見せる）。
            PlayerData.SetInt(keyPrefix + "pub", value ? 1 : 2);
            VRCPlayerApi local = Networking.LocalPlayer;
            if (Utilities.IsValid(local)) StorePlate(local.playerId, LocalPlateText());
            settingsVersion++;
            NotifyListeners();
        }
    }
}
