using UdonSharp;
using UnityEngine;
using UnityEngine.UI;
using VRC.SDKBase;

namespace WorldTitleGimmick
{
    // いま部屋にいる人の肩書きの一覧ボード（2026-10-28、ユーザー指定）。
    // 肩書きは TitleManager が持つ値（各人の PlayerData から作ったもの。名札と同じ）を使う。同期しない。
    // 毎フレームは動かさず、refreshSeconds ごとに見て、変わったときだけ描き直す。人が行より多いときは pageSeconds ごとにページをめくる。
    [AddComponentMenu("World Title Gimmick/いまいる人の一覧（TitleRoster）")]
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class TitleRoster : UdonSharpBehaviour
    {
        [Tooltip("シーンの TitleManager（空なら焼き込みで入る）")]
        public TitleManager manager;
        [Tooltip("見出しの文字（空なら出さない）")]
        public Text titleText;
        [Tooltip("1人1行の文字。上から順に使う")]
        public Text[] lines = new Text[0];
        [Tooltip("ページの文字（「1 / 2」。空なら出さない）")]
        public Text pageText;
        [Tooltip("オンなら、肩書きのない人も名前だけ出す")]
        public bool showEmpty = true;
        [Tooltip("人が行より多いとき、ページをめくる間隔（秒）")]
        public float pageSeconds = 8f;
        [Tooltip("見直す間隔（秒）")]
        public float refreshSeconds = 1f;
        [Tooltip("肩書きの色")]
        public Color plateColor = new Color(.95f, .76f, .25f, 1f);
        [Tooltip("「（肩書きなし）」の色")]
        public Color noneColor = new Color(.55f, .58f, .65f, 1f);

        private VRCPlayerApi[] players = new VRCPlayerApi[0];
        private int seenPlateVersion = -1;
        private int seenPlayers = -1;
        private int seenLanguage = -1;
        private int page;
        private float nextPage;
        private string plateHex = "";
        private string noneHex = "";
        private string hexDigits = "0123456789ABCDEF";

        private void Start()
        {
            plateHex = Hex(plateColor);
            noneHex = Hex(noneColor);
            // 最初は1ページ目から（めくるのは pageSeconds たってから）。
            nextPage = Time.time + Mathf.Max(1f, pageSeconds);
            SendCustomEventDelayedSeconds(nameof(_Tick), 1f);
        }

        public void _Tick()
        {
            SendCustomEventDelayedSeconds(nameof(_Tick), Mathf.Max(0.2f, refreshSeconds));
            if (manager == null) return;
            int count = VRCPlayerApi.GetPlayerCount();
            bool flip = Time.time >= nextPage;
            if (!flip && seenPlateVersion == manager._PlateVersion() && seenPlayers == count && seenLanguage == manager._LanguageVersion()) return;
            seenPlateVersion = manager._PlateVersion();
            seenPlayers = count;
            seenLanguage = manager._LanguageVersion();
            if (flip)
            {
                nextPage = Time.time + Mathf.Max(1f, pageSeconds);
                page++;
            }
            Redraw(count);
        }

        private void Redraw(int count)
        {
            if (players.Length < count) players = new VRCPlayerApi[Mathf.Max(count, 8)];
            VRCPlayerApi.GetPlayers(players);
            SetText(titleText, manager._Ui(TitleManager.TextRosterTitle));
            int per = lines.Length;
            if (per == 0) return;
            // 出す人を数え、ページを決める。
            int shown = 0;
            for (int p = 0; p < count; p++) if (Listed(players[p])) shown++;
            int pages = Mathf.Max(1, (shown + per - 1) / per);
            if (page >= pages) page = 0;
            int skip = page * per;
            int line = 0;
            for (int p = 0; p < count && line < per; p++)
            {
                VRCPlayerApi player = players[p];
                if (!Listed(player)) continue;
                if (skip > 0) { skip--; continue; }
                string plate = manager._PlateOfPlayer(player.playerId);
                string text = player.displayName + "　" + (string.IsNullOrEmpty(plate)
                    ? "<color=#" + noneHex + ">" + manager._Ui(TitleManager.TextRosterNone) + "</color>"
                    : "<color=#" + plateHex + ">［" + plate + "］</color>");
                SetText(lines[line], text);
                line++;
            }
            for (int i = line; i < per; i++) SetText(lines[i], "");
            SetText(pageText, pages > 1 ? (page + 1) + " / " + pages : "");
        }

        private bool Listed(VRCPlayerApi player)
        {
            if (!Utilities.IsValid(player)) return false;
            return showEmpty || !string.IsNullOrEmpty(manager._PlateOfPlayer(player.playerId));
        }

        private string Hex(Color color)
        {
            return Byte(color.r) + Byte(color.g) + Byte(color.b);
        }

        private string Byte(float value)
        {
            int v = Mathf.Clamp(Mathf.RoundToInt(value * 255f), 0, 255);
            return hexDigits.Substring(v / 16, 1) + hexDigits.Substring(v % 16, 1);
        }

        private void SetText(Text label, string text)
        {
            if (label != null && label.text != text) label.text = text;
        }
    }
}
