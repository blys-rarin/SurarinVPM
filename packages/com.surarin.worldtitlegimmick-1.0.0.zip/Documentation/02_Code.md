# ワールド内称号ギミック 説明書 2：コードから使う

UdonSharp・Udon Graphから称号を渡したり、持っているかを調べたりする方法です。

置き方・表の作り方・部品の設定は「01_Inspector.md」を読んでください。

> 入れないことにした機能は「01_Inspector.md」の 14章にまとめました。

## 目次

1. 基本の約束
2. 名前空間と参照のしかた
3. TitleManagerの公開メソッド
4. 変わったことを知る（_Listen と _OnTitlesChanged）
5. UdonSharpの例
6. Udon Graphから使う
7. 復元の前に呼んだとき
8. 保存のキー
9. 記録の称号を書く・読む

## 1. 基本の約束

- **本人の分しか書けません。** 渡す・数える・肩書きを決めるは、その端末のプレイヤー（本人）のPlayerDataに書きます。ほかの人の称号は書けません。
- ほかの人の称号・肩書きは読むだけです（その人のPlayerDataから読みます）。
- 同期はしません。称号を渡すコードは、**本人の端末で起きた出来事の中だけ**で呼んでください。
  - 例：`OnPlayerTriggerEnter(player)` では `player.isLocal` のときだけ呼ぶ。
  - 全員の端末で動くイベント（同期イベントなど）の中で `_Grant` を呼ぶと、その場の全員が称号をもらいます。
- 称号はID（数）かキー（表で決めた英数字）で指定します。キーで呼ぶと、表の並びが変わってもコードを直さずに済みます。
- IDの範囲は、称号の表の「ID の範囲」で決まります（初めは「中」：通常の称号 1〜799、接続語 801〜999、内部用 1001〜2000、記録の称号 2001〜32767。01 の 6-2）。
- 接続語は全員が最初から使えます。ただし表で「最初は使えない（解禁する接続語）」（Locked Connector）をオンにした接続語（解禁で使う接続語）は、称号と同じく渡すまで使えません。

## 2. 名前空間と参照のしかた

- 名前空間は `WorldTitleGimmick` です。
- シーンの称号マネージャー（`TitleManager`）を、公開変数でインスペクターからつなぎます。

```csharp
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using WorldTitleGimmick;

public class MyGimmick : UdonSharpBehaviour
{
    public TitleManager titles; // インスペクターで称号マネージャーを入れる
}
```

- ギミックのスクリプトは、アセンブリ `WorldTitleGimmick.Runtime`（Assembly Definition）に入っています。
  - 自分のスクリプトを Assets の下にそのまま置く（asmdef を使わない）なら、何もしなくても `TitleManager` が使えます。
  - 自分のスクリプトを asmdef に入れているときは、その asmdef の「Assembly Definition References」に `WorldTitleGimmick.Runtime` を足してください。

## 3. TitleManagerの公開メソッド

### 3-1. 渡す・数える（本人だけ）

| メソッド | 戻り値 | すること |
|---|---|---|
| `_Grant(int id)` | なし | IDの称号を渡す。解禁で使う接続語も渡せる（解禁）。持っていれば何もしない。最初から使える接続語・廃止の称号・記録の称号（`_SetRecord` で書く）・表にないIDは無視 |
| `_GrantKey(string key)` | なし | キーの称号を渡す。表にないキーは無視 |
| `_GrantIds(int[] ids)` | なし | 複数をまとめて渡す。知らせは1回にまとめる |
| `_GrantIdsWith(int[] ids, bool showPopup, AudioClip sound)` | なし | `_GrantIds` に、知らせを出すか・鳴らす音（null なら知らせの音）を付けたもの。部品の「獲得の知らせを出す」「効果音」が使う |
| `_SetRecord(string key, int value)` | bool | 記録の称号（01 の 6-6）の記録を書く。前より良いとき（初めてを含む）だけ保存して true。値は1以上（9章） |
| `_AddCount(string name, int amount)` | なし | カウンターに足す。0未満にはならない。表の `count:` の条件を見直す。カウンターの名前は1回の入室で64個まで（それを超えた新しい名前は無視） |
| `_Revoke(int id)` | なし | 称号（解禁した接続語も）を外す。肩書きに入っていれば外して保存する。持っていなければ何もしない。記録の称号は外せない |
| `_RevokeKey(string key)` | なし | キーで `_Revoke` |
| `_RevokeIds(int[] ids)` | なし | いくつかの称号をまとめて外す。持っていた称号があったときだけ、1回で保存・知らせる。部品の「外す称号」が使う |
| `_ResetAll()` | なし | 本人の称号・明かした称号・肩書き・カウンター・行動の値・来訪の日・記録（`<頭>rec.` で保存したもの）を消す（3-6） |
| `_RevealIds(int[] ids, int what, bool popup)` | なし | まだ持っていない称号を明かす（ヒント。01 の 10章）。`what` は `TitleManager.RevealName`（1）・`RevealDesc`（2）を足した値（3 で両方）。`popup` が true なら、新しく明かした称号ごとに獲得の知らせの板で「称号のヒントを見つけました」を出す。持っている・内部用・廃止・記録の称号・表にないIDは無視。変わったときだけ保存し、`_OnTitlesChanged` で知らせる。復元前は何もしない |
| `Grant()` | なし | Udon Graph用。公開変数 `grantKey` のキーで `_GrantKey` を呼ぶ（6章） |
| `AddCount()` | なし | Udon Graph用。公開変数 `countKey`・`countAdd` で `_AddCount` を呼ぶ（6章） |
| `Revoke()` | なし | Udon Graph用。公開変数 `revokeKey` のキーで `_RevokeKey` を呼ぶ（6章） |
| `ResetAll()` | なし | Udon Graph用。`_ResetAll` を呼ぶ（6章） |
| `Reveal()` | なし | Udon Graph用。公開変数 `revealKey` のキーの称号を、`revealWhat`（初期値 3）で明かし、知らせを出す（6-8） |
| `SetRecord()` | なし | Udon Graph用。公開変数 `recordKey`・`recordValue` で `_SetRecord` を呼ぶ（6-9） |
| `_MarkTemporaryCounter(string name)` | なし | そのカウンターを保存しないことにする（入室のたびに0から）。カウンター部品の「保存する」がオフのとき、部品が Start で呼ぶ |

- 渡したら、すぐに保存し、獲得の知らせを出し（内部用の称号は出さない）、`owned>=`・`all:` の条件も見直します。
- マネージャーの「称号の知らせを出す」がオフなら、獲得・ヒント（`_RevealIds`）・記録（`_SetRecord`）の知らせは出ません。
- カウンターの保存は60秒ごとか、称号を渡したときです（8章）。
- 外したとき・やり直したときは、知らせは出ません。表の条件で取れる称号は、次にその値が変わったときにまた渡されることがあります。

### 3-2. 本人について調べる

| メソッド | 戻り値 | すること |
|---|---|---|
| `_Has(int id)` | bool | 持っているか（使えるか）。最初から使える接続語は常にtrue、解禁で使う接続語は解禁していればtrue、記録の称号は記録があればtrue |
| `_HasKey(string key)` | bool | キーで `_Has` |
| `_Equipped(int id)` | bool | 肩書き（保存済み）に入れているか |
| `_EquippedKey(string key)` | bool | キーで `_Equipped` |
| `_GetCount(string name)` | int | カウンターの値 |
| `_GetStat(string name)` | int | 行動の値（名前は01の8-2）。知らない名前は0 |
| `_GetRecord(string key)` | int | 記録の称号の記録。記録がなければ0 |
| `_RecordReaches(string key, int target)` | bool | 記録が target に届いたか（大きいほど良い記録なら以上、小さいほど良い記録なら以下）。記録なしは false |
| `_InDateRange(int start, int end)` | bool | 今日（端末の日付）が期間の中か。MMDD なら毎年、YYYYMMDD ならその年だけ |
| `_OwnedCount()` | int | 持っている称号の数（接続語・廃止・内部用・記録の称号を除く） |
| `_Plate()` | int[] | 肩書きの10枠のID（写し）。空の枠は0 |
| `_SlotOpen(int slot)` | bool | 枠（0〜9）が解禁されているか。解禁の称号がない枠は常にtrue |
| `_Restored()` | bool | 本人のPlayerDataの復元が済んだか（7章） |
| `_ShowNameplates()` | bool | 本人が頭上の名札を出す設定か |
| `_PublishPlate()` | bool | 本人が自分の肩書きをほかの人に見せる設定か（2026-10-28） |
| `_English()` | bool | 今、英語で出しているか（言語が「自動」なら見る人の VRChat の言語で決まる。見る人がボードで選んだらそちら） |
| `_NameKnown(int id)` | bool | 名前が見えるか（持っている・名前を明かした） |
| `_DescKnown(int id)` | bool | 取得条件（説明（取得後））が見えるか（持っている・取得条件を明かした） |
| `_Revealed(int id)` | int | 明かしたもの（`RevealName`・`RevealDesc` を足した値。持っているかは見ない。内部用は0） |

**行動の値の注意**：行動の値は、表の条件 `stat:` か称号ゲートの「行動の値」（Stat Name）で使っている値だけが数えられます（焼き込みのときに決まります）。コードで `_GetStat("jumps")` を読みたいだけのときも、どこかの条件かゲートで `jumps` を使っていないと増えません。

### 3-3. ほかの人について調べる（読むだけ）

| メソッド | 戻り値 | すること |
|---|---|---|
| `_PlayerHas(VRCPlayerApi player, int id)` | bool | その人が持っているか。本人なら `_Has` と同じ |
| `_PlayerEquipped(VRCPlayerApi player, int id)` | bool | その人が装備しているか（保存されている枠で見る。その人が枠を解禁しているかは見ない） |
| `_GetRecordOf(VRCPlayerApi player, string key)` | int | その人の記録（その人の PlayerData を読む）。なければ0 |
| `_PlateOf(VRCPlayerApi player)` | string | その人の肩書きの文字。なければ空 |
| `_PlateOfPlayer(int playerId)` | string | playerIdで `_PlateOf` |

- `_PlateOf` は、その人のデータが届いた時点（入室の復元・データの更新）で作った文字を返します。初版では色のタグは付きません。
- 文字は**見る人の言語**で作ります（言語が「自動」のとき）。
- その人が「自分の名札：見せない」にしているときは空です。本人の分は、見せない設定でも本人の端末では肩書きが入っています。
- `_PlayerHas`・`_PlayerEquipped` は、呼ぶたびにその人のPlayerDataを読みます。毎フレーム呼ばないでください。

### 3-4. 変わった合図・登録

| メソッド | 戻り値 | すること |
|---|---|---|
| `_OwnVersion()` | int | 本人の所持が変わるたびに増える数。称号を明かしたとき・記録を書いたとき・言語が変わったときも増える（ボードの一覧を作り直すため） |
| `_PlateVersion()` | int | 誰かの肩書きの文字が変わる・誰かが退出するたびに増える数 |
| `_BoardVersion()` | int | 本人の所持・言語・やり直し・肩書きの決定・名札の設定が変わると変わる数（行動の値では変わらない）。復元の前は -1。自分で板を作るとき、`_OnTitlesChanged` でこれが変わったときだけ描き直すと軽い |
| `_BoardIds()`・`_BoardWords()`・`_BoardOwned()` | int[]・string[]・bool[] | 称号ボードの一覧に出す称号と接続語（ID・ボードに出す名前・持っているか）。先頭から `_BoardTitleCount()` 個が称号、続く `_BoardConnectorCount()` 個が接続語。所持か言語が変わったときだけ作り直す。配列は使い回すので書き換えず、必要なら自分の配列に写す |
| `_BoardOwnedCount()`・`_BoardCountedTitles()` | int | ボードの「獲得 n / m」の n・m（一覧に出す称号のうち、記録の称号を除いて数える） |
| `_ResetVersion()` | int | `_ResetAll` のたびに増える数（`_Revoke` では増えない） |
| `_LanguageVersion()` | int | 言語が切り替わるたびに増える数。画面を自作するとき、文言を描き直す合図に使う |
| `_SavedPlateVersion()` | int | 本人の肩書きを読み込んだ・決定したたびに増える数（ボードが作りかけを読み直す合図） |
| `_Listen(UdonSharpBehaviour behaviour)` | なし | 変わったときに `_OnTitlesChanged` を呼んでもらう（4章） |
| `_ListenFor(UdonSharpBehaviour behaviour, int what)` | なし | 決めた種類が変わったときだけ `_OnTitlesChanged` を呼んでもらう。`what` は `TitleManager.ListenTitles`（1。称号）・`ListenStats`（2。行動の値）・`ListenCounts`（4。カウンター）を足した値（4章） |

前の値を覚えておき、違っていたら描き直す、という使い方をします。部品の「一度だけ」は、`_ResetVersion()` が変わったのを見て戻しています。自作の部品で「一度だけ」を作るときも同じようにできます。

### 3-5. 表を読む・肩書きを扱う（画面を自作する人向け）

| メソッド | 戻り値 | すること |
|---|---|---|
| `_IdOf(string key)` | int | キーからID。なければ0 |
| `_Row(int id)` | int | 表の行番号。なければ-1 |
| `_TableCount()` | int | 表の行数（接続語・廃止を含む） |
| `_IdAt(int row)` | int | 行のID |
| `_KindAt(int row)` | int | 行の分類（`TitleManager.KindNormal`=0 / `KindConnector`=1 / `KindRecord`=2 記録の称号） |
| `_HasRows()`・`_FreeConnectorRows()` | bool[] | 表の行ごとの `_Has`、行ごとの「最初から使える接続語か」（称号イベント中継が使う）。配列は使い回すので書き換えず、すぐ使う |
| `_IsConnector(int id)` | bool | 接続語か |
| `_IsLockedConnector(int id)` | bool | 解禁で使う接続語か（解禁したかどうかは `_Has`） |
| `_ConnectorListed(int id)` | bool | ボードの接続語の一覧に出すか |
| `_Active(int id)` | bool | 状態が「使用」か |
| `_Word(int id)` | string | 語（選んだ言語）。「（空白）」は半角の空白。記録の称号は、記録があれば「語＋値」（例：最速タイム 12.34秒）、なければ語だけ |
| `_ShownWord(int id)` | string | ボードに出す名前（持っていなくて名前を明かしていない「隠す」「一覧に出さない」の称号は「？？？」） |
| `_Desc(int id)` | string | ボードに出す説明（持っているか取得条件を明かしていれば取得後、なければ取得前。空ならもう一方） |
| `_Listed(int id)` | bool | ボードの一覧に出すか（内部用は出さない。「一覧に出さない」は持つか明かしたら出す） |
| `_Internal(int id)` | bool | 表の分類が「内部用」か（ボード・知らせ・獲得数・肩書きに出さない。01 の 10章） |
| `_ListedCount()` | int | 一覧に出す称号の数（記録の称号も数える。ボードの「獲得 n / m」の m は記録の称号を除いた `_BoardCountedTitles()`） |
| `_Ui(int index)` | string | 画面の文言（`TitleManager.Text〜` の番号） |
| `_SlotType(int slot)` | int | 枠の種類（0 どちらも / 1 称号だけ / 2 接続語だけ / 3 固定の語 / 4 使わない） |
| `_SlotFixedId(int slot)` | int | 固定の語の枠の接続語のID |
| `_SlotUnlockId(int slot)` | int | 枠の解禁の称号のID。0なら最初から使える |
| `_SlotAllows(int slot, int id)` | bool | その枠にその語を入れられるか（解禁していない枠はfalse） |
| `_PlateText(int[] slots)` | string | 枠の並びから、本人の肩書きの文字を作る（保存しない） |
| `_VisibleLength(string text)` | int | 見える文字の数（タグを除く） |
| `_SetPlate(int[] slots)` | bool | 本人の肩書きを決定して保存する。合わない枠は空にする。復元前・文字数オーバーはfalse |
| `_SetShowNameplates(bool value)` | なし | 本人の名札のON/OFFを変えて保存する |
| `_SetPublishPlate(bool value)` | なし | 本人の肩書きをほかの人に見せるかを変えて保存する。復元前は何もしない |
| `_ToggleLanguage()` | なし | 見る人の言語を日本語 ⇔ English に切り替えて保存する（ボードの言語のボタンと同じ。マネージャーの「言語」より優先）。復元前は何もしない |
| `_StatIndex(string name)` | int | 行動の値の番号。なければ-1 |
| `_SeatEnter()`・`_SeatExit()` | なし | 本人が席に座った・立った（`sits`・`sit_min`）。ふつうは TitleSeat が呼ぶ。自分の席の仕組みから呼ぶときは、座ると立つを必ず対にする |
| `_CountTouch(int what)` | なし | 撫でた（0）・撫でられた（1）・ハイタッチ（2）を1回数える。ふつうは TitleTouch が呼ぶ |
| `_TouchUsed()` | bool | 撫でる・撫でられる・ハイタッチのどれかを数えるか |
| `_Handoff(Vector3 at, bool force)` | bool | ほかの人の手が at の近くにあるか（手渡し）。あれば `received_items` を1増やす（数える設定のとき）。force が false で数えない設定なら、調べずに false。ふつうは TitleAction が掴んだときに呼ぶ |
| `_RegisterPerk(TitlePerk perk)`・`_RefreshPerks()` | なし | 称号の効果（TitlePerk）の登録と、速さ・ジャンプ力・重力の決め直し。TitlePerk が呼ぶので、自分では呼ばない |

### 3-6. _ResetAll で消えるもの

| 消える | 残る |
|---|---|
| 所持（称号・解禁した接続語）・明かした称号（`rvn`・`rvd`） | 名札のON/OFF（`<頭>show`）・自分の名札を見せるか（`<頭>pub`）・ボードで選んだ言語（`<頭>lang`） |
| 肩書き（10枠とも空） | 部品が有効・無効にした物の状態 |
| カウンター：焼き込みで表の条件と部品（Counter Key・Save Key）から集めた名前と、その入室で使った名前（保存しないカウンターも、今の値は0に戻る） | 上のどちらにも当たらないカウンター（ほかの入室でコードからだけ使った名前） |
| 行動の値（全部）・来訪の日（`visit.last`） | |
| 記録の称号のうち `<頭>rec.` で保存したもの | 記録の称号のうち、表の「保存のキー（空なら自動）」（Record Save Key）でほかのキーを指定したもの |
| 部品の「一度だけ」（`_ResetVersion` が進む） | |

- 復元の前に呼ぶと何もしません。
- 部品が有効・無効にした物は戻りません。称号やり直し（TitleReset）の「やり直したあとに出す物」「やり直したあとに消す物」（Enable Objects・Disable Objects）か、自分のコードで戻してください。

## 4. 変わったことを知る（_Listen と _OnTitlesChanged）

称号ゲート・称号ボードと同じしくみを、自分のUdonSharpでも使えます。

- 呼ばれるのは、所持・肩書き・カウンター・行動の値・記録・明かした称号・やり直し・言語・名札の表示の設定が変わったときです。歩いている間は1秒ごとに呼ばれることもあるので、中の処理は軽くしてください（変わったときだけ描き直すなど）。
- `_HasKey`・`_IdOf` などキーで聞く入口は、表の行数に関係なく速く引けます（2026-10-28 から）。

1. `Start` で `titles._Listen(this);` を呼んで登録する。
2. `public void _OnTitlesChanged()` を書く（名前はこのとおり）。

```csharp
public TitleManager titles;

private void Start()
{
    if (titles != null) titles._Listen(this);
}

// 所持・肩書き・行動の値が変わったときに呼ばれる。
public void _OnTitlesChanged()
{
    bool open = titles._HasKey("vip");
    // 扉の表示などを切り替える
}
```

呼ばれるとき：

- 本人の復元が済んだとき（登録が復元の後なら、登録した時点で1回）。復元の直後は続けて何回か呼ばれることがあります
- 本人が称号をもらったとき・外したとき・やり直したとき
- 本人の肩書きを決定したとき
- カウンターが変わったとき（`_AddCount`。称号をもらわなくても呼ばれる）
- 記録を書いたとき・称号を明かしたとき
- 行動の値が増えたとき（歩いた距離などは1秒ごとに増えることがあるので、中の処理は軽くする）
- 言語・名札の設定（`_SetShowNameplates`・`_SetPublishPlate`）が変わったとき

呼ばれないとき：

- ほかの人の肩書きが変わったとき。`_PlateVersion()` の変化を見てください。

### 4-1. 要る知らせだけ受ける（_ListenFor）

同じ部品をたくさん置くときは、`_Listen` の代わりに `_ListenFor` で、要る種類だけを受けると軽くなります（2026-10-29 から）。行動の値（歩いた距離など）は歩いている間に1秒ごとに変わるので、行動の値を見ない部品は受けないようにするのが効きます。

| 種類 | 値 | 呼ばれるとき |
|---|---|---|
| `TitleManager.ListenTitles` | 1 | 上の「呼ばれるとき」のうち、カウンターと行動の値を除いた全部（復元・所持・肩書き・記録・明かした称号・やり直し・言語・名札の設定） |
| `TitleManager.ListenStats` | 2 | 行動の値が増えたとき |
| `TitleManager.ListenCounts` | 4 | カウンターが変わったとき |

```csharp
private void Start()
{
    // 称号とカウンターだけ受ける（歩いた距離などでは呼ばれない）。
    if (titles != null) titles._ListenFor(this, TitleManager.ListenTitles + TitleManager.ListenCounts);
}
```

- `_Listen(this)` は全部（`ListenAll`、7）を受けます。
- 2回呼ぶと種類が足されます。
- 付属の部品は要る種類だけを受けます。称号ゲートは「行動の値」の欄（Stat Name）を入れたときだけ行動の値を受け、称号の効果・称号ボード・称号イベント中継は称号だけ、称号カウンターは称号とカウンターを受けます。

## 5. UdonSharpの例

### 5-1. ゴールに着いたら称号を渡し、回数を数える

```csharp
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using WorldTitleGimmick;

public class GoalLine : UdonSharpBehaviour
{
    public TitleManager titles;

    public override void OnPlayerTriggerEnter(VRCPlayerApi player)
    {
        // 本人の端末で、本人が入ったときだけ
        if (!Utilities.IsValid(player) || !player.isLocal) return;
        titles._GrantKey("goal");
        titles._AddCount("goals", 1); // 表に「count:goals>=10」の称号を書けば、10回目で渡る
    }
}
```

### 5-2. 称号を持っている人だけボタンを押せる

```csharp
public TitleManager titles;

public override void Interact()
{
    if (!titles._HasKey("member"))
    {
        // 持っていない人の処理
        return;
    }
    // 持っている人の処理
}
```

### 5-3. 近くの人の肩書きを看板に出す

```csharp
public TitleManager titles;
public UnityEngine.UI.Text label;
private int seenVersion = -1;
private VRCPlayerApi target;

public void _SetTarget(VRCPlayerApi player) { target = player; seenVersion = -1; }

private void Update()
{
    // 肩書きが変わったときだけ書き直す
    int version = titles._PlateVersion();
    if (version == seenVersion || !Utilities.IsValid(target)) return;
    seenVersion = version;
    label.text = titles._PlateOf(target);
}
```

### 5-4. ミニゲームのクリアで、本人だけに渡す

```csharp
// ゲームの結果が全員の端末で決まるときは、本人が参加者かを見てから渡す
public void _OnGameCleared()
{
    VRCPlayerApi local = Networking.LocalPlayer;
    if (!IsParticipant(local)) return; // IsParticipant は自分のゲームの判定（例）
    titles._GrantKey("game_clear");
}
```

### 5-5. 称号の数で身長を変える

`_Listen` で登録し、称号が変わるたびに `_OnTitlesChanged` で本人の身長（目の高さ）を変える例です。

> 移動の速さ・ジャンプ力・重力を称号で変えるだけなら、コードを書かずに「称号の効果」（TitlePerk。01 の 7-11）で作れます。この例は、それ以外の値（身長など）を変えたいときの書き方です。

```csharp
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using WorldTitleGimmick;

public class TitleHeight : UdonSharpBehaviour
{
    public TitleManager titles;
    [Tooltip("称号0個のときの目の高さ（m）")]
    public float baseMeters = 1.2f;
    [Tooltip("称号1個ごとに足す高さ（m）")]
    public float perTitleMeters = 0.1f;
    [Tooltip("目の高さの上限（m）")]
    public float maxMeters = 3f;

    private int lastCount = -1;

    private void Start()
    {
        if (titles != null) titles._Listen(this);
    }

    // 所持・肩書き・行動の値が変わったときに呼ばれる（行動の値で頻繁に呼ばれるので、数が変わったときだけ動かす）。
    public void _OnTitlesChanged()
    {
        int count = titles._OwnedCount();
        if (count == lastCount) return;
        lastCount = count;
        Apply();
    }

    // アバターを変えると身長が戻ることがあるので、変えたときにもう一度当てる。
    public override void OnAvatarChanged(VRCPlayerApi player)
    {
        if (Utilities.IsValid(player) && player.isLocal && lastCount >= 0) Apply();
    }

    private void Apply()
    {
        VRCPlayerApi local = Networking.LocalPlayer;
        if (!Utilities.IsValid(local)) return;
        float meters = Mathf.Min(maxMeters, baseMeters + perTitleMeters * lastCount);
        // ワールドの許す範囲を超える高さにするときは、先に範囲を広げる。
        local.SetAvatarEyeHeightMaximumByMeters(Mathf.Max(maxMeters, local.GetAvatarEyeHeightMaximumAsMeters()));
        local.SetAvatarEyeHeightByMeters(meters);
    }
}
```

- 身長を変えられるのは**本人（ローカルプレイヤー）だけ**です。ほかの人の端末では、その人自身の端末が変えた身長が見えます。
- VRChatが許す目の高さには範囲があります。範囲の外の高さにしたいときは、`SetAvatarEyeHeightMinimumByMeters`・`SetAvatarEyeHeightMaximumByMeters` で範囲を広げる必要があることがあります。範囲の上限・下限の値はSDKの説明を確かめてください。
- `_OnTitlesChanged` は復元の直後にも呼ばれるので、入室したときにも身長が当たります。
- やり直し（`_ResetAll`）で称号が0個になると、`baseMeters` に戻ります。

## 6. Udon Graphから使う

Udon Graphからは、引数のあるメソッド（`_Grant(int)` など）や戻り値のあるメソッド（`_Has` など）を直接呼べません。次の方法を使います。

### 6-1. 称号を渡す（grantKey → Grant）

1. Udon Graphの変数に、型 `UdonBehaviour` の変数を作り、公開（public）にする。名前は例として `titles`。
2. インスペクターで、`titles` に称号マネージャーのGameObjectを入れる。
3. 渡したい場面のノードの後ろに、`UdonBehaviour.SetProgramVariable` を置く。
   - instance：`titles`
   - symbolName：`grantKey`
   - value：渡す称号のキー（例：`rooftop`）
4. その後ろに `UdonBehaviour.SendCustomEvent` を置く。
   - instance：`titles`
   - eventName：`Grant`

### 6-2. カウンターを足す（countKey・countAdd → AddCount）

1. `UdonBehaviour.SetProgramVariable` で symbolName `countKey` に、カウンターの名前（例：`button`）を入れる。
2. `UdonBehaviour.SetProgramVariable` で symbolName `countAdd` に、足す数（int、例：1）を入れる。
3. `UdonBehaviour.SendCustomEvent` で eventName `AddCount` を送る。

`countAdd` は前の値が残ります。毎回入れてください。

### 6-3. 称号を外す・全部やり直す（revokeKey → Revoke、ResetAll）

- 外す：`UdonBehaviour.SetProgramVariable` で symbolName `revokeKey` に外す称号のキーを入れ、`UdonBehaviour.SendCustomEvent` で eventName `Revoke` を送る。
- 全部やり直す：`UdonBehaviour.SendCustomEvent` で eventName `ResetAll` を送る。確認はありません。
- 称号やり直しの部品（TitleReset）を置いているときは、その部品へ eventName `Run` を送ると、確認なしで部品の設定どおりに行います（やり直したあとの物の切り替え・イベントも行う）。

### 6-4. カウンター部品を押す（TitleCounter の Add）

シーンに TitleCounter を置いているときは、その部品の Add を呼ぶだけで、部品の「1回に足す数」（Add Amount）だけ増え、「回数」（Steps）の段の称号も渡ります。

1. 型 `UdonBehaviour` の公開変数を作り、TitleCounter のGameObjectを入れる。
2. `UdonBehaviour.SendCustomEvent` で eventName `Add` を送る。

### 6-5. 部品からUdon Graphへイベントを送る

称号エリア・称号アクションの結果として、Udon Graphのイベントを呼べます。

1. Udon Graphに `Custom Event` ノードを置き、名前を付ける（例：`OnRooftop`）。
2. 部品のインスペクターの「詳しい設定」→「イベントを送る（Udon Graph など）」で、「イベントの送り先」（Event Targets）にそのUdon GraphのGameObjectを入れる。
3. 「送るイベントの名前」（Event Names）の同じ番号に `OnRooftop` と書く。

部品が結果を出したとき（条件を満たして動いたとき。もう持っている称号しか渡さない場合も）に、本人の端末でだけ呼ばれます。

称号やり直し（TitleReset）は、「詳しい設定」→「やり直したあとに」の「イベントの送り先」（Event Targets）と「送るイベントの名前」（Event Name。1つの名前を全部の送り先へ）で、やり直したあとにイベントを送ります。

### 6-6. 持っているかをUdon Graphで知る（称号ゲートのイベント）

`_Has` をUdon Graphから直接呼べないので、称号ゲートのイベントを使います。

1. 空のGameObjectに TitleGate を付け、「条件の称号」（Title Keys）に称号を選ぶ（「条件」Mode：0 持っている／1 装備している）。
2. 「詳しい設定」→「イベントを送る（Udon Graph など）」の「イベントの送り先」（Event Targets）にUdon GraphのGameObjectを入れる。
3. 「満たしたときに送るイベント」（Met Event）に例として `OnHasVip`、「満たさなくなったときに送るイベント」（Unmet Event）に `OnLostVip` と書く。
4. Udon Graphに同じ名前の `Custom Event` を置き、bool の変数を切り替える。

- 入室の直後は「満たさない」状態から始まります。復元が済んで条件を満たしていれば、そこで「満たしたときに送るイベント」が届きます。「満たさなくなったときに送るイベント」は、一度満たしたあとに満たさなくなったときだけ届きます。

並び順（「肩書きにこの順で並んでいる」Sequence Keys）や枠の中身（「その枠に入っている語」Slot Check Keys）を条件にしたゲートでも、同じようにイベントを受けられます。

### 6-7. 称号を得た・装備を変えたときにイベントを受ける

称号イベント中継（TitleRelay。01 の 7-13）を使います。

1. 物に TitleRelay を付ける（右クリック「World Title Gimmick」→「称号をもらったら Udon Graph へイベントを送る」）。
2. 「送り先」に Udon Graph の付いた物を入れる。
3. 「もらったとき」などにイベントの名前を入れる（初期値 `OnTitleGranted`）。Udon Graph で同じ名前の Custom Event を作る。
4. どの称号か知りたいときは、Udon Graph に string の公開変数（例：`titleKey`）を作り、TitleRelay の Key Variable に `titleKey` と入れる。イベントの前にキーが入る。

特定の称号を持っている間ずっと何かしたいときは、6-6 の称号ゲートのイベントも使えます。

### 6-8. 称号を明かす（revealKey・revealWhat → Reveal）

- `UdonBehaviour.SetProgramVariable` で symbolName `revealKey` に明かす称号のキー、`revealWhat` に明かすもの（1 名前 / 2 取得条件 / 3 両方）を入れ、`UdonBehaviour.SendCustomEvent` で eventName `Reveal` を送る。
- 新しく明かしたときは、獲得の知らせの板に「称号のヒントを見つけました」を出します。
- 部品で明かすときは、称号エリア・称号アクションの「明かす称号（ヒント）」を使うほうがかんたんです（01 の 7-2）。

### 6-9. 記録を書く（recordKey・recordValue → SetRecord）

- `UdonBehaviour.SetProgramVariable` で symbolName `recordKey` に記録の称号のキー、`recordValue` に値（int。1以上）を入れ、`UdonBehaviour.SendCustomEvent` で eventName `SetRecord` を送る。
- 前より良いときだけ保存し、知らせを出します。値の単位は記録の書式に合わせます（「時間」なら0.01秒単位：12.34秒は 1234）。

## 7. 復元の前に呼んだとき

入室してから、本人のPlayerDataの復元が済むまで数秒かかることがあります。`_Restored()` がfalseの間は次のように扱います。

| 呼んだもの | 復元前の扱い |
|---|---|
| `_Grant`・`_GrantKey`・`_GrantIds`・`_GrantIdsWith`・`Grant` | 覚えておき、復元の直後にまとめて渡す（32件まで。それを超えた分は捨てる） |
| `_AddCount`・`AddCount` | **何もしない（捨てる）** |
| `_Revoke`・`_RevokeKey`・`_RevokeIds`・`Revoke`・`_ResetAll`・`ResetAll`・TitleReset | 何もしない |
| TitleCounter の `Add` | 何もしない |
| `_SetPlate` | 何もせず false を返す |
| `_SetShowNameplates` | 今の表示は切り替えるが、保存しない |
| `_SetPublishPlate`・`_ToggleLanguage`・`_RevealIds`・`Reveal` | 何もしない |
| `_Has`・`_Equipped`・`_GetCount`・`_GetStat`・`_GetRecord` | 保存前の値（false・0）を返す（最初から使える接続語の `_Has` は true） |
| `_SetRecord`・`SetRecord` | **何もしない（捨てる）**。false を返す |

入室直後に数えたいときは、`_Restored()` を確かめてから呼ぶか、`_OnTitlesChanged`（復元の直後に呼ばれる）で始めてください。

部品（称号エリア・称号アクション・カウンター）も、復元前は動きません。

## 8. 保存のキー

本人のPlayerDataに、次のキーで書きます。`<頭>` は称号マネージャーの「保存のキーの頭」（Key Prefix。初期値 `wtg.`）です。

| キー | 型 | 中身 | 書くとき |
|---|---|---|---|
| `<頭>own2` | bytes | 所持のビット列（IDのn番目のビット。ID 11000まで、最大1,376バイト）。解禁した接続語も入る。持っている一番大きいIDのバイトまで | 称号をもらった・外したとき、やり直したとき |
| `<頭>plate2` | bytes | 肩書きの10枠×2バイト（上位バイトが先。下15ビットがID） | 肩書きを決定したとき、外した称号が入っていたとき、やり直したとき |
| `<頭>cnt.<名前>` | int | カウンター | 60秒ごと・称号をもらったとき（変わったものだけ）、やり直したとき（0） |
| `<頭>rvn`・`<頭>rvd` | bytes | 明かした称号のビット列（`rvn` 名前・`rvd` 取得条件。形は `own2` と同じ） | 称号を明かしたとき（部品・ほかの人の装備）、やり直したとき |
| `<頭>st.<名前>` | int | 行動の値（数えている値だけ） | 60秒ごと・称号をもらったとき、やり直したとき（数えている値と0でない値を0に） |
| `<頭>rec.<キー>` | int | 記録の称号の記録（版があれば `<頭>rec.<キー>.v<版>`。表の「保存のキー」（Record Save Key）を指定したときはそのキー。版があれば、そのキーにも `.v<版>` が付く） | 記録を更新したとき（すぐ）、やり直したとき（`<頭>rec.` の分だけ0） |
| `<頭>visit.last` | int | 最後に来訪を数えた日（yyyymmdd） | 入室した日が変わったとき、やり直したとき（0） |
| `<頭>show` | int | 名札の設定（1 出す / 2 出さない。なければ初期値） | ボードで切り替えたとき |
| `<頭>pub` | int | 自分の肩書きをほかの人に見せるか（1 見せる / 2 見せない。なければ見せる）。ほかの人の端末がこれを読み、2 なら名札・一覧に出さない | ボードで切り替えたとき |
| `<頭>lang` | int | 見る人がボードで選んだ言語（1 日本語 / 2 English。なければマネージャーの「言語」どおり） | ボードの言語のボタン（`_ToggleLanguage`）を押したとき |

- 来訪の日数は `<頭>st.visit_days`、滞在時間は `<頭>st.stay_min` に入ります。
- 復元の前には書きません（空の値で上書きしないため）。
- ほかのアセットのキーと重ならないよう、「保存のキーの頭」（Key Prefix）を決めてください。公開後に変えると、それまでの保存を読めなくなります。
- 保存しないカウンター（カウンター部品の「保存する」がオフ）は書きません。

## 9. 記録の称号を書く・読む

記録の称号（01 の 6-6）は、コードから記録を書きます。

```csharp
// ゴールしたとき：かかった時間を 0.01 秒単位の整数にして書く（書式「時間」なら「最速タイム 12.34秒」と出る）。
int value = Mathf.RoundToInt((Time.time - startedAt) * 100f);
bool better = titles._SetRecord("best_time", value);
```

- 前より良いとき（初めての記録を含む）だけ保存して true を返します。良い方向は表の「小さいほど良い記録（タイムなど）」（Record Lower Better）で決めます。
- 値は1以上の整数です。0以下は無視します（0は「記録なし」）。
- 保存はすぐ書きます。書くたびに同じインスタンスの人へ配られるので、毎フレーム書かないでください。
- 読むときは `_GetRecord("best_time")`（本人）、`_GetRecordOf(player, "best_time")`（ほかの人）です。
- 記録が届いたかは `_RecordReaches("best_time", 1500)`。表の条件 `record:best_time>=1500` や、称号ゲートの「記録の称号」（Record Key）でも見られます。
- 見本：`Samples/ExampleScene/Scripts/ExampleRace.cs`（03 の 19-1）。
