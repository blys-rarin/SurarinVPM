# World Title Gimmick Manual 3: Setup Examples (Ways to Get Titles and What Titles Can Do)

> This is the English translation of the Japanese manual (../03_Examples.md). If they differ, the Japanese version is correct.

This manual lists everything you can do with inspector settings alone, **with examples and setup steps**.

- The meaning of each field of each component is in "01_Inspector.md" (called "01" below). This manual explains "what to put where when you want to do something".
- For using it from UdonSharp or Udon Graph, read "02_Code.md" (called "02" below).
- Features from 01, section 14 (features we decided not to include) are not in this manual.
- **Every example here can be tried in the example scene**. Build the scene with the menu "World Title Gimmick → 見本のシーンを作る（Build Example Scene・説明書 03 の例）" (Build Example Scene, examples of manual 03) and press Play (01, section 4). In the example scene, seconds and counts are set to small numbers so they are easy to test (the signs say so).

## Reading order

1. **First look at "15. Combination examples"** to get an idea of what you can make. Then look at the applied **"18. How to use it in different kinds of worlds"** (for example, using hidden "内部用" (internal) titles as save markers). (In the example scene, this is area A, right behind the lobby. A-1 is section 15, A-2 is section 18.)
2. Use the numbers in the "Setup" of an example close to what you want to make (1-1, 8-4, and so on) to look things up in **sections 1–13, the "list of available conditions"** (area B in the example scene).
3. Read section 14 (code) only when the inspector is not enough. All the examples up to there can be made with the inspector alone.

## Table of contents

- **Read first: section 15 (combination examples), then section 18 (by kind of world, applied use)**
- 0. How to read this manual
  - 0-1. The shape of an example
  - 0-2. How field names are written
  - 0-3. What to do first in every example
  - 0-4. The basics of checking
- **Part 1: Getting titles**
- 1. Give titles with a Title Area (enter a place, place an object)
  - 1-1. When the player enters an area
  - 1-2. When the player leaves an area
  - 1-3. When the player stays in an area for N seconds in a row
  - 1-4. When the player stays in an area for N seconds in total (saved)
  - 1-5. When the player enters an area N times
  - 1-6. When an object is carried into an area (give to the person holding it)
  - 1-7. When an object is placed in an area (give to the last person who held it)
  - 1-8. When several objects are placed together
  - 1-9. When an object on a chosen layer enters
- 2. Give titles with a Title Action (use an object)
  - 2-1. When grabbed
  - 2-2. When dropped
  - 2-3. When used while held (trigger)
  - 2-4. When touched (Interact)
  - 2-5. When held for N seconds
  - 2-6. When thrown
  - 2-7. When moved N m while held
  - 2-8. When done N times (count and save)
- 3. Give titles with a counter (number of presses)
  - 3-1. When a button is pressed 10 times
  - 3-2. Different titles at 10, 100, and 1000 presses
  - 3-3. Count many at once
  - 3-4. Add up counts from other components and give a title
  - 3-5. Stop counting by pressing, and count from other Udon instead
  - 3-6. When several triggers are all met (All Of)
- 4. Give titles with table conditions only (no components)
  - 4-1. By counter value (`count:`)
  - 4-2. By stat (`stat:`): examples of every name
  - 4-3. By number of titles owned (`owned>=`)
  - 4-4. When all chosen titles are collected (`all:`)
  - 4-5. Chain conditions (titles that bring more titles)
  - 4-6. Limited time (`date:`)
  - 4-7. Add many at once with sample packs
- 5. Unlock connectors
  - 5-1. Unlock with a table condition
  - 5-2. Unlock with a component's result
- 6. Add prerequisites (give only when ...)
  - 6-1. Only people who own this title (Required Keys)
  - 6-2. Do not give to people who own this title (Forbidden Keys)
  - 6-3. Only people who have this title equipped (Equipped Keys)
  - 6-4. Only people holding this object (Held Objects)
  - 6-5. Only when N or more people are present (player count at least)
  - 6-6. Only VR players / only desktop players ("端末" Device)
  - 6-7. Combine prerequisites
- 7. Give many times / leave a gap ("一度だけ" (Once), "次に反応するまでの秒数" Cooldown Seconds)
- **Part 2: What titles can do**
- 8. Switch objects with a Title Gate
  - 8-1. Show only to people who own the title
  - 8-2. A floor only title owners can stand on (collision)
  - 8-3. Show an object only to title owners
  - 8-4. Show a wall to people without the title (objects shown until met)
  - 8-5. Invert: hide on the owner's screen
  - 8-6. An object only title owners can grab ("満たしたら掴める物" Pickup Objects)
  - 8-7. Only people who have it equipped
  - 8-8. All, any, or N of them
  - 8-9. By plate order ("肩書きにこの順で並んでいる" Sequence Keys)
  - 8-10. When a chosen word is in a chosen slot ("枠の番号", "その枠に入っている語" Slot Check)
  - 8-11. By number of titles owned ("持っている称号の数がこれ以上" Min Owned)
  - 8-12. By stat ("行動の値", "行動の値がこれ以上" Stat Name, Stat Min)
  - 8-13. Send events when the condition becomes met / no longer met
  - 8-14. Stack conditions
- 9. Use titles as "keys" to run other components
- 10. Unlock plate slots
- 11. What component results can do (besides titles)
  - 11-1. Add to a counter ("足すカウンターの名前", "カウンターに足す数" Counter Key, Counter Add)
  - 11-2. Send events to Udon Graph and others ("イベントの送り先", "送るイベントの名前" Event Targets, Event Names)
  - 11-3. Show or hide objects ("本人の画面で出す物", "本人の画面で消す物" Enable Objects, Disable Objects)
- 12. Reset / remove titles
  - 12-1. A button that resets everything
  - 12-2. A button that removes only chosen titles
  - 12-3. Restore objects and send events after a reset
- 13. Decide how things look on the board and nameplates
  - 13-1. Make nameplates lighter / change colors
  - 13-2. Hide your own nameplate
  - 13-3. Match Japanese or English to the viewer
- 13A. Title Perks (speed, jump power, gravity)
  - 13A-1. Run faster when a title is equipped
  - 13A-2. Jump lightly when "月の住人" (Moon Dweller) is equipped
  - 13A-3. Show objects only while the perk is active
- 13B. Roster Board (plates of everyone present)
- 13C. Notify Udon Graph when a title is received (TitleRelay)
- 13D. Bring up the board on the spot (Title Notebook)
- 13E. Title hints (reveal the name and unlock condition)
  - 13E-1. Reveal the name and unlock condition with a hint button
  - 13E-2. Step-by-step hints (name → unlock condition)
  - 13E-3. Reveal titles other people have equipped
- 14. Use from code
- **Part 3: Combination examples**
- 15. Combination examples
  - 15-1. Stamp rally
  - 15-2. Puzzle: clues → password door → inner room
  - 15-3. Event: when everyone gathers
  - 15-4. Rank titles (10, 100, 1000 times) and a room opened by rank
  - 15-5. A branching route (only one of the two)
  - 15-6. Hidden titles, and a special connector for people who collected them all
  - 15-7. A button only title owners can press
  - 15-8. A limited title for Halloween week, and a room with limited costumes
- 16. Summary of cautions
- 17. Check when you are done
- **Part 4: Using it in various worlds**
- 18. How to use it in different kinds of worlds
  - 18-1. Athletic course: checkpoints and shortcuts
  - 18-2. Puzzle / escape: keep solved doors open
  - 18-3. Story / horror: skip guides and scenes already seen
  - 18-4. Hangout: a room only regulars can enter
  - 18-5. Event / exhibition: visit souvenirs and stamps
  - 18-6. Exhibit / gallery: mark works already seen
  - 18-7. Mini-game: skip the tutorial, ranks
  - 18-8. Role-play: choose a job and use the job's tools
  - 18-9. Your own home: remember preferred settings
  - 18-10. Cautions when using titles as "save markers"
- **Part 5: Extra settings**
- 19. Extra settings (records, player count, period, popups, people inside, steps, hitting, pressability, counters that are not saved)
  - 19-1. Record title: best time
  - 19-2. Player count limits and period
  - 19-3. Do not show the unlock popup / change the sound effect
  - 19-4. When an object is put in, give to everyone inside the area
  - 19-5. When N people are in the area
  - 19-6. Action steps (A at 3 times, B at 6 times)
  - 19-7. When it hits another object
  - 19-8. Only title owners can press it (switch Interact with a gate)
  - 19-9. Counters that are not saved
  - 19-10. The short forms `visit>=` and `stay>=`, and testing with all titles owned

## 0. How to read this manual

### 0-1. The shape of an example

Every example has this shape.

- **Goal**: one line.
- **Setup**: numbered steps.
- **How to check**: how to see that it worked.

Table row examples are written like this. Fields not shown can stay empty or at their default values.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `rooftop` | 屋上の住人 (Rooftop Dweller) | (empty) |

### 0-2. How field names are written

A component's inspector is laid out from top to bottom as: "Udon fields (interact distance and so on; the parts you normally do not touch are folded into "Udon の設定" (Udon settings))" → "a sentence saying what the current settings will do" → "commonly used fields" → "詳しい設定" (Advanced settings, folded) (01, 7-0-1).

- **Commonly used fields** are shown with Japanese names. In this manual they are written like "渡す称号" (Grant Keys) or "きっかけ" (Trigger).
- **詳しい設定 (Advanced settings)**: when you click the triangle to open it, the inside is split into foldouts by group (such as "前提の条件（このときだけ動く）" (Prerequisites) and "称号のほかに起こすこと" (Besides the title)). This manual writes the group and the field name, like "詳しい設定 (Advanced settings) → 条件の数・反転 (Condition count / invert) → **このうち何個でよいか (Required Count)**". Group names are sometimes written without the part in parentheses (for example, "前提の条件").
- A group that has something set is shown with a bold name and "（設定あり）" (has settings).
- All field names are shown in Japanese. The English in parentheses (Required Count and so on) is the name shown at the end of the tooltip when you hover over the field (older versions of the inspector showed these English names). Notes added to field names (such as "（0 なら見ない）" (0 = ignore)) are sometimes left out.
- The fields of the table (Title Database) are also shown with Japanese names. Table headers in examples are written like "キー (Key)", "語 (Word)", "条件 (Condition)".
- For fields that choose titles, add a row with "＋ 称号を足す" (+ Add title), and choose from the list shown as "word　[key]".

### 0-3. What to do first in every example

1. Use the menu "World Title Gimmick → シーンに称号システムを置く (Add Title System To Scene)" to put the title system in the scene (01, section 5).
2. In the Title Manager's "称号の表" (title table), choose the table to use.
3. Add the title rows from the example to "称号の行" (Rows) of the table (Title Database) (01, section 6). Always fill in Key and Word.

- When adding a component, right-click the object in the Hierarchy and use the "World Title Gimmick" menu. It also adds missing colliders and so on (01, 7-0). For components that have no menu entry, use Add Component (they are listed under "World Title Gimmick" with Japanese names like "称号ゲート（TitleGate）" (Title Gate). Typing `TitleGate` or similar in the search box also finds them).
- The component's "称号マネージャー（空なら自動）" (Manager, automatic if empty) field (詳しい設定 (Advanced settings) → つなぎ (Links)) can stay empty. It is filled in automatically before Play.
- After editing the table, you can press Play right away. Baking is done automatically before Play.

### 0-4. The basics of checking

- Run it with Play (or Build & Test). When you get a title, the popup "New title unlocked!" appears from the bottom of your view.
- If the title is shown in a dark color in the list on the Title Board, you own it.
- For other people's overhead nameplates, and for examples that need several people, check with Build & Test by opening two or more VRChat clients.
- Titles are saved, so when you try the same example again, it helps to place a "reset button" (12-1).
- Right after joining the world (a few seconds until saved data finishes loading), components do not work. Wait a little before testing.

---

# Part 1: Getting titles

## 1. Give titles with a Title Area (enter a place, place an object)

A Title Area (TitleArea) works when "the local player" or "chosen objects" enter an Is Trigger collider, and so on. For the meaning of the fields, see 01, 7-3.

### 1-1. When the player enters an area

**Goal**: give "屋上の住人" (Rooftop Dweller) to people who climb to the rooftop.

| キー (Key) | 語 (Word) | 持っているときの説明 (Desc After) |
|---|---|---|
| `rooftop` | 屋上の住人 (Rooftop Dweller) | 屋上に登る (Climb to the rooftop) |

**Setup**

1. Right-click an empty spot in the Hierarchy → "World Title Gimmick" → "エリアに入ったら称号を渡す" (Give title on entering area). An object named "称号エリア" (Title Area) is created (with an Is Trigger BoxCollider).
2. Move it to the rooftop and adjust its size.
3. In "渡す称号" (Grant Keys), click "＋ 称号を足す" (+ Add title) → choose "屋上の住人　[rooftop]".
4. Leave "何が入ったら" (Who) as "本人（プレイヤー）" (Local player) and "きっかけ" (Trigger) as "入ったら" (On enter).

**How to check**: press Play and enter the rooftop. The popup appears.

### 1-2. When the player leaves an area

**Goal**: give "脱出者" (Escapee) to people who get out of a maze.

**Setup**

1. Make an area that covers the whole inside of the maze, the same way as 1-1.
2. Set "きっかけ" (Trigger) to "出たら" (On exit).
3. In "渡す称号" (Grant Keys), choose "脱出者" (Escapee).

**How to check**: go into the maze and leave through the exit. The popup appears.

- Just standing outside without entering does nothing (it works when you leave after entering).
- If you use "出たら" (On exit) with objects (1-6 to 1-9), it works only on the screen of the person who was the receiver when the object was put in. It cannot be used for "taking out" an object that was placed inside the area from the start.

### 1-3. When the player stays in an area for N seconds in a row

**Goal**: give "滝行の人" (Waterfall Monk) to people who stand under a waterfall for 30 seconds in a row.

**Setup**

1. Make an area under the waterfall (1-1, steps 1–2).
2. Set "きっかけ" (Trigger) to "続けてN秒いたら" (Stay N seconds in a row). "秒数" (Seconds) appears; set it to `30`.
3. In "渡す称号" (Grant Keys), choose "滝行の人" (Waterfall Monk).

**How to check**: stand there for 30 seconds and the popup appears. If you leave partway, the count starts over.

- It counts every 1 second. Leaving resets it to 0.

### 1-4. When the player stays in an area for N seconds in total (saved)

**Goal**: give "湯治客" (Hot Spring Guest) to people who soak in a hot spring for a total of 10 minutes. The count continues even across days.

**Setup**

1. Make an area at the hot spring.
2. Set "きっかけ" (Trigger) to "合計N秒いたら（保存）" (Stay N seconds in total, saved) and "秒数" (Seconds) to `600`.
3. In 詳しい設定 (Advanced settings) → 保存 (Save), enter `onsen_sec` in **保存の名前 (Save Key)** (the total seconds are saved to a counter with this name).
4. In "渡す称号" (Grant Keys), choose "湯治客" (Hot Spring Guest).

**How to check**: for testing, set "秒数" (Seconds) to something like `10`. Stay 5 seconds and leave → stay another 5 seconds and the popup appears. If a save name is set, the count continues even after rejoining the world.

- If the save name (Save Key) is empty, the total lasts only for that visit.
- `onsen_sec` is a normal counter, so you can also give another title with the table condition `count:onsen_sec>=3600` (1 hour in total) (4-1).

### 1-5. When the player enters an area N times

**Goal**: give "ジム通い" (Gym Regular) to people who enter the gym 5 times.

**Setup**

1. Make an area at the gym entrance.
2. Set "きっかけ" (Trigger) to "N回入ったら" (Enter N times) and "回数" (Count) to `5`.
3. If you want to keep counting after rejoining, enter `gym_enter` in 詳しい設定 (Advanced settings) → 保存 (Save) → **保存の名前 (Save Key)**.
4. In "渡す称号" (Grant Keys), choose "ジム通い" (Gym Regular).

**How to check**: go in and out of the area 5 times and the popup appears.

### 1-6. When an object is carried into an area (give to the person holding it)

**Goal**: give "灯り運び" (Torchbearer) to people who carry a torch to the back of a cave while holding it.

**Setup**

1. Add VRC Pickup, Rigidbody, and Collider to the torch object (a Pickup object usually has them already).
2. Right-click at the back of the cave → "World Title Gimmick" → "エリアに物を置いたら称号を渡す" (Give title on placing object in area). An area is created with "何が入ったら" (Who) set to "指定した物" (Specified objects).
3. Put the torch in "入る物" (Objects).
4. Leave 詳しい設定 (Advanced settings) → 物が入ったとき (When an object enters) → "誰に渡すか" (Receiver) as "その物を持っている人" (Person holding the object).
5. In "渡す称号" (Grant Keys), choose "灯り運び" (Torchbearer).

**How to check**: while holding the torch in your hand, put the torch into the area and the popup appears. If you let go and throw it in, it does not appear.

- If you want the rule to be "the player enters the area + is holding the torch", you can also build it the way shown in 6-4 (only people holding this object).

### 1-7. When an object is placed in an area (give to the last person who held it)

**Goal**: give "供え人" (Offerer) to people who place a gem on an altar.

**Setup**

1. Add VRC Pickup, Rigidbody, Collider, and **VRC Object Sync** to the gem (with Object Sync, the person who grabs it becomes its owner).
2. Right-click above the altar → "World Title Gimmick" → "エリアに物を置いたら称号を渡す" (Give title on placing object in area).
3. Put the gem in "入る物" (Objects).
4. Set 詳しい設定 (Advanced settings) → 物が入ったとき (When an object enters) → "誰に渡すか" (Receiver) to "最後に持った人（持ち主）" (Last holder (owner)). **If you do not change this, nobody receives it when the gem is placed (after letting go).**
5. In "渡す称号" (Grant Keys), choose "供え人" (Offerer).

**How to check**: grab the gem and place it on the altar. The popup appears for the person who placed it. If you test with two people in Build & Test, only the person who placed it gets the title.

### 1-8. When several objects are placed together

**Goal**: give "宝石の守り手" (Gem Keeper) to people who place all 3 gems on the altar.

**Setup**

1. Build it the same way as 1-7, and put the 3 gems in "入る物" (Objects).
2. In 詳しい設定 (Advanced settings) → 物が入ったとき (When an object enters), set **同時に入る物の数 (Object Count)** to `3` and "誰に渡すか" (Receiver) to "最後に持った人（持ち主）" (Last holder (owner)).
3. In "渡す称号" (Grant Keys), choose "宝石の守り手" (Gem Keeper).

**How to check**: nothing appears with 2. The popup appears when you place the 3rd one.

- Only the owner of the gem at the moment the 3rd gem is placed receives it.

### 1-9. When an object on a chosen layer enters

**Goal**: give "ストライカー" (Striker) to people who put any of the balls on the "Ball" layer into a goal (for when there are many balls and adding them one by one is a lot of work).

**Setup**

1. Set the layer of the balls (Pickup, Rigidbody, Collider, VRC Object Sync) to a layer you created, "Ball".
2. Make an area at the goal and set "何が入ったら" (Who) to "指定したレイヤーの物" (Objects on specified layers).
3. In "入る物のレイヤー" (Layers), choose "Ball".
4. If the balls are kicked or thrown in, set 詳しい設定 (Advanced settings) → 物が入ったとき (When an object enters) → "誰に渡すか" (Receiver) to "最後に持った人（持ち主）" (Last holder (owner)).
5. In "渡す称号" (Grant Keys), choose "ストライカー" (Striker).

**How to check**: throw a ball into the goal and the popup appears.

## 2. Give titles with a Title Action (use an object)

A Title Action (TitleAction) works when an object is grabbed, used, and so on. For the meaning of the fields, see 01, 7-4. The check is done on the device of the local player holding the object.

### 2-1. When grabbed

**Goal**: give "剣を抜いた者" (Sword Puller) to people who grab the legendary sword.

**Setup**

1. Right-click the sword object → "World Title Gimmick" → "掴んだら称号を渡す" (Give title on grab). Missing VRC Pickup, Rigidbody, and Collider are also added.
2. In "渡す称号" (Grant Keys), choose "剣を抜いた者" (Sword Puller) ("行動" (Action) is already "掴む" (Grab)).

**How to check**: grab the sword and the popup appears.

### 2-2. When dropped

**Goal**: give "熱がり" (Heat Shy) to people who grab a hot kettle and let go of it.

**Setup**

1. Right-click the kettle → add it with "掴んだら称号を渡す" (Give title on grab).
2. Set "行動" (Action) to "離す" (Drop).
3. In "渡す称号" (Grant Keys), choose "熱がり" (Heat Shy).

**How to check**: grab it and let go, and the popup appears.

- "When placed at a chosen spot" is made with a Title Area, as in 1-7.

### 2-3. When used while held (trigger)

**Goal**: give "お祝い係" (Celebrator) to people who hold a party popper and pop it (pull the trigger).

**Setup**

1. Right-click the party popper → "持って使ったら（トリガー）称号を渡す" (Give title on use (trigger)).
2. In "渡す称号" (Grant Keys), choose "お祝い係" (Celebrator).
3. If desktop players should also be able to use it, set **Auto Hold** of VRC Pickup to Yes.

**How to check**: grab it and pull the trigger (left click on desktop). The popup appears.

### 2-4. When touched (Interact)

**Goal**: give "考古学者" (Archaeologist) to people who examine (click) an old stone monument.

**Setup**

1. Right-click the monument → "触ったら（Interact）称号を渡す" (Give title on Interact). A collider is added if there is none.
2. In "渡す称号" (Grant Keys), choose "考古学者" (Archaeologist).
3. To change the text shown when pointing at the object, set 詳しい設定 (Advanced settings) → 押す（Interact） (Interact) → **物に向けたときに出る文字（Interact） (Interact Text)** to something like `調べる` (Examine).

**How to check**: point at the monument and "調べる" (Examine) appears. Press it and the popup appears.

### 2-5. When held for N seconds

**Goal**: give "力持ち" (Strongman) to people who keep holding a heavy rock for 20 seconds.

**Setup**

1. Right-click the rock → "掴んだら称号を渡す" (Give title on grab).
2. Set "行動" (Action) to "持ったままN秒" (Hold for N seconds) and "秒数" (Seconds) to `20`.
3. In "渡す称号" (Grant Keys), choose "力持ち" (Strongman).

**How to check**: hold it for 20 seconds and the popup appears. If you let go partway, the count starts over.

### 2-6. When thrown

**Goal**: give "豪腕" (Strong Arm) to people who throw a ball fast.

**Setup**

1. Right-click the ball → "投げたら称号を渡す" (Give title on throw).
2. Set "投げる速さ（m/s）" (Throw Speed) to `8` (the default is 5. The larger it is, the harder you must throw for it to count).
3. In "渡す称号" (Grant Keys), choose "豪腕" (Strong Arm).

**How to check**: throw hard and the popup appears. It does not appear if you let go gently.

### 2-7. When moved N m while held

**Goal**: give "旗手" (Flag Bearer) to people who run 100 m while holding a flag.

**Setup**

1. Right-click the flag → "掴んだら称号を渡す" (Give title on grab).
2. Set "行動" (Action) to "持ったままN m動く" (Move N m while holding) and "距離（m）" (Meters) to `100`.
3. In "渡す称号" (Grant Keys), choose "旗手" (Flag Bearer).

**How to check**: for testing, set "距離（m）" (Meters) to `10`. Hold it and walk, and the popup appears.

- Large moves at once (such as teleports) are not counted.

### 2-8. When done N times (count and save)

**Goal**: give "太鼓の達人" (Drum Master) when the number of times a drum is hit (Interacted with) reaches 50. The count continues after rejoining.

**Setup**

1. Right-click the drum → "触ったら（Interact）称号を渡す" (Give title on Interact).
2. Set "回数" (Required Count) to `50`.
3. In 詳しい設定 (Advanced settings) → 回数の保存 (Saving the count), enter `taiko` in **回数を保存する名前 (Save Key)** (saves the count).
4. In "渡す称号" (Grant Keys), choose "太鼓の達人" (Drum Master).

**How to check**: for testing, set "回数" (Required Count) to `3`. The popup appears on the 3rd time.

- Any "行動" (Action) can have a count ("掴む" (Grab) 10 times, "投げる" (Throw) 10 times, and so on).
- If you want steps (title A at 10 times, title B at 100 times), use the save name `taiko` in table conditions (4-1).

## 3. Give titles with a counter (number of presses)

A counter (TitleCounter) adds to a named count and saves it each time it is pressed (Interact), and gives titles based on the count. For the meaning of the fields, see 01, 7-6.

### 3-1. When a button is pressed 10 times

**Goal**: give "連打の人" (Button Masher) to people who press a button 10 times.

**Setup**

1. Right-click the button object → "World Title Gimmick" → "押した回数で称号を渡す（カウンター）" (Give title by press count (counter)).
2. Check "カウンターの名前（英数字）" (Counter Key). It is filled with only the letters and digits from the object's name (`counter` if the name is Japanese). Change it to `button` so it is easy to understand.
3. The first value of "回数（下の称号と同じ並び）" (Steps) is `10`. In the first entry of "その回数で渡す称号" (Step Keys), choose "連打の人" (Button Masher).

**How to check**: press it 10 times and the popup appears.

### 3-2. Different titles at 10, 100, and 1000 presses

**Goal**: add ranks by the number of presses.

**Setup**

1. In the counter from 3-1, set "回数（下の称号と同じ並び）" (Steps) to three values: `10`, `100`, `1000`.
2. Set "その回数で渡す称号" (Step Keys) to three titles in the same order: "見習い" (Novice), "常連" (Regular), "名人" (Master).

**How to check**: for testing, set the counts to something like `2`, `4`, `6`.

- Entries with the same index in the two lists form a pair. If the lengths differ, the extra entries are not used.

### 3-3. Count many at once

**Goal**: a golden drum counts as 10 per hit.

**Setup**: set 詳しい設定 (Advanced settings) → 数え方 (How to count) → **1回に足す数 (Add Amount)** to `10`.

- Counters with the same name are shared. If a normal drum (Add Amount 1) and a golden drum (Add Amount 10) have the same **カウンターの名前 (Counter Key)**, they count toward the same total.

### 3-4. Add up counts from other components and give a title

**Goal**: add 1 to `views` each time the player reaches any of 3 lookout points, and give "景色好き" (Scenery Lover) at 5 in total.

**Setup**

1. Place a Title Area (1-1) at each lookout. "渡す称号" (Grant Keys) can be empty.
2. In 詳しい設定 (Advanced settings) → 称号のほかに起こすこと (Besides the title), set **足すカウンターの名前 (Counter Key)** to `views` and **カウンターに足す数 (Counter Add)** to `1`.
3. Turn off "一度だけ" (Once) (count every visit).
4. Add this row to the table.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `views5` | 景色好き (Scenery Lover) | `count:views>=5` |

**How to check**: enter the lookouts 5 times and the popup appears.

- Since 2026-10-28, the steps of a counter component (TitleCounter) ("回数" (Steps) and "その回数で渡す称号" (Step Keys)) are also checked when the counter is increased by another component's "足すカウンターの名前" (Counter Key). If you place a counter component with the same name, you can give titles by steps instead of with a table condition (if it should not be pressed, turn off Interactable).

### 3-5. Stop counting by pressing, and count from other Udon instead

**Goal**: count how many times a mini-game is cleared and give a title at 3 (the clear check is your own Udon).

**Setup**

1. Add TitleCounter to an empty object (Add Component).
2. Turn off 詳しい設定 (Advanced settings) → 押して数える（Interact） (Count by pressing) → **押して（Interact）増やす (Interactable)** (pressing does not increase it).
3. Enter the counter name, counts, and titles the same way as 3-1.
4. From your own Udon, send `Add` to this component (02, 6-4).

### 3-6. When several triggers are all met (All Of)

**Goal**: give "村の英雄" (Village Hero) to people who have done all 3 of these: "ring the bell (Interact)", "throw a stone into the well", and "stand on top of the clock tower". They may be done on different days.

**Setup**

1. Add "触ったら（Interact）称号を渡す" (Give title on Interact) to the bell. The title to give can stay empty.
2. Add "エリアに物を置いたら称号を渡す" (Give title on placing object in area) to the well, and put the stone in "入る物" (Objects). The title to give can stay empty.
3. Add "エリアに入ったら称号を渡す" (Give title on entering area) on top of the clock tower. The title to give can stay empty.
4. Right-click an empty spot in the Hierarchy → "World Title Gimmick" → "いくつかのきっかけを全部満たしたら称号を渡す（条件まとめ）" (Give title when several triggers are all met (All Of)).
5. Put the objects from 1–3 in "まとめる部品" (Parts), and choose "村の英雄" (Village Hero) in "渡す称号" (Grant Keys). Leave "これまでに全部" (Saved) on.

**How to check**: do the 3 in order, and the popup appears on the 3rd. It also appears if you do only 2, rejoin, and then do the last one.

- If you want "all within this visit", turn off "これまでに全部" (Saved).
- You can also give 3 separate titles and combine them with the table condition `all:` (4-4). If you want to show the intermediate titles, 4-4 suits better; if not, All Of suits better.

## 4. Give titles with table conditions only (no components)

If you write a condition in the **条件 (Condition)** of a table (Title Database) row, the title is given automatically without placing any component. For how to write conditions, see 01, section 8. The only comparison is `>=` (at least). You can also build a condition by choosing a type and a number with "条件を選んで作る" (Build a condition) in the Title Editor (01, 6-1) (for example: "行動の値" (stat) → "ジャンプした回数" (jump count) → `1000`).

### 4-1. By counter value (`count:`)

**Goal**: add ranks by the number of drum hits (the save name `taiko` from 2-8).

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `taiko10` | 太鼓の見習い (Drum Novice) | `count:taiko>=10` |
| `taiko100` | 太鼓の名人 (Drum Expert) | `count:taiko>=100` |

**Setup**: just add the rows above to the table.

**How to check**: hit the drum 10 times and "太鼓の見習い" (Drum Novice) appears.

- Names you can use in `count:` are: a counter component's **カウンターの名前 (Counter Key)**, an area's or action's **保存の名前 (Save Key)** and **足すカウンターの名前 (Counter Key)**, and names added from code. If the names are the same, they are the same count.
- Conditions are also re-checked when a player joins the world, so even if you add a condition later, people who have already reached it get the title when they join.

### 4-2. By stat (`stat:`): examples of every name

These are values the gimmick counts automatically (01, 8-2). The following 30 names can be used.

| Name | What it counts | Condition example | Title example |
|---|---|---|---|
| `jumps` | Number of jumps | `stat:jumps>=1000` | 跳ねる人 (Hopper) |
| `respawns` | Number of respawns | `stat:respawns>=10` | 不死鳥 (Phoenix) |
| `walk_m` | Distance walked or run (m) | `stat:walk_m>=10000` | 10kmの旅人 (10 km Traveler) |
| `height_max_m` | Highest height climbed (m, from the world origin Y=0) | `stat:height_max_m>=100` | 雲の上の人 (Above the Clouds) |
| `visits` | Number of times joined the world | `stat:visits>=10` | よく来る人 (Frequent Visitor) |
| `visit_days` | Number of days visited | `stat:visit_days>=7` | 常連 (Regular) |
| `stay_min` | Total time stayed (minutes) | `stat:stay_min>=600` | 住人 (Resident) |
| `met_people` | Total number of people met (counting repeats) | `stat:met_people>=100` | 顔が広い人 (Well Connected) |
| `crowd_max` | Largest number of people together (including yourself) | `stat:crowd_max>=20` | お祭り好き (Crowd Lover) |
| `avatar_changes` | Number of avatar changes | `stat:avatar_changes>=10` | 着せ替え好き (Quick Change) |
| `pickups` | Number of times any object was grabbed | `stat:pickups>=100` | 手癖の人 (Grabby) |
| `visit_streak` | Current number of days visited in a row (goes back to 1 after a missed day) | `stat:visit_streak>=3` | 三日坊主じゃない (Streaker) |
| `visit_streak_max` | Best number of days visited in a row | `stat:visit_streak_max>=7` | 皆勤賞 (Perfect Attendance) |
| `vr_min` | Time spent in VR (minutes) | `stat:vr_min>=600` | VR の住人 (VR Dweller) |
| `desktop_min` | Time spent not in VR (minutes) | `stat:desktop_min>=600` | 画面の向こうの人 (Screen Dweller) |
| `together_min` | Time spent with other people (minutes) | `stat:together_min>=300` | 人なつっこい (Friendly) |
| `fall_max_m` | Highest height fallen (m) | `stat:fall_max_m>=30` | 落ちる人 (Faller) |
| `airtime_s` | Time spent in the air (seconds) | `stat:airtime_s>=600` | 滞空の人 (Airborne) |
| `afk_count` | Number of times gone AFK | `stat:afk_count>=10` | うたた寝 (Dozer) |
| `sits` | Number of times sat in a seat (TitleSeat seats) | `stat:sits>=50` | 腰かける人 (Sitter) |
| `sit_min` | Time spent sitting (minutes) | `stat:sit_min>=120` | くつろぐ人 (Lounger) |
| `uses` | Number of times the trigger was pulled while holding an object | `stat:uses>=500` | 使い手 (User) |
| `near_min` | Time spent near other people (2 m) (minutes) | `stat:near_min>=60` | そばにいる人 (Close By) |
| `welcomes` | Number of times someone joined while you were there | `stat:welcomes>=100` | 出迎えの人 (Greeter) |
| `met_title_holders` | Number of times you met people who own chosen titles | `stat:met_title_holders>=5` | 先輩と会った (Met a Senior) |
| `met_creator` | Number of times you met the creator or other chosen people | `stat:met_creator>=1` | 作者に会った (Met the Creator) |
| `pats` | Number of times you patted someone's head | `stat:pats>=10` | なでる人 (Patter) |
| `patted` | Number of times someone patted your head | `stat:patted>=10` | なでられる人 (Patted) |
| `high_fives` | Number of high fives | `stat:high_fives>=10` | ハイタッチ (High Five) |
| `received_items` | Number of times you received an object handed over by someone (Title Action objects) | `stat:received_items>=5` | 受け取り上手 (Good Catch) |

**Setup**: just write it in the "条件" (Condition) of a table row.

**How to check**: make the number small (for example `stat:jumps>=3`), press Play, and jump 3 times. The popup appears.

- Stats are counted **only for the values used in table conditions or Title Gates (8-12)**. Actions before the condition was added are not counted (for example, if you add `stat:jumps>=1000` after publishing, counting starts from that version).
- `visit_days` is counted by the device's date. `stay_min` goes up by 1 every 60 seconds.
- Walking distance counts only horizontal movement while on the ground. The distance treated as a teleport is changed with the manager's "テレポートとみなす距離（m）" (Teleport Meters).
- `sits` and `sit_min` are counted only on seats that have the seat component TitleSeat. With the "すべての席に付ける" (Add to all seats) button shown in Check Scene (menu "World Title Gimmick → シーンを点検 (Check Scene)"), you can add it to every seat in the scene (01, 7-15).
- For `met_title_holders`, set the manager's "会うと数える称号" (Holder Keys); for `met_creator`, set "会うと数える人の表示名" (Creator Names). Display names can be changed, so do not use `met_creator` titles for prizes and the like.
- `pats`, `patted`, and `high_fives` are counted with avatar contacts (01, 7-16). Some avatars cannot be counted. Check on a real device.
- `received_items` is counted when you grab an object with a Title Action near another person's hand. Add VRC Object Sync to the object so that others can see who is holding it. If you make a Title Action with the action "ほかの人から受け取る（手渡し）" (Receive from another person (hand-over)), that object alone can give a title.
- `near_min` checks the distance to everyone every 1 second. In worlds with many people, it gets a little heavier.

### 4-3. By number of titles owned (`owned>=`)

**Goal**: give "コレクター" (Collector) to people who have collected 20 titles.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `collector` | コレクター (Collector) | `owned>=20` |

**How to check**: for testing, use `owned>=2`. Get 2 other titles, and the popups appear one after another.

- Connectors, record titles, "内部用" (internal) titles, and retired titles are not counted. "コレクター" (Collector) itself is counted once it is received.

### 4-4. When all chosen titles are collected (`all:`)

**Goal**: give "上下を制した人" (Up and Down) to people who have been to both the rooftop and the basement.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `rooftop` | 屋上の住人 (Rooftop Dweller) | (empty; given by the area from 1-1) |
| `basement` | 地下の探検家 (Basement Explorer) | (empty; given by an area) |
| `updown` | 上下を制した人 (Up and Down) | `all:rooftop,basement` |

**How to check**: go to both the rooftop and the basement. After the second popup, "上下を制した人" (Up and Down) appears.

- Separate keys with `,`. You can also write keys of locked connectors.

### 4-5. Chain conditions (titles that bring more titles)

Titles given by conditions are also "owned titles", so they can be used again in `owned>=` and `all:` conditions.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `jump100` | よく跳ぶ人 (Jumper) | `stat:jumps>=100` |
| `walk1k` | 歩く人 (Walker) | `stat:walk_m>=1000` |
| `athlete` | アスリート (Athlete) | `all:jump100,walk1k` |

The moment a player gets "歩く人" (Walker), "アスリート" (Athlete) is given right after it.

### 4-6. Limited time (`date:`)

**Goal**: every year, give "かぼちゃ" (Pumpkin) to people who come to the world during Halloween week (October 25–31).

| キー (Key) | 語 (Word) | 語・英語 (Word En) | 持っているときの説明 (Desc After) | 条件 (Condition) |
|---|---|---|---|---|
| `halloween` | かぼちゃ | Pumpkin | ハロウィンの週に来た (Came during Halloween week) | `date:1025-1031` |

**Setup**: just write it in the "条件" (Condition) of a table row.

**How to check**: for testing, enter today's date (for example, if today is October 28, `date:1028`). Press Play, and the popup appears right after joining.

- How to write it: `date:1025-1031` (every year), `date:20261025-20261031` (2026 only), `date:1031` (only that one day every year), `date:1225-0105` (a yearly period that crosses the new year).
- It is checked on joining and every 60 seconds (people who are in the world at the moment the period starts also get it).
- The date is **the date on the viewer's device**. The time the date changes differs by country. Changing the device's clock lets people get it, so do not use it for prizes.
- Titles received stay even after the period ends.

### 4-7. Add many at once with sample packs

**Goal**: add titles such as "came 7 days" and "1000 jumps" all at once, without placing components.

**Setup**

1. In the Project window, select the title table (Title Database).
2. In the inspector, open "見本の称号を足す（部品なしで動く称号のパック）" (Add sample titles: packs of titles that work without components).
3. From "来訪・滞在" (Visits / stays), "体を動かす" (Moving around), "交流" (Socializing), "称号集め" (Collecting titles), and "よく使う接続語" (Common connectors), press "足す" (Add) for what you want to add (contents are in 01, 6-4).
4. You may freely change the words, descriptions, and numbers of the added rows.

**How to check**: press Play, then jump a few times, join, and so on. Making the numbers small makes it easier to test (for example, change `stat:jumps>=100` to `>=3`).

## 5. Unlock connectors

If you turn on **最初は使えない（解禁する接続語） (Locked Connector)** on a connector row, it cannot be used at first, and only people who unlock it can use it (01, 6-3). When it is unlocked, a popup appears just like for a title, and it is saved.

### 5-1. Unlock with a table condition

**Goal**: only people who have collected 3 titles can use "♛".

| キー (Key) | 分類 (Kind) | 語 (Word) | 条件 (Condition) | 最初は使えない (Locked Connector) | 名前の見せ方 (Name Mode) |
|---|---|---|---|---|---|
| `crown` | 接続語 (connector) | ♛ | `owned>=3` | On | 隠す (hide) |

**How to check**: before it is unlocked, a faint "???" is shown in the connector list on the board, and it cannot be put into a slot. Collect 3 titles and the popup appears, and it becomes usable.

- As with titles, the conditions `count:`, `stat:`, `owned>=`, `all:`, `date:`, `record:`, `visit>=`, and `stay>=` can be used.
- A condition written on a connector whose "最初は使えない" (Locked Connector) is off is not used.

### 5-2. Unlock with a component's result

**Goal**: only people who sang on stage (stayed in the area for 30 seconds) can use "♪".

| キー (Key) | 分類 (Kind) | 語 (Word) | 最初は使えない (Locked Connector) |
|---|---|---|---|
| `note` | 接続語 (connector) | ♪ | On |

**Setup**

1. Make an area on the stage. Set "きっかけ" (Trigger) to "続けてN秒いたら" (Stay N seconds in a row) and "秒数" (Seconds) to `30`.
2. In "渡す称号" (Grant Keys), choose "♪　[note]" (connectors also appear in the "渡す称号" list).

**How to check**: stay for 30 seconds and the popup appears, and "♪" becomes usable on the board.

- Connectors can also be chosen in a counter's "その回数で渡す称号" (Step Keys) and in a reset's "外す称号" (Revoke Keys).
- Choosing a connector that is usable from the start ("最初は使えない" (Locked Connector) off) does nothing.

## 6. Add prerequisites (give only when ...)

Title Areas and Title Actions have prerequisite fields in the "前提の条件（このときだけ動く）" (Prerequisites) group inside "詳しい設定" (Advanced settings) (01, 7-2). If they are not met, nothing happens even when the trigger occurs. Counter components (TitleCounter) have no prerequisites (use the approach in 15-7).

### 6-1. Only people who own this title (Required Keys)

**Goal**: give "騎士" (Knight) to people who own "見習い騎士" (Squire) when they enter the arena (can only be obtained in order).

**Setup**

1. Make an area at the arena and choose "騎士" (Knight) in "渡す称号" (Grant Keys).
2. In 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites) → **この称号を全部持っている人だけ (Required Keys)**, choose "見習い騎士" (Squire).

**How to check**: without "見習い騎士" (Squire), nothing appears when you enter. After getting it, enter again and it appears.

- If you choose several, it works only when the player owns **all** of them.

### 6-2. Do not give to people who own this title (Forbidden Keys)

**Goal**: people who chose "光の道" (Path of Light) cannot get "闇の道" (Path of Darkness) (see also 15-5).

**Setup**: in the Path of Darkness area's 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites) → **この称号を持っている人には渡さない (Forbidden Keys)**, choose "光の道" (Path of Light).

- If you choose several, it does not work if the player owns **any** one of them.

### 6-3. Only people who have this title equipped (Equipped Keys)

**Goal**: give "魔王を倒した者" (Demon Slayer) to people who enter the Demon Lord's room with "勇者" (Hero) in their plate.

**Setup**

1. Make an area in the Demon Lord's room and choose "魔王を倒した者" (Demon Slayer) in "渡す称号" (Grant Keys).
2. In 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites) → **この称号を装備している人だけ (Equipped Keys)**, choose "勇者" (Hero).

**How to check**: just owning "勇者" (Hero) does not make it appear. Put "勇者" (Hero) into your plate on the board, press "Apply", and then enter. It appears.

- It checks the plate saved with "Apply". If you choose several, it works if **any** of them is equipped.

### 6-4. Only people holding this object (Held Objects)

**Goal**: give "ロマンチスト" (Romantic) to people who come to the lookout holding a bouquet.

**Setup**

1. Make an area at the lookout and choose "ロマンチスト" (Romantic) in "渡す称号" (Grant Keys).
2. In 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites) → **この物を手に持っている人だけ (Held Objects)**, put the bouquet object (the object that itself has VRC Pickup).

**How to check**: enter holding the bouquet and it appears. Entering without it does nothing.

- If you put several, it works if the player is holding **any** of them (for example, either a red bouquet or a blue bouquet).
- If you put this on a Title Action, you can also make things like "when you Interact with a treasure chest while holding the key".

### 6-5. Only when N or more people are present (player count at least)

**Goal**: give "パーティーピープル" (Party People) to people who enter the dance floor while 8 or more people are in the instance.

**Setup**: in the dance floor area's 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites), set "人数がこれ以上のとき（0 なら見ない）" (Min Players, 0 = ignore) to `8`.

**How to check**: test with different player counts in Build & Test (with `2`, you can check with two VRChat clients).

- The count is the number of people in the whole instance, including yourself. It is not the number of people inside the area.

### 6-6. Only VR players / only desktop players ("端末" Device)

**Goal**: give "体操選手" (Gymnast) only to people who hang from the iron bar in VR.

**Setup**: in the area's or action's 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites), set **端末 (Device)** to "VR だけ" (VR only).

- "デスクトップだけ" (Desktop only) means only people who are not in VR (people VRChat does not detect as VR).

### 6-7. Combine prerequisites

Prerequisites work only when **all** of the ones you set are met.

**Goal**: give "伝説の勇者" (Legendary Hero) to people who have "勇者" (Hero) equipped, hold the holy sword, and do not own "呪い" (Curse), when they enter the altar while 4 or more people are present.

**Setup** (in the altar area's 詳しい設定 (Advanced settings) → 前提の条件 (Prerequisites))

1. **この称号を装備している人だけ (Equipped Keys)**: "勇者" (Hero)
2. **この物を手に持っている人だけ (Held Objects)**: the holy sword
3. **この称号を持っている人には渡さない (Forbidden Keys)**: "呪い" (Curse)
4. "人数がこれ以上のとき（0 なら見ない）" (Min Players): `4`

- Components that count (enter N times, do N times) still count even while the prerequisites are not met. If the prerequisites are met after the count is reached, the title is given on the next trigger.

## 7. Give many times / leave a gap ("一度だけ" (Once), "次に反応するまでの秒数" Cooldown Seconds)

A title is done once received, but a component's results (counter, events, switching objects) can happen many times.

| Field | How to use |
|---|---|
| "一度だけ" (Once) | On (default): after producing a result once, does nothing for the rest of that visit. Off: produces a result on every trigger |
| **次に反応するまでの秒数 (Cooldown Seconds)** (詳しい設定 (Advanced settings) → くり返し (Repeat)) | Seconds from producing a result until it reacts again (default 0.5) |

**Goal**: a gate that adds 1 to `gates` each time you pass through (but waits 5 seconds so it does not count repeatedly).

**Setup**: turn off the area's "一度だけ" (Once), set 詳しい設定 (Advanced settings) → 称号のほかに起こすこと (Besides the title) → **足すカウンターの名前 (Counter Key)** to `gates`, and set くり返し (Repeat) → **次に反応するまでの秒数 (Cooldown Seconds)** to `5`.

- If you turn off "一度だけ" (Once) with "N回入ったら" (Enter N times) or "N回したら" (do N times), it produces a result every time after the Nth.
- Even with "一度だけ" (Once), if the player already owns all the titles to give and no counter or event is set, it does nothing even after rejoining.

---


# Part 2: What titles can do

## 8. Switch objects with a Title Gate

A Title Gate (TitleGate) shows or hides objects only on the screen of people who meet the condition. For the meaning of the fields, see 01, 7-5.

- **Things switch only on the local player's own screen**. Other people's screens are not affected (this gimmick does not use network sync).
- It re-checks only when the local player's titles, plate, or stats change.
- Right after joining the world (until saved data is loaded), it is treated as "not met".
- Put the gate on a **different object** from the objects it switches (the ones in "満たしたら出す物" (Objects) and "満たすまで出す物（壁など）" (Objects When Not)). If it disables itself, it stops.
- The gate's "commonly used fields": "条件の称号" (Title Keys), "条件" (Mode), "全部そろったら（オフ＝どれか1つ）" (Match All), "満たしたら見える" (Renderers), "満たしたら当たり判定あり" (Colliders), "満たしたら出す物" (Objects), "満たすまで出す物（壁など）" (Objects When Not).

### 8-1. Show only to people who own the title

**Goal**: only people who own "霊感持ち" (Medium) can see a ghost.

**Setup**

1. Right-click the ghost object → "World Title Gimmick" → "称号を持つ人だけに見せる・触れさせる" (Show / make touchable only for title owners). The object and its children's Renderers and Colliders are put into "満たしたら見える" (Renderers) and "満たしたら当たり判定あり" (Colliders).
2. In "条件の称号" (Title Keys), choose "霊感持ち" (Medium). "条件" (Mode) is "持っている" (Owned).
3. If it does not need to be touchable (only visible), clear the contents of "満たしたら当たり判定あり" (Colliders).

**How to check**: without the title, the ghost is invisible. The moment you get the title, it becomes visible.

- If only the visuals are hidden and the collision is kept, it becomes an "invisible wall".

### 8-2. A floor only title owners can stand on (collision)

**Goal**: only people who own "空の住人" (Sky Dweller) can walk on the clouds.

**Setup**

1. Right-click the cloud object → "称号を持つ人だけに見せる・触れさせる" (Show / make touchable only for title owners).
2. If the clouds should be visible to everyone, clear the contents of "満たしたら見える" (Renderers) (switch only the collision).
3. In "条件の称号" (Title Keys), choose "空の住人" (Sky Dweller).

**How to check**: without the title, you fall through the clouds. With it, you can stand on them.

- **Do not switch collision on VRC Object Sync objects or other objects whose position is shared with other people** (collision differs from person to person, and movement goes out of sync; 01, 13-3).

### 8-3. Show an object only to title owners

**Goal**: show the secret recipe book in the back of the kitchen (the whole object, including its children) only to people who own "料理人" (Cook).

**Setup**

1. Create an empty object and add TitleGate with Add Component.
2. In "条件の称号" (Title Keys), choose "料理人" (Cook).
3. Put the recipe book object in "満たしたら出す物" (Objects).

**How to check**: while you do not have the title, the recipe book is inactive (hidden). Once you get it, it appears.

- The whole object is activated and deactivated, so Udon, sounds, and particles inside it also stop.
- If you want to keep the object shown and switch **only components** (for example: a BGM AudioSource plays, a light turns on, or another Udon runs only for title owners), put those components in 詳しい設定 (Advanced settings) → 切り替える物（コンポーネント・掴む・押す） (Things to switch: components, grab, press) → **満たしたら有効にするコンポーネント (Behaviours)** (drag the component's header in the inspector). The other way around, put things you want to stop on the title owner's screen (for example, a guide sound for beginners) in **満たしたら無効にするコンポーネント (Behaviours When Not)**. One gate can use both.

### 8-4. Show a wall to people without the title (objects shown until met)

**Goal**: only people who own "通行証" (Pass) can go through a door.

**Setup**

1. Place a wall (an object with a Collider and a Renderer) at the door.
2. Add TitleGate to a separate empty object.
3. In "条件の称号" (Title Keys), choose "通行証" (Pass).
4. Put the wall in "満たすまで出す物（壁など）" (Objects When Not).

**How to check**: without the title, the wall is there and you cannot pass. Once you get it, the wall disappears. If you test with two people, the wall stays on the screen of the person who does not own it.

- The wall is also shown right after joining (it starts as "not met"), so this approach suits doors where you want to prevent people from slipping through.

### 8-5. Invert: hide on the owner's screen

**Goal**: make the same "wall only title owners can pass" as 8-4, using just the wall object.

**Setup**

1. Right-click the wall object → "称号を持つ人だけ通れる壁にする" (Make a wall only title owners can pass). A gate is added to the wall, the wall is put in "満たしたら見える" (Renderers) and "満たしたら当たり判定あり" (Colliders), and 詳しい設定 (Advanced settings) → 条件の数・反転 (Condition count / invert) → **反転 (Invert)** is turned on.
2. In "条件の称号" (Title Keys), choose "通行証" (Pass).

**How to check**: on the screen of people who own the title, the wall's look and collision disappear.

- When **反転 (Invert)** is on, it switches as "met" on the screen of people who do not meet the condition. You can also use it for "signs shown only to people who do not own the title" (for example, "a guide for people who have not been to the rooftop yet").
- Right after joining (a few seconds until saved data finishes loading), the player is treated as "not owning the title", so an inverted wall **is shown** (fixed on 2026-10-28. In earlier versions, the wall disappeared during this time).

### 8-6. An object only title owners can grab ("満たしたら掴める物" Pickup Objects)

**Goal**: only people who own "魔法使い" (Wizard) can grab the staff (others can see it but cannot grab it).

**Setup**

1. Add TitleGate to an empty object and choose "魔法使い" (Wizard) in "条件の称号" (Title Keys).
2. Put the staff (an object with VRC Pickup) in 詳しい設定 (Advanced settings) → 切り替える物（コンポーネント・掴む・押す） (Things to switch) → **満たしたら掴める物（Pickup） (Pickup Objects)**.

**How to check**: without the title, you cannot grab the staff. Once you get it, you can.

- Whether it can be grabbed switches only on the local player's screen. If you add VRC Object Sync to the staff, the staff moved by the person holding it also moves on other people's screens.

### 8-7. Only people who have it equipped

**Goal**: only people who have "影" (Shadow) in their plate can see a hidden passage.

**Setup**

1. Make a gate the same way as 8-3 and put the hidden passage in "満たしたら出す物" (Objects).
2. In "条件の称号" (Title Keys), choose "影" (Shadow), and set "条件" (Mode) to "装備している" (Equipped).

**How to check**: put "影" (Shadow) into your plate on the board and press "Apply". The passage appears. Remove it and press "Apply", and it disappears.

- Nothing changes before you apply (while you are still arranging on the board).

### 8-8. All, any, or N of them

How it checks when you choose several "条件の称号" (Title Keys).

| Goal | Setup |
|---|---|
| If the player owns any one of them | "全部そろったら（オフ＝どれか1つ）" (Match All) off (default) |
| If the player owns all of them | "全部そろったら（オフ＝どれか1つ）" (Match All) on |
| If the player owns 3 of the 5 | 詳しい設定 (Advanced settings) → 条件の数・反転 (Condition count / invert) → **このうち何個でよいか (Required Count)** set to `3` (takes priority over "全部そろったら" (Match All)) |

**Example**: open a door for people who own 3 of 5 clue titles → put the 5 in "条件の称号" (Title Keys), `3` in **このうち何個でよいか (Required Count)**, and the wall in "満たすまで出す物（壁など）" (Objects When Not).

- If you set "条件" (Mode) to "装備している" (Equipped), it becomes "if 3 are in the plate".
- Only normal titles appear in the "条件の称号" (Title Keys) list (connectors are used in the order and slot conditions).

### 8-9. By plate order ("肩書きにこの順で並んでいる" Sequence Keys)

**Goal**: the moon door opens only for people who made their plate "月の鍵" (Moon's Key) (a password).

**Setup**

1. Add TitleGate to an empty object. "条件の称号" (Title Keys) can stay empty.
2. In 詳しい設定 (Advanced settings) → 肩書きの並び・枠 (Plate order / slots) → **肩書きにこの順で並んでいる (Sequence Keys)**, choose "月" (Moon), "の" (connector "of"), "鍵" (Key) in order (both titles and connectors can be chosen).
3. If no other words may be placed in between, turn on **間にほかの語を挟まない (Sequence Contiguous)**.
4. Put the door's wall in "満たすまで出す物（壁など）" (Objects When Not).

**How to check**: arrange "月", "の", "鍵" on the board and press "Apply". The door opens. "鍵の月" (the reverse order) does not open it.

- Empty slots are skipped when counting. If **間にほかの語を挟まない (Sequence Contiguous)** is off, "月☆の鍵" also meets it.
- Words shown in fixed-word slots are not counted in the order.

### 8-10. When a chosen word is in a chosen slot ("枠の番号", "その枠に入っている語" Slot Check)

**Goal**: the star staircase is visible only when slot 1 is "星" (Star) and slot 3 is "扉" (Door).

**Setup**

1. Add TitleGate to an empty object.
2. In 詳しい設定 (Advanced settings) → 肩書きの並び・枠 (Plate order / slots), enter `1` and `3` in **枠の番号（1〜10） (Slot Check Slots)**, and "星" (Star) and "扉" (Door) in **その枠に入っている語 (Slot Check Keys)**, in the same order.
3. Put the staircase in "満たしたら出す物" (Objects).

**How to check**: put "星" (Star) in slot 1 and "扉" (Door) in slot 3, and press "Apply". It appears.

- Slot numbers are 1–10. If that slot is not unlocked, the condition is not met.

### 8-11. By number of titles owned ("持っている称号の数がこれ以上" Min Owned)

**Goal**: only people who own 10 or more titles can enter the VIP lounge.

**Setup**

1. Add TitleGate to an empty object. Leave "条件の称号" (Title Keys) empty.
2. Set 詳しい設定 (Advanced settings) → 称号の数・行動の値・記録 (Title count / stats / records) → **持っている称号の数がこれ以上 (Min Owned)** to `10`.
3. Put the wall at the lounge entrance in "満たすまで出す物（壁など）" (Objects When Not).

**How to check**: for testing, set it to `2`. Get 2 titles and the wall disappears.

- Only normal titles are counted (connectors, record titles, "内部用" (internal) titles, and retired titles are not counted).

### 8-12. By stat ("行動の値", "行動の値がこれ以上" Stat Name, Stat Min)

**Goal**: show the regulars' seat sign only to people who have visited on 7 or more days.

**Setup**

1. Add TitleGate to an empty object. Leave "条件の称号" (Title Keys) empty.
2. In 詳しい設定 (Advanced settings) → 称号の数・行動の値・記録 (Title count / stats / records) → **行動の値 (Stat Name)**, choose "来訪した日数　[visit_days]" (days visited). **行動の値がこれ以上 (Stat Min)** appears; set it to `7`.
3. Put the sign in "満たしたら出す物" (Objects).

**How to check**: for testing, use "ジャンプした回数　[jumps]" (jump count) with **行動の値がこれ以上 (Stat Min)** `5`. Jump 5 times and it appears.

- The values you can choose are the 30 in 4-2. You can show different things by values alone, without making titles.

### 8-13. Send events when the condition becomes met / no longer met

**Goal**: change the BGM only on the screen of people who have "DJ" equipped (call your own Udon Graph).

**Setup**

1. In Udon Graph, place two `Custom Event` nodes and name them `OnDjOn` and `OnDjOff`.
2. Add TitleGate to an empty object, choose "DJ" in "条件の称号" (Title Keys), and set "条件" (Mode) to "装備している" (Equipped).
3. In 詳しい設定 (Advanced settings) → イベントを送る（Udon Graph など） (Send events: Udon Graph, etc.), put the Udon Graph object in **イベントの送り先 (Event Targets)**, write `OnDjOn` in **満たしたときに送るイベント (Met Event)**, and `OnDjOff` in **満たさなくなったときに送るイベント (Unmet Event)**.

**How to check**: put "DJ" into your plate and apply, and `OnDjOn` is called. Remove it and apply, and `OnDjOff` is called.

- If the condition is already met right after joining, the "満たしたときに送るイベント" (Met Event) arrives after saved data is loaded. The "満たさなくなったときに送るイベント" (Unmet Event) arrives only when the condition stops being met after having been met once (02, 6-6).
- Events are called only on the local player's device.

### 8-14. Stack conditions

The conditions written on a gate (titles, order, slots, number owned, stats, records) become "met" when **all** of them are met.

**Example**: the castle gate opens only for people who have "騎士" (Knight) equipped, own 5 or more titles, and have jumped 100 times.

1. "条件の称号" (Title Keys): "騎士" (Knight), "条件" (Mode): "装備している" (Equipped)
2. **持っている称号の数がこれ以上 (Min Owned)**: `5`
3. **行動の値 (Stat Name)**: "ジャンプした回数　[jumps]" (jump count), **行動の値がこれ以上 (Stat Min)**: `100`
4. "満たすまで出す物（壁など）" (Objects When Not): the gate


## 9. Use a title as a "key" to make other components work

If you put titles in the prerequisites (chapter 6) of a Title Area or Title Action, you can make the component work "only for people who own (or have equipped) the title".

| What you want | Field |
|---|---|
| Works only for people who own it | 詳しい設定 (Advanced settings) → Prerequisites (前提の条件) → **この称号を全部持っている人だけ (Required Keys)** |
| Does not work for people who own it | **この称号を持っている人には渡さない (Forbidden Keys)** |
| Works only for people who have it equipped | **この称号を装備している人だけ (Equipped Keys)** |

**Example**: Only people who own 「鍵師」 (Locksmith) can open the treasure chest (Interact shows its contents).

1. Right-click the treasure chest → 「触ったら（Interact）称号を渡す」 (Give a title on Interact).
2. **渡す称号 (Grant Keys)** can stay empty (no title is given; it only shows objects).
3. In 詳しい設定 (Advanced settings) → Prerequisites (前提の条件), put 「鍵師」 (Locksmith) in **この称号を全部持っている人だけ (Required Keys)**. In Other results (称号のほかに起こすこと), put the chest contents in **本人の画面で出す物 (Enable Objects)**.

**How to check**: Without 「鍵師」 (Locksmith), nothing happens when you press it. With it, the contents appear (only on the local player's screen).

- The contents do not appear for other people. "Open a treasure chest that everyone can see" cannot be made with this component alone (this gimmick does not use network sync).

## 10. Unlock plate slots

**What you want**: At first, only 3 plate slots can be used. People who own 「上級者」 (Advanced) can also use slots 4–6.

**Setup**

1. Select the Title Manager in the Hierarchy.
2. Under 「枠 4」「枠 5」「枠 6」 (Slot 4, 5, 6), set **解禁の称号（なし＝最初から） (Slot Unlock Keys)** to 「上級者」 (Advanced).
3. For slots you do not want people to use (slots 7–10), set the type to 「使わない」 (Unused).

**How to check**: While you do not have the title, slots 4–6 on the board show "Locked" and cannot be chosen. After you get it, you can choose them.

- If the unlock title is removed or reset, the words in those slots are taken off the plate.
- For other people's overhead plates too, this depends on whether that person owns the unlock title.
- How to use slot types (titles only, connectors only, fixed word, unused): 01, section 9-1.

## 11. What components can do with their results (besides titles)

Besides giving titles, a Title Area or Title Action can produce the following results (in 詳しい設定 (Advanced settings) → Other results (称号のほかに起こすこと) and Send events (イベントを送る（Udon Graph など）)). You may use a component only for these, without giving a title. If you put titles in the prerequisites (chapter 6), it becomes "only people who own the title can ...".

### 11-1. Add to a counter (足すカウンターの名前 / カウンターに足す数, Counter Key / Counter Add)

**What you want**: Each time a coin is picked up (grabbed), add 1 to `coins`, and give a title by a table condition.

1. Right-click the coin → 「掴んだら称号を渡す」 (Give a title when grabbed). **渡す称号 (Grant Keys)** can stay empty.
2. Set **足すカウンターの名前 (Counter Key)** to `coins` and **カウンターに足す数 (Counter Add)** to `1`.
3. Turn off **一度だけ (Once)**.
4. Add a row with `count:coins>=30` to the table (4-1).

### 11-2. Send events to Udon Graph and others (イベントの送り先 / 送るイベントの名前, Event Targets / Event Names)

**What you want**: When you enter the goal area, your own Udon Graph launches fireworks.

1. Put a `Custom Event` node named `OnGoal` in the Udon Graph.
2. In the goal area, put the Udon Graph object in **イベントの送り先 (Event Targets)**, and write `OnGoal` at the same index in **送るイベントの名前 (Event Names)**.

- For several targets, line them up: the first name goes with the first target, the second name with the second target, and so on (02, section 6-5).
- The event is called only on the local player's device. If you want everyone to see the fireworks, you need to make it a network event inside the Udon Graph (this is outside this gimmick).

### 11-3. Show and hide objects (本人の画面で出す物 / 本人の画面で消す物, Enable Objects / Disable Objects)

**What you want**: When you Interact with a lever, a bridge appears and the blocking fence disappears.

1. Right-click the lever → 「触ったら（Interact）称号を渡す」 (Give a title on Interact).
2. Put the bridge in **本人の画面で出す物 (Enable Objects)** and the fence in **本人の画面で消す物 (Disable Objects)**.

- This is **only on the local player's screen**. On other people's screens, the bridge is not there.
- Resetting does not undo it. If you want to undo it, put the objects in the reset button (12-3). Objects shown by a Title Gate (chapter 8) go back automatically when the title disappears.

## 12. Reset and remove titles

Title Reset (TitleReset) is a button that resets the titles of the person who pressed it. For what each field means, see 01, section 7-7.

### 12-1. A button that resets everything

**What you want**: A button for people who want to start over (also useful for testing).

**Setup**

1. Right-click the button object → 「World Title Gimmick」 → 「やり直しのボタンにする」 (Make a reset button).
2. Leave **すること (Mode)** as 「全部やり直す」 (Reset everything) and **確認の秒数（0＝1回で実行） (Confirm Seconds)** at `3`.

**How to check**: Press once and a confirmation message ("Press again to reset") appears on the popup board. Press again within 3 seconds and titles, plates, counters, and stats are erased.

### 12-2. A button that removes only chosen titles

**What you want**: Remove only the puzzle titles so the puzzle can be played again (other titles stay).

**Setup**

1. Add it as in 12-1, and set **すること (Mode)** to 「指定の称号を外す」 (Remove chosen titles).
2. In **外す称号 (Revoke Keys)**, choose the puzzle titles (you can also choose unlocked connectors).

- Removed titles are also taken off the plate.
- Titles given by table conditions may be given again the next time the value changes.
- This way does not reset **一度だけ (Once)** on components (it resets when you rejoin the world). Be careful with **一度だけ (Once)** on components you test many times.

### 12-3. Restore objects or send events after resetting

**What you want**: After resetting, hide the bridge shown by the lever (11-3) and bring back the fence.

**Setup**: In the reset button's 詳しい設定 (Advanced settings) → After resetting (やり直したあとに), put the fence in **やり直したあとに出す物 (Enable Objects)** and the bridge in **やり直したあとに消す物 (Disable Objects)**. If you also want to notify an Udon Graph, fill in **イベントの送り先 (Event Targets)** and **送るイベントの名前 (Event Name)**.

## 13. Decide how titles look on the board and nameplates

When you own a title, you can put it into your plate on the board, and it appears on the overhead nameplate other people see. You decide how it looks in these places.

| What you want | Where | Details |
|---|---|---|
| Show the name as "???" before unlocking | Set the table's **名前の見せ方 (Name Mode)** to 「隠す」 (Hidden) | 01, chapter 10 |
| Do not list it until owned (hidden title) | Set the table's **名前の見せ方 (Name Mode)** to 「一覧に出さない」 (Unlisted) | 01, chapter 10 |
| Never show it (a save mark; no popup either) | Set the table's **名前の見せ方 (Name Mode)** to 「内部用」 (Internal) | 01, chapters 10 and 18 |
| A vague description before unlocking, the real one after | The table's **持っていないときの説明 (Desc Before)** and **持っているときの説明 (Desc After)** | 01, section 6-2 |
| Show the name and unlock condition of titles you don't own, as hints | The component's **明かす称号（ヒント） (Reveal Keys)** and the manager's **ほかの人の装備で明かす (Reveal Equipped)** | 01, chapter 10, and section 13E of this manual |
| Order on the board | The table's **ボードでの並び順 (Order)** (smaller comes first) | 01, section 6-2 |
| Show in English | The table's **語（英語。空なら日本語） (Word En)** and others, and the manager's **言語 (Language)** | 01, section 7-1 |
| Fix the form to "[title] 's [title]" | The manager's 「枠 1〜10」 (Slots 1–10) and 「固定の語」 (Fixed word) | 01, section 9-1 |
| Set the plate length | The manager's **文字数の上限 (Max Plate Chars)** | 01, section 7-1 |
| Hide nameplates at first | Turn off the manager's **名札を最初は出す (Show Nameplates Default)** | 01, section 7-1 |
| How popups are shown | The manager's **知らせの出し方 (Popup Mode)** (「1つずつ」 (One by one) / 「まとめて」 (Together)) | 01, section 7-10 |

- The nameplate shows the plate the person has applied ("Apply"). Your own nameplate is not shown to you.
- With 「1つずつ」 (One by one), the popup shows the "description after unlocking" under the title (or the "description before unlocking" if it is empty). It is kind to write it so it reads as the unlock condition.

### 13-1. Make nameplates lighter and change their color

**What you want**: Even at an 80-person event, keep it light by showing nameplates only for the 8 nearest people. Make the text yellow.

**Setup**

1. In the Hierarchy, select 「World Title Gimmick」 → 「Title Nameplates」.
2. Set **これより遠い人には出さない (Hide Meters)** to 15 (hide people farther than 15 m), and **一度に出す数の上限 (Max Shown)** to 8 (up to the 8 nearest people).
3. Set **文字の色 (Text Color)** to yellow, and the A of **背景の色 (Back Color)** to 0 (no background).

**How to check**: Spawn other people in ClientSim. When they move away, their nameplates disappear.

### 13-2. Hide your own nameplate

**What you want**: Keep other people from seeing your plate, for example while taking photos (the player chooses).

**Setup**: No setup is needed. The player presses the "My plate: shown / My plate: hidden" button on the Title Board. Boards placed before 2026-10-28 get this button when you run 「シーンに称号システムを置く」 (Add Title System To Scene) again.

**How to check**: Join with 2 people. When one sets it to "My plate: hidden", that person's plate disappears from the nameplate and the Roster Board (13B) on the other person's screen.

- "Others' plates: OFF" hides plates on your own screen. "My plate: hidden" hides your plate on other people's screens.
- Hiding it does not change how Title Gates and perks decide.

### 13-3. Match Japanese and English to the viewer

**What you want**: Show 「屋上の住人」 to Japanese players and "Rooftop Dweller" to players from other countries.

**Setup**

1. Set the manager's **言語 (Language)** to 「自動（見る人の言語）」 (Auto (viewer's language)) (the default since 2026-10-28).
2. In the table rows, write English in **語（英語。空なら日本語） (Word En)**, **持っていないときの説明（英語） (Desc Before En)**, and **持っているときの説明（英語） (Desc After En)**.

**How to check**: Change the language in the ClientSim settings between Japanese and English and press Play (not yet checked in Unity).

- Rows with empty English fields are shown in Japanese to English viewers too.
- Other people's nameplates and the plates on the Roster Board are also shown in **the viewer's language** (the same person's plate looks Japanese to Japanese players and English to players from other countries).

## 13A. Title Perks (speed, jump, gravity)

Use the "Title Perk" component (TitlePerk; 01, section 7-11). It only affects the local player who meets the condition.

### 13A-1. Run faster when a title is equipped

**What you want**: People who have 「韋駄天」 (Swift Runner) in their plate run faster.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `idaten` | 韋駄天 (Swift Runner) | `stat:walk_m>=10000` |

**Setup**

1. Right-click an empty spot in the Hierarchy → 「World Title Gimmick」 → 「称号を装備したら速く動ける・高く跳べるようにする」 (Move faster / jump higher when a title is equipped). An object named 「称号の効果」 (Title Perk) is created.
2. In **条件の称号 (Title Keys)**, choose 「韋駄天」 (Swift Runner). Leave **条件 (Mode)** as 「装備している」 (Equipped).
3. With **移動の速さを変える (Change Speed)** on, set **走る速さ (Run Speed)** to 7.

**How to check**: Press Play while owning 「韋駄天」 (Swift Runner). Put it in your plate on the board and press "Apply", and you run faster. Take it off and press "Apply", and you go back to normal.

### 13A-2. Float when 「月の住人」 (Moon Dweller) is equipped

**Setup**: Add it as in 13A-1. Turn off **移動の速さを変える (Change Speed)**, turn on **ジャンプ力を変える (Change Jump)** (jump power 4), and turn on **重力を変える (Change Gravity)** (gravity 0.3).

**How to check**: Equip it and jump. You go higher and fall slowly.

### 13A-3. Show objects only while the perk is active

**What you want**: Show a shortcut sign only on the screens of people who have 「韋駄天」 (Swift Runner) equipped.

**Setup**: Put the sign in **満たしたら出す物 (Objects)** of the component from 13A-1 (you don't need to disable it beforehand; it is hidden automatically on Play).

- If you place 2 or more speed components and their conditions are met at the same time, the values of only one of them are used. When one stops applying, the values of the other one are used.

## 13B. Roster Board (plates of the people here)

**What you want**: Put a board in the lobby that lists the names and plates of the people in the room right now.

**Setup**

1. Right-click an empty spot in the Hierarchy → 「World Title Gimmick」 → 「いまいる人の肩書きの一覧ボードを置く」 (Place a Roster Board).
2. Move the board (Title Roster) to a place where it is easy to see.
3. If you don't want to list people without a plate, turn off **肩書きのない人も名前だけ出す (Show Empty)**.

**How to check**: Spawn other people in ClientSim. When they apply a plate, they appear in the list. With more than 12 people, the page turns every 8 seconds.

- People who set "My plate: hidden" are shown as "(no title)" on other people's screens (on their own screen, their own plate is shown).

## 13C. Notify an Udon Graph when a title is received (TitleRelay)

**What you want**: Each time you receive any title, an Udon Graph shows fireworks. When 「王冠」 (Crown) is equipped, the BGM changes.

**Setup**

1. Right-click an empty spot in the Hierarchy → 「World Title Gimmick」 → 「称号をもらったら Udon Graph へイベントを送る」 (Send an event to Udon Graph when a title is received).
2. Put the fireworks Udon Graph object in **送り先 (Event Targets)**. Leave **もらったとき (Granted Event)** as `OnTitleGranted`. Make a Custom Event `OnTitleGranted` in the fireworks Udon Graph.
3. Add one more for the BGM. Set **見る称号 (Watch Keys)** to 「王冠」 (Crown), **装備したとき (Equipped Event)** to `CrownOn`, and **装備を外したとき (Unequipped Event)** to `CrownOff`. Make Custom Events with the same names in the BGM Udon Graph.

**How to check**: Give a title with the Test Panel (01, section 5-2), and the fireworks appear. Put the crown in your plate on the board and press "Apply", and the BGM changes.

- If you want to know which title was received, make a public string variable `titleKey` in the Udon Graph, and enter `titleKey` in 詳しい設定 (Advanced settings) → How to send (送り方) → **称号のキーを入れる送り先の変数 (Key Variable)**.
- Titles you already own when joining the world do not send events (turn on Fire On Join if you want them to).

## 13D. Bring up a board anywhere (Title Notebook)

**What you want**: Change your plate where you are, without going back to the board (also handy for trying equip examples).

**Setup**: No setup is needed. 「シーンに称号システムを置く」 (Add Title System To Scene) places a Title Notebook next to the board. If you don't want people to use it, turn off the manager's **その場で出すボード（手帳）を使う (Use Portable Board)**.

**How to check**

1. On desktop press the **T** key; in VR **hold both triggers at the same time for 1 second**. The notebook comes in front of you.
2. Grab the notebook and "use" it (trigger / click). A board appears in front of you.
3. Apply your plate and press "Close" (or use the notebook again). The board disappears.

## 13E. Title hints (reveal names and unlock conditions)

Show the name of a title you don't own yet (what is behind "???") and its unlock condition (the table's "description after unlocking") only to people who meet a condition. No title is given. What has been revealed is saved and stays the next time you visit. For a table of how things look, see 01, chapter 10.

### 13E-1. Reveal names and unlock conditions with a hint button

**What you want**: When you "read" a book in the library, the names and unlock conditions of the hidden titles 「迷宮の主」 (Labyrinth Lord) (name mode: 隠す (Hidden)) and 「星読み」 (Stargazer) (一覧に出さない (Unlisted)) become visible on the board.

**Setup**

1. In the table row for 「迷宮の主」 (Labyrinth Lord), write "Open something in some room" in **持っていないときの説明 (Desc Before)** and "Open the treasure chest in the underground labyrinth" in **持っているときの説明 (Desc After)** (the description after unlocking is shown as the unlock condition).
2. Add a Title Action to the book. Set **行動 (Action)** to 「押す（Interact）」 (Interact), and in 詳しい設定 (Advanced settings) → Interact (押す（Interact）), set **物に向けたときに出る文字（Interact） (Interact Text)** to "Read the hint".
3. Put 「迷宮の主」 (Labyrinth Lord) and 「星読み」 (Stargazer) in **明かす称号（ヒント） (Reveal Keys)**, and leave **明かすもの (Reveal What)** as 「名前と取得条件」 (Name and unlock condition). **渡す称号 (Grant Keys)** can stay empty.
4. It may be read any number of times, so **一度だけ (Once)** can be off (no popup appears for titles that are already revealed).

**How to check**: Read the book and the popup "Found a title hint" appears. On the board, the card that was "???" becomes 「迷宮の主」 (Labyrinth Lord), and pressing it shows "Open the treasure chest in the underground labyrinth". A new card for 「星読み」 (Stargazer) appears. It is still there after you rejoin.

- Only the person who pressed it gets the reveal (no network sync).
- The same fields exist on Title Area (for "reveal when you enter an area") and on All Of (for "reveal when all 3 components are met").

### 13E-2. Step-by-step hints (name → unlock condition)

**What you want**: The stone tablet at the entrance reveals only the name of 「夜の番人」 (Night Watch), and the tablet deep inside also reveals the unlock condition.

**Setup**

1. Add a Title Action (Interact) to the entrance tablet. Set **明かす称号 (Reveal Keys)** to 「夜の番人」 (Night Watch) and **明かすもの (Reveal What)** to 「名前だけ」 (Name only).
2. Add one to the inner tablet too, and set **明かすもの (Reveal What)** to 「取得条件だけ」 (Unlock condition only).

**How to check**: The card on the board changes "???" → (entrance) 「夜の番人」 (Night Watch) → (inner) the description becomes the unlock condition. If you read the inner one first, the name stays "???" and only the description changes.

- If you want to enforce the order, use prerequisites on the inner tablet (at the entrance, also give an 「内部用」 (Internal) mark title, and put that mark in **この称号を全部持っている人だけ (Required Keys)** of the inner tablet. For how to use marks, see chapter 18).

### 13E-3. Reveal titles other people have equipped

**What you want**: When you see someone with a title in their plate, you learn that title's name and unlock condition (a conversation starter: "How do you get that title?").

**Setup**: Set the manager's **ほかの人の装備で明かす (Reveal Equipped)** to 「名前と取得条件」 (Name and unlock condition) (to show only the name, 「名前だけ」 (Name only)).

**How to check**: In Build & Test, join with 2 people. One gets 「迷宮の主」 (Labyrinth Lord), puts it in their plate, and applies it. On the other person's board, the name and unlock condition of 「迷宮の主」 (Labyrinth Lord) become visible.

- It reveals even if you are not nearby, as long as you are in the same instance (it only reads that person's saved data, so it is not heavy).
- It does not reveal from the plates of people who set "My plate: hidden".
- 「内部用」 (Internal) titles are not revealed.

## 14. Use it from code

From UdonSharp and Udon Graph you can give, remove, and check titles, add to counters, receive notifications when things change, and more. For the steps and examples, read 02.

| What you want | Where in 02 |
|---|---|
| Give a title by your own check (clearing a minigame, etc.) | 5-1, 5-4, 6-1 |
| Only people who own a title can press a button (UdonSharp) | 5-2 |
| Show the plates of nearby people on a sign | 5-3 |
| Change height by the number of titles | 5-5 |
| Add to a counter, press a counter component | 6-2, 6-4 |
| Remove titles, reset everything | 6-3 |
| Know in Udon Graph whether someone owns a title | 6-6 (Title Gate events; same as 8-13) |

---

# Part 3: Combination examples

## 15. Combination examples

### 15-1. Stamp rally

**What you want**: Visit 5 places in the world to get 「スタンプコンプリート」 (Stamp Complete). While collecting, the board shows "???".

| キー (Key) | 語 (Word) | 持っていないときの説明 (Desc Before) | 持っているときの説明 (Desc After) | 条件 (Condition) | 名前の見せ方 (Name Mode) |
|---|---|---|---|---|---|
| `st_1` | 時計台 (Clock Tower) | Somewhere high | Climb the clock tower | (empty) | 隠す (Hidden) |
| `st_2` | 噴水 (Fountain) | Where you hear water | Go to the fountain | (empty) | 隠す (Hidden) |
| `st_3` | 図書館 (Library) | A quiet place | Enter the library | (empty) | 隠す (Hidden) |
| `st_4` | 港 (Harbor) | Where you can see the sea | Go to the harbor | (empty) | 隠す (Hidden) |
| `st_5` | 森 (Forest) | Where there are many trees | Go deep into the forest | (empty) | 隠す (Hidden) |
| `st_all` | スタンプコンプリート (Stamp Complete) | Visit 5 places | Visited 5 places | `all:st_1,st_2,st_3,st_4,st_5` | 見せる (Shown) |

**Setup**

1. Add the 6 rows above to the table.
2. At each of the 5 places, place an area with 「エリアに入ったら称号を渡す」 (Give a title on entering an area), and choose one of `st_1`–`st_5` for **渡す称号 (Grant Keys)** in each.
3. At the entrance, place a reset button (12-2) that removes only the 5 place titles.

**How to check**: When you enter the 5th place, the popup for that place is followed by 「スタンプコンプリート」 (Stamp Complete).

- If you also want to give a "midway prize for visiting 3 places", count the visited places with a counter. Put `stamps` in **足すカウンターの名前 (Counter Key)** of each area, and add a row with `count:stamps>=3` to the table. Keep **一度だけ (Once)** on (each area counts only once per visit).
  - However, if you rejoin and enter the same place again, it counts again (**一度だけ (Once)** only lasts while you are in the world). If you want exactly "3 different places", don't use a title; instead, use the gate's **Required Count** `3` (8-8) to show the midway reward object.

### 15-2. Puzzle: clues → password door → inner room

**What you want**: Find 2 of the 3 clues and door 1 opens. Set your plate to the password 「月の鍵」 (Moon's Key) and door 2 opens. Reach the inner room and you get more plate slots.

| キー (Key) | 分類 (Kind) | 語 (Word) | 持っていないときの説明 (Desc Before) | 名前の見せ方 (Name Mode) |
|---|---|---|---|---|
| `clue_a` | 通常 (Normal) | 月 (Moon) | Somewhere | 隠す (Hidden) |
| `clue_b` | 通常 (Normal) | 鍵 (Key) | Somewhere | 隠す (Hidden) |
| `clue_c` | 通常 (Normal) | 星 (Star) | Somewhere | 隠す (Hidden) |
| `deep` | 通常 (Normal) | 奥の部屋の到達者 (Deep Explorer) | ??? | 隠す (Hidden) |
| `no` | 接続語 (Connector) | の ('s) | | 見せる (Shown) |

**Setup**

1. Add 「触ったら（Interact）称号を渡す」 (Give a title on Interact) to the 3 clue objects, giving `clue_a`, `clue_b`, and `clue_c` one each (2-4).
2. Door 1: add a TitleGate to a separate empty object. Put the 3 titles in **条件の称号 (Title Keys)**, set **このうち何個でよいか (Required Count)** to `2`, and put door 1's wall in **満たすまで出す物（壁など） (Objects When Not)** (8-8).
3. Door 2: add a TitleGate to a separate empty object. Put 「月」「の」「鍵」 (Moon, 's, Key) in **肩書きにこの順で並んでいる (Sequence Keys)**, turn on **間にほかの語を挟まない (Sequence Contiguous)**, and put door 2's wall in **満たすまで出す物（壁など） (Objects When Not)** (8-9).
4. At the entrance of the inner room, give `deep` with 「エリアに入ったら称号を渡す」 (Give a title on entering an area).
5. In the manager, set **解禁の称号（なし＝最初から） (Slot Unlock Keys)** of 「枠 4」–「枠 6」 (Slots 4–6) to 「奥の部屋の到達者」 (Deep Explorer) (chapter 10).
6. At the starting point, place a reset button (「指定の称号を外す」 (Remove chosen titles) with `clue_a`, `clue_b`, `clue_c`, `deep`).

**How to check**: Get 2 clues and door 1 disappears. Arrange 「月の鍵」 (Moon's Key) on the board and press "Apply", and door 2 disappears. Enter the inner room and you have 6 slots. The reset button puts everything back.

- Every door opens only on that person's screen. A friend's door does not open unless the friend solves it themselves.
- Write hints in the table's "description after unlocking" or on notes posted in the rooms.
- In the example scene, slots 4–6 are unlocked by 「上級者」 (Advanced) (`advanced`), the same as chapter 10, so the inner area gives 「上級者」 (Advanced) together with `deep`.

### 15-3. Event: when everyone gathers

**What you want**: On the day of a meetup, give 「集会の参加者」 (Gathering Member) to people who were in the plaza for 1 minute with 10 or more people. Only participants can see a commemorative object.

**Setup**

1. Make an area in the plaza. Set **きっかけ (Trigger)** to 「続けてN秒いたら」 (Stay N seconds in a row), and **秒数 (Seconds)** to `60`.
2. In 詳しい設定 (Advanced settings) → Prerequisites (前提の条件), set **人数がこれ以上のとき（0 なら見ない） (Min Players)** to `10`.
3. Set **渡す称号 (Grant Keys)** to 「集会の参加者」 (Gathering Member).
4. Add a TitleGate to a separate empty object. Put 「集会の参加者」 (Gathering Member) in **条件の称号 (Title Keys)** and the commemorative object in **満たしたら出す物 (Objects)** (8-3).

**How to check**: In Build & Test, lower **人数がこれ以上のとき (Min Players)** to `2` and test with 2 VRChat clients.

- The number of people is the number in the whole instance (not the number inside the plaza). If you want to count the people inside the plaza, use the trigger 「中の人数がN人以上」 (N or more people inside) (19-5).
- To limit it to the day of the meetup, write the dates in the area's **期間 (Period)** (19-2; it uses the device's date). Titles already received stay after the period ends.

### 15-4. Rank titles (10, 100, 1000 times) and a room opened by rank

**What you want**: Give ranks by the number of target hits (throw a ball into the target's area), and make a room only 「的の名人」 (Target Master) can enter.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `dan1` | 初段 (First Dan) | `count:target>=10` |
| `dan2` | 達人 (Expert) | `count:target>=100` |
| `dan3` | 的の名人 (Target Master) | `count:target>=1000` |

**Setup**

1. Make an area on the target. Set **何が入ったら (Who)** to 「指定した物」 (Specified objects), put the ball in **入る物 (Objects)**, and set **誰に渡すか (Receiver)** to 「最後に持った人（持ち主）」 (Last holder (owner)) (1-7).
2. Leave **渡す称号 (Grant Keys)** empty. Set **足すカウンターの名前 (Counter Key)** to `target`, turn off **一度だけ (Once)**, and set **次に反応するまでの秒数 (Cooldown Seconds)** to `1`.
3. Add the 3 rows above to the table.
4. At the entrance of the master's room, place the wall from 8-4 (with 「的の名人」 (Target Master) in **条件の称号 (Title Keys)**).

**How to check**: When testing, lower the numbers in the conditions to `2`, `4`, and `6`.

### 15-5. Branching routes (only one of the two)

**What you want**: You can choose only one of 「光の道」 (Path of Light) and 「闇の道」 (Path of Darkness). What you can see changes depending on the path you chose.

**Setup**

1. Area at the altar of light: set **渡す称号 (Grant Keys)** to 「光の道」 (Path of Light), and **この称号を持っている人には渡さない (Forbidden Keys)** to 「闇の道」 (Path of Darkness).
2. Area at the altar of darkness: set **渡す称号 (Grant Keys)** to 「闇の道」 (Path of Darkness), and **この称号を持っている人には渡さない (Forbidden Keys)** to 「光の道」 (Path of Light).
3. Decorations only light people can see: a TitleGate with 「光の道」 (Path of Light) in **条件の称号 (Title Keys)** and the decorations in **満たしたら出す物 (Objects)**. Make the path of darkness the same way.
4. A button to choose again: a reset button with 「指定の称号を外す」 (Remove chosen titles) and 「光の道」 (Path of Light) and 「闇の道」 (Path of Darkness).

**How to check**: After entering the altar of light, entering the altar of darkness gives you nothing.

### 15-6. A hidden title, and a special connector for people who collected everything

**What you want**: Place a hidden title nobody knows about. Only people who own it and 10 normal titles can use 「♚」.

| キー (Key) | 分類 (Kind) | 語 (Word) | 条件 (Condition) | 名前の見せ方 (Name Mode) | 最初は使えない (Locked Connector) |
|---|---|---|---|---|---|
| `secret` | 通常 (Normal) | 秘密を知る者 (Secret Keeper) | (empty) | 一覧に出さない (Unlisted) | — |
| `crown2` | 接続語 (Connector) | ♚ | `all:secret,collector` | 隠す (Hidden) | On |
| `collector` | 通常 (Normal) | コレクター (Collector) | `owned>=10` | 見せる (Shown) | — |

**Setup**

1. Add the 3 rows above to the table.
2. In a hard-to-find place, give `secret` with 「エリアに入ったら称号を渡す」 (Give a title on entering an area).

**How to check**: Until you get `secret`, it does not appear in the board's list and is not included in m of "Unlocked n / m". When you have both `secret` and 「コレクター」 (Collector), the popup for 「♚」 appears.

- This is a different connector from `crown` (♛) in 5-1. If you put both in the same table, use different keys.

### 15-7. A button only title holders can press

**What you want**: Only people who own 「職人」 (Craftsman) can press a button that counts smithing (rank titles by the number of presses).

The counter component (TitleCounter) has no prerequisites, so make it in one of the following ways.

**Method A: count with a Title Action**

1. Right-click the button → 「触ったら（Interact）称号を渡す」 (Give a title on Interact). Leave **渡す称号 (Grant Keys)** empty.
2. Put 「職人」 (Craftsman) in **この称号を全部持っている人だけ (Required Keys)** and `smith` in **足すカウンターの名前 (Counter Key)**, and turn off **一度だけ (Once)**.
3. Add rows such as `count:smith>=10` to the table (4-1).

**Method B: show or hide the button with a gate**

1. Add a counter (3-1) to the button.
2. Add a TitleGate to a separate empty object. Put 「職人」 (Craftsman) in **条件の称号 (Title Keys)** and the button in **満たしたら出す物 (Objects)**.

- With method A, people without the title can see the button, but nothing happens when they press it. With method B, people without the title cannot see the button.

### 15-8. A limited title for Halloween week, and a limited costume room

**What you want**: Only people who visit during Halloween week get 「かぼちゃ」 (Pumpkin), and only people who own it can enter the costume room. People who got it can still enter after the period ends.

| キー (Key) | 語 (Word) | 語（英語） (Word En) | 条件 (Condition) |
|---|---|---|---|
| `halloween` | かぼちゃ | Pumpkin | `date:1025-1031` |

**Setup**

1. Add the row above to the table (4-6).
2. Right-click the costume room door → 「称号を持つ人だけ通れる壁にする」 (Make a wall only title holders can pass). Choose 「かぼちゃ」 (Pumpkin) in **条件の称号 (Title Keys)** (8-5).
3. Set the objects in the room with 「称号を持つ人だけに見せる・触れさせる」 (Show / allow touch only for title holders), and choose 「かぼちゃ」 (Pumpkin) (8-1).

**How to check**: Set `date:` to today's date and press Play. The popup appears right after joining, and you can pass through the door.

## 16. Summary of cautions

- **No network sync is used**. Title Gates, the component fields **本人の画面で出す物 (Enable Objects)** and **本人の画面で消す物 (Disable Objects)**, the objects switched by reset buttons, and events all happen only on the local player's screen (device). If you want to show something on other people's screens, build the sync outside this gimmick.
- **Nothing works right after joining the world**. Until saved data finishes loading (a few seconds), components do nothing and gates are treated as "not met" (for an inverted gate, the objects it switches are shown; 8-5).
- **The title key (Key) is the name you choose in component fields**. If you change it later, the component field shows 「？ キー（表にない）」 ("? key (not in table)"). Choose it again.
- **Do not change IDs or delete rows after publishing** (to stop using one, set **状態 (State)** to 「廃止」 (Retired)). See 01, section 13-1.
- **一度だけ (Once) is only remembered while you are in the world**. 「全部やり直す」 (Reset everything) resets it; 「指定の称号を外す」 (Remove chosen titles) does not.
- **Only the stats in use are counted** (4-2).
- **There is no cheat protection**. Do not use it for things where correctness matters, such as prizes or rankings (01, section 13-6).

## 17. Check when you are done

When you have finished adding components, press the menu "World Title Gimmick → シーンを点検 (Check Scene)" (01, section 5-1). It lists in a window: components that choose a title not in the table, objects missing a collider or VRC Pickup, gates with no condition or no objects to switch, and so on. Click a row to select that object.

---

# Part 4: Using titles in different kinds of worlds

## 18. How to use it by world type

Titles can also be used as **marks** meaning "this person got this far" or "this person saw this". Titles are saved per player, so they stay the next time the player visits. Combine them with Title Gates and you can make **a "world that remembers" without writing any code**.

- For marks you don't want players to see, set the table's **名前の見せ方 (Name Mode)** to 「内部用」 (Internal) (01, chapter 10). They don't appear on the board, no popup is shown when they are received, and they are not counted in the number of unlocked titles.
- You can try these in the A-2 「18章」 (Chapter 18) row of the example scene (18-1, 18-3, 18-4, 18-6, 18-8, 18-9). For the other examples, booths with the same structure are described.

### 18-1. Athletic course: checkpoint saves and shortcuts

**What you want**: People who reached a checkpoint can take a shortcut to the checkpoint the next time they come. The save marks are not shown.

| キー (Key) | 語 (Word) | 持っているときの説明 (Desc After) | 名前の見せ方 (Name Mode) |
|---|---|---|---|
| `cp1` | 中継地点1 (Checkpoint 1) | Reach checkpoint 1 | 内部用 (Internal) |
| `cp2` | 中継地点2 (Checkpoint 2) | Reach checkpoint 2 | 内部用 (Internal) |
| `runner` | 完走者 (Finisher) | Reach the goal | 見せる (Shown) |

**Setup**

1. Add the rows above to the table.
2. Place an empty object on the checkpoint floor, then right-click → 「エリアに入ったら称号を渡す」 (Give a title on entering an area). Set **渡す称号 (Grant Keys)** to `cp1`. Do checkpoint 2 the same way with `cp2`.
3. Build the shortcut bridge (from the start to checkpoint 1), and add a TitleGate to a separate empty object. Put `cp1` in **条件の称号 (Title Keys)** and the bridge in **満たしたら出す物 (Objects)** (8-3).
4. If you put a fence at the shortcut entrance, put the fence in **満たすまで出す物（壁など） (Objects When Not)** (8-4).
5. Make the shortcut to checkpoint 2 the same way with `cp2`. If you line up several "continue from here" entrances, players can choose a stage.
6. At the goal, give `runner` (a shown title) with 「エリアに入ったら称号を渡す」 (Give a title on entering an area).
7. A "delete save" button at the start: right-click → 「やり直しのボタンにする」 (Make a reset button), set **すること (Mode)** to 「指定の称号を外す」 (Remove chosen titles), put `cp1` and `cp2` in **外す称号 (Revoke Keys)**, and set the confirm seconds to `0`.

**How to check**: Entering a checkpoint shows no popup and nothing appears on the board. Even so, the shortcut bridge appears. If you leave the world and rejoin, the bridge is still there.

- As a goal reward, you can use a Title Perk (13A) to make players a little faster while 「完走者」 (Finisher) is equipped, so the second run is easier.
- For a "no mistakes" title, the table condition `stat:respawns` cannot express "at most N times". If you want to count falls, use 「エリアに入ったら」 on the falling floor to add to **足すカウンターの名前 (Counter Key)** (11-1), and put a "fell" mark title in **この称号を持っている人には渡さない (Forbidden Keys)** of the goal area (remove that mark at the start).
- If you want to **teleport** players to a checkpoint, call `TeleportTo` in your own Udon (Udon Graph is fine too) from the gate's **満たしたときに送るイベント (Met Event)** (8-13) or the area's **イベントの送り先 (Event Targets)** (11-2). This gimmick does not teleport.

### 18-2. Puzzle / escape: keep solved doors open

**What you want**: Doors of rooms you solved stay open the next time you come. The last room opens only for people who solved everything.

| キー (Key) | 語 (Word) | 名前の見せ方 (Name Mode) |
|---|---|---|
| `room1_clear` | 部屋1を解いた (Solved Room 1) | 内部用 (Internal) |
| `room2_clear` | 部屋2を解いた (Solved Room 2) | 内部用 (Internal) |
| `escaper` | 脱出者 (Escapee) | 見せる (Shown) (condition `all:room1_clear,room2_clear`) |

**Setup**

1. Past the solved puzzle (at the exit of room 1, etc.), give `room1_clear` with 「エリアに入ったら称号を渡す」 (Give a title on entering an area).
2. Right-click the door of room 1 → 「称号を持つ人だけ通れる壁にする」 (Make a wall only title holders can pass) with `room1_clear` (8-5). Do room 2 the same way.
3. The door of the last room: a TitleGate with `room1_clear` and `room2_clear` in **条件の称号 (Title Keys)**, **全部そろったら (Match All)** on, and the door in **満たすまで出す物（壁など） (Objects When Not)** (8-8).
4. You can also mix in a door that uses the plate order as a password (15-2). The board becomes a puzzle tool.
5. A "start over" button: a reset button with 「指定の称号を外す」 (Remove chosen titles) and `room1_clear`, `room2_clear`.

**How to check**: Solve room 1, leave the world, and rejoin. The door of room 1 stays open, and room 2 stays closed.

- In the example scene, 15-2 (puzzle) has the same structure.
- Even if someone learns the answer from another person, a door only opens for people who solved it on their own screen (because it switches only on the local player's screen).

### 18-3. Story / horror: skip guides and effects you have already seen

**What you want**: Show a long guide at the entrance (or a scare effect) only to first-time visitors. From the second visit on, don't show it.

| キー (Key) | 語 (Word) | 名前の見せ方 (Name Mode) |
|---|---|---|
| `seen_intro` | 案内を見た (Saw Intro) | 内部用 (Internal) |

**Setup**

1. Past the guide (where people pass after finishing the guide), give `seen_intro` with 「エリアに入ったら称号を渡す」 (Give a title on entering an area).
2. Make a parent object that holds the guide objects (signs, the areas that trigger the effects, etc.).
3. Add a TitleGate to a separate empty object. Put `seen_intro` in **条件の称号 (Title Keys)** and the guide's parent in **満たすまで出す物（壁など） (Objects When Not)**.

**How to check**: At first the guide is shown. Go ahead and it disappears, and it does not appear after rejoining.

- **Branching endings** in a story are made the same way as 15-5 (only one of the two). Give a shown title for each ending, and you can make "all endings collected" with `all:` in the table.
- If your effects run on Udon Graph, instead of the effect's trigger area you can use the gate's **満たさなくなったときに送るイベント (Unmet Event)** and **満たしたときに送るイベント (Met Event)** (8-13) to make "start the effect only for first-time visitors".

### 18-4. Hangout: a room only regulars can enter

**What you want**: Give 「常連」 (Regular) to people who have visited on 7 or more days, and let only regulars into the lounge. Give 「おしゃべり好き」 (Chatterbox) to people who spent a long time with others.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `regular` | 常連 (Regular) | `stat:visit_days>=7` |
| `talker` | おしゃべり好き (Chatterbox) | `stat:together_min>=600` |

**Setup**

1. Add the rows above to the table. No components are needed (4-2).
2. Right-click the lounge door → 「称号を持つ人だけ通れる壁にする」 (Make a wall only title holders can pass) with 「常連」 (Regular).
3. On a wall of the room, right-click → 「いまいる人の肩書きの一覧ボードを置く」 (Place a Roster Board) (13B). It becomes a conversation starter with first-time visitors.

**How to check**: Set the stat `visit_days` to 7 with the Test Panel (01, section 5-2), and the door disappears.

- You can also check the stat directly with the gate's **行動の値 (Stat Name)** and **行動の値がこれ以上 (Stat Min)**, without giving a title (8-12). The example scene's 18-4 uses this way (`visit_days` of 3 or more).
- You can also make 「皆勤賞」 (Perfect Attendance) with the number of consecutive days (`visit_streak`).

### 18-5. Event / exhibition: attendance memento and stamps

**What you want**: Give a memento title to people who came on the event days. Visiting booths at the venue collects stamps.

| キー (Key) | 語 (Word) | 条件 (Condition) |
|---|---|---|
| `expo2026` | 2026年の来場者 (2026 Visitor) | `date:20261103-20261105` |

**Setup**

1. Add the row above to the table (4-6). People who join on the event days get it right after joining.
2. Booth stamps are made the same way as 15-1 (stamp rally).
3. A memento room only visitors can enter is made the same way as 15-8 (the Halloween room).

**How to check**: Set `date:` to today's date and press Play. The popup appears right after joining.

- People who come after the period cannot get it, so it is a memento of "I was there that day".
- For next year's event, add a new row (such as `expo2027`). Do not delete the previous year's row; keep it (so the records of people who got it remain).

### 18-6. Exhibition / gallery: mark the works you have seen

**What you want**: Show a "seen" mark next to works you have looked at. It stays the next time you come, so you can tell which works you missed. Give a title to people who saw them all.

| キー (Key) | 語 (Word) | 条件 (Condition) | 名前の見せ方 (Name Mode) |
|---|---|---|---|
| `seen_art1` | 作品1を見た (Saw Work 1) | (empty) | 内部用 (Internal) |
| `seen_art2` | 作品2を見た (Saw Work 2) | (empty) | 内部用 (Internal) |
| `seen_art3` | 作品3を見た (Saw Work 3) | (empty) | 内部用 (Internal) |
| `kansho` | 鑑賞者 (Art Lover) | `all:seen_art1,seen_art2,seen_art3` | 見せる (Shown) |

**Setup**

1. Right-click the work (or its caption plate) → 「触ったら（Interact）称号を渡す」 (Give a title on Interact) with `seen_art1`. You may instead place 「エリアに入ったら称号を渡す」 (Give a title on entering an area) on the floor in front of the work, so it is marked when people come close.
2. Make the mark object (a check mark shape, etc.), and add a TitleGate to a separate empty object. Put `seen_art1` in **条件の称号 (Title Keys)** and the mark in **満たしたら出す物 (Objects)**.
3. Do works 2 and 3 the same way.

**How to check**: Examine a work and only that work's mark appears. No popup is shown. On the 3rd one, the popup for 「鑑賞者」 (Art Lover) appears.

- Internal titles can also be used in `all:`.

### 18-7. Minigame: skip the tutorial, and ranks

**What you want**: Don't show the entrance explanation to people who already learned how to play. Give ranks by the number of wins, and make a room only the higher ranks can enter.

**Setup**

1. At the end of the explanation (an "I got it" button, etc.), give the internal title `tutorial_done` with 「触ったら（Interact）称号を渡す」 (Give a title on Interact).
2. Put the entrance explanation board in **満たすまで出す物（壁など） (Objects When Not)** of a gate for `tutorial_done` (same as 18-3).
3. When the player wins, call `_AddCount("win", 1)` from the game's Udon (02, sections 3-1 and 5-1; for Udon Graph, 6-2), or put `win` in **足すカウンターの名前 (Counter Key)** of the goal area (11-1).
4. Add rank rows such as `count:win>=10` and `count:win>=100` to the table. The room for higher ranks is made the same way as 15-4.

**How to check**: Press "I got it" in the explanation, and the explanation board disappears. It does not appear after rejoining.

- In the example scene, 18-3 (guide) and 15-4 (ranks) have the same structure.

### 18-8. Role-play: choose a job and use the job's tools

**What you want**: You can choose only one of 「剣士」 (Swordsman) and 「魔法使い」 (Wizard). Only people who have the job title equipped can grab that job's tools.

| キー (Key) | 語 (Word) |
|---|---|
| `swordsman` | 剣士 (Swordsman) |
| `mage` | 魔法使い (Wizard) |

**Setup**

1. On the "Become a swordsman" button, give `swordsman` with 「触ったら（Interact）称号を渡す」 (Give a title on Interact), and put `mage` in **この称号を持っている人には渡さない (Forbidden Keys)** (6-2). Make "Become a wizard" the other way around.
2. Put the sword in **満たしたら掴める物（Pickup） (Pickup Objects)** of a TitleGate, put `swordsman` in **条件の称号 (Title Keys)**, and set **条件 (Mode)** to 「装備している」 (Equipped) (8-6, 8-7). Do the staff the same way.
3. A "change job" button: a reset button with 「指定の称号を外す」 (Remove chosen titles) and `swordsman`, `mage`.

**How to check**: Get swordsman and equip it on the board, and you can grab the sword. Take it off and you can't. While you own swordsman, pressing the wizard button does nothing.

- Job perks (swordsmen run faster, etc.) can be added with Title Perks (13A).

### 18-9. Your own house: remember preferred settings

**What you want**: People who pressed the button to darken the room find it still dark the next time they come. A button brings it back to bright.

| キー (Key) | 語 (Word) | 名前の見せ方 (Name Mode) |
|---|---|---|
| `pref_dark` | 暗くする (Dark Mode) | 内部用 (Internal) |

**Setup**

1. Right-click the "Darken" button → 「触ったら（Interact）称号を渡す」 (Give a title on Interact) with `pref_dark`. Turn off **一度だけ (Once)** (chapter 7).
2. Right-click the "Brighten" button → 「やり直しのボタンにする」 (Make a reset button). Set **すること (Mode)** to 「指定の称号を外す」 (Remove chosen titles), put `pref_dark` in **外す称号 (Revoke Keys)**, and set the confirm seconds to `0`.
3. Add a TitleGate to a separate empty object. Put `pref_dark` in **条件の称号 (Title Keys)**. Put the dark-room objects (dark lights, curtains, etc.) in **満たしたら出す物 (Objects)**, and the bright-room objects (bright lights, etc.) in **満たすまで出す物（壁など） (Objects When Not)**.

**How to check**: Press "Darken" and it gets dark. It is still dark after rejoining. "Brighten" brings it back. Neither button shows a popup.

- A reset button that removes only internal titles does not announce that it finished (01, section 7-7).
- If you want to remember the mirror position, BGM volume, etc. in 2–3 levels, make an internal title for each level, and remove the other levels each time one is chosen (stack two button components, or use **この称号を持っている人には渡さない (Forbidden Keys)**).
- A gate switches things only on the local player's screen. Other people in the same room keep their own settings.

### 18-10. Cautions when using titles as "save marks"

- **「全部やり直す」 (Reset everything) also erases the marks**. When you place a button for playing again, use 「指定の称号を外す」 (Remove chosen titles) and choose the marks to erase.
- **Right after joining (a few seconds), the player is treated as having no marks**. Shortcut bridges and the like do not appear until loading finishes (walls of inverted gates stay shown).
- **It does not affect other people's screens**. A friend's shortcut does not appear until the friend reaches the checkpoint.
- **Do not use it for important checks**. The data is not impossible to rewrite (chapter 16).
- **Do not change or delete keys (Key) and IDs after publishing**. If you delete them, the marks of people who visited before can no longer be used (01, section 13-1).

## 19. Additional settings

These are examples of settings added on 2026-10-28. In the example scene, they are in the 「B-10　19章 追加の設定」 (B-10 Chapter 19: additional settings) row.

### 19-1. Record title: best time

**What you want**: Let players put the time from start to goal into their plate as "Best Time 12.34s". It updates each time they get faster. Within 15 seconds, give 「俊足」 (Speedster); within 10 seconds, show a gold sign.

**Setup**

1. In the Title Editor, press 「記録を足す」 (Add Record). Set **キー (Key)** to `best_time`, **語（日本語） (Word)** to 「最速タイム」 (Best Time), **記録の書式 (Record Format)** to 「時間」 (Time), **値のあとに付ける語 (Record Suffix)** to 「秒」 (s), and turn on **小さいほど良い記録（タイムなど） (Record Lower Better)** (01, section 6-6).
2. Add a Title Area to the start floor, leave the title to give empty, and turn off **一度だけ (Once)**. In 詳しい設定 (Advanced settings) → Send events (イベントを送る（Udon Graph など）), put the goal's Udon in **イベントの送り先 (Event Targets)** and `_StartRace` in **送るイベントの名前 (Event Names)**.
3. On the goal's Is Trigger collider, add an UdonSharp script that measures the time and calls `_SetRecord("best_time", time in units of 0.01 seconds)` (sample: `Samples/ExampleScene/Scripts/ExampleRace.cs`; 02, chapter 9).
4. In **条件 (Condition)** of the 「俊足」 (Speedster) row, write `record:best_time>=1500` (because smaller is better, this means "reached 1500 or less" = within 15 seconds).
5. In a Title Gate's 詳しい設定 (Advanced settings) → Title count, stats, records (称号の数・行動の値・記録), choose 「最速タイム」 (Best Time) in **記録の称号 (Record Key)**, enter `1000` in **記録がこの値に届いている (Record Min)**, and put the gold sign in **満たしたら出す物 (Objects)**.

**How to check**: Step on the start floor and run to the goal. "New title unlocked!" and "Best Time ○○s" appear. Run faster again and "New record!" appears. If you put it in your plate on the board, the record on your nameplate changes too.

- Nothing happens when you are slower (the record is saved only when it improves).
- During Play, you can write values with 「記録」 (Records) in the Test Panel.

### 19-2. Player count limit and period

**What you want**: Step on a floor when you are the only person in the instance to get 「ひとり旅」 (Solo Traveler). Step on a floor during a set period to get 「季節の来訪者」 (Seasonal Visitor).

**Setup**

1. In the Title Area on the 「ひとり旅」 (Solo Traveler) floor, set 詳しい設定 (Advanced settings) → Prerequisites (前提の条件) → **人数がこれ以下のとき (Max Players)** to `1`.
2. In the Title Area on the 「季節の来訪者」 (Seasonal Visitor) floor, write something like `1225-0105` (winter holidays every year) in **期間 (Period)**. The format is the same as `date:` in the table (the example scene uses `0101-1231` for testing).

**How to check**: Press Play alone and step on the left floor to get 「ひとり旅」 (Solo Traveler). With 2 people in Build & Test, stepping on it gives nothing.

- The period uses the device's date. Do not use it for prizes and the like (chapter 16).

### 19-3. Hide the unlock popup, change the sound effect

**What you want**: Give a title quietly (no popup). Play a different sound only for special titles.

**Setup**

1. In the component's 詳しい設定 (Advanced settings) → Popup & sound (知らせ・音), turn off **獲得の知らせを出す (Show Popup)**.
2. To change the sound, put an AudioClip in **効果音 (Sound)** in the same group (if empty, the unlock popup's sound is used). The sound plays even when no popup is shown.

**How to check**: Stepping on the floor shows no popup, but on the board you own 「忍び足」 (Sneaky).

### 19-4. When an object goes in, give a title to everyone inside the area

**What you want**: When a ball goes into the goal, give 「応援団」 (Cheer Squad) to everyone in the box in front of the goal (the person who threw it may be outside the box).

**Setup**

1. Add a Title Area to the box. Set **何が入ったら (Who)** to 「指定した物」 (Specified objects), and put the ball in **入る物 (Objects)**.
2. In 詳しい設定 (Advanced settings) → When an object enters (物が入ったとき), set **誰に渡すか (Receiver)** to 「エリアの中にいる人」 (People inside the area).
3. Add VRC Object Sync to the ball (so other people can see the ball's position too).

**How to check**: With 2 people in Build & Test, one stands in the box and the other throws the ball into the box. The person in the box gets 「応援団」 (Cheer Squad).

- Object positions look slightly different for each person. Make the box large.

### 19-5. When N people gather in an area

**What you want**: When 2 or more people gather in a circle in the plaza, give 「集合」 (Gathered) to everyone inside.

**Setup**: Set the Title Area's **きっかけ (Trigger)** to 「中の人数がN人以上」 (N or more people inside) and **人数 (Crowd Count)** to `2` (**何が入ったら (Who)** is 「本人（プレイヤー）」 (Player)).

**How to check**: With 2 people in Build & Test, enter the circle, and both get 「集合」 (Gathered).

- Each time someone enters or leaves, each person's device counts again.

### 19-6. Action steps (A at 3 times, B at 6 times)

**What you want**: By the number of times a bell is rung: 「鈴の見習い」 (Bell Novice) at 3 times and 「鈴の名人」 (Bell Master) at 6 times.

**Setup**

1. Add a Title Action to the bell. Set **行動 (Action)** to 「使う（トリガー）」 (Use (trigger)), turn off **一度だけ (Once)**, and in 詳しい設定 (Advanced settings) → Repeat (くり返し), set **次に反応するまでの秒数 (Cooldown Seconds)** to 0.
2. In 詳しい設定 (Advanced settings) → Saving the count (回数の保存), put `bell` in **回数を保存する名前 (Save Key)** (counting continues after rejoining).
3. In 詳しい設定 (Advanced settings) → Steps (段（N回で称号A、M回で称号B）), put `3` and `6` in **段の回数 (Steps)**, and 「鈴の見習い」 (Bell Novice) and 「鈴の名人」 (Bell Master) in **段で渡す称号 (Step Keys)** in the same order. **渡す称号 (Grant Keys)** can stay empty.

**How to check**: Hold the bell and pull the trigger 3 times to get 「鈴の見習い」 (Bell Novice), and 6 times to get 「鈴の名人」 (Bell Master).

- You can do the same with a counter (3-2) or the table condition `count:bell>=3`. Steps are easy because you can write them inside the action alone.

### 19-7. When it hits another object

**What you want**: Hit the target with a ball to get 「的当て」 (Bullseye).

**Setup**: Add a Title Action to the ball. Set **行動 (Action)** to 「ほかの物に当てる」 (Hit another object), and put the target in **当てる物 (Hit Objects)** (to choose by layer, use **当てるレイヤー (Hit Layers)**). The time allowed from throwing to hitting is **投げてから待つ秒数 (Hit Seconds)** (default 3 seconds).

**How to check**: Touch the target while holding the ball, or throw the ball and hit it, to get 「的当て」 (Bullseye).

- The target also needs a collider.

### 19-8. Only title holders can press it (switch Interact with a gate)

**What you want**: Only people who own 「鍵の持ち主」 (Key Holder) can press the treasure chest to open it.

**Setup**

1. Add a Title Action (Interact) to the chest, and set the title to give to 「宝箱を開けた」 (Chest Opener).
2. Add a Title Gate to a separate empty GameObject, and set its **条件の称号 (Title Keys)** to 「鍵の持ち主」 (Key Holder).
3. Put the chest's Udon (the Title Action) in the gate's **満たしたら押せる Udon（Interact） (Interact Targets)**.

**How to check**: Without 「鍵の持ち主」 (Key Holder), nothing appears when you point your hand at the chest. Get 「鍵の持ち主」 (Key Holder) from the button, and "Open" appears so you can press it.

- The collision does not go away, so you still bump into the chest. If you don't want it to be seen, also use **満たしたら見える (Renderers)** and **満たしたら出す物 (Objects)** (chapter 8).

### 19-9. A counter that is not saved

**What you want**: Press 3 times on the spot to get 「三連打」 (Triple Tap). Rejoining starts the count from 0 again.

**Setup**: Turn off the counter's **保存する (Saved)**.

**How to check**: Press twice, rejoin, and press once more: you don't get it (it counts again from 0). Press 3 times in a row and you get it.

- Components and table conditions that use a counter with the same name also stop saving it.

### 19-10. The short forms `visit>=` and `stay>=`, and testing with all titles owned

- Writing `visit>=7` in the table's **条件 (Condition)** means "visited on 7 days" (same as `stat:visit_days>=7`), and `stay>=600` means "stayed 10 hours in total" (same as `stat:stay_min>=600`).
- Turn on the manager's **Editor で始めたとき全称号を持つ (Test All Owned)** and press Play, and you start owning all titles. Use it to test how the board looks and how long plates get. Nothing is saved, so turning it off puts things back. It has no effect in uploaded worlds.
