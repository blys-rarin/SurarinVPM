# World Title Gimmick Manual 1: Setting Up in the Inspector

> This is the English translation of the Japanese manual (../01_Inspector.md). If they differ, the Japanese version is correct.

World Title Gimmick (ワールド内称号ギミック) is an asset for VRChat worlds. Players collect "titles" and combine them into a "plate" that is shown above their head.

If this is your first time, read "00_QuickStart.md" first (steps to make one title in 10 minutes).

This manual is for people who use the asset only through Inspector settings, without writing code. To use it from UdonSharp or Udon Graph, read "02_Code.md".

> Features we decided not to include are listed in chapter 14.

## Contents

1. What you can do
2. Terms
3. Requirements
4. Installation
5. Placing it in the scene
6. Making the title table
7. Settings for each component
8. How to write conditions in the table
9. Slot types and unlocking slots
10. How titles look before unlocking
11. Examples of common setups
12. Examples of puzzle setups
13. Notes
14. Features we decided not to include

## 1. What you can do

- Give players titles for things like "climbed to the rooftop", "pressed the button 10 times", or "put the gem on the altar".
- Players line up titles and connectors (such as "'s") on the Title Board to build a plate.
- The plate is shown above the player's head to other people (nameplate).
- Make doors that only title holders can pass, paths that only people who equip a title can see, devices that open when a plate has a certain order, and more.
- Titles, plates and counts are saved per player and are still there on the next visit. You can also erase them with a reset button.
- Change the movement speed and jump power of players who equip a title (7-11). Show a list of the plates of everyone in the room (7-12).
- Automatically count 30 kinds of actions, such as jumps, distance walked, fall height, times sat in a seat, head pats and high fives, and use them in title conditions (8-2).
- Limited-time titles (for example, "visit during Halloween week". 8-1). With the sample title packs, you can add many titles at once that work just by adding them (6-4).
- Words, descriptions and screen texts have both Japanese and English. If you set the manager's "言語 (Language)" to "自動 (Auto)", they switch to match the viewer's VRChat language (7-1; the default is Japanese).
- Record titles that build their word from a saved value, like "Best Time 12.34 s" (6-6). Reveal the name and unlock condition of titles the player does not have yet, as hints (7-2, chapter 10).
- Hidden "internal" titles can be used as save markers (checkpoints, solved doors, guides already seen, preferred settings) (chapter 10). You can build things that "remember on the next visit" without any programming.
- Check for setup mistakes with a single menu (5-1). Change titles and counts during Play to test (5-2). Edit the table as CSV (6-5).

No synced variables are used. Network traffic does not grow as more people join (chapter 13).

## 2. Terms

| Term | Meaning |
|---|---|
| Title | A word you get when you meet a condition. One row of the table is one title |
| Connector | A word that joins a plate together, such as "'s", "☆" or "（空白）" (space). Normally everyone can use them from the start. A connector set as "locked" cannot be used until its condition is met |
| Plate | Titles and connectors lined up in slots (up to 10 slots). Shown above the name |
| Equip | Having a title in a plate slot (applied and saved) |
| Unlock | Making a slot or connector usable that could not be used before |
| Key | An alphanumeric name used to refer to a title (example: `rooftop`). Set in the table |
| Counter | A named count (example: `button`). It is saved |
| Stat | A value the gimmick counts automatically from the player's actions, such as jump count or distance walked |
| Component | A component you add to an object in the scene and set up (Title Area and so on) |
| Manager | The main object; place one in the scene (TitleManager) |
| Local player | The player playing on that device |
| PlayerData | VRChat's system for saving data per player. This gimmick saves there |
| Restore | VRChat finishing loading the saved PlayerData after joining the world. It can take a few seconds |
| Bake | Writing the contents of the table into the manager in a form Udon can read |

## 3. Requirements

- Unity 2022.3
- VRChat Worlds SDK 3.10.5 or later (if you install with VCC, it asks you to update when the version is too old)
- UdonSharp (the one bundled with the SDK)
- PC, Quest (Android), iOS
- No other assets such as TextMeshPro or lilToon are needed.

## 4. Installation

Install it in one of these ways.

- VCC (VRChat Creator Companion): add the repository listed on the BOOTH page, then add "World Title Gimmick" to your project.
- unitypackage: import it with the Unity menu Assets → Import Package → Custom Package.

After installing, when script compilation finishes, "World Title Gimmick" appears in Unity's top menu.

**Where it goes**: either way, the gimmick goes into `Packages/com.surarin.worldtitlegimmick` (Project window: Packages → World Title Gimmick). Files inside the package are overwritten when you update. Things you edit are created in `Assets/WorldTitleGimmickData`, shown below.

| Location | Contents |
|---|---|
| `Packages/com.surarin.worldtitlegimmick` | The gimmick itself, the sample title table (`Samples/SampleTitles.asset`), the example scene, and the manuals. Do not edit |
| `Assets/WorldTitleGimmickData/Titles.asset` | The title table for your own world. "シーンに称号システムを置く (Add Title System To Scene)" creates it by copying the sample table (6-1) |
| `Assets/WorldTitleGimmickData/ExampleScene` | The example scene rebuilt with "見本のシーンを作る (Build Example Scene)" |

- If you put your own UdonSharp scripts in an Assembly Definition (asmdef), add `WorldTitleGimmick.Runtime` to that asmdef's references (02, chapter 2). If you do not use an asmdef, you do not need to do anything.

**Example scene**: open `Samples/ExampleScene/TitleExamples.unity` in the package to try every example in manual 03. The scene inside the package is overwritten on update even if you edit it, so if you want to play around with it, rebuild it into `Assets/WorldTitleGimmickData/ExampleScene/TitleExamples.unity` with the menu "World Title Gimmick/見本のシーンを作る (Build Example Scene, examples from manual 03)".

- Areas built from basic shapes such as Cubes are lined up. In order from the lobby: **A Concrete examples** (A-1 Combinations = 03, chapter 15; A-2 Using it in a world (advanced) = 03, chapter 18), a yellow line and a boundary sign, then **B List of available conditions** (B-1 to B-9 = 03, chapters 1–13; B-10 = 03, chapter 19, extra settings).
- The "components used" on the A signs list the numbers of the B areas (1-1, 8-4 and so on). The blue button in the lobby takes you to the entrance of B.
- Each area's sign explains how to try it.
- Prerequisite titles can be received with the orange buttons (the gray buttons remove them).
- At the right end of each row are blue warp buttons: "To the left end of this row" and "To the lobby".
- The spawn point is surrounded by walls. When you join, you automatically get "はじめの一歩" (First Step). Equip it on the board you bring up with the Title Notebook, and the walls disappear so you can go outside (practice for using the notebook).
- It also creates its own title table, `ExampleTitles.asset`. Seconds and counts are set to small numbers so they are easy to try.
- Running it again rebuilds the scene and the table (your edits are lost).

## 5. Placing it in the scene

1. Open your own scene where you want titles.
2. Run the menu "World Title Gimmick/シーンに称号システムを置く (Add Title System To Scene)".
   A GameObject named "World Title Gimmick" is created in the scene, with the following inside it.
   - Title Manager (TitleManager)
   - Title Board (TitleBoard)
   - Overhead nameplates (TitleNameplates)
   - Unlock popup (TitlePopup)
   - Title Notebook (TitleNotebook) and the portable Title Board that the notebook brings up in front of you (Title Board (Portable)). On desktop, press the T key; in VR, hold both triggers to call the notebook. If you do not use it, turn off the manager's "その場で出すボード（手帳）を使う (Use Portable Board)" (7-1)
   - The receiver for head pats and high fives (Title Touch, 7-16). If you do not use the stats `pats`, `patted` or `high_fives`, it removes itself at the start of Play
3. Make the title table (Title Database) (chapter 6). The first time you place it, the sample table is set automatically.
4. Select the Title Manager in the Hierarchy, and choose the table to use in the Inspector's "称号の表 (Title Database)".
5. Move the Title Board to a place where players can touch it.
6. Add components to the places and objects where you want to give titles (chapter 7). The component field "称号マネージャー（空なら自動） (Manager)" (under "詳しい設定 (advanced settings)" → "つなぎ (link)") can stay empty (it is filled in automatically when baking).
7. Save the scene.

- Baking runs automatically before Play and before building. To do it by hand, press "今すぐ焼き込む (Bake Now)" in the manager's Inspector.
- Mistakes in the table (duplicate keys, conditions that cannot be read, and so on) show warnings in the Console when baking.
- If you run "シーンに称号システムを置く (Add Title System To Scene)" again, the Title Board, nameplates, popup, notebook and head-pat receiver are rebuilt (the board's position is also reset). The manager's settings are kept. The network IDs of the removed old objects are also removed from the scene's record (VRC Scene Descriptor).
- If pressing Play stops with "InvalidObject at …" and "Found 1 errors while configuring network IDs!", network IDs of deleted objects remain in the scene. Remove them with the "取り除く" (Remove) button in Check Scene, or by opening VRChat SDK → Utilities → Network ID Import and Export Utility. Then save the scene.

### 5-1. Check Scene

When you have finished adding components, press the menu "World Title Gimmick/シーンを点検 (Check Scene)" (or "シーンを点検 (Check Scene)" in the manager's Inspector). It lists setup mistakes in a window. Click a row to select that object.

| Mark | Meaning | Examples |
|---|---|---|
| ✖ Problem | Will not work as is | A component's title is not in the table; a Title Area has no Is Trigger collider; an object to grab has no VRC Pickup; a gate has no condition or nothing to switch; duplicate keys or unreadable conditions in the table |
| ▲ Warning | Works, but may not behave as you expect | Using a retired title; switching the collider of an Object Sync object; two Perks that change speed |
| ・ Info | Good to know | A title that nothing gives (fine if you give it from code); an estimate of the save size |

Check Scene does not change the scene (it only bakes, the same as before Play).

### 5-2. Test Panel during Play

During Play (ClientSim), open the menu "World Title Gimmick/テスト用パネル (Test Panel)". You can change the local player's data to test.

| What you can do | How |
|---|---|
| Give / remove titles | "渡す (Give)" / "外す (Remove)" in the list. ✔ marks titles you own. Use "絞り込み (Filter)" to search by word or key |
| Give all | "全部渡す (Give All)" at the top |
| Add to a counter | Enter a name and an amount, then "足す (Add)". The counter names used in this table and scene are shown below |
| Write a stat | Choose a stat, enter a number, then "書き込む (Write)" (you can write stats that are not being counted too) |
| Write a record | Shown only when the table has record titles. Choose a record, enter a number, then "書き込む (Write)" (it writes even if the value is not better; 0 means no record) |
| Reset all | "全部やり直す (Reset All)" at the top (same as Title Reset) |

- Values you change stay in ClientSim's save. To undo them, press "全部やり直す (Reset All)".
- Nothing is added to the world (it only works from the editor during Play).

## 6. Making the title table

### 6-1. Creating the table asset

**The table already exists.** When you use the menu "シーンに称号システムを置く (Add Title System To Scene)", it creates `Assets/WorldTitleGimmickData/Titles.asset` by copying the package's sample table (`Samples/SampleTitles.asset`) and puts it in the manager's "称号の表 (Title Database)" (if the file already exists, it uses that). Edit this table. The sample table inside the package is overwritten on update (the example scene uses `Samples/ExampleScene/ExampleTitles.asset`). You can see which table the scene uses in the "称号の表 (Title Database)" field of the manager's Inspector, or in "表の場所 (Table location)" at the top of the Title Editor ("Project で見る (Show in Project)" shows it in the Project window).

To make another table yourself:

1. In the Project window, right-click the folder where you want it.
2. Choose Create → World Title Gimmick → "称号の表 (Title Database)".
3. Select the new asset, and you can add and edit rows in "称号の行（N）" (Rows) in the Inspector.

- "次に振る ID (Next ID)" is shown near the top of the Inspector (below "ID の範囲 (ID range)" and "消した行の番号を使い直す（公開前だけ） (Reuse numbers of deleted rows, before publishing only)"). IDs are assigned automatically and **cannot be edited** (since 2026-10-28, because if you typed a large number by hand, the next rows would be numbered from there).
- After you duplicate a row (Duplicate Array Element or the + button), **change the key of the copy**. The original row keeps its ID and the copy gets a new ID (if you change the key of the original row instead, the ID follows the key, so it moves to the copy).
- "キー (Key)" is updated when you finish typing and confirm (press Enter or click another field).
- When "次に振る ID (Next ID)" is ahead of the largest ID in the table (you entered an ID by hand or deleted rows), a button "次に振る ID を表に合わせて詰める (Shrink Next ID to fit the table)" appears. Use it **only before publishing** (if you reuse the IDs of deleted rows after publishing, people who had those titles will see a different title).
- Problems in the table (duplicate keys, empty words and so on) are shown in a yellow box at the top of the Inspector.
- When you have many rows, use the menu "World Title Gimmick/称号エディタ (Title Editor)" (or "称号エディタで開く (Open in Title Editor)" in the table's Inspector). When it opens, the table of the scene's manager is loaded (you can choose another table in the field at the top left).
  - "表の場所 (Table location)" (the file location of the table asset) is shown at the top. "Project で見る (Show in Project)" shows it in the Project window. With "CSV に書き出す (Export CSV)" and "CSV から読み込む (Import CSV)", you can edit the whole table in a spreadsheet app (6-5).
  - In the list you can search (key, word, condition, description, ID), sort (ID, order, key, word), and filter by type (all, titles, connectors, internal, records). Turn off "廃止も出す (Show retired)" to hide retired rows. Select a row to see all of its fields on the right.
  - The "もらい方 (How to get)" column in the list shows the table condition or "部品 n 個 (n components)" (the number of components in the scene that give that title). A title that nothing gives shows "（渡すものなし） (nothing gives it)". Click a component's name under "この称号を渡す部品 (Components that give this title)" at the lower right to select that component.
  - Mistakes in conditions and duplicate keys are shown in red text with ⚠.
  - Add rows with "称号を足す (Add Title)", "接続語を足す (Add Connector)", "内部用を足す (Add Internal)", "記録を足す (Add Record)" and "選んだ行を写す (Duplicate Selected Row)" (a key that does not overlap is filled in automatically).
  - "**削除** (Delete)", "**▲ 番号を前と入れ替え** (Swap number with previous)" and "**▼ 番号を後と入れ替え** (Swap number with next)" can be pressed only while "消した行の番号を使い直す（公開前だけ）" (Reuse numbers of deleted rows, before publishing only) at the top (6-2) is on (deleting rows or changing numbers after publishing makes people's titles look like different ones; 13-1).
    - Delete: deletes the selected row right away, without a confirmation. If scene components give that title, or the key appears in other rows' conditions, the Console shows how many.
    - ▲ / ▼: swaps the selected row's ID with the row of the same kind that has the next lower (higher) number (when the list is sorted by ID, it swaps with the row above or below). The display order (order on the board) does not change.
    - All of these can be undone with Ctrl+Z.
  - With "**条件を選んで作る (Build a condition by choosing)**" below the fields on the right, you can make a condition (chapter 8) by choosing instead of writing it. Choose a "種類 (Type)" (stat, counter, number of owned titles, owns all of these titles, period, record title), then choose from the list and set a number, and it is written into the "条件 (Condition)" field right away. A sentence like "Gives the title when 'times jumped' reaches 100 or more" appears below, so you can check that it is correct. It reads the current condition and shows it as already selected, so it is easy to change only the number later. If the condition is written in a way it cannot read, it shows "（手で書いた条件・読めない） (hand-written condition, cannot read)", and choosing a type rebuilds it. It is not shown for record rows or for connector rows usable from the start (because they do not use conditions).

### 6-2. Table fields

In the table's Inspector and on the right side of the Title Editor, field names are shown in Japanese. Hover the mouse over a field, and the end of the tooltip shows the English name and the name used in code and CSV, in the form "［Word En / wordEn］". In the table's Inspector, each row is folded under a heading "ID　word　[key]" (the list is named "称号の行（N） (Rows)"), and fields that do not fit the row's kind are hidden (record settings only on record rows, "最初は使えない (Locked Connector)" only on connector rows, and so on).

| Field | What to write | Example |
|---|---|---|
| "ID（自動）" Id (`id`) | Assigned automatically. Cannot be edited (13-1) | 1 |
| "キー（英数字と _）" Key (`key`) | Letters, numbers and `_`. A name that does not overlap with others in the table. Components and code refer to the title by this name | `rooftop` |
| "分類" Kind (`kind`) | 通常 (Normal) / 接続語 (Connector) / 内部用 (Internal) (chapter 10; save markers) / 記録 (Record) (6-6) | 通常 (Normal) |
| "語（日本語）" Word (`word`) | The Japanese word. The text shown in the plate | 屋上の住人 |
| "語（英語。空なら日本語）" Word En (`wordEn`) | The English word. If empty, the Japanese word is shown (people viewing in English also see Japanese) | Rooftop Dweller |
| "持っていないときの説明" Desc Before (`descBefore`) | Description (before unlocking). Shown on the board while the player does not own the title. Can be vague. If empty, the description after unlocking is shown | ？？？に登る |
| "持っていないときの説明（英語）" Desc Before En (`descBeforeEn`) | English description (before unlocking) | Climb ??? |
| "持っているときの説明" Desc After (`descAfter`) | Description (after unlocking). Shown when the player owns the title | 屋上に登る |
| "持っているときの説明（英語）" Desc After En (`descAfterEn`) | English description (after unlocking) | Climb to the rooftop |
| "条件（表だけで渡す。空なら部品から）" Condition (`condition`) | A condition for giving the title automatically from the table alone (chapter 8). If empty, the title is given from components or code. Not shown on record rows | `count:button>=10` |
| "名前の見せ方" Name Mode (`nameMode`) | Name before unlocking: 見せる (Show) / 隠す (Hide) / 一覧に出さない (Not listed). For titles used as save markers, set the Kind to "内部用 (Internal)" (chapter 10; this field is not shown for internal rows) | 見せる (Show) |
| "最初は使えない（解禁する接続語）" Locked Connector (`lockedConnector`) | Shown only on connector rows. When on, the connector cannot be used at first and is unlocked by a condition or similar (6-3) | Off |
| "状態" State (`state`) | 使用 (Active) / 廃止 (Retired) | 使用 (Active) |
| "ボードでの並び順" Order (`order`) | Order on the Title Board. Smaller comes first. If equal, by ID | 0 |

- Choose the ID ranges with **ID の範囲 (ID Range)** at the top of the table's inspector (default: 中 (Medium)).

| ID Range | Normal titles | Connectors | Internal | Record titles |
|---|---|---|---|---|
| 小 (Small) | 1–199 | 201–299 | 301–1000 | 1001–32767 |
| 中 (Medium, default) | 1–799 | 801–999 | 1001–2000 | 2001–32767 |
| 大 (Large) | 1–8999 | 9001–9999 | 10001–11000 | 11001–32767 |

  - The owned-titles save is "the largest owned ID ÷ 8" bytes. Smaller ranges make the save smaller when a player owns an unlocked connector or an internal title (Medium: from about 100 bytes for connectors and about 125 bytes for internal titles; Large: from about 1.1 KB and 1.25 KB). Record titles are saved separately, so the range does not matter for them.
  - Changing the range renumbers rows whose IDs do not fit (a confirmation appears). **Do not change it in a published world** (players' saves and titles would no longer match).
  - When a range is full, IDs cannot be assigned (the table check reports it). In that case, make the range larger (before publishing).
  - By default, a number that has been used once is never reused (when you delete a row, its number stays empty). To fill in empty numbers **before publishing**, turn on "**消した行の番号を使い直す（公開前だけ）** (Reuse numbers of deleted rows, before publishing only)" at the top of the table inspector or the Title Editor (a confirmation appears). New rows then get the smallest empty number in the range (existing rows keep their numbers). Turn it off after publishing: people who owned a deleted title would appear to own the new title with that number.
- You can change words, descriptions and conditions later. Only the IDs are saved.
- If a connector's word is "（空白）", it appears in the plate as a half-width space.
- Choose the language in the manager (7-1; the default is "日本語 (Japanese)"). With "自動 (Auto)", if the viewer's VRChat language is Japanese the Japanese fields are shown, otherwise the English fields. Rows with empty English fields are shown in Japanese. For a Japanese-only world, the English fields can stay empty.

> Fields for record titles ("記録の書式" Record Format and so on) are in 6-6. We decided not to include yellow titles. Revealing titles you have seen is set not by a table column but by the manager's "ほかの人の装備で明かす (Reveal Equipped)" (7-1, chapter 10).

### 6-3. Locked connectors

You can let only players who meet a condition use a special connector (example: ♛).

1. On the connector row, turn on "最初は使えない（解禁する接続語）" (Locked Connector).
2. Write the unlock condition in "条件" (Condition) (example: `owned>=3`).

- Unlocked connectors are saved just like titles. An unlock popup is also shown.
- Before unlocking, the connector appears faded in the board's connector list and cannot be put in a slot.
- "名前の見せ方" (Name Mode: Hide / Not listed) and the descriptions before and after unlocking also work for connectors.
- Connectors are not included in the "獲得 n / m" (Owned n / m) count or in the count for the condition `owned>=`.
- If you write a condition on a connector whose "最初は使えない" (Locked Connector) is off, it is not used (a warning is shown when baking).
- The lists of "渡す称号" (Grant Keys) on components and "その回数で渡す称号" (Step Keys) on counters also show connectors. If you choose a connector, the component's result unlocks that connector (give a row that has only "最初は使えない" turned on, with no condition, from a component).

The sample table's connectors are 「が・で・と・な・の・は・・・！」 (usable from the start) and ♛ (key `crown`, condition `owned>=3`, Hide). Other symbols (☆, ★, 〜, （空白） (space), etc.) can be added with the pack "Common connectors" (6-4).

### 6-4. Adding sample titles (packs)

You can add many titles at once that work without placing any components. Only titles that work in any world are included.

1. Select the table asset.
2. In the Inspector, open "見本の称号を足す（部品なしで動く称号のパック） (Add sample titles: packs of titles that work without components)".
3. Press "足す (Add)" for the pack you want.

| Pack | Titles included (condition) |
|---|---|
| Visits & stay (8) | Welcome Back (join 10 times), Familiar Face (3 days), Regular (7 days), Resident (30 days), Local Legend (100 days), Perfect Attendance (7 days in a row), Laid-back (60 minutes in total), Fixture (10 hours in total) |
| Moving around (7) | Jumper (100 times), Jump King (1000 times), Stroller (1 km), Traveler (10 km), Marathoner (42.195 km), Phoenix (10 respawns), Grabby (50 times) |
| Social (5) | Socialite (10 people in total), Well-Connected (100 people in total), Party Goer (5 or more people), Crowd Lover (20 or more people), Quick Change (10 avatar changes) |
| Title collecting (2) | Title Hunter (10 titles), Title Master (20 titles) |
| Common connectors (8) | の ('s), ・, ☆, ★, 〜, ♪, ＆ (&), （空白） (space) |

- The titles include English words and descriptions (among the connectors, only "の", "＆" and "（空白）" have English words; the other symbols are shown as they are).
- Keys start with `pack_`. If a row with the same key or word already exists, that row is not added.
- After adding, you are free to change the words, descriptions and conditions (counts and so on).

### 6-5. Editing as CSV

1. Press "CSV に書き出す (Export CSV)" at the top of the Title Editor (menu "World Title Gimmick/称号エディタ (Title Editor)") to turn the table into CSV (a format Excel can open directly). The table's Inspector has the same button.
2. Edit it in a spreadsheet app and save it as CSV. In Excel, save as "**CSV UTF-8 (Comma delimited)**" (plain "CSV (Comma delimited)" becomes Shift_JIS. If it can be read, it is read as Shift_JIS and a warning is shown).
3. Read it with "CSV から読み込む (Import CSV)". You can undo the import with Undo (Ctrl+Z).

- Rows are **matched by key (Key)**. Rows whose key is in the table are updated, and rows whose key is not are added.
- **Import does not change the ID or "分類" (Kind)** (to prevent saves from switching to a different title). New rows get IDs automatically.
- Rows not in the CSV are not deleted. To stop using a title, set its "状態" (State) to "廃止 (Retired)".
- The columns are `id,key,kind,word,wordEn,descBefore,descBeforeEn,descAfter,descAfterEn,condition,nameMode,lockedConnector,state,order`, plus the record row settings `recordFormat,recordDigits,recordSuffix,recordSuffixEn,recordLowerBetter,recordSaveKey,recordVersion` (6-6). You can delete columns you do not need (deleted columns leave those fields unchanged).
- Write kind, nameMode, state and recordFormat as their Japanese names (通常・接続語・内部用・記録; 見せる・隠す・一覧に出さない・内部用; 使用・廃止; 数・小数・時間・分秒) or as numbers. lockedConnector and recordLowerBetter are 1 / 0.
- For rows that could not be read, the reason is shown in the message after importing.

### 6-6. Record titles

A title that builds its word from a saved value. Examples: "Best Time 12.34 s", "High Score 9,800 pts", "Fish Caught 52". Set the table's "分類" (Kind) to "記録 (Record)" (in the Title Editor, "記録を足す (Add Record)").

| Field | Meaning | Default |
|---|---|---|
| "語（日本語）" / "語（英語。空なら日本語）" Word / Word En | The prefix. Placed before the value, with a half-width space between them | Empty |
| "記録の書式" Record Format (`recordFormat`) | Format: 数 (Number, with "," every 3 digits) / 小数 (Decimal) / 時間 (Time, a value in 0.01 s units shown as `12.34`) / 分秒 (Min:Sec, a value in seconds shown as `1:05`) | 数 (Number) |
| "小数のけた数" Record Digits (`recordDigits`) | Number of digits when the format is "小数 (Decimal)" (value 1234 with 2 digits gives `12.34`). Shown only for "小数 (Decimal)" | 2 |
| "値のあとに付ける語" / "値のあとに付ける語（英語）" Record Suffix / Record Suffix En | A word placed after the value (s, pts, fish and so on) | Empty |
| "小さいほど良い記録（タイムなど）" Record Lower Better (`recordLowerBetter`) | When on, smaller is better (times and so on). When off, larger is better (scores and so on) | Off |
| "保存のキー（空なら自動）" Record Save Key (`recordSaveKey`) | The save key (write the PlayerData key as it is). If empty, `<prefix>rec.<key>`. Use this to read a value that another system already saves | Empty |
| "記録の版" Record Version (`recordVersion`) | Raise this when you change how the record is counted. Records with a different version become "no record" (`.v<version>` is added to the save key). 0 adds nothing | 0 |

- Records are written from code or Udon Graph (`_SetRecord("key", value)`; 02, chapter 3). It saves only when the value is better than before, and shows a popup ("New title unlocked!" the first time, "New record!" when updated). The value is an integer of 1 or more (0 means "no record").
- If there is a record, the player owns that title. Put it in a plate slot and it shows like "Best Time 12.34 s"; when the record improves, the plate changes too. Other people's nameplates are built from their own records.
- While there is no record, the board shows only the prefix (the word). How the name is shown before unlocking ("名前の見せ方" Name Mode) is the same as normal titles.
- Records are not counted in the owned count (`owned>=`). You cannot write a "条件" (Condition) on a record row (the field is not shown), because having a record means owning it.
- You can give other titles based on a record's value (table condition `record:key>=N`, 8-1). If you write a record title's key in the condition `all:`, it counts as owned when there is a record. It can also be used in a gate's condition ("記録の称号" Record Key in 7-5).
- Records are saved immediately when written. Each write is sent to the people in the same instance, so do not use it in a way that writes every frame.
- "全部やり直す (Reset All)" (7-7) erases only records saved under `<prefix>rec.`. Records whose key was set to another system's key with "保存のキー（空なら自動）" (Record Save Key) are kept.
- During Play, you can write values in "記録 (Record)" in the Test Panel (5-2) (it writes even if the value is not better; 0 means no record).

## 7. Settings for each component

### 7-0. The easy way to add them (right-click menu)

If you are not sure which component to add, right-click an object in the Hierarchy → "World Title Gimmick" and choose what you want to do. It adds the matching component and anything missing (collider, Rigidbody, VRC Pickup). If no object is selected, it creates a new object and adds it there.

| Menu | Component added | Settings filled in automatically |
|---|---|---|
| 掴んだら称号を渡す (Give a title when grabbed) | Title Action | Action "掴む (Grab)". Adds Pickup, Rigidbody and collider if missing |
| 持って使ったら（トリガー）称号を渡す (Give a title when used while held (trigger)) | Title Action | Action "使う (Use)" |
| 投げたら称号を渡す (Give a title when thrown) | Title Action | Action "投げる (Throw)" |
| 触ったら（Interact）称号を渡す (Give a title when touched (Interact)) | Title Action | Action "押す（Interact） (Press (Interact))". Adds a collider if missing |
| 押した回数で称号を渡す（カウンター） (Give titles by number of presses (counter)) | Counter | Counter name is the object's name (alphanumeric), with one step at 10 times |
| エリアに入ったら称号を渡す (Give a title when entering an area) | Title Area | "本人が入ったら (When the local player enters)". Adds an Is Trigger collider if missing |
| エリアに物を置いたら称号を渡す (Give a title when an object is placed in an area) | Title Area | "指定した物が入ったら (When a chosen object enters)" |
| 称号を持つ人だけに見せる・触れさせる (Show / allow touching only for title holders) | Title Gate | Puts the object's own renderer and collider into the visual and collider fields |
| 称号を持つ人だけ通れる壁にする (Make a wall only title holders can pass) | Title Gate | "反転 (Invert)" on (the visual and collider disappear only on the screen of people who own the title) |
| 称号を装備したら速く動ける・高く跳べるようにする (Move faster / jump higher when a title is equipped) | Title Perk (7-11) | Condition "装備している (Equipped)", changes speed |
| いくつかのきっかけを全部満たしたら称号を渡す（条件まとめ） (Give a title when several triggers are all met (All Of)) | All Of (7-14) | All so far (saved). The save name is the object's name |
| 称号をもらったら Udon Graph へイベントを送る (Send an event to Udon Graph when a title is received) | Title Relay (7-13) | `OnTitleGranted` when received |
| 肩書きのボードを作成する (Create a Title Board) | Title Board (7-8) | Creates one more Title Board, the same as the one from "シーンに称号システムを置く (Add Title System To Scene)" (named Title Board (Extra)) |
| いまいる人の肩書きの一覧ボードを置く (Place a Roster Board) | Roster Board (7-12) | Creates a board with 12 lines |
| やり直しのボタンにする (Make a reset button) | Title Reset | Reset all; press twice within 3 seconds |

After adding one, it works if you just **choose the title to give (for a gate, the condition titles)** in the Inspector.

### 7-0-1. How to read the Inspector

- The very top is the Udon section (UdonSharp's English fields shown in Japanese).
  - Pressable components (components that work with Press (Interact)) show "押せる距離 (Proximity)" and "押してみる（Play 中だけ） (Trigger Interact)". For Title Action they are shown only when the action is "押す（Interact） (Press (Interact))", and for Title Counter only when "押して（Interact）増やす (Interactable)" is on.
  - The text shown when pointing at the object (Interaction Text) is not shown at the top for Title Action, Title Counter and the reset button. Set it in the component's "物に向けたときに出る文字（Interact） (Interact Text)" field (because this field's text overwrites it when you join the world).
  - **When added to an existing switch or button**: Title Action, Title Counter and the reset button show "ほかの押せる部品に合わせる (Match Other Interact)" (on by default) at the top. If the same object has another interactable Udon (UdonSharp, Udon Graph, CyanTrigger and so on), its interact distance and text are copied to this component, and this component's distance and text fields are greyed out (change them on the original switch instead). They are copied when you open the inspector, when you add the component from the right-click menu, before Play and before a build. One press runs both the original switch and the title component. If there is no other interactable component, this component's own settings are used. Turn it off if you want a different distance or text.
  - Program, sync and utilities (Program Source, Utilities and so on) are folded under "Udon の設定（ふつうは触らない：プログラム・同期・道具） (Udon settings: usually leave alone: program, sync, utilities)". You normally do not need to open it.
  - Fields of VRChat SDK components such as VRC Pickup (Use Text and so on) stay in English.
- Below that, a gray box describes in a sentence what happens with the current settings (example: "When this object is grabbed 5 times, gives 'Grabber' (once only)."). The sentence changes when you change the settings.
- Below that, only the **commonly used fields** are listed. In most cases these are enough.
- Prerequisites, counters, events, switching objects and so on are folded under "**詳しい設定 (advanced settings)**".
- When you open "詳しい設定 (advanced settings)", **foldouts by category** are listed (example: for a Title Area, "物が入ったとき (When an object enters)", "保存 (Save)", "ヒント（持っていない称号を明かす） (Hints: reveal titles not owned)", "前提の条件（このときだけ動く） (Prerequisites: works only when)", "称号のほかに起こすこと (Other things to do besides titles)", "イベントを送る（Udon Graph など） (Send events: Udon Graph etc.)", "知らせ・音 (Popup & sound)", "くり返し (Repeat)", "つなぎ（ふつうは空のまま。自動で入る） (Link: usually leave empty, filled in automatically)"). Click the triangle of the category you want to open.
- A category that has something set (a field with a title, object or text in it) shows its name in **bold** with "（設定あり） (set)" added. You can see where you made changes even while it is closed (number and on/off fields are not checked).
- Fields that do not belong to any category are shown under "そのほか (Other)". The Title Manager field in "つなぎ (Link)" can normally stay empty (it is filled in automatically when baking).
- All field names are shown in Japanese. Hover the mouse over a field to see its description, ending with the English name and the code name in the form "［Required Keys / requiredKeys］". The "English (`variable`)" names in the tables of this manual are these names.
- In fields where you choose titles, you can pick from a list shown as "word　[key]" instead of typing the key. Add a row with "＋ 称号を足す (+ Add Title)" and delete one with "－".
- Settings stored as numbers (such as an area's trigger) are chosen from a list of options.
- Unused fields are hidden depending on the choices in other fields (example: when "何が入ったら (Who)" is "本人 (Local player)", "入る物 (Objects)" is not shown).
- If the scene has no manager or no table is set, titles are entered as key text.
- The "Where" column in the tables below shows where the field is. "Common" means the fields listed at the top; "Advanced: XX" means the "XX" category inside "詳しい設定 (advanced settings)".
- In Add Component, they are listed under "World Title Gimmick" with Japanese names such as "称号ゲート（TitleGate）". Typing `TitleGate` in the search field also finds them.

### 7-1. Title Manager (TitleManager)

Place only one in the scene. Its Inspector is shown in Japanese.

| Section | Field | Meaning | Default |
|---|---|---|---|
| 全体 (General) | 称号の表 (Title Database) | The Title Database to use | The sample table |
|  | 言語 (Language) | 日本語 / English / 自動（見る人の言語） (Auto: viewer's language). Table words and descriptions, and board and popup texts, are shown in this language. "自動 (Auto)" uses Japanese if the viewer's VRChat language is Japanese and English otherwise, and switches immediately when the VRChat language changes. Other people's plates are also shown in the viewer's language. If the viewer chooses a language with the language button on the Title Board, that takes priority (7-8) | 日本語 (Japanese) (since 2026-10-29; managers already placed keep their value) |
|  | 保存のキーの頭 (Key Prefix) | The prefix of save names. Use a name that does not overlap with other assets. **Do not change it after publishing** (if you change it, earlier saves can no longer be read) | `wtg.` |
| 肩書き (Plate) | 文字数の上限 (Max Plate Chars) | Maximum number of characters in a plate | 50 |
|  | 枠 1〜10 (Slot 1–10) | The type of each slot (chapter 9) | Slot 1 どちらも (Both), Slot 2 接続語だけ (Connectors only), Slot 3 どちらも (Both), Slots 4–10 使わない (Unused) (since 2026-10-29; managers already placed keep their values) |
|  | 固定の語 (Fixed word) | The connector put in a slot whose type is "固定の語 (Fixed word)" | None |
|  | 解禁の称号（なし＝最初から） (Unlock title: none = from the start) | The slot cannot be used until the player owns this title (9-2) | None |
| 表示 (Display) | 称号の知らせを出す (Show Popups) | When off, no title popups (unlocks, hints, record updates) are shown anywhere in the world. If a component has a "効果音 (Sound)" set, only the sound plays. The reset button's confirmation and "done" messages are still shown (7-10) | On |
| 表示 (Display) | 獲得の知らせ (Popup) | The unlock popup (TitlePopup). If empty, no popup is shown (and no sound plays) | Set automatically |
| 表示 (Display) | 知らせの出し方 (Popup Mode) | "1つずつ（称号の下に取得条件） (One at a time, with unlock condition below the title)": shows received titles one at a time in order, with the unlock condition (the description after unlocking; if empty, the description before unlocking) below the title. "まとめて (Together)": lists titles received at the same time in a single popup | 1つずつ (One at a time) |
|  | ほかの人の装備で明かす (Reveal Equipped) | 明かさない (Don't reveal) / 名前だけ (Name only) / 名前と取得条件 (Name and unlock condition). Makes titles that other people in the same instance have in their plates visible on the board even if you do not own them yet (chapter 10). What is revealed is saved | 明かさない (Don't reveal) |
|  | 名札を最初は出す (Show Nameplates Default) | Whether overhead nameplates are shown from the start. When a player switches it on the board, that player's setting is saved | On |
|  | その場で出すボード（手帳）を使う (Use Portable Board) | When on, the Title Notebook (called with the T key on desktop, or by holding both triggers in VR) can bring up a Title Board in front of you. When off, the notebook is removed. Players cannot choose | On |
| 行動の値 (Stats) | テレポートとみなす距離（m） (Teleport Meters) | For distance walked (`walk_m`) and fall height (`fall_max_m`): a single move of this distance or more is not counted | 20 |
|  | 近くにいるとみなす距離（m） (Near Meters) | For `near_min` (time spent near other people): counts as near if someone is within this distance | 2 |
|  | 手渡しとみなす距離（m） (Handoff Meters) | For `received_items` (times received): when you grab a Title Action's object and another person's hand is within this distance, it is a hand-off | 0.4 |
|  | 会うと数える称号 (Holder Keys) | Titles counted by `met_title_holders` (times met a person with a title). Add them with "＋ 称号を足す (+ Add Title)". Meeting someone who owns any one of them counts once | None |
|  | 会うと数える人の表示名 (Creator Names) | Display names of people counted by `met_creator` (times met the creator, etc.). Display names can be changed, so do not use this for prizes and the like | None |
| テスト (Test) | Editor で始めたとき全称号を持つ (Test All Owned) | Only during Play in the Editor, start with all titles owned (not saved; see below) | Off |

Below them, "今すぐ焼き込む (Bake Now)" bakes, "シーンを点検 (Check Scene)" opens the check window (5-1), and "称号の表を開く (Open Title Table)" selects the table.

- Whether a stat (8-2) is counted is decided automatically. Only stats used in table conditions or Title Gates are counted.
- To give or remove titles, or change counters, stats or records during Play, use the Test Panel (5-2).
- If you turn on the test option "**Editor で始めたとき全称号を持つ (Test All Owned)**", Play in the Editor (ClientSim) starts with all titles and locked connectors owned. Ownership is not saved (when you turn it off again, you go back to what you really own). Baking enables it only before Play and always disables it before building (uploading), so it has no effect in a published world.

### 7-2. Fields shared by Title Area and Title Action

Title Area (TitleArea) and Title Action (TitleAction) both have the following fields. All Of (TitleAllOf, 7-14) has the same fields too.

"渡す称号 (Grant Keys)" is shown in the commonly used fields (at the top). The others are inside "詳しい設定 (advanced settings)", divided into categories with the same names as the "Advanced:" headings below. However, in Title Action, "明かす称号（ヒント） (Reveal Keys)" and "明かすもの (Reveal What)" are also shown at the top. "一度だけ (Once)" is shown at the top in Title Area and Title Action (in All Of it is inside "くり返し (Repeat)").

**Titles to give** (common)

| Field | Meaning |
|---|---|
| "渡す称号" Grant Keys (`grantKeys`) | The titles to give. If there are several, they are shown together in a single popup |

**Advanced: ヒント（持っていない称号を明かす） (Hints: reveal titles not owned)**

| Field | Meaning |
|---|---|
| "明かす称号（ヒント）" Reveal Keys (`revealKeys`) | The titles to reveal. Makes the name and unlock condition of titles not yet owned visible on the Title Board (chapter 10). Does not give the titles. What is revealed is saved |
| "明かすもの" Reveal What (`revealWhat`) | 名前と取得条件 (Name and unlock condition) / 名前だけ (Name only) / 取得条件だけ (Unlock condition only). Shown only when there are titles to reveal |
| "明かしたら知らせを出す" Reveal Popup (`revealPopup`) | When on, a newly revealed title shows "Found a title hint" with its name and description on the unlock popup board (not shown for titles already revealed). Shown only when there are titles to reveal |

**Advanced: 前提の条件（このときだけ動く） (Prerequisites: works only when)** (if not met, nothing happens even when the trigger occurs)

| Field | Meaning |
|---|---|
| "この称号を全部持っている人だけ" Required Keys (`requiredKeys`) | Works only when the player owns **all** of these titles |
| "この称号を持っている人には渡さない" Forbidden Keys (`forbiddenKeys`) | Does not work if the player owns **any** of these titles |
| "この称号を装備している人だけ" Equipped Keys (`equippedKeys`) | Works only when the player has **any** of these titles equipped. If empty, not checked |
| "この物を手に持っている人だけ" Held Objects (`heldObjects`) | Works only when the local player is holding **any** of these objects. If empty, not checked |
| "人数がこれ以上のとき（0 なら見ない）" Min Players (`minPlayers`) | Only when the instance has this many players or more. 0 means not checked |
| "人数がこれ以下のとき（0 なら見ない）" Max Players (`maxPlayers`) | Only when the instance has this many players or fewer. 0 means not checked |
| "期間（例 1025-1031。空なら見ない）" Period (`period`) | Only during this period (the device's date). Written the same way as `date:` in the table: `1025-1031` is every year, `20261025-20261031` is only that year, `1031` is a single day. If empty, not checked |
| "端末" Device (`device`) | すべて (All) / VR だけ (VR only) / デスクトップだけ (Desktop only) |

**Advanced: 称号のほかに起こすこと (Other things to do besides titles)**

| Field | Meaning |
|---|---|
| "外す称号" Revoke Keys (`revokeKeys`) | Titles to remove (unlocked connectors can be chosen too). They are removed before the titles to give, so you can also use it to swap ("remove A and give B"). If equipped, they are also taken off the plate. Nothing happens if not owned. No popup is shown for removing. Titles earned by a table condition are given again the next time a value changes if the condition is still met (Check Scene warns about this). Use it for titles given by components (empty condition) |
| "足すカウンターの名前（空なら足さない）" Counter Key (`counterKey`) | The name of the counter to add to. If empty, nothing is added |
| "カウンターに足す数" Counter Add (`counterAdd`) | The amount to add to the counter |
| "本人の画面で出す物" Enable Objects (`enableObjects`) | Objects to enable. **Only on the local player's screen** |
| "本人の画面で消す物" Disable Objects (`disableObjects`) | Objects to disable. **Only on the local player's screen** |

**Advanced: イベントを送る（Udon Graph など） (Send events: Udon Graph etc.)**

| Field | Meaning |
|---|---|
| "イベントの送り先" Event Targets (`eventTargets`) | The UdonBehaviours to send events to (Udon Graph and so on) |
| "送るイベントの名前（送り先と同じ並び）" Event Names (`eventNames`) | The event names to send. List them in the same order as the targets (the first name goes to the first target) |

**Advanced: 知らせ・音 (Popup & sound)**

| Field | Meaning |
|---|---|
| "獲得の知らせを出す" Show Popup (`showPopup`) | When off, giving a title from this component does not show the unlock popup (the sound still plays) |
| "効果音（空なら知らせの音）" Sound (`sound`) | The AudioClip played when the title is given. If empty, the sound of the unlock popup (TitlePopup) |

**Advanced: くり返し (Repeat)**

| Field | Meaning | Default |
|---|---|---|
| "一度だけ" Once (`once`) | When on, after giving its result once, it does nothing afterwards | On |
| "次に反応するまでの秒数" Cooldown Seconds (`cooldownSeconds`) | Seconds before it reacts again (so it does not count repeatedly in a row) | 0.5 |

**Advanced: つなぎ（ふつうは空のまま。自動で入る） (Link: usually leave empty, filled in automatically)**

| Field | Meaning |
|---|---|
| "称号マネージャー（空なら自動）" Manager (`manager`) | The scene's Title Manager. If empty, it is filled in automatically when baking |

- "一度だけ (Once)" is remembered only for that visit. However, a component that gives titles the player already all owns, has no reveal titles, revoke titles, counter or events set, and is not part of an All Of, does nothing even after rejoining.
- "全部やり直す (Reset All)" (7-7) also resets "一度だけ (Once)", so it works again.
- Periods check only the date (not the time). It uses the device's date, so do not use it for prizes and the like (13-6). Mistakes are reported when baking.
- The sound plays through the AudioSource of the unlock popup (TitlePopup). If there is no AudioSource, it does not play.

### 7-3. Title Area (TitleArea)

Gives titles for "entered that place" or "put an object in that place".

How to add:

1. Create an empty GameObject, add a BoxCollider or similar, and **turn on Is Trigger**.
2. Fit its size to the area.
3. With Add Component, add "World Title Gimmick/称号エリア（TitleArea）".

| Field | Where | Meaning | Default |
|---|---|---|---|
| "何が入ったら" Who (`who`) | Common | 本人（プレイヤー） (Local player) / 指定した物 (Chosen objects) / 指定したレイヤーの物 (Objects on chosen layers) | 本人 (Local player) |
| "入る物" Objects (`objects`) | Common | The objects, when "指定した物 (Chosen objects)" | Empty |
| "入る物のレイヤー" Layers (`layers`) | Common | The layers, when "指定したレイヤーの物 (Objects on chosen layers)" | Nothing |
| "きっかけ" Trigger (`trigger`) | Common | 入ったら (On enter) / 出たら (On exit) / 続けてN秒いたら (Stay N seconds in a row) / 合計N秒いたら（保存） (Stay N seconds in total (saved)) / N回入ったら (Enter N times) / 中の人数がN人以上（本人のとき） (N or more people inside; local player only) | 入ったら (On enter) |
| "秒数" Seconds (`seconds`) | Common | The seconds for "N seconds in a row" and "N seconds in total" | 10 |
| "回数" Count (`count`) | Common | The count for "Enter N times" | 5 |
| "人数" Crowd Count (`crowdCount`) | Common | The number of people for "N or more people inside" (including yourself) | 2 |
| "誰に渡すか" Receiver (`receiver`) | Advanced: 物が入ったとき (When an object enters) | For objects, who receives it: その物を持っている人 (The person holding it) / 最後に持った人（持ち主） (The last person who held it (owner)) / エリアの中にいる人 (People inside the area) | The person holding it |
| "同時に入る物の数" Object Count (`objectCount`) | Advanced: 物が入ったとき (When an object enters) | For objects, triggers when this many are inside at the same time | 1 |
| "保存の名前（合計の秒・回数。空なら保存しない）" Save Key (`saveKey`) | Advanced: 保存 (Save) | For "N seconds in total" and "Enter N times", the name of the counter that saves the total seconds or count. If empty, it is not saved (goes back to 0 when rejoining) | Empty |

It also has the shared fields from 7-2 ("渡す称号 (Grant Keys)" and "一度だけ (Once)" are shown in the commonly used fields).

- "N seconds in a row" counts every second only while the player is inside. Leaving resets it to 0.
- To keep "N seconds in total" going after rejoining, enter a name in "保存の名前" (Save Key). The counter accumulates the seconds.
- When placing objects, the objects need a Rigidbody and a Collider (VRC Pickup objects usually have them).
- "最後に持った人 (The last person who held it)" is the object's owner. For objects whose position other people should also see, add VRC Object Sync. With it, the person who grabs the object becomes its owner.
- When giving a title for "put an object", set "誰に渡すか" (Receiver) to "最後に持った人 (The last person who held it)". This is because once the object is let go and placed, nobody is "holding it now".
- When "同時に入る物の数" (Object Count) is 3, only the owner of the third object at the moment it enters receives the title.
- "エリアの中にいる人 (People inside the area)": when an object enters the area, everyone inside the area receives the title. Each person decides on their own device, by checking whether they are inside and where the object is. The person who put the object in can be outside. It also gives the title when the object was already inside and a person enters later. So that others can see the object's position, add VRC Object Sync to the object. The object's position can look slightly different to each person, so right at the edge of the area the title may not be given.
- "中の人数がN人以上 (N or more people inside)": usable only when "何が入ったら (Who)" is "本人 (Local player)". When N or more people are in the area, each person inside receives it on their own device. It recounts every time someone enters or leaves, so if the number drops and then reaches N again, it works again (when "一度だけ (Once)" is off).

### 7-4. Title Action (TitleAction)

Gives titles for things like "grab", "use" or "throw" an object. Add it to a VRC Pickup object, or to an object you want players to Interact with (click to use).

| Field | Where | Meaning | Default |
|---|---|---|---|
| "行動" Action (`action`) | Common | 掴む (Grab) / 離す (Drop) / 使う（トリガー） (Use (trigger)) / 押す（Interact） (Press (Interact)) / 持ったままN秒 (Hold for N seconds) / 投げる (Throw) / 持ったままN m動く (Move N m while holding) / ほかの人から受け取る（手渡し） (Receive from another person (hand-off)) / ほかの物に当てる (Hit another object) | 掴む (Grab) |
| "回数" Required Count (`requiredCount`) | Common | Gives the result at this count | 1 |
| "秒数" Seconds (`seconds`) | Common | The seconds for "Hold for N seconds" | 10 |
| "投げる速さ（m/s）" Throw Speed (`throwSpeed`) | Common | The speed that counts as "Throw" (m/s) | 5 |
| "距離（m）" Meters (`meters`) | Common | The distance for "Move N m while holding" (m) | 50 |
| "当てる物" Hit Objects (`hitObjects`) | Common | The objects to hit for "Hit another object" | Empty |
| "当てるレイヤー" Hit Layers (`hitLayers`) | Common | The layers to hit for "Hit another object" (counts if it hits either these or the hit objects) | Nothing |
| "投げてから待つ秒数" Hit Seconds (`hitSeconds`) | Common | Counts if it hits within this many seconds after being thrown | 3 |
| "段の回数" Steps (`steps`) | Advanced: 段（N回で称号A、M回で称号B） (Steps: title A at N times, title B at M times) | When the count reaches these numbers (same order as the step titles). The count is the action count above (or the saved count if a save name is set) | Empty |
| "段で渡す称号" Step Keys (`stepKeys`) | Advanced: 段（N回で称号A、M回で称号B） (Steps: title A at N times, title B at M times) | The titles given at each step (same order as the step counts) | Empty |
| "回数を保存する名前（空なら保存しない）" Save Key (`saveKey`) | Advanced: 回数の保存 (Saving the count) | The name of the counter that saves the count. If empty, it is not saved (starts from 0 when rejoining) | Empty |
| "物に向けたときに出る文字（Interact）" Interact Text (`interactText`) | Advanced: 押す（Interact） (Press (Interact)) | For Interact, the text shown when pointing at the object (shown only when the action is "押す（Interact） (Press (Interact))") | Use |
| "ほかの押せる部品に合わせる" Match Other Interact (`matchOtherInteract`) | Top (above the interact distance) | When on, if the same object has another interactable Udon (such as an existing switch), the interact distance and text are matched to it. While matched, this component's distance and text fields cannot be edited (7-0-1) | On |

It also has the shared fields from 7-2 ("渡す称号 (Grant Keys)", "明かす称号（ヒント） (Reveal Keys)", "明かすもの (Reveal What)" and "一度だけ (Once)" are shown in the commonly used fields).

- The check is done on the device of the local player holding the object.
- "使う (Use)" is when you pull the trigger while holding the Pickup. To let desktop players use it, set the Pickup's Auto Hold to Yes.
- "投げる (Throw)" is decided by the speed right after letting go. The object needs a Rigidbody.
- The two "while holding" actions count every 0.25 seconds only while held.
- "ほかの人から受け取る（手渡し） (Receive from another person (hand-off))" counts once when, at the moment you grab it, another person's hand is near the object (the manager's "手渡しとみなす距離 (Handoff Meters)", default 0.4 m). So that the other person can be seen holding it, add VRC Object Sync to the object.
- When the stat `received_items` is in use, grabbing by hand-off adds 1 to `received_items` for Title Actions with any action.
- When the action is not "押す（Interact） (Press (Interact))", the Interact text is not shown.
- "Enter a chosen area while holding" and "place in a chosen area" are made with a Title Area (7-3).
- Steps: gives titles at different counts, such as "title A at 3 times, title B at 6 times". Prerequisites are checked, but "一度だけ (Once)" and the cooldown are not. If you use only steps, "渡す称号 (Grant Keys)" can be empty. To keep counting after rejoining, enter "回数を保存する名前" (Save Key).
- "ほかの物に当てる (Hit another object)": counts once when the object hits a hit object (or an object on a hit layer) while being held, or within "投げてから待つ秒数 (Hit Seconds)" after the local player throws it. To avoid counting bounces in a row, it does not count for 0.3 seconds. The thing it hits also needs a collider (an Is Trigger collider is fine).

### 7-5. Title Gate (TitleGate)

Shows or hides objects only on the screen of people who own (or equip) a title.

**Commonly used fields** (shown at the top)

| Field | Meaning | Default |
|---|---|---|
| "条件の称号" Title Keys (`titleKeys`) | The titles to check | Empty |
| "条件" Mode (`mode`) | 持っている (Owned) / 装備している (Equipped) (how the condition titles are checked) | 持っている (Owned) |
| "全部そろったら（オフ＝どれか1つ）" Match All (`matchAll`) | When on, all condition titles; when off, any one of them | Off |
| "反転（満たさない人のほうで切り替える）" Invert (`invert`) | When on, switches as "met" when the condition is not met (all the "満たしたら…" (when met) fields below work the other way round; for example "a wall only title owners can pass") | Off |
| "満たしたら見える" Renderers (`renderers`) | Shown only when met | Empty |
| "満たしたら当たり判定あり" Colliders (`colliders`) | Collision enabled only when met | Empty |
| "満たしたら出す物" Objects (`objects`) | Enabled only when met | Empty |
| "満たすまで出す物（壁など）" Objects When Not (`objectsWhenNot`) | Enabled only when not met (such as "a wall for people without the title") | Empty |

**Advanced: 条件の数 (Condition count)**

| Field | Meaning | Default |
|---|---|---|
| "このうち何個でよいか（0＝全部／どれか で決める）" Required Count (`requiredCount`) | It is enough to meet this many of the condition titles. If 1 or more, it takes priority over "全部そろったら (Match All)". If 0, "全部そろったら (Match All)" decides | 0 |

**Advanced: 肩書きの並び・枠 (Plate order & slots)**

| Field | Meaning | Default |
|---|---|---|
| "肩書きにこの順で並んでいる" Sequence Keys (`sequenceKeys`) | These are lined up in this order in the plate. You can choose both titles and connectors. If empty, not checked | Empty |
| "間にほかの語を挟まない" Sequence Contiguous (`sequenceContiguous`) | When on, no other words may be between them in the sequence | Off |
| "枠の番号（1〜10）" Slot Check Slots (`slotCheckSlots`) | Slot numbers (1–10). Same order as "その枠に入っている語 (Slot Check Keys)" | Empty |
| "その枠に入っている語" Slot Check Keys (`slotCheckKeys`) | The word in that slot. You can choose both titles and connectors | Empty |

**Advanced: 称号の数・行動の値・記録 (Title count, stats & records)**

| Field | Meaning | Default |
|---|---|---|
| "持っている称号の数がこれ以上（0 なら見ない）" Min Owned (`minOwned`) | The number of owned titles is this or more (internal titles are not counted). 0 means not checked | 0 |
| "行動の値" Stat Name (`statName`) | The stat (8-2). Choose from the list. "（見ない） (not checked)" means not checked | Not checked |
| "行動の値がこれ以上" Stat Min (`statMin`) | The stat is this or more (shown only when "行動の値 (Stat Name)" is chosen) | 0 |
| "記録の称号" Record Key (`recordKey`) | The record title (6-6). Choose from the list. "（見ない） (not checked)" means not checked | Not checked |
| "記録がこの値に届いている" Record Min (`recordMin`) | The record has reached this value (at least this for higher-is-better records, at most this for lower-is-better records). No record means not met | 0 |

**Advanced: 切り替える物（コンポーネント・掴む・押す） (Things to switch: components, grab, press)**

| Field | Meaning |
|---|---|
| "満たしたら有効にするコンポーネント" Behaviours (`behaviours`) | Turns on the component's enabled only when met (the object is not hidden). AudioSource, Light, Animator, Canvas, other Udon and so on. To add one, do not drag the object into this field; drag the component's header in the Inspector |
| "満たしたら無効にするコンポーネント" Behaviours When Not (`behavioursWhenNot`) | Turns off the component's enabled only when met (on when not met). Add them the same way as above |
| "満たしたら掴める物（Pickup）" Pickup Objects (`pickupObjects`) | Can be grabbed only when met (put in objects that have a Pickup) |
| "満たしたら押せる Udon（Interact）" Interact Targets (`interactTargets`) | Can be pressed with Interact only when met (put in UdonBehaviours, such as Title Actions and counters) |

**Advanced: イベントを送る（Udon Graph など） (Send events: Udon Graph etc.)**

| Field | Meaning |
|---|---|
| "イベントの送り先" Event Targets (`eventTargets`) | Where to send events |
| "満たしたときに送るイベント" Met Event (`metEvent`) | The event name sent when met |
| "満たさなくなったときに送るイベント" Unmet Event (`unmetEvent`) | The event name sent when no longer met |

**Advanced: つなぎ（ふつうは空のまま。自動で入る） (Link: usually leave empty, filled in automatically)**

| Field | Meaning | Default |
|---|---|---|
| "称号マネージャー（空なら自動）" Manager (`manager`) | The scene's Title Manager. If empty, it is filled in when baking | Empty |

- It becomes "met" when **all** the conditions you wrote (titles, order, slots, owned count, stat, record) are met.
- The order ("肩書きにこの順で並んでいる (Sequence Keys)") and slots ("枠の番号 (Slot Check Slots)" and "その枠に入っている語 (Slot Check Keys)") are checked against the plate that was applied and saved. They do not change until the player presses Apply on the board.
- The order is counted with empty slots removed. Unused slots and slots not yet unlocked are not counted.
  - Example: if "肩書きにこの順で並んでいる (Sequence Keys)" is "騎士 (Knight)", "の ('s)", "王 (King)", both "騎士の王" and "騎士☆の王" meet it. If you turn on "間にほかの語を挟まない (Sequence Contiguous)", only "騎士の王" does (no words in between).
  - Words shown in fixed-word slots are not counted in the order.
- A slot check ("その枠に入っている語 (Slot Check Keys)") is not met unless that slot is unlocked.
- It rechecks only when the local player's titles, plate or stats change. It does not check every frame.
- Right after joining the world, until restore finishes, it is treated as "not met".
- Switching happens **only on the local player's screen**. It does not affect other people's screens (13-2).
- Put the gate on a different GameObject from the objects it switches (if it disables itself, it stops).
- Only components that have enabled (Behaviour) can go in "満たしたら有効にするコンポーネント (Behaviours)" and "満たしたら無効にするコンポーネント (Behaviours When Not)". Renderers and Colliders go in their own fields ("満たしたら見える (Renderers)" and "満たしたら当たり判定あり (Colliders)"). Particles (ParticleSystem) cannot go in, so switch the whole object with "満たしたら出す物 (Objects)". Do not put the gate's own Udon in (Check Scene warns you).
- Udon put in "満たしたら押せる Udon（Interact） (Interact Targets)" cannot be pressed while not met (no text appears when pointing at it). The pressable object's collider is not removed, so you can still bump into it.

### 7-6. Counter (TitleCounter)

Counts presses on a button or similar, and gives titles by count.

| Field | Where | Meaning | Default |
|---|---|---|---|
| "カウンターの名前（英数字）" Counter Key (`counterKey`) | Common | The counter's name (alphanumeric) | Empty |
| "回数（下の称号と同じ並び）" Steps (`steps`) | Common | When the count reaches these numbers (same order as "その回数で渡す称号 (Step Keys)") | Empty |
| "その回数で渡す称号" Step Keys (`stepKeys`) | Common | The titles to give (same order as "回数 (Steps)") | Empty |
| "1回に足す数" Add Amount (`addAmount`) | Advanced: 数え方 (Counting) | The amount added each time | 1 |
| "保存する（オフ＝入室のたびに 0 から）" Saved (`saved`) | Advanced: 数え方 (Counting) | When on, it is saved (continues on the next visit). When off, it starts from 0 every time you join the world | On |
| "押して（Interact）増やす" Interactable (`interactable`) | Advanced: 押して数える（Interact） (Count by pressing (Interact)) | When on, it increases on click (Interact). The object needs a Collider | On |
| "物に向けたときに出る文字（Interact）" Interact Text (`interactText`) | Advanced: 押して数える（Interact） (Count by pressing (Interact)) | The text shown when pointing at it | Push |
| "ほかの押せる部品に合わせる" Match Other Interact (`matchOtherInteract`) | Top (above the interact distance) | When on, if the same object has another interactable Udon (such as an existing switch), the interact distance and text are matched to it. While matched, this component's distance and text fields cannot be edited (7-0-1) | On |
| "称号マネージャー（空なら自動）" Manager (`manager`) | Advanced: つなぎ (Link) | The scene's Title Manager. If empty, it is filled in when baking | Empty |

- If you turn "保存する (Saved)" off, that counter name is no longer saved. Other components using the same name (save name Save Key, counter name Counter Key) and the table condition `count:` also become counts for that visit only.
- A counter with the same name is shared with other components (save name Save Key, counter name Counter Key) and the table condition `count:`.
- Steps ("回数 (Steps)" and "その回数で渡す称号 (Step Keys)") are checked not only when this counter component is pressed, but also when other components or code add to the same counter (since 2026-10-28). When you join the world, it also gives the titles for steps already reached.
- For how to increase it from other Udon, see "02_Code.md".

### 7-7. Title Reset (TitleReset)

A button that resets the local player's titles when pressed. Use it for replaying, retrying puzzles and testing. Add it to an object that has a Collider.

| Field | Where | Meaning | Default |
|---|---|---|---|
| "すること" Mode (`mode`) | Common | 全部やり直す (Reset all) / 指定の称号を外す (Remove chosen titles) | 全部やり直す (Reset all) |
| "外す称号" Revoke Keys (`revokeKeys`) | Common | The titles to remove, for "指定の称号を外す (Remove chosen titles)" | Empty |
| "確認の秒数（0＝1回で実行）" Confirm Seconds (`confirmSeconds`) | Common | To prevent mistakes, it runs only if pressed again within this many seconds. 0 runs it with one press | 3 |
| "物に向けたときに出る文字（Interact）" Interact Text (`interactText`) | Advanced: 押す（Interact） (Press (Interact)) | The text shown when pointing at it | Reset |
| "ほかの押せる部品に合わせる" Match Other Interact (`matchOtherInteract`) | Top (above the interact distance) | When on, if the same object has another interactable Udon (such as an existing switch), the interact distance and text are matched to it. While matched, this component's distance and text fields cannot be edited (7-0-1) | On |
| "やり直したあとに出す物" Enable Objects (`enableObjects`) | Advanced: やり直したあとに (After resetting) | Objects to enable after resetting (only on the local player's screen) | Empty |
| "やり直したあとに消す物" Disable Objects (`disableObjects`) | Advanced: やり直したあとに (After resetting) | Objects to disable after resetting (only on the local player's screen) | Empty |
| "イベントの送り先" Event Targets (`eventTargets`) | Advanced: やり直したあとに (After resetting) | Where to send an event after resetting | Empty |
| "送るイベントの名前" Event Name (`eventName`) | Advanced: やり直したあとに (After resetting) | The event name to send | Empty |
| "称号マネージャー（空なら自動）" Manager (`manager`) | Advanced: つなぎ (Link) | The scene's Title Manager. If empty, it is filled in when baking | Empty |

The first press shows a confirmation message ("Press again to reset") on the popup board. Pressing again right away runs it and tells you it is done ("Reset done").

**What "全部やり直す (Reset all)" erases and keeps**

| Erased | Kept |
|---|---|
| Owned titles and unlocked connectors | Nameplate ON/OFF setting and the language chosen on the board |
| Revealed titles (hints) | Records whose key was set to another system's key with "保存のキー（空なら自動）" (Record Save Key) (6-6) |
| The plate (all slots become empty) | The state of objects other components enabled or disabled (see the note below) |
| Counters (names used in table conditions and components, and names used during that visit) | |
| Stats and visit days | |
| Records of record titles (those saved under `<prefix>rec.`) | |
| Components' "一度だけ (Once)" | |

- Objects that components enabled or disabled (such as a Title Area's "本人の画面で出す物 (Enable Objects)") do not go back when you reset. Put objects you want to restore into this button's "やり直したあとに出す物 (Enable Objects)" and "やり直したあとに消す物 (Disable Objects)" (example: closing an opened door again). Objects switched by a Title Gate go back automatically when the titles are erased.
- Counter names used only from code (names that are not in the table or components and were not used during that visit) are not erased.
- Titles removed with "指定の称号を外す (Remove chosen titles)" are also removed from the plate.
- If "指定の称号を外す (Remove chosen titles)" removes only internal titles (chapter 10), it does not tell you it is done (so it can be used for things like a button that undoes "make it dark"). Titles obtainable by a table condition may be given again the next time the value changes.
- "指定の称号を外す (Remove chosen titles)" does not reset "一度だけ (Once)" (rejoining resets it).
- Only the local player's data can be reset.

### 7-8. Title Board (TitleBoard)

The board where players look at their titles and build their plate. "シーンに称号システムを置く (Add Title System To Scene)" creates the board together with its buttons. To place another one somewhere else, right-click in the Hierarchy → 「World Title Gimmick」 → 「肩書きのボードを作成する」 (Create a Title Board) (with an object selected, it is created as its child; with nothing selected, in front of the Scene view. It is named "Title Board (Extra)", and running "シーンに称号システムを置く (Add Title System To Scene)" again neither removes nor rebuilds it).

From top to bottom, the board has: the top strip (titles, "Unlocked n / m", language, nameplate settings), the **plate** section ("Your plate"; warm colors: the plate being built, slots, character count, Apply / Revert / Clear all), and the **title list** section ("Title list"; cool colors: filters, page buttons, title cards, description, connectors). (On 2026-10-28 the plate section was moved to the top. Layout drawing: `Docs/UI/01_Board.svg`.)

**Using the board (for players)**

1. Tap a title or a connector in the title list below to pick it (the card turns orange and its name and description appear on the description line).
2. In "Your plate" at the top, only the slots that can take the picked word keep their color; the others (a connector for a title-only slot, fixed and locked slots, and so on) turn gray. Tap a bright slot to put the word there. After that, the word is no longer picked (to add more, pick a word again).
3. Tapping a slot that has a word in it while nothing is picked empties it. Tapping the picked word again stops picking it.
4. Check how "[plate] Name" will look on the top line of the section.
5. Press "Apply" (決定) to save. The plate then also shows above your head for other people. While there are changes you have not applied, the Apply button turns orange and the line below the slots says "Unsaved changes (press Apply)".

Other buttons:

| Button | What it does |
|---|---|
| Revert (元に戻す) | Discards the changes you have not applied and goes back to the plate you have applied now |
| Clear all (全部消す) | Empties all slots (not saved until you press Apply) |
| ◀ Prev / Next ▶ (前・次) | Turns the pages of the title list (on the heading line of the title list). The ◀ / ▶ on the connector line turn the connector pages |
| All / Unlocked / Locked (全部・持っている・まだ) | Filters the title list (per viewer; not saved) |
| 言語：日本語 / Language: English | Switches between Japanese and English. This is a per-viewer setting and is saved (the same language is used next time). Until it is pressed, the manager's "言語 (Language)" setting is used |
| Others' plates: ON / OFF (他の人の名札：表示／非表示) | Whether other people's overhead nameplates are shown on your screen. Per-viewer setting, saved |
| My plate: shown / hidden (自分の名札：見せる／見せない) | Whether your plate is shown on other people's nameplates and on the Roster Board (7-12). Saved. Hiding it does not change checks such as Title Gates |

- If you tap a title or connector you do not have, its name and description appear on the description line, but it is not picked (the line below the slots says "You don't have this title yet"). If no slot can take the picked word, it says "No slot can take this".
- If you tap an empty slot with nothing picked, it says "Tap a title or connector first".
- If the selected card disappears from the list because of a filter or similar, the description disappears too (a word you have stays picked and can still be put into a slot).
- The gray color can be changed in the board's inspector under "色" (Colors) → "入れられない枠（灰色）" (slot that can't take it).
- Messages below the slots, such as "Plate saved", disappear when you turn a page or change the filter (the unsaved-changes and too-long messages stay).
- The text on title and connector cards has a fixed size (titles 24, connectors 22. Best Fit, which re-tests the size every time the text changes, is not used because it makes page turning heavy). Long titles wrap onto two lines, and anything that does not fit is cut off on the card (tap it to see the whole text on the description line). Boards placed before 2026-10-28 change when you run "シーンに称号システムを置く (Add Title System To Scene)" again.
- The board is split into three child Canvases: the top strip (Header), the list (List) and the plate (Plate). (This keeps the area rebuilt when text changes small, so it is lighter.) If you add your own parts, put them inside the nearest child Canvas. Boards placed before 2026-10-28 get split when you run "シーンに称号システムを置く (Add Title System To Scene)" again.
- The board redraws only when titles, language, plate or nameplate settings change (nothing runs every frame). A board shown by the notebook does not redraw while it is closed; it redraws everything at once when opened.
- If you put the same title into a second slot, it is removed from the first slot (it moves). Connectors can be used any number of times.
- Titles you do not have and locked connectors you have not unlocked cannot be put into slots.
- Locked slots show "Locked" and cannot take anything.
- The top strip shows "Unlocked n / m". Record titles are not counted in either n or m (the same count as the condition `owned>=`).
- The "My plate" and "Language" buttons are not on boards placed before 2026-10-28. They are rebuilt when you run "シーンに称号システムを置く (Add Title System To Scene)" again.
- If the character count goes over the limit, the count turns red and the line below the slots says "Too long (over the length limit)". You cannot apply it like that.
- Even if there are two or more boards (for example, the board shown by the notebook and a board in the lobby), applying on one of them makes the others reload the applied plate (any plate being built on them is discarded).

**Showing the board where you are (Title Notebook)**

"シーンに称号システムを置く (Add Title System To Scene)" also places a **Title Notebook** (a Pickup shaped like a small book) next to the board. With it, players can change their plate where they are, without walking to the board.

| Action | What it does |
|---|---|
| Hold the notebook and "Use" it (trigger / click) | Shows a portable Title Board in front of you. Use it again to hide it |
| "Close" (閉じる) on the board | Hides the portable board |
| Desktop: **T** key | Calls the notebook to the front of you (from anywhere) |
| VR: **hold both triggers at the same time for 1 second** | Calls the notebook to the front of you |

- The notebook and the board appear only on the local player's screen (no network sync). Other people see their own notebook.
- If you do not use it, turn off the manager's "その場で出すボード（手帳）を使う (Use Portable Board)" (the notebook is removed, and the key check stops too).

**Title Notebook fields** (the inspector is shown in Japanese)

| Field | Where | Meaning | Default |
|---|---|---|---|
| **デスクトップでキーを押して呼ぶ** (Key Summon, `keySummon`) | Basic (よく使う) | If on, pressing a key on desktop calls the notebook | On |
| **呼ぶキー** (Summon Key, `summonKey`) | Basic | The key to press (shown only when the field above is on) | T |
| **VR で両手のトリガー長押しで呼ぶ** (Vr Summon, `vrSummon`) | Basic | If on, holding both triggers in VR calls the notebook | On |
| **長押しの秒数** (Vr Hold Seconds, `vrHoldSeconds`) | Basic | How long to hold, in seconds (shown only when the field above is on) | 1 |
| **手帳を置く目からの距離（m）** (Notebook Distance, `notebookDistance`) | Advanced: Placement (置き方) | Distance from the eyes where the called notebook is placed | 0.45 |
| **ボードを出す目からの距離（m）** (Board Distance, `boardDistance`) | Advanced: Placement | Distance from the eyes where the portable board appears | 1 |
| **ボードを目の高さから下げる長さ（m）** (Board Down, `boardDown`) | Advanced: Placement | How far below eye level the board appears | 0.15 |
| **出し入れする称号ボード** (Board, `board`) | Advanced: UI parts (画面の部品（自動で作られる。ふつうは触らない）; created automatically, normally leave alone) | The portable Title Board that the notebook shows and hides | Set automatically |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene | Set automatically |

- To check the desktop key, the notebook runs one small process every frame (it is light).
- Scenes where the system was placed before 2026-10-28 have no notebook. It is placed when you run "シーンに称号システムを置く (Add Title System To Scene)" again.

**Placing more than one board**

You can duplicate the board GameObject ("Title Board") and place it in other rooms too. Every board edits the same plate of the local player.

**Fields (for creators)**

The inspector is shown in Japanese. There are no basic fields; everything is inside "詳しい設定 (Advanced settings)". The button and text fields (`pressButtons`, `cardTexts`, etc.) are in the group "画面の部品（自動で作られる。ふつうは触らない） (UI parts; created automatically, normally leave alone)", and "シーンに称号システムを置く (Add Title System To Scene)" links them automatically. You do not need to change them by hand. The fields you may change are the ones in the "色 (Colors)" group.

| Field | Where | Meaning |
|---|---|---|
| **持っている称号の札** (Card Owned, `cardOwned`) | Advanced: Colors (色) | Color of cards for titles you have and connectors you can use |
| **持っていない称号の札** (Card Locked, `cardLocked`) | Advanced: Colors | Color of cards for titles you do not have and locked connectors |
| **選んでいる札** (Card Selected, `cardSelected`) | Advanced: Colors | Color of the selected card and filter button. Also used for the Apply button while there are unsaved changes |
| **持っている称号の文字** (Text Owned, `textOwned`) | Advanced: Colors | Text color of titles you have |
| **持っていない称号の文字** (Text Locked, `textLocked`) | Advanced: Colors | Text color of titles you do not have |
| **肩書きの枠** (Slot Normal, `slotNormal`) | Advanced: Colors | Color of plate slots (the default is a brown that matches the plate section) |
| **固定の語の枠** (Slot Fixed, `slotFixed`) | Advanced: Colors | Color of fixed-word slots and locked slots |
| **入れられない枠（灰色）** (Slot Dimmed, `slotDimmed`) | Advanced: Colors | While a word is picked, the color of slots that cannot take it (gray) |
| **絞り込みのボタン** (Filter Normal, `filterNormal`) | Advanced: Colors | Color of filter buttons that are not selected |
| **注意の文字** (Text Warn, `textWarn`) | Advanced: Colors | Color of the character count when it goes over the limit (red) |
| **ボタン**, **称号の札の文字**, etc. (Press Buttons `pressButtons`, Card Texts `cardTexts`, etc.) | Advanced: UI parts (画面の部品（自動で作られる。ふつうは触らない）) | Buttons and texts of the board. Linked automatically |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene |

- A setting to change the number of cards per page (not supported in the first version).
- "All", "Unlocked" and "Locked" (全部・持っている・まだ) on the heading line of the title list filter the title list (since 2026-10-28. Boards placed before that get them when you run "シーンに称号システムを置く (Add Title System To Scene)" again).
- The background color of the sections and the color of the heading text can be changed in "Plate Area" and "List Area" (Image) and "Plate Label" and "List Label" (Text) inside the child Canvases (the heading text comes from the screen text table). (They go back to the defaults when the board is rebuilt with "シーンに称号システムを置く (Add Title System To Scene)".) Boards placed before 2026-10-28 get the new layout when rebuilt.
- Tabs (putting titles and connectors on separate pages) were left out (section 14). The title list and the connector list are shown on one page.

### 7-9. Nameplates (TitleNameplates)

Shows each other player's plate above their head. Your own nameplate is not shown. People with an empty plate and people who set "My plate: hidden" (自分の名札：見せない) are not shown either.

When there are many people, nameplates are shown **starting from the nearest people**, up to the number of plates (or "一度に出す数の上限 (Max Shown)"). People farther away than the "これより遠い人には出さない (Hide Meters)" distance are not shown.

The inspector is shown in Japanese.

| Field | Where | Meaning | Default |
|---|---|---|---|
| **頭からの高さ（m）** (Height, `height`) | Basic (よく使う) | Height above the head (m) | 0.8 |
| **文字の色** (Text Color, `textColor`) | Basic | Text color | White |
| **背景の色（透明なら A を 0）** (Back Color, `backColor`) | Basic | Background color of the plate. Set A to 0 for transparent | Navy (slightly see-through) |
| **これより遠い人には出さない（m。0＝消さない）** (Hide Meters, `hideMeters`) | Basic | Nameplates of people farther than this (m) are not shown. 0 means distance never hides them | 30 |
| **一度に出す数の上限（0＝板の数まで）** (Max Shown, `maxShown`) | Basic | Maximum number of nameplates shown at once (nearest first). 0 means up to the number of plates | 0 |
| **1行に収まる文字数の目安** (One Line Chars, `oneLineChars`) | Advanced: Text (文字) | Plates longer than this use smaller text | 16 |
| **文字の大きさ** (Normal Size, `normalSize`) | Advanced: Text | Normal text size | 56 |
| **長い肩書きの文字の大きさ** (Small Size, `smallSize`) | Advanced: Text | Text size for long plates | 36 |
| **誰に出すかを選び直す間隔（秒）** (Refresh Seconds, `refreshSeconds`) | Advanced: Load (負荷) | Interval (seconds) for re-choosing who gets a nameplate and refreshing the plate text | 0.5 |
| **これより遠い人は 0.1 秒ごとに追う（m）** (Far Meters, `farMeters`) | Advanced: Load | People horizontally farther than this are followed only every 0.1 seconds (to keep it light) | 15 |
| **名札の板** (Roots, `roots`) | Advanced: UI parts (画面の部品（自動で作られる。ふつうは触らない）) | The nameplate objects. Their number is the maximum number of people shown at the same time | Set automatically (16) |
| **名札の文字** (Labels, `labels`) | Advanced: UI parts | Nameplate texts | Set automatically |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene | Set automatically |

- In crowded worlds or on Quest, setting "これより遠い人には出さない (Hide Meters)" lower (15–20) and "一度に出す数の上限 (Max Shown)" to about 8 makes it lighter.

### 7-10. Unlock popup (TitlePopup)

When a title is unlocked, a panel slides up from the bottom of the view, on the local player's screen only, and shows "New title unlocked!" with the word. It is also used for the Title Reset confirmation, hints ("Found a title hint", section 10) and record updates ("New record!", 6-6). It is not shown for internal titles.

- With the default "1つずつ (One at a time)", if several titles are unlocked at once, they are shown one after another (each for "出しておく秒数 (Show Seconds)"), with the unlock condition shown below the title.
- **To avoid a backlog**: while there is a queue, each one is shown for "順番待ちがあるときの1つの秒数 (Busy Seconds)" (default 1.5), and only the content is swapped without lowering the panel. When the queue grows beyond the number in "順番待ちがこの数を超えたらまとめる (Merge Above)" (default 2), the rest are merged into one panel, shown like "New title unlocked! ×4" (merged panels do not show unlock conditions). So a first-time visitor who gets several titles right after joining the world does not have to wait long.
- If you set the manager's "知らせの出し方 (Popup Mode)" to "まとめて (Together)", titles unlocked at the same time are listed in one popup (unlock conditions are not shown).
- **To turn off all popups**, turn off the manager's "称号の知らせを出す (Show Popups)". Unlock, hint and record-update popups are no longer shown (if a component has a "効果音 (Sound)" set, only the sound plays). The reset button's confirmation is still shown, because the person pressing it needs it. To hide popups for only some components, turn off that component's "獲得の知らせを出す (Show Popup)".
- Popups created with "シーンに称号システムを置く (Add Title System To Scene)" before this feature existed do not have the unlock condition line. Run "シーンに称号システムを置く (Add Title System To Scene)" again to rebuild them (the manager's settings are kept).

The inspector is shown in Japanese (this component has no "つなぎ (Links)" group).

| Field | Where | Meaning | Default |
|---|---|---|---|
| **獲得の効果音（空なら鳴らさない）** (Clip, `clip`) | Basic (よく使う) | Unlock sound effect. **No sound file is included.** If empty, no sound plays | Empty |
| **出しておく秒数** (Show Seconds, `showSeconds`) | Basic | How long it stays shown (seconds) | 4 |
| **順番待ちがこの数を超えたらまとめる（0＝まとめない）** (Merge Above, `mergeAbove`) | Basic | When the queue grows beyond this number, the rest are merged into one panel. 0 means never merge | 2 |
| **順番待ちがあるときの1つの秒数** (Busy Seconds, `busySeconds`) | Advanced: Display (出し方) | Seconds per popup while there is a queue | 1.5 |
| **出し入れにかける秒数** (Slide Seconds, `slideSeconds`) | Advanced: Display | Seconds for sliding up and down | 0.3 |
| **目からの距離（m）** (Distance, `distance`) | Advanced: Display | Distance from the eyes (m) | 0.8 |
| **目の高さから下げる角度（度）** (Down Angle, `downAngle`) | Advanced: Display | Angle below eye level (degrees) | 20 |
| **顔の向きについていく速さ** (Follow Rate, `followRate`) | Advanced: Display | How fast it follows where you face | 4 |
| **出し入れで動く距離（m）** (Slide Distance, `slideDistance`) | Advanced: Display | How far it slides up (m) | 0.25 |
| **知らせの板** (Root, `root`) | Advanced: UI parts (画面の部品（自動で作られる。ふつうは触らない）) | The panel itself | Set automatically |
| **見出しの文字** (Headline, `headline`) | Advanced: UI parts | Headline text | Set automatically |
| **称号の文字** (Words, `words`) | Advanced: UI parts | Text of the words received | Set automatically |
| **取得条件の文字** (Desc, `desc`) | Advanced: UI parts | Text of the unlock condition shown below the title. If empty, it is not shown | Set automatically |
| **音を鳴らす AudioSource** (Audio Source, `audioSource`) | Advanced: UI parts | The AudioSource that plays the sound. If empty, no sound plays | Set automatically |

### 7-11. Title Perk (TitlePerk)

Changes the movement speed, jump power and gravity of the local player who has or has equipped a title, and shows objects. You can add it with the right-click menu "称号を装備したら速く動ける・高く跳べるようにする" (Move faster / jump higher when a title is equipped).

| Field | Where | Meaning | Default |
|---|---|---|---|
| **条件の称号** (Title Keys, `titleKeys`) | Basic (よく使う) | The effect applies with these titles | None |
| **条件** (Mode, `mode`) | Basic | 持っている (Have) / 装備している (Equipped) | 装備している (Equipped) |
| **全部そろったら（オフ＝どれか1つ）** (Match All, `matchAll`) | Basic | If on, all of them; if off, any one of them | Off |
| **移動の速さを変える** (Change Speed, `changeSpeed`) | Basic | If on, use the three speeds below | On |
| **歩く速さ（初期値 2）**, **走る速さ（初期値 4）**, **横歩きの速さ（初期値 2）** (Walk Speed, Run Speed, Strafe Speed; `walkSpeed`, `runSpeed`, `strafeSpeed`) | Basic | VRChat's defaults are 2, 4, 2 | 3, 6, 3 |
| **ジャンプ力を変える** (Change Jump, `changeJump`), **ジャンプ力（初期値 3）** (Jump Impulse, `jumpImpulse`) | Basic | The default is 3. 0 means you cannot jump | Off, 5 |
| **重力を変える** (Change Gravity, `changeGravity`), **重力（1 が普通）** (Gravity Strength, `gravityStrength`) | Basic | 1 is normal. The smaller it is, the floatier the jump | Off, 0.5 |
| **満たしたら出す物** (Objects, `objects`) | Basic | Objects shown on the local player's screen (hidden again when the condition is no longer met) | None |
| **イベントの送り先** (Event Targets, `eventTargets`), **満たしたときに送るイベント** (Met Event, `metEvent`), **満たさなくなったときに送るイベント** (Unmet Event, `unmetEvent`) | Advanced: Send events (イベントを送る（Udon Graph など）; to Udon Graph, etc.) | Events sent when the condition becomes met / no longer met | None |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene. If empty, it is filled in by the bake | Empty |

- When the condition is no longer met, the values go back to what they were before the effect.
- Speed and so on are movements of the local player's body, so other people see them as they are. "満たしたら出す物 (Objects)" is shown only on the local player's screen.
- If you place two or more components that change speed and both are met at the same time, the values of one of them (the component that started later in the scene) are used (Check Scene gives a warning). If one stops being met, the other's values are used; if both stop, the original values come back.
- The original values are the values at the moment the perk component first ran (such as the speeds on the world's VRC World). Even if another script changes the speed after that, the remembered values are restored when the effect ends.

### 7-12. Roster Board (TitleRoster)

A board that lists the names and plates of the people in the instance. You can place it with the right-click menu "いまいる人の肩書きの一覧ボードを置く" (Place a Roster Board). When there are more people than lines, it turns the pages automatically.

The inspector is shown in Japanese.

| Field | Where | Meaning | Default |
|---|---|---|---|
| **肩書きのない人も名前だけ出す** (Show Empty, `showEmpty`) | Basic (よく使う) | If on, people without a plate are also listed (name only) | On |
| **ページをめくる間隔（秒）** (Page Seconds, `pageSeconds`) | Basic | Interval for turning pages (seconds) | 8 |
| **肩書きの色** (Plate Color, `plateColor`), **「（肩書きなし）」の色** (None Color, `noneColor`) | Basic | Color of plates, and color of "(no title)" | Gold, gray |
| **見直す間隔（秒）** (Refresh Seconds, `refreshSeconds`) | Advanced: Load (負荷) | Interval for checking again (seconds). It redraws only when something changed | 1 |
| **見出しの文字**, **1人1行の文字**, **ページの文字** (Title Text, Lines, Page Text; `titleText`, `lines`, `pageText`) | Advanced: UI parts (画面の部品（自動で作られる。ふつうは触らない）; created automatically, normally leave alone) | Heading, one text line per person, page text | Set automatically (12 lines) |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene | Set automatically |

- The plates are the same as on the nameplates, and are shown in the viewer's language.
- People who set "My plate: hidden" (自分の名札：見せない) are shown as "(no title)" on other people's screens (on their own screen, their own plate is shown).
- To change the number of lines, add or remove texts in "1人1行の文字 (Lines)".

### 7-13. Title Relay (TitleRelay)

Sends events to Udon Graph and so on when the local player gets a title, loses a title, equips a title, unequips a title, or changes their plate. You can add it with the right-click menu "称号をもらったら Udon Graph へイベントを送る" (Send an event to Udon Graph when a title is unlocked).

| Field | Where | Meaning | Default |
|---|---|---|---|
| **見る称号（空＝どれでも）** (Watch Keys, `watchKeys`) | Basic (よく使う) | Send when these titles change. If empty, any title | Empty |
| **送り先** (Event Targets, `eventTargets`) | Basic | The UdonBehaviours that receive the events | Empty |
| **もらったとき** (Granted Event, `grantedEvent`) | Basic | Event name for when a title is unlocked | `OnTitleGranted` |
| **外れたとき** (Revoked Event, `revokedEvent`) | Basic | When a title is lost by a reset or by being removed | Empty |
| **装備したとき** (Equipped Event, `equippedEvent`), **装備を外したとき** (Unequipped Event, `unequippedEvent`) | Basic | When a plate is applied and that title was put in / taken out | Empty |
| **肩書きを変えたとき** (Plate Changed Event, `plateChangedEvent`) | Basic | When a plate is applied and the order of words changed | Empty |
| **称号のキーを入れる送り先の変数（空なら入れない）** (Key Variable, `keyVariable`) | Advanced: Sending (送り方) | Before sending, puts the title key into the target's variable (string) with this name. Create that variable on the target beforehand. If empty, nothing is put in | Empty |
| **入室したときにも送る（持っている・装備している称号の分）** (Fire On Join, `fireOnJoin`) | Advanced: Sending | If on, events are also sent on joining the world, for the titles the player has / has equipped | Off |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene. If empty, it is filled in by the bake | Empty |

- Events whose name is empty are not sent.
- Events are sent only inside the local player's client.
- To know which title it was, create a string variable (for example `titleKey`) on the target Udon Graph, and enter that name in "称号のキーを入れる送り先の変数 (Key Variable)" under "詳しい設定 (Advanced settings)" → "送り方 (Sending)".

### 7-14. All Of (TitleAllOf)

When **all** of the listed components (Title Areas, Title Actions, etc.) **have "fired"**, it gives the results (titles to give, etc.). You can add it with the right-click menu "いくつかのきっかけを全部満たしたら称号を渡す（条件まとめ）" (Give a title when several triggers are all met (All Of)).

"Fired" means that the component met its own condition (entering the area, grabbing, doing it N times, etc.) and its preconditions, and gave its results. The components do not need to have titles to give (they can be components used only for combining).

| Field | Where | Meaning | Default |
|---|---|---|---|
| **渡す称号** (Grant Keys, `grantKeys`) | Basic (よく使う) | Titles given when all are complete | Empty |
| **まとめる部品** (Parts, `parts`) | Basic | Title Areas and Title Actions (other All Of components are also allowed) | Empty |
| **これまでに全部（オフ＝この入室で全部）** (Saved, `saved`) | Basic | If on, the fired components are saved, so they can be met on different days. If off, all of them must be met during this visit | On |
| **保存の名前（英数字）** (Save Key, `saveKey`) | Basic | The name used for saving (letters and numbers). Saved as counters `<name>.1`, `<name>.2`, …. If empty while "これまでに全部 (Saved)" is on, nothing is saved (Check Scene warns about it). Not shown when "これまでに全部 (Saved)" is off | The object's name when added from the right-click menu. Empty when added by hand |

- The other fields, such as preconditions, once only, counters, events and object switching, are the same as on the other components (7-2). The groups inside "詳しい設定 (Advanced settings)" are also the same ("一度だけ (Once)" is under "くり返し (Repeat)").
- The order is not checked. (If you want players to go through them in order, use the precondition "この称号を全部持っている人だけ (Required Keys)" to require the previous title.)
- "やり直す" (reset) also clears the saved "fired" states.
- If a component is "once only" and has already fired before you add the All Of, that component does not fire again. When you add one after publishing the world, note that those earlier firings are not included in the "これまでに全部 (Saved)" save.

### 7-15. Seat (TitleSeat)

When added to the same object as a seat (VRC Station), it counts how many times the player sat down (`sits`) and how long they sat (`sit_min`). When the table conditions use `sits` or `sit_min`, **Check Scene** (menu "World Title Gimmick → シーンを点検 (Check Scene)") reports seats that do not have it. Press "**すべての席に付ける**" (Add to all seats) on the right of that line to add it to every seat in the scene at once (seats that already have it are left as they are).

The inspector shows only a sentence explaining what is counted (there are no basic fields).

| Field | Where | Meaning | Default |
|---|---|---|---|
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The TitleManager in the scene. If empty, it is filled in by the bake | Automatic |

- Sitting in a seat without TitleSeat is not counted.
- It runs only when sitting down and standing up. The time while sitting is counted by the manager's once-per-second process.
- While sitting, fall height and airtime (`fall_max_m`, `airtime_s`) are not counted.
- If `sits` or `sit_min` is used in the table conditions and there is no TitleSeat, Check Scene reports it.

### 7-16. Head pat / high five (TitleTouch)

"シーンに称号システムを置く (Add Title System To Scene)" places three of these under "Title Touch" (head, left hand, right hand). Each has a contact receiver (VRC Contact Receiver) and follows the local player's head or hand every frame. It counts when a contact on another person's avatar touches it.

| Field | Where | Meaning | Default |
|---|---|---|---|
| **付いていく所** (Part, `part`) | Basic (よく使う) | 頭 (Head) / 左手 (Left hand) / 右手 (Right hand) (0, 1, 2 in code) | Per object |
| **同じ所で次に数えるまでの秒数** (Cooldown Seconds, `cooldownSeconds`) | Basic | After counting once, the same part does not count again for this many seconds (so that keeping contact does not count many times) | 2 |
| **称号マネージャー（空なら自動）** (Manager, `manager`) | Advanced: Links (つなぎ) | The Title Manager in the scene | Set automatically |

| Receiver | Contact names it accepts (Collision Tags) | Value counted |
|---|---|---|
| Head (radius 0.12 m) | Hand, HandL, HandR, Finger, FingerL, FingerR | `patted` (was patted) |
| Left hand, right hand (radius 0.07 m) | Head → `pats` (patted someone), Hand, HandL, HandR → `high_fives` (high five) | `pats`, `high_fives` |

- If none of `pats`, `patted` or `high_fives` is used in the table conditions, these are removed at the start of Play (and the every-frame process goes away too).
- Contacts on your own body and on world objects are not counted (the receivers have Allow Self off and Content Types set to Avatar).
- Some avatars have no head or hand contacts, and then nothing can be counted. **Check it in the real VRChat client** (it cannot be tested in ClientSim).
- Scenes where the system was placed before 2026-10-28 do not have them. They are placed when you run "シーンに称号システムを置く (Add Title System To Scene)" again.

## 8. Writing table conditions

If you write in the table's "条件（表だけで渡す。空なら部品から）" (Condition) column, the title is given automatically without placing any component. It can also be written on rows for locked connectors (6-3) (on rows for connectors usable from the start and on record title rows, it is not used). The only comparison is `>=` (at least). With "条件を選んで作る" (Build a condition from a list) in the Title Editor (6-1), you can build one by choosing from a list without learning the syntax.

### 8-1. Syntax

| Syntax | Meaning | Checked when |
|---|---|---|
| (empty) | Given by components or code | — |
| `count:<name>>=N` | The counter value is N or more | When that counter increases, and on joining the world |
| `stat:<name>>=N` | The stat (8-2) is N or more | When that value increases, and on joining the world |
| `owned>=N` | The number of titles owned is N or more (connectors, retired, internal and record titles are not counted) | When titles increase |
| `all:<key>,<key>,…` | Owns all of the listed titles (locked connectors and record titles are also allowed; a record title counts as owned if it has a record) | When titles increase, and when a record is written for the first time |
| `date:<start>-<end>` | Was in the world during that period (device date). `1025-1031` means every year, `20261025-20261031` means that year only. `1031` means a single day. Yearly periods that cross the new year (`1225-0105`) are also allowed | On joining the world, and every 60 seconds |
| `record:<key>>=N` | The record of a record title (6-6) has reached N (N or more if bigger is better, N or less if smaller is better) | When the record is updated, and on joining the world |
| `visit>=N` | Number of visit days is N or more (same as `stat:visit_days>=N`) | When visit days increase, and on joining the world |
| `stay>=N` | Total time in the world is N minutes or more (same as `stat:stay_min>=N`) | When stay time increases, and on joining the world |

Examples:

```
count:button>=10
stat:jumps>=1000
stat:visit_days>=7
stat:stay_min>=600
owned>=20
all:rooftop,basement,secret_room
date:1025-1031
date:20270101-20270103
record:best_time>=1500
visit>=7
stay>=600
```

- Limited-time conditions (`date:`) use the device date. Changing the device clock lets people get them, so do not use them for prizes and the like (13-6).

- `record:` compares in the record's "better direction". For a time (smaller is better) where you want 15 seconds or less, the unit is 0.01 seconds, so write `record:best_time>=1500` (`>=` means "reached").

### 8-2. Stat names

These are values the gimmick counts automatically from the local player's actions. Only values used in a table condition `stat:` (also `visit>=` and `stay>=`) or in a Title Gate's "行動の値 (Stat Name)" are counted.

| Name | What it counts | How it counts |
|---|---|---|
| `jumps` | Number of jumps | When jump is pressed while on the ground |
| `respawns` | Number of respawns | When the local player respawns |
| `walk_m` | Distance walked or run (m) | Every second. Horizontal movement while on the ground. Teleports (at least "テレポートとみなす距離 (Teleport Meters)" in 7-1) are not counted |
| `height_max_m` | Highest point climbed (m). Keeps the largest value | Every second. Height from the world origin (Y=0), not from the ground |
| `visits` | Number of times joining the world | On joining the world |
| `visit_days` | Number of visit days | Once a day, by device date |
| `stay_min` | Total time in the world (minutes) | Every 60 seconds |
| `met_people` | Total number of people met (with repeats) | People present on joining the world + people who joined while you were there. The same person rejoining is counted again |
| `crowd_max` | Largest number of people together (including yourself) | On joining the world, and when someone joins |
| `avatar_changes` | Number of avatar changes | The one right after joining the world is not counted |
| `pickups` | Number of times grabbing an object (any object) | Checks both hands every second, and counts 1 if a newly held object is found |
| `visit_streak` | Current number of consecutive visit days | When the day of joining changes. Adds 1 if the last visit was yesterday, otherwise goes back to 1 (it can go down) |
| `visit_streak_max` | Longest run of consecutive visit days. Keeps the largest value | Same as above |
| `vr_min` | Total time spent in VR (minutes) | Every 60 seconds |
| `desktop_min` | Total time spent not in VR (desktop, phone, etc.) (minutes) | Every 60 seconds |
| `together_min` | Total time spent with other people (minutes), when at least one other person was there | Every 60 seconds |
| `fall_max_m` | Highest fall (m). Keeps the largest value | Difference between the highest point after leaving the ground and the landing point. Falls under 1 m are not counted. Checked every 0.1 seconds only while in the air. Respawns and teleports during a fall are not counted |
| `airtime_s` | Total time in the air (seconds) | From leaving the ground until landing. Checked every 0.1 seconds only while in the air |
| `afk_count` | Number of times AFK (headset removed, game paused) | 1 each time it pauses (VRChat's "suspend") |
| `sits` | Number of times sitting in a seat | When sitting in a seat that has the seat component (TitleSeat) (7-15) |
| `sit_min` | Total time sitting (minutes) | While sitting in a TitleSeat seat, counted every second; 60 seconds = 1 |
| `uses` | Number of times using an object (trigger) | When pulling the trigger while holding an object (any object) |
| `near_min` | Total time near other people (minutes) | Every 3 seconds, checks the distance to everyone, and counts if someone is within "近くにいるとみなす距離 (Near Meters)" (7-1, default 2 m); 60 seconds = 1 |
| `welcomes` | Number of times someone else joined while you were there | When someone joins. People present when you joined are not counted |
| `met_title_holders` | Number of times meeting someone with a title | 1 each time you meet someone who has one of the manager's "会うと数える称号 (Holder Keys)". Once per person per visit (counted again if they rejoin). People who get that title while you are there are also counted |
| `met_creator` | Number of times meeting the creator or similar | 1 each time you meet someone listed in the manager's "会うと数える人の表示名 (Creator Names)". Once per person per visit |
| `pats` | Number of times patting another person's head | When your hand touches the head of another person's avatar (7-16) |
| `patted` | Number of times another person patted your head | When the hand or finger of another person's avatar touches your head (7-16) |
| `high_fives` | Number of high fives | When your hand touches the hand of another person's avatar (7-16) |
| `received_items` | Number of times receiving an object hand to hand from another person | 1 when you grab a Title Action (7-4) object while another person's hand is nearby ("手渡しとみなす距離 (Handoff Meters)", default 0.4 m) |

- `pats`, `patted` and `high_fives` are counted with the contacts on other people's avatars. Some avatars have no head or hand contacts, and then they may not be counted. **Check it in the real VRChat client** (it cannot be tested in ClientSim).
- Time values (`sit_min`, `near_min`, etc.) go up by 1 every time 60 seconds have built up. Anything shorter than 60 seconds before leaving is not kept.

## 9. Slot types and slot unlocking

### 9-1. Slot types

In the Title Manager's "枠 1〜10" (Slot 1–10), you decide which words each plate slot can take. By default there are 3 slots: Slot 1 is "どちらも (Both)", Slot 2 is "接続語だけ (Connectors only)", Slot 3 is "どちらも (Both)", and Slots 4–10 are "使わない (Unused)" (for example "title" "の" "title"). To add slots, change Slot 4 onward to "どちらも (Both)" or another type.

| Type | What it can take | Example use |
|---|---|---|
| どちらも (Both) | Titles and connectors | Lets players arrange freely (Slots 1 and 3 by default) |
| 称号だけ (Titles only) | Titles | A slot for the main title |
| 接続語だけ (Connectors only) | Connectors | A slot for putting "'s" (の) or "☆" in between (Slot 2 by default) |
| 固定の語 (Fixed word) | The one connector chosen in "固定の語 (Fixed word)". Players cannot change it | The "'s" (の) in "[title]'s [title]" |
| 使わない (Unused) | Nothing. Not shown on the board | When you want fewer slots (Slots 4–10 by default) |

Example setup "[title]'s [title]" (「［称号］の［称号］」):

1. Set Slot 1 to "称号だけ (Titles only)", Slot 2 to "固定の語 (Fixed word)", Slot 3 to "称号だけ (Titles only)", and Slots 4–10 to "使わない (Unused)".
2. In Slot 2's "固定の語 (Fixed word)", choose the connector "の" ('s).

- A fixed word is not shown if all the other slots are empty.
- Even if you change the types later, slots in saved plates that no longer fit are just shown as empty. Player data is not broken.

### 9-2. Slot unlocking

If you choose a title in a slot's "解禁の称号（なし＝最初から）" (Unlock title; none = from the start), that slot cannot be used until the player has that title.

- On the board it shows "Locked" and cannot be selected.
- It is not shown in the plate either. Fixed-word slots are also not shown until unlocked.
- For other people's overhead plates, it also depends on whether that person has the unlock title.
- If the unlock title is removed or reset, the word in that slot is removed from the plate.

Example: Slots 1–3 can be used from the start, and Slots 4–6 become usable when the player has "奥の部屋の到達者" (Deep Explorer) (12-4). Slots 4–6 are "使わない (Unused)" by default, so change their type to "どちらも (Both)" or another type before choosing the unlock title.

## 10. How titles look before unlocking

With the table's "名前の見せ方" (Name Mode), you decide for each title how a title the player does not have yet looks on the board. It also applies to locked connectors.

| 名前の見せ方 (Name Mode) | Name | Description | Card in the list |
|---|---|---|---|
| 見せる (Show) | Shown as is | Description (before unlocking) | Shown in a faded color |
| 隠す (Hide) | "???" | Description (before unlocking) | Shown in a faded color as "???" |
| 一覧に出さない (Not listed) | — | — | Not shown until owned. Not counted in the m of "Unlocked n / m". Once owned, it is counted in both n and m |
| 内部用 (Internal) | — | — | Not shown even when owned ("Internal titles" below) |

- If the description (before unlocking) is empty, the description (after unlocking) is shown.
- Once owned, the name and the description (after unlocking) are shown.
- Example: before unlocking "Do ??? 10 times" (？？？を10回する) → after unlocking "Jump 10 times" (ジャンプを10回する).

**Reveal (hints)** (2026-10-28)

You can show the name and unlock condition of a title the player does not have yet, only to people who met a condition. There are two ways to reveal.

| Way to reveal | Setting |
|---|---|
| Someone else has it equipped | The manager's "ほかの人の装備で明かす" (Reveal Equipped) (7-1). Reveals titles that other people in the same instance have in their plate. They do not need to be nearby; being in the same instance is enough. People who set "My plate: hidden" (自分の名札：見せない) are not counted |
| A hint button, etc. | "明かす称号（ヒント）" (Reveal Keys) on Title Areas, Title Actions and All Of (7-2). Reveals with the component's trigger: pressing, entering, grabbing, etc. |

How it looks after revealing:

| 名前の見せ方 (Name Mode) | Name revealed | Unlock condition revealed |
|---|---|---|
| 見せる (Show) | (visible from the start) | The description changes from "before" to "after" |
| 隠す (Hide) | "???" becomes the real name | The description changes to "after" (the name stays "???") |
| 一覧に出さない (Not listed) | The card appears and the name is visible | The card appears as "???" and the description changes to "after" |
| 内部用 (Internal) | Not revealed | Not revealed |

- The unlock condition is the table's description (after unlocking). Write it so it reads as an unlock condition. If the description (after unlocking) is empty, the description (before unlocking) is shown.
- What was revealed is saved in the local player's PlayerData and is kept for the next visit. It is cleared by "全部やり直す" (Reset everything) (7-7).
- Revealing a "一覧に出さない (Not listed)" title makes its card appear, so it is also counted in the m of "Unlocked n / m".
- Titles the player already has are not revealed (if they have it, everything is visible anyway). Record titles and retired titles are not revealed either.
- For step-by-step hints, use two components (the first with "名前だけ" (Name only), the second with "取得条件だけ" (Unlock condition only)). See manual 03, 13E for an example.

**Internal titles** (save markers)

To make one, set the row's **分類 (Kind)** to "内部用 (Internal)" (in the Title Editor, use "内部用を足す" (Add internal)). Its ID is assigned from the internal range (6-2; 1001–2000 with 中 (Medium)), so it can be told apart from other titles by number. In the Title Editor list it is marked "（内）", and the kind filter can show only internal rows.
- Normal rows that had **名前の見せ方 (Name Mode)** set to "内部用 (Internal)" in the earlier design are automatically changed to the Internal kind and get new IDs.
- If you change the Kind from Internal to something else, the Name Mode goes back to "見せる (Show)".

Titles that are not shown to players and are used to remember things like "this person got this far" or "this person saw this". They are saved like other titles and are kept for the next visit. For usage examples, see manual 03, section 18.

| Internal titles | |
|---|---|
| Title Board list | Not shown even when owned. Not counted in either n or m of "Unlocked n / m" |
| Unlock popup | Not shown |
| Condition `owned>=`, and the Title Gate's "持っている称号の数がこれ以上" (Min Owned) | Not counted |
| Plate | Cannot be put in (also not shown on nameplates or the Roster Board) |
| A component's "渡す称号" (Grant Keys), "この称号を全部持っている人だけ" (Required Keys), "この称号を持っている人には渡さない" (Forbidden Keys), the Title Gate's "条件の称号" (Title Keys), and the condition `all:` | Can be used like any other title |
| Reset | Cleared by "全部やり直す" (Reset everything). When "指定の称号を外す" (Remove specific titles) removes only internal titles, it does not show that it finished (the confirmation popup is still shown when the confirm seconds are greater than 0) |
| Title Relay (7-13) | Sends "granted" and "revoked" like any other title |

- "語（日本語）" (Word) may be empty (writing something makes it easier to tell them apart in the Title Editor and the Test Panel).
- Connectors cannot be internal (they would become unusable; the table check gives a warning).
- They are only hidden from players. This does not mean that nobody except the world creator can change the data (same as PlayerData saving in general). Do not use them for important checks such as prizes.

## 11. Common setups

### 11-1. When a player climbs to the rooftop

1. Add a title to the table. Key `rooftop`, word "屋上の住人" (Rooftop Dweller), condition empty.
2. On the rooftop, place an empty GameObject with a BoxCollider set to Is Trigger.
3. Add TitleArea.
4. Set "何が入ったら" (Who) to "本人" (the local player) and "きっかけ" (Trigger) to "入ったら" (On enter).
5. In "渡す称号" (Grant Keys), choose "屋上の住人" (Rooftop Dweller).

### 11-2. When a button is pressed 10 times

**Method A: give it with counter steps**

1. Add a title to the table. Key `push10`, word "連打の人" (Button Masher).
2. Add TitleCounter to the button object (it needs a Collider).
3. Enter `button` in "カウンターの名前（英数字）" (Counter Key) ("押して（Interact）増やす" (Interactable) under "詳しい設定 (Advanced settings)" → "押して数える（Interact）" (Count by pressing) is on by default).
4. Enter `10` as the first "回数" (Steps), and choose "連打の人" (Button Masher) as the first "その回数で渡す称号" (Step Keys).

**Method B: give it with a table condition**

1. Write `count:button>=10` in the title's condition in the table.
2. Add TitleCounter to the button and set "カウンターの名前（英数字）" (Counter Key) to `button` (leave "回数" (Steps) empty).

For more steps (10 times, 100 times), put two entries each in "回数" (Steps) and "その回数で渡す称号" (Step Keys), or add a row with `count:button>=100` to the table.

### 11-3. When three gems are placed on an altar

1. Add a title to the table. Key `altar`, word "供え人" (Offerer).
2. Add VRC Pickup, Rigidbody, Collider and VRC Object Sync to the gem objects.
3. On the altar, place an empty GameObject with an Is Trigger collider, and add TitleArea.
4. Set "何が入ったら" (Who) to "指定した物" (Specified objects), and put the three gems in "入る物" (Objects).
5. Set "きっかけ" (Trigger) to "入ったら" (On enter). Under "詳しい設定 (Advanced settings)" → "物が入ったとき" (When objects enter), set "同時に入る物の数" (Object Count) to 3 and "誰に渡すか" (Receiver) to "最後に持った人（持ち主）" (Last holder (owner)).
6. In "渡す称号" (Grant Keys), choose "供え人" (Offerer).

The person who places the third gem receives it.

### 11-4. A door only title holders can pass

1. At the door, place a blocking wall (an object with a Collider and a Renderer).
2. Add TitleGate to a separate empty GameObject.
3. In "条件の称号" (Title Keys), choose the title that may pass, and set "条件" (Mode) to "持っている" (Have).
4. Put the wall in "満たすまで出す物（壁など）" (Objects When Not).

On the screen of people who have the title, the wall disappears; on the screen of people who do not, the wall stays.

### 11-5. A path visible only to players who equip a title

1. Make the path object.
2. Add TitleGate to an empty GameObject.
3. Choose a title in "条件の称号" (Title Keys), and set "条件" (Mode) to "装備している" (Equipped).
4. Put the path in "満たしたら出す物" (Objects).

### 11-6. After 10 minutes in total in the hot spring

1. Place an Is Trigger area in the hot spring and add TitleArea.
2. Set "何が入ったら" (Who) to "本人" (the local player), "きっかけ" (Trigger) to "合計N秒いたら（保存）" (Total N seconds (saved)), and "秒数" (Seconds) to 600.
3. Under "詳しい設定 (Advanced settings)" → "保存" (Save), enter `onsen_sec` in "保存の名前" (Save Key) (counting continues after rejoining).
4. Choose a title in "渡す称号" (Grant Keys).

### 11-7. 1000 jumps, 7 visit days (no components)

Just write it in the table condition.

| Word | Condition |
|---|---|
| 跳ねる人 (Jumper) | `stat:jumps>=1000` |
| 常連 (Regular) | `stat:visit_days>=7` |
| コレクター (Collector) | `owned>=20` |
| 地下と屋上を制した人 (Master of Basement and Rooftop) | `all:rooftop,basement` |

### 11-8. When a player goes to the observation deck holding a bouquet

1. Place a TitleArea on the observation deck, and set "何が入ったら" (Who) to "本人" (the local player) and "きっかけ" (Trigger) to "入ったら" (On enter).
2. Under "詳しい設定 (Advanced settings)" → "前提の条件" (Preconditions), put the bouquet in "この物を手に持っている人だけ" (Held Objects).

### 11-9. When an object is thrown

1. Add TitleAction to the object to throw (VRC Pickup, Rigidbody).
2. Set "行動" (Action) to "投げる" (Throw), and "投げる速さ（m/s）" (Throw Speed) to 8.
3. If you set "回数" (Required Count) to 10 and enter `throws` in "回数を保存する名前" (Save Key) under "詳しい設定 (Advanced settings)" → "回数の保存" (Save count), it becomes "after throwing 10 times".

## 12. Puzzle examples

Examples of puzzles where titles are used as "keys" to move through rooms. All of them work only on each player's own screen, and no network sync is needed.

### 12-1. A door that opens when you collect clues

Place three clues in a room, and make the door open when two or more are found.

1. Add three clue titles to the table (`clue_a`, `clue_b`, `clue_c`). Set "名前の見せ方" (Name Mode) to "隠す" (Hide), and write "Somewhere" (どこかにある) in the description shown before owning it.
2. At each clue's location, add a TitleArea (local player, on enter), or add a TitleAction (Interact) to the clue object, and give each title.
3. Place a wall at the door.
4. Add TitleGate to an empty GameObject, put the three titles in "条件の称号" (Title Keys), and under "詳しい設定 (Advanced settings)" → "条件の数" (Condition count), set "このうち何個でよいか" (Required Count) to 2.
5. Put the wall in "満たすまで出す物（壁など）" (Objects When Not).

If you want to decide by the number of titles owned, not only clues, leave "条件の称号" (Title Keys) empty and use "持っている称号の数がこれ以上" (Min Owned) under "詳しい設定 (Advanced settings)" → "称号の数・行動の値・記録" (Title count, stats, records).

### 12-2. A door that opens when you equip a title

1. Give the key title (for example "門番の友" (Gatekeeper's Friend)) in the previous room.
2. In the door's TitleGate, set "条件の称号" (Title Keys) to "門番の友" (Gatekeeper's Friend), and "条件" (Mode) to "装備している" (Equipped).
3. Put the wall in "満たすまで出す物（壁など）" (Objects When Not).

When the player puts "門番の友" (Gatekeeper's Friend) into their plate on the board and applies it, the wall disappears. When they take it out and apply, the wall comes back.

### 12-3. Objects shown by a combination or word order

Use the order of words in the plate as the answer.

- Word order: in the TitleGate's "詳しい設定 (Advanced settings)" → "肩書きの並び・枠" (Plate order and slots), put "月" (Moon), "の" ('s) and "鍵" (Key) in "肩書きにこの順で並んでいる" (Sequence Keys). It is met if the plate is "月の鍵" (Moon's Key). To forbid other words in between, turn on "間にほかの語を挟まない" (Sequence Contiguous).
- Slot position: in the same group, put `1` and `3` in "枠の番号（1〜10）" (Slot Check Slots), and "星" (Star) and "扉" (Door) in "その枠に入っている語" (Slot Check Keys). It is met if Slot 1 is "星" (Star) and Slot 3 is "扉" (Door).

Put the objects to show when met in "満たしたら出す物" (Objects), and the objects to hide in "満たすまで出す物（壁など）" (Objects When Not). Write the hints in the table's description (after unlocking) or on notes posted in the room.

### 12-4. A board in each room, and slot unlocking

1. Duplicate the Title Board and place one in each room. Every board edits the same plate.
2. In the Title Manager, keep Slots 1–2 usable from the start, and set "解禁の称号" (Unlock title) of Slots 3–4 to "奥の部屋の到達者" (Deep Explorer).
3. At the entrance of the back room, place a TitleArea (local player, on enter) that gives "奥の部屋の到達者" (Deep Explorer).

When players reach the back, they can make longer answers (orders of 3 or more words).

### 12-5. A reset button

1. At the entrance, place an object with a Collider and add TitleReset.
2. Set "すること" (Mode) to "指定の称号を外す" (Remove specific titles), and put the puzzle titles (clues, keys, explorer) in "外す称号" (Revoke Keys).
3. If there are objects that components opened or closed (for example, objects shown by a Title Area's "本人の画面で出す物" (Enable Objects)), put them in "やり直したあとに出す物" (Enable Objects) and "やり直したあとに消す物" (Disable Objects) under "詳しい設定 (Advanced settings)" → "やり直したあとに" (After reset) to put them back.

This lets players redo only the puzzle while keeping the world's other titles. If it is fine to clear everything, set "すること" (Mode) to "全部やり直す" (Reset everything).

### 12-6. Changing avatar height with titles

Things like changing height by the number of titles are made with a short UdonSharp script. An example is in section 5-5 of "02_Code.md".

## 13. Notes

### 13-1. Do not change IDs; set titles to "retired" instead of deleting them

- A player's save contains only title IDs.
- If you change an ID, or delete a row and reuse its ID for another title, the titles players own get swapped for different ones.
- For titles you want to stop using, set "状態" (State) to "廃止" (Retired). Retired titles cannot be unlocked and are not shown even if equipped.
- Do not change the save key prefix after publishing either.

### 13-2. Showing and hiding only changes the local player's screen

- Title Gates, a component's "本人の画面で出す物" (Enable Objects) and "本人の画面で消す物" (Disable Objects), and the object switching of Title Reset change only the local player's own screen.
- Other people see things according to their own state. Even if a door is open on one person's screen, it is closed on other people's screens.

### 13-3. Do not switch collisions on Object Sync objects

- If you use a Title Gate to switch the Collider of an object whose position is shared with others (VRC Object Sync, synced Pickups, etc.), collisions differ from person to person, and the object's movement gets out of step.
- Do not switch collisions on shared objects. Switch only the display (Renderer), or use objects that are not shared.

### 13-4. PlayerData size

- PlayerData has a size limit per world. It includes what other assets use.
- Rough amount used by this gimmick:
  - Owned titles: up to the largest ID owned, 1 byte per 8 titles (with the 中 (Medium) ID range: up to about 100 bytes with normal titles only, about 125 bytes including locked connectors, about 250 bytes including internal titles; with 大 (Large): about 1.1 KB, 1.25 KB and 1.4 KB; 6-2).
  - Plate: 20 bytes.
  - Revealed titles (section 10): two entries, name and unlock condition. Each up to the largest revealed ID, 1 byte per 8 titles.
  - Counters, stats, records: 4 bytes each.
  - Nameplate and language settings (only when changed) and the last visit date: 4 bytes each (up to 4 in total).
- Using title IDs from small numbers keeps the save small. If a player owns even one unlocked connector or internal title, the owned-titles save grows up to that ID (about 100–250 bytes with the 中 (Medium) ID range, about 1.1 KB or more with 大 (Large); 6-2).

### 13-5. When data is saved

- Titles are saved immediately when unlocked. The plate (when applied), revealed titles, and nameplate and language settings are also saved immediately when they change.
- Counters and stats are saved together every 60 seconds (also when a title is unlocked). Record titles are saved immediately when the record is updated. If VRChat is closed, anything shorter than the last 60 seconds may be lost.
- Right after joining the world, components do not run until the restore has finished.
- A player's save is cleared only by Title Reset (7-7) or by actions on the VRChat side (deleting the world's data).

### 13-6. There is no cheat protection

- Saves are written by the local player's client. They can be changed with modified clients and similar.
- Visit days are counted by the device date, so changing the device clock can increase them.
- Use these features for fun display. Do not use them for things where correctness matters, such as prizes or rankings.

### 13-7. Actions that cannot be counted

- Stats are counted from VRChat events. Actions the world cannot detect, such as voice, portals and the camera, cannot be counted.

## 14. Features left out

Of the items in the specification, the following were left out (2026-10-28). All features that were described as "planned for the next version" have been added.

| Feature | Reason |
|---|---|
| Yellow titles | It would make the design too complex |
| Tabs on the Title Board (titles and connectors on separate pages) | Filter buttons and a connector row were used instead (7-8) |
| A "collect them all" component (`<prefix>col.<key>`) | The same thing can be done with All Of's (7-14) "これまでに全部 (Saved)" |
