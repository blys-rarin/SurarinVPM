# World Title Gimmick Manual 0: Getting Started (10 minutes)

> This is the English translation of the Japanese manual (../00_QuickStart.md). If they differ, the Japanese version is correct.

These are the shortest steps for first-time users. You will build this: "a player enters an area, gets a title, and the title appears above their head."

After that, in section 8, you can pick one setup that fits your kind of world (social, exploration, game, event, programming) and add it.

For details, read these manuals later:

- 01_Inspector.md: settings in the Inspector (every field explained)
- 02_Code.md: using it from UdonSharp and Udon Graph
- 03_Examples.md: setup examples

## What this gimmick does

1. When a player does something in the world (enters a place, grabs an object, presses a button, jumps 1000 times, etc.), they get a **title**.
2. On the **Title Board**, the player lines up titles to build a **plate** (e.g. 「屋上の住人 の 冒険者」: "Rooftop Dweller" + the connector "の" + "Adventurer").
3. The plate appears on the **nameplate** above their head, and other people can see it.
4. Titles the player gets are saved, and they are still there on the next visit.

You can use it without writing any code. It does not use network sync, so it does not get heavier as more people join.

## 1. Install

- Requirements: Unity 2022.3, VRChat Worlds SDK 3.10.5 or later (UdonSharp is included in the SDK).
- Add "World Title Gimmick" in VCC (VRChat Creator Companion). Or import the unitypackage with Assets → Import Package → Custom Package.
- Either way, the gimmick goes into **Packages → World Title Gimmick** (`Packages/com.surarin.worldtitlegimmick`) in the Project window.
- When compiling finishes, a "**World Title Gimmick**" menu appears in Unity's top menu bar.

## 2. Put it in the scene

1. Open your world's scene.
2. Click the menu "**World Title Gimmick → シーンに称号システムを置く (Add Title System To Scene)**".
3. A "World Title Gimmick" object is created in the scene. It contains the following.

| Object | Role |
|---|---|
| Title Manager | The core. One per scene |
| Title Board | The board where players choose titles and build their plate |
| Title Notebook | A small book that brings up the board where you are (Desktop: T key. VR: hold both triggers). If you don't use it, turn off **その場で出すボード（手帳）を使う (Use Portable Board)** on the Title Manager |
| Nameplate (overhead) | Shows the plate above the head |
| Unlock popup | Appears on screen when a player gets a title |
| Head pat / high five receiver (Title Touch) | Counts head pats and so on. If not used, it is removed at the start of Play |

4. Move the Title Board to a place players can reach (near the spawn point, for example).

At this point, a title table (`Assets/WorldTitleGimmickData/Titles.asset`) has been created and assigned. It contains sample titles, and some of them already work, such as the title you get just by joining the world. This table is for your own world, so edit it freely (it is not deleted when you update the package).

## 3. Make one title

1. Open the menu "**World Title Gimmick → 称号エディタ (Title Editor)**".
2. Click "**称号を足す (Add Title)**".
3. Fill in the fields on the right.

| Field | What to write | Example |
|---|---|---|
| キー（英数字と _） (Key) | A name in letters and numbers (must not match any other) | `rooftop` |
| 語（日本語） (Word) | The word shown in the plate | 屋上の住人 (Rooftop Dweller) |
| 持っていないときの説明 (Desc Before) | Description while the player does not have it yet (can be vague) | Climb up to ??? |
| 持っているときの説明 (Desc After) | Description once the player has it | Climb up to the rooftop |

## 4. Add "enter here to get a title"

1. In the Hierarchy, with nothing selected (or with the rooftop floor selected), **right-click → World Title Gimmick → エリアに入ったら称号を渡す (Give a title when entering an area)**.
2. Match the size and position of the new object to the place where you want to give the title (a trigger box is added automatically).
3. In the Inspector, under **渡す称号 (Grant Keys)**, click "**＋ 称号を足す (+ Add Title)**" and choose 「屋上の住人」 (Rooftop Dweller) in the new field.

If a sentence like "When a player enters this area, gives 『屋上の住人』" appears at the very top of the Inspector, the setup is done.

The right-click menu also has other choices, such as "when grabbed", "when touched", "by number of presses", and "a wall only title holders can pass" (01, section 7-0).

## 5. Check

Click the menu "**World Title Gimmick → シーンを点検 (Check Scene)**".

- If you see ✖, click that line to select the object with the problem. Fix it and click again.
- If there is no ✖, you are fine.

## 6. Try it

1. Save the scene and press **Play**.
2. Walk to the rooftop (the area) → the popup "New title unlocked!" appears on screen.
3. On the Title Board:
   1. Click 「屋上の住人」 (Rooftop Dweller) in the list to select it (among the slots in "Your plate" at the top, only the slots it can go into stay bright; the others turn gray).
   2. Click a bright **slot** → it goes into the slot.
   3. Click "**Apply**".
4. The plate appears above your head.

During Play, open the menu "**World Title Gimmick → テスト用パネル (Test Panel)**" to try things with buttons: give or remove titles, reset everything, and so on.

## 7. Upload

Use VRChat SDK Build & Test / Build & Publish as usual. Writing the title table into the scene (bake) happens automatically before Play and before building.

## 8. Build for your world (5 setups)

When steps 1–7 work, pick the setup closest to your world and add it. Each one takes 5–10 minutes. In every setup, add the title rows with "称号を足す (Add Title)" in the Title Editor (same as step 3).

| Setup | Good for | What you can do |
|---|---|---|
| 8-1 Social | Hangouts, chat worlds | Titles for days visited, time spent with others, number of head pats. A room for regulars only |
| 8-2 Exploration | Scenic worlds, large maps | A stamp rally of hidden places. A room only for people who visited all of them |
| 8-3 Game | Obstacle courses, minigames | A title for clearing, ranks by number of clears. A shortcut only for people who cleared |
| 8-4 Event | Seasonal events, exhibitions | A commemorative title only for people who came on the event days |
| 8-5 Programming | Worlds with your own Udon | Give titles from your own logic |

When testing, you can change counts and day numbers in the Test Panel during Play (menu "World Title Gimmick → テスト用パネル (Test Panel)").

You can see the finished versions in the example scene (menu "World Title Gimmick → 見本のシーンを作る (Build Example Scene)"), in the frontmost row "A-0 はじめの5つの型" (A-0: the five starter setups). In the sample, keys start with `qs_` so they don't clash with the other examples, and some words are a little different (e.g. the rank in 8-3 can be tested with 3 clears).

### 8-1. Social world: titles for regulars, and a room for regulars only

You don't need any components. Just write rows in the table, and the gimmick counts and gives the titles automatically.

| Key | Word | Condition |
|---|---|---|
| `regular` | 常連 (Regular) | `visit>=7` (came on 7 days) |
| `resident` | 住人 (Resident) | `stay>=600` (stayed 10 hours in total) |
| `talker` | おしゃべり好き (Chatterbox) | `stat:together_min>=300` (5 hours together with other people) |
| `patter` | なでる人 (Patter) | `stat:pats>=10` (patted other people's heads 10 times) |

1. Add the rows above to the table (write the condition in the field **条件（表だけで渡す。空なら部品から） (Condition)** on the right. In the Title Editor, you can also build it with "条件を選んで作る (Build a Condition)" at the bottom, by choosing e.g. "行動の値 (Stat)" → "来訪した日数" (days visited, `visit_days`)).
2. Put a wall at the lounge entrance, then right-click → "World Title Gimmick → **称号を持つ人だけ通れる壁にする (Make a wall only title holders can pass)**". Choose 「常連」 (Regular) in **条件の称号 (Title Keys)**.
3. If you like, right-click the wall → "**いまいる人の肩書きの一覧ボードを置く (Place a Roster Board)**". It gives first-time visitors something to talk about.

How to test: in the Test Panel, set `visit_days` to 7. The popup appears and the wall disappears.

- Head pats are counted with avatar contacts. Some avatars cannot be counted, so check on a real device.
- There are 30 stats in all (number of jumps, distance walked, etc. See 03, section 4-2).

### 8-2. Exploration world: a stamp rally, and a room for those who visited everywhere

| Key | Word | Desc Before | Desc After | Condition | Name Mode |
|---|---|---|---|---|---|
| `st_1` | 時計台 (Clock Tower) | Somewhere high | Climb the clock tower | (empty) | 隠す (Hide) |
| `st_2` | 噴水 (Fountain) | A place where you hear water | Go to the fountain | (empty) | 隠す (Hide) |
| `st_3` | 森 (Forest) | A place with many trees | Go deep into the forest | (empty) | 隠す (Hide) |
| `st_all` | 冒険家 (Adventurer) | Visit 3 places | Visited 3 places | `all:st_1,st_2,st_3` | 見せる (Show) |

1. Add the rows above to the table. With 隠す (Hide), the board shows "???" to people who don't have the title.
2. Put "**エリアに入ったら称号を渡す (Give a title when entering an area)**" at 3 places (same as step 4), and choose one of `st_1`–`st_3` in **渡す称号 (Grant Keys)** for each.
3. Make the entrance of the reward room "**称号を持つ人だけ通れる壁にする (Make a wall only title holders can pass)**", and choose 「冒険家」 (Adventurer) in **条件の称号 (Title Keys)**.

How to test: when you enter the third place, that place's popup is followed by 「冒険家」 (Adventurer), and the wall disappears.

- For details, see 03, sections 15-1 (stamp rally) and 15-6 (hidden titles).

### 8-3. Game world: a clear title and ranks, and a shortcut for those who cleared

| Key | Word | Condition |
|---|---|---|
| `clear` | 完走者 (Finisher) | (empty) |
| `clear_10` | 常連ランナー (Regular Runner) | `count:clears>=10` |

1. Add the rows above to the table.
2. Put "**エリアに入ったら称号を渡す (Give a title when entering an area)**" at the goal, and choose 「完走者」 (Finisher) in **渡す称号 (Grant Keys)**.
3. On the same area, open **詳しい設定 (Advanced settings)** → **称号のほかに起こすこと (Other things to do besides titles)**, and enter `clears` in **足すカウンターの名前 (Counter Key)** and `1` in **カウンターに足す数 (Counter Add)**. Turn off **一度だけ (Once)** above, and in **詳しい設定 (Advanced settings)** → **くり返し (Repeat)**, set **次に反応するまでの秒数 (Cooldown Seconds)** to `10` (so it does not count many times while you stand at the goal).
4. Make the shortcut entrance "**称号を持つ人だけ通れる壁にする (Make a wall only title holders can pass)**", and choose 「完走者」 (Finisher) in **条件の称号 (Title Keys)**.

How to test: when you enter the goal, 「完走者」 (Finisher) appears and the shortcut opens. For testing, use something like `count:clears>=3` to check faster.

- To give ranks by number of presses, right-click → "押した回数で称号を渡す（カウンター） (Give titles by number of presses (Counter))" (03, section 3-2).
- For saving progress partway or skipping a tutorial, see 03, sections 18-1 and 18-7.

### 8-4. Event world: a commemorative title for people who came on the event days

| Key | Word | Desc After | Condition |
|---|---|---|---|
| `expo2026` | 2026年の来場者 (2026 Visitor) | Came to the 2026 exhibition | `date:20261103-20261105` |
| `halloween` | かぼちゃ (Pumpkin) | Came during Halloween week | `date:1025-1031` (every year) |

1. Add the rows above to the table. You don't need any components. People who join the world during the period get the title right away.
2. If you like, make the commemorative room "**称号を持つ人だけ通れる壁にする (Make a wall only title holders can pass)**" and choose the commemorative title. People who got it can still enter after the period ends.

How to test: set `date:` to today's date (e.g. `date:1028`) and press Play. The popup appears right after joining.

- The date is the date on the viewer's own device. Changing the device clock lets people get the title, so don't use it for prizes.
- For the next year, add a new row (e.g. `expo2027`). Don't delete the previous year's row (the records of people who got it would be lost).

### 8-5. From a program: give titles with your own logic

This is for giving titles from your own Udon logic, such as clearing a minigame.

1. Add a row to the table (the key in this example is `game_clear`. Leave "Condition" empty).
2. In your UdonSharp script, make a variable that holds the Title Manager, and call `_GrantKey` where you want to give the title.

```csharp
using WorldTitleGimmick;

public TitleManager titles; // Assign the Title Manager in the Inspector

void OnCleared()
{
    titles._GrantKey("game_clear"); // Called on your own device, it gives the title to you
    titles._AddCount("clears", 1);  // If you also count clears (write count:clears>=10 etc. in the table)
}
```

- Only the person on the device that calls it gets the title. In a game where the result is decided on everyone's device, check that the local player is a participant before calling it.
- From Udon Graph, put the key into the variable `grantKey`, then send the `Grant` event. See 02, sections 5 and 6 for details.

## Troubleshooting

| Problem | Where to look |
|---|---|
| Entering the area gives no title | The ✖ marks in Check Scene. Check that the area box is not too small |
| You want to change a title's word after publishing | You may change the word and description. **Do not change the Key or delete the row** (to stop using it, set **状態 (State)** to 廃止 (retired)). 01, section 13-1 |
| You want to see other examples | Build the example scene with the menu "見本のシーンを作る (Build Example Scene)". It has signs with images of the settings |
| You want finer control | 01, section 7 (every field of every component). **詳しい設定 (Advanced settings)** in each component's Inspector is split into groups (a group with something set is shown in bold with "（設定あり）" (has settings)) |
