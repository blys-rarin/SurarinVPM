# World Title Gimmick Manual 2: Using It from Code

> This is the English translation of the Japanese manual (../02_Code.md). If they differ, the Japanese version is correct.

How to give titles and check whether a player has them from UdonSharp and Udon Graph.

For placing objects, making the table, and component settings, read "01_Inspector.md".

> Features we decided not to include are listed in section 14 of "01_Inspector.md".

## Contents

1. Basic rules
2. Namespace and how to reference it
3. Public methods of TitleManager
4. Knowing when things change (_Listen and _OnTitlesChanged)
5. UdonSharp examples
6. Using it from Udon Graph
7. Calls made before restore
8. Save keys
9. Writing and reading record titles

## 1. Basic rules

- **You can only write data for the local player.** Giving, counting, and setting the plate write to the PlayerData of the player on that device (the local player). You cannot write other people's titles.
- Other people's titles and plates are read-only (read from that person's PlayerData).
- There is no network sync. Call title-giving code **only inside events that happened on the local player's device**.
  - Example: in `OnPlayerTriggerEnter(player)`, call it only when `player.isLocal`.
  - If you call `_Grant` inside an event that runs on everyone's device (such as a synced event), everyone there gets the title.
- Titles are specified by ID (a number) or by key (letters and numbers set in the table). If you use keys, you don't have to change your code when the order of the table changes.
- ID ranges: normal titles 1–8999, connectors 9001–9999, record titles 10000–32767.
- Everyone can use connectors from the start. However, connectors with **最初は使えない（解禁する接続語） (Locked Connector)** turned on in the table (locked connectors) cannot be used until they are given, just like titles.

## 2. Namespace and how to reference it

- The namespace is `WorldTitleGimmick`.
- Connect the scene's Title Manager (`TitleManager`) through a public variable in the Inspector.

```csharp
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using WorldTitleGimmick;

public class MyGimmick : UdonSharpBehaviour
{
    public TitleManager titles; // Assign the Title Manager in the Inspector
}
```

- The gimmick's scripts are in the assembly `WorldTitleGimmick.Runtime` (Assembly Definition).
  - If you put your own scripts directly under Assets (without an asmdef), you can use `TitleManager` without doing anything.
  - If your scripts are in an asmdef, add `WorldTitleGimmick.Runtime` to that asmdef's "Assembly Definition References".

## 3. Public methods of TitleManager

### 3-1. Giving and counting (local player only)

| Method | Returns | What it does |
|---|---|---|
| `_Grant(int id)` | nothing | Gives the title with that ID. Can also give a locked connector (unlocks it). Does nothing if already owned. Ignores connectors usable from the start, retired titles, record titles (write those with `_SetRecord`), and IDs not in the table |
| `_GrantKey(string key)` | nothing | Gives the title with that key. Ignores keys not in the table |
| `_GrantIds(int[] ids)` | nothing | Gives several at once. The popup is combined into one |
| `_GrantIdsWith(int[] ids, bool showPopup, AudioClip sound)` | nothing | `_GrantIds` plus whether to show the popup and which sound to play (null means the popup's sound). Used by the component fields **獲得の知らせを出す (Show Popup)** and **効果音 (Sound)** |
| `_SetRecord(string key, int value)` | bool | Writes the record of a record title (01, section 6-6). Saves and returns true only when it is better than before (including the first time). The value must be 1 or more (section 9) |
| `_AddCount(string name, int amount)` | nothing | Adds to a counter. Never goes below 0. Re-checks the table's `count:` conditions |
| `_Revoke(int id)` | nothing | Removes a title (also an unlocked connector). If it is in the plate, removes it from there and saves. Does nothing if not owned |
| `_RevokeKey(string key)` | nothing | `_Revoke` by key |
| `_ResetAll()` | nothing | Deletes the local player's titles, revealed titles, plate, counters, stats, visit day, and records (those saved under `<prefix>rec.`) (section 3-6) |
| `_RevealIds(int[] ids, int what, bool popup)` | nothing | Reveals titles the player doesn't have yet (hints. 01, section 10). `what` is the sum of `TitleManager.RevealName` (1) and `RevealDesc` (2) (3 for both). If `popup` is true, shows "Found a title hint" on the unlock popup for each newly revealed title. Ignores owned, internal, retired, and record titles, and IDs not in the table. Saves only when something changed, and notifies through `_OnTitlesChanged`. Does nothing before restore |
| `Grant()` | nothing | For Udon Graph. Calls `_GrantKey` with the key in the public variable `grantKey` (section 6) |
| `AddCount()` | nothing | For Udon Graph. Calls `_AddCount` with the public variables `countKey` and `countAdd` (section 6) |
| `Revoke()` | nothing | For Udon Graph. Calls `_RevokeKey` with the key in the public variable `revokeKey` (section 6) |
| `ResetAll()` | nothing | For Udon Graph. Calls `_ResetAll` (section 6) |
| `Reveal()` | nothing | For Udon Graph. Reveals the title with the key in the public variable `revealKey`, using `revealWhat` (default 3), and shows the popup (6-8) |
| `SetRecord()` | nothing | For Udon Graph. Calls `_SetRecord` with the public variables `recordKey` and `recordValue` (6-9) |
| `_MarkTemporaryCounter(string name)` | nothing | Makes that counter not saved (it starts from 0 on every join). The counter component calls this in Start when its **保存する (Saved)** is off |

- When a title is given, it is saved right away, the unlock popup is shown (not for internal titles), and `owned>=` and `all:` conditions are re-checked.
- Counters are saved every 60 seconds or when a title is given (section 8).
- No popup is shown when a title is removed or reset. Titles you get from a table condition may be given again the next time that value changes.

### 3-2. Checking the local player

| Method | Returns | What it does |
|---|---|---|
| `_Has(int id)` | bool | Whether the player has it (can use it). Always true for connectors usable from the start; true for a locked connector if unlocked; true for a record title if there is a record |
| `_HasKey(string key)` | bool | `_Has` by key |
| `_Equipped(int id)` | bool | Whether it is in the (saved) plate |
| `_EquippedKey(string key)` | bool | `_Equipped` by key |
| `_GetCount(string name)` | int | The counter's value |
| `_GetStat(string name)` | int | A stat value (names in 01, section 8-2). 0 for unknown names |
| `_GetRecord(string key)` | int | The record of a record title. 0 if there is no record |
| `_RecordReaches(string key, int target)` | bool | Whether the record has reached target (at least target if bigger is better, at most target if smaller is better). false if no record |
| `_InDateRange(int start, int end)` | bool | Whether today (the device's date) is inside the period. MMDD means every year; YYYYMMDD means that year only |
| `_OwnedCount()` | int | Number of titles owned (excluding connectors, retired, internal, and record titles) |
| `_Plate()` | int[] | IDs of the 10 plate slots (a copy). Empty slots are 0 |
| `_SlotOpen(int slot)` | bool | Whether the slot (0–9) is unlocked. Always true for slots with no unlock title |
| `_Restored()` | bool | Whether the local player's PlayerData restore has finished (section 7) |
| `_ShowNameplates()` | bool | Whether the local player has nameplates turned on |
| `_PublishPlate()` | bool | Whether the local player shows their own plate to other people (2026-10-28) |
| `_English()` | bool | Whether text is currently shown in English (if the language is "Auto", it depends on the viewer's VRChat language; if the viewer chose one on the board, that one) |
| `_NameKnown(int id)` | bool | Whether the name is visible (owned, or the name was revealed) |
| `_DescKnown(int id)` | bool | Whether the unlock condition (description after unlocking) is visible (owned, or the unlock condition was revealed) |
| `_Revealed(int id)` | int | What has been revealed (sum of `RevealName` and `RevealDesc`. Does not look at ownership. 0 for internal titles) |

**Note on stats**: only stats used in a table condition `stat:` or in a Title Gate's **行動の値 (Stat Name)** are counted (decided at bake time). Even if you only want to read `_GetStat("jumps")` from code, it will not increase unless `jumps` is used in some condition or gate.

### 3-3. Checking other people (read-only)

| Method | Returns | What it does |
|---|---|---|
| `_PlayerHas(VRCPlayerApi player, int id)` | bool | Whether that person has it. Same as `_Has` for the local player |
| `_PlayerEquipped(VRCPlayerApi player, int id)` | bool | Whether that person has it equipped (checks the saved slots; does not check whether that person has unlocked the slot) |
| `_GetRecordOf(VRCPlayerApi player, string key)` | int | That person's record (reads that person's PlayerData). 0 if none |
| `_PlateOf(VRCPlayerApi player)` | string | The text of that person's plate. Empty if none |
| `_PlateOfPlayer(int playerId)` | string | `_PlateOf` by playerId |

- `_PlateOf` returns text built when that person's data arrived (restore on joining, or a data update). In the first release, no color tags are added.
- The text is built in **the viewer's language** (when the language is "Auto").
- It is empty if that person has set "My plate: hidden". For the local player, the plate is filled on their own device even with the hidden setting.
- `_PlayerHas` and `_PlayerEquipped` read that person's PlayerData every time you call them. Don't call them every frame.

### 3-4. Change signals and registration

| Method | Returns | What it does |
|---|---|---|
| `_OwnVersion()` | int | A number that goes up every time the local player's owned titles change. Also goes up when a title is revealed, a record is written, or the language changes (so the board list is rebuilt) |
| `_PlateVersion()` | int | A number that goes up every time someone's plate text changes or someone leaves |
| `_BoardVersion()` | int | A number that changes when the local player's owned titles, language, reset, plate apply, or nameplate setting change (not stats). -1 before restore. When you build your own board, redrawing only when this changes in `_OnTitlesChanged` keeps it light |
| `_BoardIds()`, `_BoardWords()`, `_BoardOwned()` | int[], string[], bool[] | Titles and connectors shown in the Title Board list (ID, name shown on the board, whether owned). The first `_BoardTitleCount()` items are titles, and the next `_BoardConnectorCount()` items are connectors. Rebuilt only when owned titles or the language change. The arrays are reused, so don't modify them; copy them into your own arrays if needed |
| `_BoardOwnedCount()`, `_BoardCountedTitles()` | int | The n and m of the board's "Unlocked n / m" (counted among titles in the list, excluding record titles) |
| `_ResetVersion()` | int | A number that goes up on every `_ResetAll` (not on `_Revoke`) |
| `_LanguageVersion()` | int | A number that goes up every time the language switches. When you make your own screen, use it as the signal to redraw text |
| `_SavedPlateVersion()` | int | A number that goes up every time the local player's plate is loaded or applied (the signal for the board to reload its draft) |
| `_Listen(UdonSharpBehaviour behaviour)` | nothing | Asks the manager to call `_OnTitlesChanged` when something changes (section 4) |

Use them like this: remember the previous value, and redraw when it is different. The components' **一度だけ (Once)** resets itself by watching for a change in `_ResetVersion()`. You can do the same when you make "once" in your own components.

### 3-5. Reading the table and handling plates (for people who make their own screens)

| Method | Returns | What it does |
|---|---|---|
| `_IdOf(string key)` | int | ID from key. 0 if none |
| `_Row(int id)` | int | Row number in the table. -1 if none |
| `_TableCount()` | int | Number of rows in the table (including connectors and retired) |
| `_IdAt(int row)` | int | ID of the row |
| `_KindAt(int row)` | int | Kind of the row (`TitleManager.KindNormal`=0 / `KindConnector`=1 / `KindRecord`=2 record title) |
| `_IsConnector(int id)` | bool | Whether it is a connector |
| `_IsLockedConnector(int id)` | bool | Whether it is a locked connector (whether it was unlocked: `_Has`) |
| `_ConnectorListed(int id)` | bool | Whether it appears in the board's connector list |
| `_Active(int id)` | bool | Whether the state is 使用 (in use) |
| `_Word(int id)` | string | The word (in the chosen language). 「（空白）」 (blank) becomes a half-width space. For a record title: "word + value" if there is a record (e.g. "Best Time 12.34s"), otherwise only the word |
| `_ShownWord(int id)` | string | The name shown on the board ("???" for 隠す (Hide) / 一覧に出さない (Not listed) titles the player doesn't own and whose name is not revealed) |
| `_Desc(int id)` | string | The description shown on the board (the "after" description if owned or the unlock condition is revealed, otherwise the "before" one. If empty, the other one) |
| `_Listed(int id)` | bool | Whether it appears in the board list (internal titles never do; 一覧に出さない (Not listed) ones do once owned or revealed) |
| `_Internal(int id)` | bool | Whether the table's **名前の見せ方 (Name Mode)** is 内部用 (internal) (not shown on the board, popup, owned count, or plate. 01, section 10) |
| `_ListedCount()` | int | The m of "Unlocked n / m" |
| `_Ui(int index)` | string | Screen text (number from `TitleManager.Text…`) |
| `_SlotType(int slot)` | int | Slot type (0 either / 1 titles only / 2 connectors only / 3 fixed word / 4 unused) |
| `_SlotFixedId(int slot)` | int | Connector ID of a fixed-word slot |
| `_SlotUnlockId(int slot)` | int | ID of the slot's unlock title. 0 means usable from the start |
| `_SlotAllows(int slot, int id)` | bool | Whether that word can go into that slot (false for a slot not yet unlocked) |
| `_PlateText(int[] slots)` | string | Builds the local player's plate text from a slot arrangement (does not save) |
| `_VisibleLength(string text)` | int | Number of visible characters (excluding tags) |
| `_SetPlate(int[] slots)` | bool | Applies and saves the local player's plate. Slots that don't fit are emptied. false before restore or if over the length limit |
| `_SetShowNameplates(bool value)` | nothing | Turns the local player's nameplates on/off and saves |
| `_SetPublishPlate(bool value)` | nothing | Changes whether the local player's plate is shown to other people, and saves. Does nothing before restore |
| `_ToggleLanguage()` | nothing | Switches the viewer's language between Japanese ⇔ English and saves (same as the board's language button. Takes priority over the manager's **言語 (Language)**). Does nothing before restore |
| `_StatIndex(string name)` | int | Index of the stat. -1 if none |
| `_SeatEnter()`, `_SeatExit()` | nothing | The local player sat down / stood up (`sits`, `sit_min`). Normally TitleSeat calls these. If you call them from your own seat system, always pair sitting with standing |
| `_CountTouch(int what)` | nothing | Counts one head pat given (0), head pat received (1), or high five (2). Normally TitleTouch calls this |
| `_TouchUsed()` | bool | Whether any of head pat given / received / high five is counted |
| `_Handoff(Vector3 at, bool force)` | bool | Whether another person's hand is near `at` (a handoff). If so, adds 1 to `received_items` (when it is being counted). If force is false and it is not being counted, returns false without checking. Normally TitleAction calls this when an object is grabbed |
| `_RegisterPerk(TitlePerk perk)`, `_RefreshPerks()` | nothing | Registers a Title Perk (TitlePerk) and recalculates speed, jump, and gravity. TitlePerk calls these, so don't call them yourself |

### 3-6. What _ResetAll deletes

| Deleted | Kept |
|---|---|
| Owned items (titles, unlocked connectors), revealed titles (`rvn`, `rvd`) | Nameplate on/off (`<prefix>show`), whether to show your own plate (`<prefix>pub`), language chosen on the board (`<prefix>lang`) |
| The plate (all 10 slots emptied) | The state of objects that components enabled or disabled |
| Counters: names collected at bake time from table conditions and components (Counter Key, Save Key), and names used in that session | Counters that match neither of the above (names used only from code in other sessions) |
| Stats (all), visit day (`visit.last`) | Counters that are not saved (never saved in the first place) |
| Record titles saved under `<prefix>rec.` | Record titles that use another key set in the table's **保存のキー（空なら自動） (Record Save Key)** |
| The components' **一度だけ (Once)** (`_ResetVersion` goes up) | |

- If called before restore, it does nothing.
- Objects that components enabled or disabled are not restored. Restore them with Title Reset (TitleReset)'s **やり直したあとに出す物 (Enable Objects)** and **やり直したあとに消す物 (Disable Objects)**, or with your own code.

## 4. Knowing when things change (_Listen and _OnTitlesChanged)

You can use the same mechanism as the Title Gate and Title Board in your own UdonSharp.

- It is called when any of these change: owned titles, plate, counters, stats, records, revealed titles, reset, language, or nameplate display settings. While walking, it may be called every second, so keep the work inside light (e.g. redraw only when something changed).
- Key-based lookups such as `_HasKey` and `_IdOf` are fast regardless of how many rows the table has (since 2026-10-28).

1. Call `titles._Listen(this);` in `Start` to register.
2. Write `public void _OnTitlesChanged()` (use exactly this name).

```csharp
public TitleManager titles;

private void Start()
{
    if (titles != null) titles._Listen(this);
}

// Called when owned titles, the plate, or stats change.
public void _OnTitlesChanged()
{
    bool open = titles._HasKey("vip");
    // Switch the door display, etc.
}
```

When it is called:

- When the local player's restore finishes (if you register after the restore, once at the moment you register). Right after restore, it may be called several times in a row
- When the local player gets, loses, or resets titles
- When the local player applies their plate
- When a counter changes (`_AddCount`. Called even if no title is given)
- When a record is written or a title is revealed
- When a stat increases (distance walked and so on can increase every second, so keep the work inside light)
- When the language or nameplate settings (`_SetShowNameplates`, `_SetPublishPlate`) change

When it is not called:

- When someone else's plate changes. Watch for changes in `_PlateVersion()`.

## 5. UdonSharp examples

### 5-1. Give a title at the goal and count arrivals

```csharp
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using WorldTitleGimmick;

public class GoalLine : UdonSharpBehaviour
{
    public TitleManager titles;

    public override void OnPlayerTriggerEnter(VRCPlayerApi player)
    {
        // Only on the local player's device, and only when the local player entered
        if (!Utilities.IsValid(player) || !player.isLocal) return;
        titles._GrantKey("goal");
        titles._AddCount("goals", 1); // If you add a title with "count:goals>=10" to the table, it is given on the 10th time
    }
}
```

### 5-2. Only title holders can press the button

```csharp
public TitleManager titles;

public override void Interact()
{
    if (!titles._HasKey("member"))
    {
        // What to do for people who don't have it
        return;
    }
    // What to do for people who have it
}
```

### 5-3. Show a nearby person's plate on a sign

```csharp
public TitleManager titles;
public UnityEngine.UI.Text label;
private int seenVersion = -1;
private VRCPlayerApi target;

public void _SetTarget(VRCPlayerApi player) { target = player; seenVersion = -1; }

private void Update()
{
    // Rewrite only when a plate changed
    int version = titles._PlateVersion();
    if (version == seenVersion || !Utilities.IsValid(target)) return;
    seenVersion = version;
    label.text = titles._PlateOf(target);
}
```

### 5-4. Give a title only to the local player when they clear a minigame

```csharp
// When the game result is decided on everyone's device, check that the local player is a participant before giving
public void _OnGameCleared()
{
    VRCPlayerApi local = Networking.LocalPlayer;
    if (!IsParticipant(local)) return; // IsParticipant is your own game's check (example)
    titles._GrantKey("game_clear");
}
```

### 5-5. Change height by the number of titles

This example registers with `_Listen`, and every time titles change, changes the local player's height (eye height) in `_OnTitlesChanged`.

> If you only want to change movement speed, jump, or gravity with titles, you can do it without code using the Title Perk (TitlePerk. 01, section 7-11). This example shows how to write it when you want to change other values (such as height).

```csharp
using UdonSharp;
using UnityEngine;
using VRC.SDKBase;
using WorldTitleGimmick;

public class TitleHeight : UdonSharpBehaviour
{
    public TitleManager titles;
    [Tooltip("Eye height with 0 titles (m)")]
    public float baseMeters = 1.2f;
    [Tooltip("Height added per title (m)")]
    public float perTitleMeters = 0.1f;
    [Tooltip("Maximum eye height (m)")]
    public float maxMeters = 3f;

    private int lastCount = -1;

    private void Start()
    {
        if (titles != null) titles._Listen(this);
    }

    // Called when owned titles, the plate, or stats change (stats call it often, so act only when the count changed).
    public void _OnTitlesChanged()
    {
        int count = titles._OwnedCount();
        if (count == lastCount) return;
        lastCount = count;
        Apply();
    }

    // Changing avatars can reset the height, so apply it again when the avatar changes.
    public override void OnAvatarChanged(VRCPlayerApi player)
    {
        if (Utilities.IsValid(player) && player.isLocal && lastCount >= 0) Apply();
    }

    private void Apply()
    {
        VRCPlayerApi local = Networking.LocalPlayer;
        if (!Utilities.IsValid(local)) return;
        float meters = Mathf.Min(maxMeters, baseMeters + perTitleMeters * lastCount);
        // To go beyond the range the world allows, widen the range first.
        local.SetAvatarEyeHeightMaximumByMeters(Mathf.Max(maxMeters, local.GetAvatarEyeHeightMaximumAsMeters()));
        local.SetAvatarEyeHeightByMeters(meters);
    }
}
```

- **Only the local player** can change their own height. On other people's devices, you see the height that each person's own device set.
- VRChat allows eye heights only within a range. To use a height outside the range, you may need to widen it with `SetAvatarEyeHeightMinimumByMeters` / `SetAvatarEyeHeightMaximumByMeters`. Check the SDK documentation for the range's upper and lower limits.
- `_OnTitlesChanged` is also called right after restore, so the height is applied when joining the world too.
- When a reset (`_ResetAll`) brings titles to 0, the height goes back to `baseMeters`.

## 6. Using it from Udon Graph

From Udon Graph, you cannot directly call methods with arguments (such as `_Grant(int)`) or methods with return values (such as `_Has`). Use the methods below instead.

### 6-1. Give a title (grantKey → Grant)

1. In the Udon Graph variables, make a variable of type `UdonBehaviour` and make it public. The name in this example is `titles`.
2. In the Inspector, put the Title Manager's GameObject into `titles`.
3. After the node for the moment you want to give the title, add `UdonBehaviour.SetProgramVariable`.
   - instance: `titles`
   - symbolName: `grantKey`
   - value: the key of the title to give (e.g. `rooftop`)
4. After that, add `UdonBehaviour.SendCustomEvent`.
   - instance: `titles`
   - eventName: `Grant`

### 6-2. Add to a counter (countKey, countAdd → AddCount)

1. With `UdonBehaviour.SetProgramVariable`, put the counter name (e.g. `button`) into symbolName `countKey`.
2. With `UdonBehaviour.SetProgramVariable`, put the amount to add (int, e.g. 1) into symbolName `countAdd`.
3. Send eventName `AddCount` with `UdonBehaviour.SendCustomEvent`.

`countAdd` keeps its previous value. Set it every time.

### 6-3. Remove a title / reset everything (revokeKey → Revoke, ResetAll)

- Remove: with `UdonBehaviour.SetProgramVariable`, put the key of the title to remove into symbolName `revokeKey`, then send eventName `Revoke` with `UdonBehaviour.SendCustomEvent`.
- Reset everything: send eventName `ResetAll` with `UdonBehaviour.SendCustomEvent`. There is no confirmation.
- If you have placed a Title Reset component (TitleReset), sending eventName `Run` to that component does the reset as the component is set up, without confirmation (it also switches objects and sends events after the reset).

### 6-4. Press a counter component (TitleCounter's Add)

If you have a TitleCounter in the scene, just call its Add. It increases by the component's **1回に足す数 (Add Amount)**, and also gives the titles for each step in **回数 (Steps)**.

1. Make a public variable of type `UdonBehaviour` and put the TitleCounter's GameObject into it.
2. Send eventName `Add` with `UdonBehaviour.SendCustomEvent`.

### 6-5. Send events from components to Udon Graph

As a result of a Title Area or Title Action, you can call an Udon Graph event.

1. Put a `Custom Event` node in Udon Graph and give it a name (e.g. `OnRooftop`).
2. In the component's Inspector, under **詳しい設定 (Advanced settings)** → **イベントを送る（Udon Graph など） (Send events (Udon Graph etc.))**, put that Udon Graph's GameObject into **イベントの送り先 (Event Targets)**.
3. Write `OnRooftop` at the same index in **送るイベントの名前 (Event Names)**.

It is called only on the local player's device, when the component produces a result (when its conditions are met and it runs, even if it only gives titles the player already has).

Title Reset (TitleReset) sends events after a reset, using **イベントの送り先 (Event Targets)** and **送るイベントの名前 (Event Name)** (one name sent to all targets) under **詳しい設定 (Advanced settings)** → **やり直したあとに (After reset)**.

### 6-6. Find out in Udon Graph whether the player has a title (Title Gate events)

You cannot call `_Has` directly from Udon Graph, so use the Title Gate's events.

1. Add TitleGate to an empty GameObject and choose titles in **条件の称号 (Title Keys)** (**条件 (Mode)**: 0 owned / 1 equipped).
2. Under **詳しい設定 (Advanced settings)** → **イベントを送る（Udon Graph など） (Send events (Udon Graph etc.))**, put the Udon Graph's GameObject into **イベントの送り先 (Event Targets)**.
3. Write, for example, `OnHasVip` in **満たしたときに送るイベント (Met Event)** and `OnLostVip` in **満たさなくなったときに送るイベント (Unmet Event)**.
4. Put `Custom Event` nodes with the same names in Udon Graph, and switch a bool variable.

- Right after joining, the gate starts in the "not met" state. When the restore finishes and the condition is met, the Met Event arrives at that point. The Unmet Event arrives only when the condition stops being met after it was met once.

Gates whose condition is the order (**肩書きにこの順で並んでいる (Sequence Keys)**) or slot contents (**その枠に入っている語 (Slot Check Keys)**) can receive events in the same way.

### 6-7. Receive events when a title is gained or equipment changes

Use the Title Relay (TitleRelay. 01, section 7-13).

1. Add TitleRelay to an object (right-click "World Title Gimmick" → "称号をもらったら Udon Graph へイベントを送る (Send an event to Udon Graph when a title is gained)").
2. Put the object with the Udon Graph into **送り先 (Event Targets)**.
3. Enter event names in fields such as **もらったとき (Granted Event)** (default `OnTitleGranted`). Make a Custom Event with the same name in Udon Graph.
4. To know which title it was, make a public string variable in Udon Graph (e.g. `titleKey`), and enter `titleKey` in TitleRelay's Key Variable. The key is set before the event.

If you want to do something for as long as the player has a certain title, you can also use the Title Gate events in 6-6.

### 6-8. Reveal a title (revealKey, revealWhat → Reveal)

- With `UdonBehaviour.SetProgramVariable`, put the key of the title to reveal into symbolName `revealKey`, and what to reveal (1 name / 2 unlock condition / 3 both) into `revealWhat`, then send eventName `Reveal` with `UdonBehaviour.SendCustomEvent`.
- When something is newly revealed, the unlock popup shows "Found a title hint".
- To reveal from a component, it is easier to use **明かす称号（ヒント） (Reveal Keys)** on a Title Area or Title Action (01, section 7-2).

### 6-9. Write a record (recordKey, recordValue → SetRecord)

- With `UdonBehaviour.SetProgramVariable`, put the record title's key into symbolName `recordKey` and the value (int, 1 or more) into `recordValue`, then send eventName `SetRecord` with `UdonBehaviour.SendCustomEvent`.
- It saves and shows the popup only when the value is better than before. Match the value's unit to the record format (for 時間 (Time), units of 0.01 seconds: 12.34 seconds is 1234).

## 7. Calls made before restore

After joining, it can take a few seconds until the local player's PlayerData restore finishes. While `_Restored()` is false, calls are handled like this.

| Call | Handling before restore |
|---|---|
| `_Grant`, `_GrantKey`, `_GrantIds`, `_GrantIdsWith`, `Grant` | Remembered and given together right after restore (up to 32 items. Anything beyond that is dropped) |
| `_AddCount`, `AddCount` | **Does nothing (dropped)** |
| `_Revoke`, `_RevokeKey`, `Revoke`, `_ResetAll`, `ResetAll`, TitleReset | Does nothing |
| TitleCounter's `Add` | Does nothing |
| `_SetPlate` | Does nothing and returns false |
| `_SetShowNameplates` | Switches the current display, but does not save |
| `_SetPublishPlate`, `_ToggleLanguage`, `_RevealIds`, `Reveal` | Does nothing |
| `_Has`, `_Equipped`, `_GetCount`, `_GetStat`, `_GetRecord` | Returns the pre-save values (false, 0) |
| `_SetRecord`, `SetRecord` | **Does nothing (dropped)**. Returns false |

If you want to count right after joining, check `_Restored()` before calling, or start in `_OnTitlesChanged` (which is called right after restore).

Components (Title Area, Title Action, counter) also don't run before restore.

## 8. Save keys

The following keys are written to the local player's PlayerData. `<prefix>` is the Title Manager's **保存のキーの頭 (Key Prefix)** (default `wtg.`).

| Key | Type | Contents | When written |
|---|---|---|---|
| `<prefix>own2` | bytes | Bit array of owned titles (bit n for ID n. Up to ID 9999, max 1,250 bytes). Unlocked connectors are included. Stored up to the byte of the largest owned ID | When a title is given or removed, on reset |
| `<prefix>plate2` | bytes | 10 plate slots × 2 bytes (high byte first. The lower 15 bits are the ID) | When the plate is applied, when a removed title was in it, on reset |
| `<prefix>cnt.<name>` | int | Counter | Every 60 seconds and when a title is given (only changed ones), on reset (0) |
| `<prefix>rvn`, `<prefix>rvd` | bytes | Bit arrays of revealed titles (`rvn` names, `rvd` unlock conditions. Same format as `own2`) | When a title is revealed (by a component or by someone else's equipped plate), on reset |
| `<prefix>st.<name>` | int | Stat (only counted values) | Every 60 seconds and when a title is given, on reset (counted values and non-zero values set to 0) |
| `<prefix>rec.<key>` | int | Record of a record title (`<prefix>rec.<key>.v<version>` if it has a version. If the table's **保存のキー (Record Save Key)** is set, that key) | When the record is updated (immediately), on reset (only the `<prefix>rec.` ones, set to 0) |
| `<prefix>visit.last` | int | The last day a visit was counted (yyyymmdd) | When the join date changes, on reset (0) |
| `<prefix>show` | int | Nameplate setting (1 show / 2 hide. If missing, the default) | When switched on the board |
| `<prefix>pub` | int | Whether to show your own plate to other people (1 show / 2 hide. If missing, show). Other people's devices read this, and if it is 2, it is not shown on nameplates or lists | When switched on the board |
| `<prefix>lang` | int | Language the viewer chose on the board (1 Japanese / 2 English. If missing, the manager's **言語 (Language)**) | When the board's language button (`_ToggleLanguage`) is pressed |

- The number of visit days goes into `<prefix>st.visit_days`, and the stay time into `<prefix>st.stay_min`.
- Nothing is written before restore (so empty values don't overwrite saved data).
- Choose a **保存のキーの頭 (Key Prefix)** that doesn't clash with other assets' keys. If you change it after publishing, earlier saves can no longer be read.
- Counters that are not saved (counter component with **保存する (Saved)** off) are not written.

## 9. Writing and reading record titles

For record titles (01, section 6-6), you write the record from code.

```csharp
// At the goal: write the time taken as an integer in units of 0.01 seconds (with the format 時間 (Time), it shows "Best Time 12.34s").
int value = Mathf.RoundToInt((Time.time - startedAt) * 100f);
bool better = titles._SetRecord("best_time", value);
```

- It saves and returns true only when the value is better than before (including the first record). Which direction is better is set by the table's **小さいほど良い記録（タイムなど） (Record Lower Better)**.
- The value is an integer of 1 or more. 0 or less is ignored (0 means "no record").
- It is saved right away. Each write is sent to the people in the same instance, so don't write every frame.
- To read: `_GetRecord("best_time")` (local player), `_GetRecordOf(player, "best_time")` (other people).
- To check whether a record has reached a value: `_RecordReaches("best_time", 1500)`. You can also check it with the table condition `record:best_time>=1500` or the Title Gate's **記録の称号 (Record Key)**.
- Sample: `Samples/ExampleScene/Scripts/ExampleRace.cs` (03, section 19-1).
