# World Title Gimmick（ワールド内称号ギミック）

VRChat ワールドの中で称号を集めて組み合わせ、肩書きとして頭の上に出すギミックです。
An in-world title system for VRChat worlds: players collect titles, combine them into a nameplate, and show it above their heads.

- 版 / Version：1.0.0
- 作者 / Author：Surarin
- 利用規約 / License：[LICENSE.md](LICENSE.md)
- 更新履歴 / Changelog：[CHANGELOG.md](CHANGELOG.md)

## 日本語

### 要るもの

- Unity 2022.3
- VRChat Worlds SDK 3.10.5 以上（UdonSharp は SDK に入っています）
- ほかのアセット（TextMeshPro・lilToon など）は要りません。

### 入れ方

- VCC（VRChat Creator Companion）：BOOTH のページに書いたリポジトリを VCC に追加し、プロジェクトに「World Title Gimmick」を追加します。
- unitypackage：Unity のメニュー Assets → Import Package → Custom Package で読み込みます。

どちらで入れても `Packages/com.surarin.worldtitlegimmick` に入ります。自分のワールドの称号の表などは `Assets/WorldTitleGimmickData` に作られるので、パッケージを更新しても消えません。

### はじめかた

1. メニュー「World Title Gimmick → シーンに称号システムを置く」を押す。
2. `Documentation/00_QuickStart.md` の手順で、称号を1つ作って試す。

### 説明書（Documentation）

| ファイル | 中身 |
|---|---|
| `00_QuickStart.md` | はじめての使い方（10分） |
| `01_Inspector.md` | インスペクターでの設定（全部の欄） |
| `02_Code.md` | UdonSharp・Udon Graph から使う |
| `03_Examples.md` | 設定の例 |

英語の説明書は `Documentation/en` にあります。

### 大事なこと

- 保存は各プレイヤーの PlayerData を使います。同期は使いません。
- 不正対策はありません。景品や順位など、正しさが大事なものには使わないでください（01 の 13-6）。

## English

### Requirements

- Unity 2022.3
- VRChat Worlds SDK 3.10.5 or later (UdonSharp is included in the SDK)
- No other assets (TextMeshPro, lilToon, etc.) are needed.

### Installation

- VCC (VRChat Creator Companion): add the repository listed on the BOOTH page to VCC, then add "World Title Gimmick" to your project.
- unitypackage: in Unity, use Assets → Import Package → Custom Package.

Either way, the package goes into `Packages/com.surarin.worldtitlegimmick`. Your own title table and other editable files are created in `Assets/WorldTitleGimmickData`, so updating the package does not erase them.

### Getting started

1. Click the menu "World Title Gimmick → シーンに称号システムを置く (Add Title System To Scene)".
2. Follow `Documentation/en/00_QuickStart.md` to make your first title and test it.

### Documentation

| File | Contents |
|---|---|
| `en/00_QuickStart.md` | Quick start (10 minutes) |
| `en/01_Inspector.md` | Inspector settings (every field) |
| `en/02_Code.md` | Using it from UdonSharp and Udon Graph |
| `en/03_Examples.md` | Setup examples |

The Unity menus and inspectors are in Japanese, with the English name shown in parentheses or tooltips.

### Important notes

- Progress is saved in each player's PlayerData. No network sync is used.
- There is no cheat protection. Do not use it for prizes, rankings, or anything where correctness matters (01, section 13-6).
