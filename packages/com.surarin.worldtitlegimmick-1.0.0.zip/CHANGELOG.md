# 更新履歴 / Changelog

## 1.0.0（2026-10-28）

- 最初の版。 / First release.
