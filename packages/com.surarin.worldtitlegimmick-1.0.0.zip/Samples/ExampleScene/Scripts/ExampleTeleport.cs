using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace WorldTitleGimmick.Examples
{
    // 見本のシーン用：押すと、本人を決めた場所へワープさせる（列の右端から左端へ戻るため）。同期しない。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ExampleTeleport : UdonSharpBehaviour
    {
        [Tooltip("ワープ先（位置と向き）")]
        public Transform target;
        public string interactText = "Warp";

        private void Start() { InteractionText = interactText; }

        public override void Interact()
        {
            VRCPlayerApi local = Networking.LocalPlayer;
            if (target == null || !Utilities.IsValid(local)) return;
            local.TeleportTo(target.position, target.rotation);
        }
    }
}
