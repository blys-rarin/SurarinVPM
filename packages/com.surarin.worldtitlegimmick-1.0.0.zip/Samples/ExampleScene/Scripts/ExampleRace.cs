using UdonSharp;
using UnityEngine;
using VRC.SDKBase;

namespace WorldTitleGimmick.Examples
{
    // 見本のシーンのレース（19-1）。ゴールの Is Trigger のコライダーに付ける。
    // スタートのエリア（TitleArea）のイベントで _StartRace を受け、ゴールに入るまでの時間を記録の称号に書く。
    // 時間は 0.01 秒単位の整数（書式「時間」で 12.34 と出る）。小さいほど良い記録。同期しない。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ExampleRace : UdonSharpBehaviour
    {
        public TitleManager manager;
        [Tooltip("書く記録の称号のキー")]
        public string recordKey = "best_time";

        private float started = -1f;

        // スタートのエリアに入ったとき（TitleArea の Event Names に書く）。
        public void _StartRace() { started = Time.time; }

        public override void OnPlayerTriggerEnter(VRCPlayerApi player)
        {
            if (manager == null || started < 0f || !Utilities.IsValid(player) || !player.isLocal) return;
            int value = Mathf.Max(1, Mathf.RoundToInt((Time.time - started) * 100f));
            started = -1f;
            manager._SetRecord(recordKey, value);
        }
    }
}
