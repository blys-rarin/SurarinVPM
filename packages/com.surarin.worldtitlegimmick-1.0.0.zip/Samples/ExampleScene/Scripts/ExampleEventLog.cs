using UdonSharp;
using UnityEngine;
using UnityEngine.UI;

namespace WorldTitleGimmick.Examples
{
    // 見本のシーン用（説明書 03 の 8-13・11-2・13C）：受けたイベントの名前を看板に出す。Udon Graph の代わり。
    // 称号イベント中継の Key Variable に「titleKey」と入れると、どの称号かも出す。同期しない。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ExampleEventLog : UdonSharpBehaviour
    {
        [Tooltip("受けたイベントを出す文字")]
        public Text label;
        [Tooltip("イベントのたびに出したり消したりする物（花火の代わり。空でよい）")]
        public GameObject flash;
        [Tooltip("称号イベント中継が入れる称号のキー")]
        public string titleKey = "";

        private string[] lines = new string[5];
        private int received;

        private void Start() { Show(); }

        public void OnGoal() { Log("OnGoal"); }
        public void OnDjOn() { Log("OnDjOn"); }
        public void OnDjOff() { Log("OnDjOff"); }
        public void OnTitleGranted() { Log("OnTitleGranted"); }
        public void CrownOn() { Log("CrownOn"); }
        public void CrownOff() { Log("CrownOff"); }

        private void Log(string eventName)
        {
            received++;
            for (int i = lines.Length - 1; i > 0; i--) lines[i] = lines[i - 1];
            lines[0] = received + ". " + eventName + (string.IsNullOrEmpty(titleKey) ? "" : "（" + titleKey + "）");
            titleKey = "";
            if (flash != null) flash.SetActive(!flash.activeSelf);
            Show();
        }

        private void Show()
        {
            if (label == null) return;
            string text = "受けたイベント：";
            for (int i = 0; i < lines.Length; i++) if (!string.IsNullOrEmpty(lines[i])) text += "\n" + lines[i];
            if (received == 0) text += "\n（まだありません）";
            label.text = text;
        }
    }
}
