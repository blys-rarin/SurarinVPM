using UdonSharp;
using VRC.SDKBase;

namespace WorldTitleGimmick.Examples
{
    // 見本のシーンの椅子（4-2）。押すと、同じ物の VRC Station に座る。座った回数・時間は TitleSeat が数える。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ExampleSit : UdonSharpBehaviour
    {
        private void Start() { InteractionText = "座る"; }

        public override void Interact()
        {
            VRCStation station = (VRCStation)GetComponent(typeof(VRCStation));
            if (station != null) station.UseStation(Networking.LocalPlayer);
        }
    }
}
