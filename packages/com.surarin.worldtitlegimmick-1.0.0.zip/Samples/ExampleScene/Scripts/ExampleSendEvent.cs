using UdonSharp;
using UnityEngine;
using VRC.Udon;

namespace WorldTitleGimmick.Examples
{
    // 見本のシーン用（説明書 03 の 3-5）：押すと、ほかの Udon にイベントを送る（「ミニゲームをクリアした」の代わり）。同期しない。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ExampleSendEvent : UdonSharpBehaviour
    {
        [Tooltip("送り先（カウンター部品など）")]
        public UdonBehaviour target;
        [Tooltip("送るイベントの名前（カウンター部品なら Add）")]
        public string eventName = "Add";
        public string interactText = "Send";

        private void Start() { InteractionText = interactText; }

        public override void Interact()
        {
            if (target != null && !string.IsNullOrEmpty(eventName)) target.SendCustomEvent(eventName);
        }
    }
}
