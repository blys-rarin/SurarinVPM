using UdonSharp;
using WorldTitleGimmick;

namespace WorldTitleGimmick.Examples
{
    // 見本のシーンの「A-0 8-5 プログラムから渡す」（説明書 00 の 8-5）。
    // 押すと、自分の UdonSharp から称号を渡し、回数を1足す。押した人の端末だけで動く（同期なし）。
    [UdonBehaviourSyncMode(BehaviourSyncMode.None)]
    public class ExampleGrant : UdonSharpBehaviour
    {
        public TitleManager titles;
        public string grantKey = "qs_game";
        public string countKey = "qs_games";

        private void Start() { InteractionText = "ミニゲームをクリアした（ことにする）"; }

        public override void Interact()
        {
            if (titles == null) return;
            titles._GrantKey(grantKey);
            titles._AddCount(countKey, 1);
        }
    }
}
